const CACHE_NAME = "version-1";
const urlsToCache = [
    '/index.html',
    '/offline.html',
    '/BCPLogo-192.png',
    '/BCPLogo-512.png',
    '/BCPLogo-144.png'
];


const self = this;

// Install the service worker
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
        .then((cache) => {
            return cache.addAll(urlsToCache);
        })
        .catch((error) => {
        })
    );
});


// Fetch the data from cache or network
self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request)
        .then(() => {
            return fetch(event.request)
            .catch(() => caches.match('offline.html'));
        })
    );
});

// Activate the service worker
self.addEventListener('activate', (event) => {
    const cacheWhitelist = [];
    cacheWhitelist.push(CACHE_NAME);

    event.waitUntil(
        caches.keys().then((cacheNames) => Promise.all(
            cacheNames.map((cacheName) => {
                if (!cacheWhitelist.includes(cacheName)) {
                    return caches.delete(cacheName);
                }
            })
        ))
    );
});

// Handle push notifications
self.addEventListener('push', (event) => {
    let data = {};

    if (event.data) {
        data = event.data.json(); 
    }

    const options = {
        body: data.body || 'Default notification body',
        icon: '/BCPLogo-144.png',
    };

    event.waitUntil(
        self.registration.showNotification(data.title || 'Notification', options)
    );
});
