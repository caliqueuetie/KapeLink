import axios from 'axios';

// Set default configuration for Axios
axios.defaults.baseURL = 'http://localhost:9000/api/kape-link'; // Base URL for all requests
axios.defaults.withCredentials = true; // Include credentials with requests

export default axios;
