/**
 * Navigation bar component for the Admin panel.
 * Displays navigation options based on the admin role and highlights the active route.
 * Fetches and displays the user's name on component mount.
 *
 * @module AdminNavBar
 */
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import NavBar, { NavbarItem } from "../Global/NavBar";
import axios from "/axios.config"; // Import configured axios with credentials

const AdminNavBar = () => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const [user, setUser] = useState({ firstName: "Loading", lastName: "..." });

  /**
   * Updates the active navigation item based on the selected path.
   *
   * @function handleSetActive
   * @param {string} path - The path to set as active in the navigation.
   * @returns {void}
   */
  const handleSetActive = (path) => setActiveItem(path);

  /**
   * Fetches user data from the backend to display the user's name in the NavBar.
   * Runs once on component mount. If the fetch fails, sets a fallback user as "Guest."
   *
   * @async
   * @function fetchUser
   * @returns {Promise<void>}
   */
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/auth",
          { withCredentials: true }
        );
        if (response.data) {
          setUser(response.data); // Update with fetched user data
        } else {
          console.error("Error fetching user data: Auth error");
          setUser({ firstName: "Guest", lastName: "" }); // Fallback user info
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
        setUser({ firstName: "Guest", lastName: "" }); // Fallback user info
      }
    };

    fetchUser();
  }, []);

  return (
    <NavBar user={user} role="Admin">
      <Link
        to="/manage-products"
        onClick={() => handleSetActive("/manage-products")}
      >
        <NavbarItem
          text="Manage Products"
          active={activeItem === "/manage-products"}
        />
      </Link>

      <Link
        to="/manage-product-category"
        onClick={() => handleSetActive("/manage-product-category")}
      >
        <NavbarItem
          text="Manage Product Category"
          active={activeItem === "/manage-product-category"}
        />
      </Link>

      <Link to="/manage-users" onClick={() => handleSetActive("/manage-users")}>
        <NavbarItem
          text="Manage Users"
          active={activeItem === "/manage-users"}
        />
      </Link>

      <Link
        to="/manage-payment-options"
        onClick={() => handleSetActive("/manage-payment-options")}
      >
        <NavbarItem
          text="Manage Payment Options"
          active={activeItem === "/manage-payment-options"}
        />
      </Link>

      <Link
        to="/manage-locations"
        onClick={() => handleSetActive("/manage-locations")}
      >
        <NavbarItem
          text="Manage Locations"
          active={activeItem === "/manage-locations"}
        />
      </Link>

      <Link
        to="/manage-configurations"
        onClick={() => handleSetActive("/manage-configurations")}
      >
        <NavbarItem
          text="Manage Configurations"
          active={activeItem === "/manage-configurations"}
        />
      </Link>
    </NavBar>
  );
};

export default AdminNavBar;
