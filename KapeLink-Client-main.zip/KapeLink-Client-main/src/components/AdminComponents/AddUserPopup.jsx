import React, { useState } from "react";
import axios from "axios";
import { X, Loader, Eye, EyeOff } from "lucide-react";
import bcrypt from "bcryptjs";

const AddUserPopup = ({ setShowNotification, setNotificationMessage }) => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    userId: "",
    firstName: "",
    lastName: "",
    contactNumber: "+639",
    password: "",
    role: "barista",
    status: "active",
  });

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;

    if (id === "firstName" || id === "lastName") {
      // Remove any symbols or numbers, allow only letters and spaces
      let filteredValue = value.replace(/[^a-zA-Z\s]/g, "");

      // Reduce multiple spaces to a single space
      filteredValue = filteredValue.replace(/\s+/g, " ");

      setFormData({ ...formData, [id]: filteredValue });
    } else if (id === "contactNumber") {
      // Ensure contact number starts with +639 and restrict remaining characters to 9 digits
      const prefix = "+639";
      if (value.startsWith(prefix)) {
        const remainingNumbers = value.slice(prefix.length);
        if (/^\d*$/.test(remainingNumbers) && remainingNumbers.length <= 9) {
          setFormData({ ...formData, contactNumber: value });
        }
      } else if (value === "" || value === "+") {
        // Allow clearing the field and maintain the prefix
        setFormData({ ...formData, contactNumber: prefix });
      }
    } else {
      setFormData({ ...formData, [id]: value });
    }
  };

  const handleRoleChange = (role) => {
    setFormData({ ...formData, role });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setError(""); // Reset error

    // Validation
    const { firstName, lastName, contactNumber, password, role } = formData;
    const contactRegex = /^\+639\d{9}$/;

    // Trim firstName and lastName here
    const trimmedFirstName = firstName.trim();
    const trimmedLastName = lastName.trim();

    if (!firstName || !lastName || !contactNumber || !password) {
      setError("All fields are required.");
      return;
    }

    if (!contactRegex.test(contactNumber)) {
      setError(
        "Invalid contact number. It must start with +639 and be followed by 9 digits."
      );
      return;
    }

    setIsLoading(true); // Start loading

    try {
      // Hash the password before submission
      const saltRounds = 12; // Adjust the salt rounds as needed
      const hashedPassword = await bcrypt.hash(formData.password, saltRounds);

      // Fetch the latest user ID from the database
      const userResponse = await axios.get("/get-latest");
      const users = userResponse.data;

      // Get the highest userId and increment it
      const latestUserId = users.reduce((maxId, user) => {
        const currentUserId = parseInt(user.userId, 10);
        return currentUserId > maxId ? currentUserId : maxId;
      }, 0);

      const newUserId = latestUserId + 1;

      // Send POST request to create user
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/create-user",
        {
          userId: newUserId,
          firstName: trimmedFirstName,
          lastName: trimmedLastName,
          contactNumber,
          password: hashedPassword,
          role,
          status: "active",
          pushSubscription: null,
        }
      );

      if (response.status === 200) {
        handleClosePopup();
        setNotificationMessage("User added successfully.");
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 3000);
        setFormData({
          firstName: "",
          lastName: "",
          contactNumber: "+639",
          password: "",
          role: "barista",
        });
      }
    } catch (error) {
      setError("Failed to add user. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenPopup = () => {
    setIsPopupOpen(true);
  };

  const handleClosePopup = () => {
    setIsPopupOpen(false);
  };

  return (
    <div className="flex justify-center mt-5 xl:mt-10">
      <button
        className="custom-button-color text-white font-medium py-2 px-7 border border-transparent rounded-lg sm:rounded-xl max-[640px]:py-1 max-[640px]:px-5 max-[640px]:text-sm"
        onClick={handleOpenPopup}
      >
        Add a User
      </button>

      {isPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
            <X
              size={30}
              className="cursor-pointer flex ml-auto mb-3"
              onClick={handleClosePopup}
            />

            <div className="text-center mb-5">
              <h2 className="font-semibold text-2xl max-[640px]:text-xl">
                Add a User
              </h2>
            </div>

            <form onSubmit={handleFormSubmit}>
              {/* Role Selection */}
              <div className="mb-4">
                <p className="block text-gray-700 mb-1 max-[640px]:text-sm">
                  Role
                </p>
                <div className="flex space-x-2">
                  <label
                    className={`px-6 py-1 border border-black rounded-full max-[640px]:text-sm max-[640px]:px-8 cursor-pointer ${
                      formData.role === "barista"
                        ? "custom-button-color text-white"
                        : "text-gray-700"
                    }`}
                  >
                    <input
                      type="radio"
                      value="barista"
                      checked={formData.role === "barista"}
                      onChange={() => handleRoleChange("barista")}
                      className="hidden"
                    />
                    Barista
                  </label>
                  <label
                    className={`px-6 py-1 border border-black rounded-full max-[640px]:text-sm cursor-pointer ${
                      formData.role === "manager"
                        ? "custom-button-color text-white"
                        : "text-gray-700"
                    }`}
                  >
                    <input
                      type="radio"
                      value="manager"
                      checked={formData.role === "manager"}
                      onChange={() => handleRoleChange("manager")}
                      className="hidden"
                    />
                    Manager
                  </label>
                </div>
              </div>

              {/* Name fields */}
              <div className="flex mb-4 space-x-4 max-[640px]:flex-col max-[640px]:space-x-0">
                <div className="w-1/2 max-[640px]:w-full max-[640px]:mb-4">
                  <label
                    className="block text-gray-700 max-[640px]:text-sm"
                    htmlFor="firstName"
                  >
                    First Name
                  </label>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
                    required
                  />
                </div>
                <div className="w-1/2 max-[640px]:w-full">
                  <label
                    className="block text-gray-700 max-[640px]:text-sm"
                    htmlFor="lastName"
                  >
                    Last Name
                  </label>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
                    required
                  />
                </div>
              </div>

              {/* Contact Number */}
              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-sm"
                  htmlFor="contactNumber"
                >
                  Contact Number
                </label>
                <input
                  id="contactNumber"
                  name="contactNumber"
                  type="text"
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
                  required
                />
              </div>

              {/* Password */}
              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-sm"
                  htmlFor="password"
                >
                  Password
                </label>
                <div className="relative flex w-full">
                  <input
                    type={showPassword ? "text" : "password"}
                    id="password"
                    name="password"
                    className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                    placeholder="Enter user password"
                    onChange={handleInputChange}
                    required
                  />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute right-3 top-2"
                  >
                    {showPassword ? <Eye /> : <EyeOff />}
                  </button>
                </div>
              </div>

              {error && (
                <p className="text-red-500 text-center mb-4">{error}</p>
              )}

              {/* Submit button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                    ${
                      isLoading
                        ? "bg-gray-400 cursor-not-allowed"
                        : "custom-button-color text-white "
                    }`}
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <Loader className="animate-spin" size={20} />
                  ) : (
                    "Add User"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddUserPopup;
