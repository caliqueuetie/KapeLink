import React, { useState, useEffect } from "react";
import { X, Loader } from "lucide-react"; // Import a loading icon
import axios from "/axios.config"; // Import configured axios with credentials

const AddPdfPopup = ({ setAddPdfPopupOpen, refreshKnowledgeBase, pdfKeys }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isDuplicate, setIsDuplicate] = useState(false);
  const [loading, setLoading] = useState(false); // State for loading
  const [credentials, setCredentials] = useState(null); // State for credentials
  const [errorMessage, setErrorMessage] = useState(""); // State for error messages
  const [fileTooLarge, setFileTooLarge] = useState(false); // State for file size warning

  // Fetch chatbot credentials from the server on component mount
  useEffect(() => {
    const fetchCredentials = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/credentials"
        );
        setCredentials(response.data.credentials); // Adjusted based on the data structure from the controller
      } catch (error) {
        setErrorMessage("Failed to load credentials");
        console.error("Error fetching credentials:", error);
      }
    };

    fetchCredentials();
  }, []);

  const handleAddPdfClosePopup = () => {
    setAddPdfPopupOpen(false);
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);

    // Check for duplicate files in the knowledge base
    if (file && credentials) {
      const fileKey = `${credentials.kbId}/${file.name}`;
      setIsDuplicate(pdfKeys.includes(fileKey));
    }

    // Check for file size
    if (file && file.size > 10 * 1024 * 1024) {
      // Check if file size exceeds 10MB
      setFileTooLarge(true);
      setSelectedFile(null); // Reset selected file if it's too large
    } else {
      setFileTooLarge(false); // Reset file size warning
    }
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();

    if (
      !selectedFile ||
      isDuplicate ||
      loading ||
      !credentials ||
      fileTooLarge
    ) {
      return;
    }

    setLoading(true); // Set loading state to true

    try {
      const arrayBuffer = await selectedFile.arrayBuffer();
      const buffer = new Uint8Array(arrayBuffer);

      // Step 1: Create the file entry on the server
      const createFileResponse = await axios.put(
        credentials.fetchLink,
        {
          key: `${credentials.kbId}/${selectedFile.name}`,
          size: buffer.byteLength,
          index: true,
          tags: {
            source: credentials.source,
            kbId: credentials.kbId,
            title: selectedFile.name,
          },
        },
        {
          withCredentials: true,
          headers: {
            accept: "application/json",
            "x-bot-id": credentials.botId,
            "x-workspace-id": credentials.workspaceId,
            "content-type": "application/json",
            Authorization: `Bearer ${credentials.token}`,
          },
        }
      );

      const createFileResult = createFileResponse.data;

      if (createFileResponse.status !== 200) {
        throw new Error(
          "Failed to create file entry: " + createFileResult.message
        );
      }

      // Step 2: Upload the actual file content to the server
      const uploadUrl = encodeURIComponent(createFileResult.file.uploadUrl);
      await axios.put(
        `http://localhost:9000/api/kape-link/upload-pdf/${uploadUrl}`,
        buffer,
        {
          withCredentials: true,
          headers: {
            "Content-Type": "application/octet-stream",
          },
        }
      );

      // Close the popup and refresh the knowledge base
      setAddPdfPopupOpen(false);
      refreshKnowledgeBase();
    } catch (error) {
      setErrorMessage("Error uploading file");
      console.error("Error uploading file:", error);
    } finally {
      setLoading(false); // Set loading state to false after upload is done
    }
  };

  if (!credentials) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
        <Loader className="animate-spin" size={40} />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        {/* Header section with title and close button */}
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Add New PDF
          </h2>
          <X
            size={30}
            className="cursor-pointer"
            onClick={handleAddPdfClosePopup}
          />
        </div>
        <p>The file must be less than 10MB.</p>

        {errorMessage && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md mb-4 max-[640px]:text-sm max-[640px]:mt-3">
            <p>{errorMessage}</p>
          </div>
        )}

        {fileTooLarge && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md mb-4 max-[640px]:text-sm max-[640px]:mt-3">
            <p>Your file is above 10MB. Please choose a different file.</p>
          </div>
        )}

        {isDuplicate && (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md mb-4 max-[640px]:text-sm max-[640px]:mt-3">
            <p className="text-justify">
              A file with this name already exists in the knowledge base. You
              may delete it first before uploading this one.
            </p>
          </div>
        )}

        <form onSubmit={handleFormSubmit}>
          <div className="mb-4">
            <input
              type="file"
              id="fileInput"
              onChange={handleFileChange}
              accept=".pdf"
              className="max-[640px]:text-sm mt-3 whitespace-break-spaces"
            />
          </div>

          <div className="flex justify-end mt-4">
            <button
              type="submit"
              disabled={!selectedFile || isDuplicate || loading || fileTooLarge}
              className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
              ${
                !selectedFile || isDuplicate || loading || fileTooLarge
                  ? "bg-gray-400 cursor-not-allowed"
                  : "custom-button-color text-white"
              }`}
            >
              {loading ? (
                <Loader className="animate-spin" size={20} />
              ) : (
                "Upload"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPdfPopup;
