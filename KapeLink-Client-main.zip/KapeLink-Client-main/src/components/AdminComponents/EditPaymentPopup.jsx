/**
 * Popup component to edit payment method details.
 * Allows users to update the name, details, visibility status, and QR code image for a payment method.
 * Provides form validation and duplicate checking, with notifications on successful update or error.
 *
 * @module EditPaymentPopup
 * @param {Object} props - Component properties.
 * @param {Function} props.setEditPaymentPopupOpen - Function to control popup visibility.
 * @param {Object} props.data - Current data for the payment method being edited.
 * @param {Function} props.onPaymentUpdated - Callback to refresh the list of payment methods after updates.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 */
import React, { useState, useRef } from "react";
import { X } from "lucide-react";
import axios from "axios";

const EditPaymentPopup = ({
  setEditPaymentPopupOpen,
  data,
  onPaymentUpdated,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [paymentMethodName, setPaymentMethodName] = useState(data.name || "");
  const [paymentDetails, setPaymentDetails] = useState(
    data.payment_details || ""
  );
  const [img, setImg] = useState(null);
  const [error, setError] = useState("");
  const [status, setStatus] = useState(data.status || "Active");
  const fileInputRefQR = useRef(null);
  const [fileName, setFileName] = useState("");

  /**
   * Handles QR file input change and sets the selected file for upload.
   * Updates the displayed filename to show which file is selected.
   *
   * @function handleQRFileChange
   * @param {Object} event - File input change event object.
   * @returns {void}
   */
  const handleQRFileChange = (event) => {
    setImg(event.target.files[0]);
    setFileName(event.target.files[0].name);
  };

  /**
   * Closes the edit payment popup.
   *
   * @function handleEditPaymentClosePopup
   * @returns {void}
   */
  const handleEditPaymentClosePopup = () => {
    setEditPaymentPopupOpen(false);
  };

  /**
   * Submits the form to update the payment method details.
   * Checks for duplicates, prepares form data, and sends an update request.
   * Displays success notification upon update or error message if validation or submission fails.
   *
   * @async
   * @function handleFormSubmit
   * @param {Object} e - Form submission event object.
   * @returns {Promise<void>}
   */
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-payment-methods"
      );
      const allPayments = response.data;

      const isDuplicate = allPayments.some(
        (payment) =>
          payment.name &&
          payment.name.toLowerCase() === paymentMethodName.toLowerCase() &&
          payment._id !== data._id
      );

      if (isDuplicate) {
        setError(
          "Payment method name already exists. Please choose a different name."
        );
        return;
      }

      const formData = new FormData();

      formData.append(
        "name",
        paymentMethodName !== data.name ? paymentMethodName : data.name
      );
      formData.append(
        "payment_details",
        paymentDetails !== "" ? paymentDetails : data.payment_details
      );
      formData.append("status", status !== data.status ? status : data.status);

      if (img) {
        formData.append("img", img);
      }

      const updateResponse = await axios.patch(
        `http://localhost:9000/api/kape-link/update-payment-information/${data._id}`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      setNotificationMessage("Payment option details updated successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 5000);
      setError("");
      onPaymentUpdated();
      setEditPaymentPopupOpen(false);
    } catch (error) {
      console.error("Error updating payment:", error);
      setError("Error updating payment. Please try again.");
    }
  };

  return (
    <div className="sm:absolute fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20 h-[900px] 2xl:h-full">
      <div className="w-5/12 2xl:w-3/12 bg-white px-14 py-6 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:px-8 max-[640px]:py-6">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleEditPaymentClosePopup}
        />
        <div className="text-center mb-3">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Edit Payment Method
          </h2>
        </div>

        {/* Payment Method Name */}
        <div className="mb-1 sm:mb-2">
          <label className="block text-gray-700 text-xs sm:text-sm mb-2">
            Payment Method Name
          </label>
          <input
            type="text"
            value={paymentMethodName}
            onChange={(e) => setPaymentMethodName(e.target.value)}
            className="w-full text-xs md:text-base px-3 py-1 sm:py-2 border border-gray-300 rounded-md"
            placeholder="Enter payment method name"
          />
        </div>

        {/* Payment Details */}
        <div className="sm:mb-2">
          <label className="block text-gray-700 text-xs sm:text-sm mb-2">
            Payment Details
          </label>
          <textarea
            type="text"
            value={paymentDetails}
            onChange={(e) => setPaymentDetails(e.target.value)}
            className="w-full text-xs md:text-base text-justify px-2 py-1 border border-gray-300 rounded-md h-20 sm:h-14 2xl:h-28 overflow-y-auto"
            placeholder="Enter payment details"
          />
        </div>

        {/* Show/Hide Status */}
        <div>
          <label className="block text-gray-700 text-xs sm:text-sm mb-1">
            Show/Hide Payment Method
          </label>
          <div>
            <label className="inline-flex items-center">
              <input
                type="radio"
                name="status"
                value="Active"
                checked={status === "Active"}
                onChange={() => setStatus("Active")}
                className="form-radio"
              />
              <span className="ml-2 text-sm sm:text-base">Show </span>
            </label>
            <label className="inline-flex items-center ml-6">
              <input
                type="radio"
                name="status"
                value="Inactive"
                checked={status === "Inactive"}
                onChange={() => setStatus("Inactive")}
                className="form-radio"
              />
              <span className="ml-2 text-sm sm:text-base">Hide </span>
            </label>
          </div>
        </div>

        {/* Display existing Payment QR */}
        <div className="text-center mt-1 mb-1">
          <h3 className="font-semibold text-sm sm:text-lg mb-3">
            Current Payment QR
          </h3>
          <div className="flex items-center justify-center w-full">
            <div className="flex items-center justify-center h-[200px] sm:h-[170px] 2xl:h-[250px] w-44 border-2 border-gray-300 rounded-md">
              {data.img ? ( // Check if data.img is not null
                <img
                  src={`http://localhost:9000/${data.img}`}
                  alt="Payment QR"
                  width="100"
                  className="rounded-lg mt-2"
                />
              ) : (
                <p className="text-gray-500">No Payment QR</p> // Text to show if img is null
              )}
            </div>
          </div>
        </div>

        {/* QR Upload */}
        <div className="flex flex-col items-center">
          <label className="mt-1 2xl:mt-4">
            <input
              type="file"
              ref={fileInputRefQR}
              onChange={handleQRFileChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRefQR.current.click()}
              className="border px-4 py-1 hover:bg-gray-100 duration-300 sm:py-2 rounded-lg text-sm shadow-md"
            >
              Upload New QR
            </button>
          </label>
          {/* Display the file name below the button */}
          {fileName && (
            <span className="mt-2 text-sm text-gray-600 max-w-xs truncate">
              {fileName}
            </span>
          )}
        </div>

        {/* Error message */}
        {error && <div className="text-red-500 text-center mt-4">{error}</div>}
        <div className="flex justify-center space-x-3 mt-7">
          <button
            type="submit"
            onClick={handleFormSubmit}
            className="custom-button-color text-white font-medium py-1 sm:py-2 px-6 rounded-md"
          >
            Update
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditPaymentPopup;
