import React, { useState } from "react";
import { X, Loader } from "lucide-react";
import axios from "axios";

const AddCategoryPopup = ({ setPopupOpen, refreshCategories, type }) => {
  const [categoryName, setCategoryName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleClosePopup = () => {
    setPopupOpen(false);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    // Ensure required fields are filled based on type
    if (!categoryName || (type === "main" && !description)) {
      setError("Please fill out all fields.");
      setLoading(false);
      return;
    }

    try {
      // Fetch existing categories based on type
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/get-category",
        { type }
      );
      const categories = response.data;

      // Check if the category already exists
      const categoryExists = categories.some(
        (category) => category.name.toLowerCase() === categoryName.toLowerCase()
      );

      if (categoryExists) {
        setError(`A category with this name already exists in ${type}.`);
        setLoading(false);
        return;
      }

      // Find the highest ID in the current categories
      const highestId = categories.reduce(
        (maxId, category) => (category.id > maxId ? category.id : maxId),
        0
      );
      const newId = highestId + 1;

      const newCategory = {
        type,
        id: newId,
        name: categoryName,
        ...(type === "main" && { description }), // Add description only for 'main' type
        show: true,
      };

      // POST request to the backend
      await axios.post(
        "http://localhost:9000/api/kape-link/create-category",
        newCategory
      );

      // Refresh categories and close popup
      refreshCategories();
      setPopupOpen(false);
    } catch (error) {
      console.error(`Error adding ${type} category:`, error);
      setError(
        `There was an issue adding the ${type} category. Please try again.`
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-lg">
            {type === "main"
              ? "Add Main Category"
              : type === "sales"
              ? "Add Sales Category"
              : "Add Menu Category"}
          </h2>
        </div>

        <form onSubmit={handleFormSubmit}>
          {error && <p className="text-red-500 mb-4">{error}</p>}

          <div className="mb-2 sm:mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="categoryName"
            >
              {type === "main"
                ? "Main Category Name"
                : type === "sales"
                ? "Sales Category Name"
                : "Menu Category Name"}
            </label>
            <input
              id="categoryName"
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 max-[640px]:w-full"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
            />
          </div>

          {type === "main" && (
            <div className="mb-4">
              <label
                className="block text-gray-700 max-[640px]:text-xs mb-1"
                htmlFor="description"
              >
                Description
              </label>
              <input
                id="description"
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          )}

          <div className="flex justify-end mt-4">
            <button
              type="submit"
              disabled={loading}
              className={`font-medium py-2 px-8 rounded-md max-[640px]:text-xs 
              ${
                loading
                  ? "bg-gray-400 cursor-not-allowed"
                  : "custom-button-color text-white"
              }`}
            >
              {loading ? (
                <Loader className="animate-spin" size={20} />
              ) : (
                `Add ${
                  type === "main" ? "Main" : type === "sales" ? "Sales" : "Menu"
                } Category`
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCategoryPopup;
