/**
 * Popup component to delete a product.
 * Provides a confirmation step to prevent accidental deletion and displays product details
 * for review before deletion. Shows success or failure notifications based on the result.
 *
 * @module DeleteProductPopup
 * @param {Object} props - Component properties.
 * @param {Object} props.menuRef - Reference for the popup's parent menu element.
 * @param {Function} props.setIsDeletePopupOpen - Function to control popup visibility.
 * @param {Object} props.product - Product object containing details of the item to delete.
 * @param {Function} props.onSaveSuccess - Callback to refresh the product list after a successful deletion.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 */
import React from "react";
import { X, Loader } from "lucide-react";
import { useState, useEffect } from "react";
import axios from "axios";

const DeleteProductPopup = ({
  menuRef,
  setIsDeletePopupOpen,
  product,
  onSaveSuccess,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState(null);

  /**
   * Deletes the selected product by sending a delete request to the server.
   * Displays a success notification if successful, or an error notification if it fails.
   *
   * @async
   * @function handleDelete
   * @returns {Promise<void>}
   */
  const handleDelete = async () => {
    setLoading(true);
    try {
      await axios.delete(
        `http://localhost:9000/api/kape-link/delete-product/${product.prodId}`
      );
      setNotificationMessage("Product deleted successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
      onSaveSuccess();
      handleClosePopup();
    } catch (error) {
      console.error("Error deleting product:", error);
      setNotificationMessage("Failed to delete the product. Please try again.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
      setLoading(false);
    }
  };

  /**
   * Closes the delete popup.
   *
   * @function handleClosePopup
   * @returns {void}
   */
  const handleClosePopup = () => {
    setIsDeletePopupOpen(false);
  };

  /**
   * Toggles the delete confirmation state and clears any existing error.
   * When active, presents an additional step for the user to confirm deletion.
   *
   * @function toggleDeleteConfirmation
   * @returns {void}
   */
  const toggleDeleteConfirmation = () => {
    setConfirmDelete(!confirmDelete);
    setError(null); // Clear any existing error when toggling
  };

  return (
    <div
      ref={menuRef}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20"
    >
      <div className="bg-white p-14 w-[500px] rounded-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Delete Product
          </h2>
        </div>

        {/* Display product details */}
        <div className="mb-4">
          <p>
            <span className="font-semibold">Name:</span> {product.name}
          </p>
          <p>
            <span className="font-semibold">Main Category:</span>{" "}
            {product.category}
          </p>
          <p>
            <span className="font-semibold">Menu Category:</span>{" "}
            {product.menuCategory}
          </p>
          <p>
            <span className="font-semibold">Sales Category:</span>{" "}
            {product.salesReport}
          </p>
          <p>
            <span className="font-semibold">Base Price:</span> P
            {product.basePrice}
          </p>
          <p>
            <span className="font-semibold">Markup:</span> {product.markupRate}%
          </p>
        </div>

        <div className="block justify-end">
          {confirmDelete ? (
            <>
              {error && <p className="text-red-500 mb-4">{error}</p>}
              <p className="text-red-500 mb-4">
                Are you sure you want to delete this product?
              </p>

              <div className="flex justify-center space-x-4 mt-4">
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleDelete}
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                ${
                  loading
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-gray-900 hover:bg-gray-700 duration-300 text-white "
                }`}
                >
                  {loading ? (
                    <Loader className="animate-spin" size={20} />
                  ) : (
                    "Delete"
                  )}
                </button>
                <button
                  type="button"
                  onClick={toggleDeleteConfirmation}
                  className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-200 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                >
                  Cancel
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center mt-4">
              <button
                type="button"
                onClick={toggleDeleteConfirmation}
                className="font-medium py-2 px-8 bg-gray-900 hover:bg-gray-700 duration-300 text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Delete
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DeleteProductPopup;
