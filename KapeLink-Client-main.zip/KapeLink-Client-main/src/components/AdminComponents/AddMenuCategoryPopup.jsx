import React, { useState } from "react";
import { X, Loader } from "lucide-react";
import axios from "axios";

const AddMenuCategoryPopup = ({
  setAddMenuCategoryPopupOpen,
  refreshCategories,
}) => {
  const [categoryName, setCategoryName] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleAddMenuCategoryClosePopup = () => {
    setAddMenuCategoryPopupOpen(false);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    if (!categoryName) {
      setError("Please enter a category name.");
      return;
    }

    setLoading(true); // Set loading to true

    try {
      // Fetch existing categories
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/get-category",
        { type: "menu" }
      );
      const categories = response.data;

      // Check if the category already exists
      const categoryExists = categories.some(
        (category) => category.name.toLowerCase() === categoryName.toLowerCase()
      );

      if (categoryExists) {
        setError("A category with this name already exists.");
        setLoading(false); // Reset loading state
        return;
      }

      // Find the highest ID in the current categories
      const highestId = categories.reduce(
        (maxId, category) => (category.id > maxId ? category.id : maxId),
        0
      );
      const newId = highestId + 1;

      const newCategory = {
        type: "menu",
        id: newId,
        name: categoryName,
        show: true,
      };

      // POST request to the backend
      await axios.post(
        "http://localhost:9000/api/kape-link/create-category",
        newCategory
      );

      // Refresh categories and close popup
      refreshCategories();
      setAddMenuCategoryPopupOpen(false);
    } catch (error) {
      console.error("Error adding category:", error);
      setError("There was an issue adding the category. Please try again.");
    } finally {
      setLoading(false); // Reset loading state
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleAddMenuCategoryClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Add Menu Category
          </h2>
        </div>

        <form onSubmit={handleFormSubmit}>
          {error && <p className="text-red-500 mb-4">{error}</p>}

          <div className="mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-xs"
              htmlFor="categoryName"
            >
              Menu Category Name
            </label>
            <input
              id="categoryName"
              type="text"
              className="w-80 px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 max-[640px]:w-full"
              value={categoryName}
              onChange={(e) => setCategoryName(e.target.value)}
            />
          </div>

          <div className="flex justify-end mt-4">
            <button
              type="submit"
              disabled={loading}
              className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
              ${
                loading
                  ? "bg-gray-400 cursor-not-allowed"
                  : "custom-button-color text-white"
              }`}
            >
              {loading ? (
                <Loader className="animate-spin" size={20} />
              ) : (
                "Add Menu Category"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddMenuCategoryPopup;
