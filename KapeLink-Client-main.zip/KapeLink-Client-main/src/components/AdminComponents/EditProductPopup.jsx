/**
 * Popup component to edit product details.
 * Allows users to update the product name, category, menu and sales categories, base price, and markup rate.
 * Provides validation to prevent duplicate names and missing required fields.
 * Shows success or error notifications based on the result.
 *
 * @module EditProductPopup
 * @param {Object} props - Component properties.
 * @param {Object} props.menuRef - Reference for the popup's parent menu element.
 * @param {Function} props.setIsEditPopupOpen - Function to control popup visibility.
 * @param {Object} props.product - Product object containing details of the item to edit.
 * @param {Function} props.onSaveSuccess - Callback to refresh the product list after a successful edit.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 */
import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import axios from "axios";

const EditProductPopup = ({
  menuRef,
  setIsEditPopupOpen,
  product,
  onSaveSuccess,
  setNotificationMessage,
  setShowNotification,
}) => {
  const [formData, setFormData] = useState({ ...product });

  const [mainCategories, setMainCategories] = useState([]);
  const [menuCategories, setMenuCategories] = useState([]);
  const [salesCategories, setSalesCategories] = useState([]);

  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedMenuCategory, setSelectedMenuCategory] = useState("");
  const [selectedSalesCategory, setSelectedSalesCategory] = useState("");

  const [productName, setProductName] = useState(product?.name || "");
  const [basePrice, setBasePrice] = useState(product?.basePrice || "");
  const [markup, setMarkup] = useState(product?.markupRate || "");
  const [error, setError] = useState(null);

  const [originalProductName] = useState(product?.name || "");
  const isBeverage = product?.category === "Beverages";
  useEffect(() => {
    setFormData({ ...product });
    if (product) {
      setSelectedCategory(product.category || "");
      setSelectedMenuCategory(product.menuCategory || "");
      setSelectedSalesCategory(product.salesReport || "");
    }
  }, [product]);

  /**
   * Fetches all available categories and updates the main, menu, and sales categories.
   * Executes once on component mount.
   *
   * @useEffect
   */
  useEffect(() => {
    axios
      .get("http://localhost:9000/api/kape-link/get-categories")
      .then((response) => {
        const fetchedCategories = response.data;

        // Set categories based on the backend response structure
        setMainCategories(
          fetchedCategories.mainCategories.map((cat) => cat.name)
        );
        setMenuCategories(
          fetchedCategories.menuCategories.map((cat) => cat.name)
        );
        setSalesCategories(
          fetchedCategories.salesCategories.map((cat) => cat.name)
        );
      })
      .catch((error) => {
        console.error("Error fetching categories:", error);
      });
  }, []);

  /**
   * Updates selected main category and resets menu and sales categories.
   *
   * @function handleCategoryChange
   * @param {Object} e - Event object containing selected category value.
   * @returns {void}
   */
  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
    setSelectedMenuCategory(""); // Reset menu category when category changes
    setSelectedSalesCategory(""); // Reset sales category when category changes
  };

  /**
   * Saves the updated product data after validation checks.
   * Checks for required fields and duplicate product names before sending an update request.
   * Displays a success notification upon save, or an error message if validation fails.
   *
   * @async
   * @function handleSave
   * @param {Object} e - Form submission event object.
   * @returns {Promise<void>}
   */
  const handleSave = async (e) => {
    e.preventDefault();

    setError("");

    // Validate to ensure no fields are left blank
    if (
      !productName.trim() ||
      !selectedCategory.trim() ||
      !selectedMenuCategory.trim() ||
      !selectedSalesCategory.trim() ||
      !basePrice.toString().trim() ||
      !markup.toString().trim()
    ) {
      setError("Please fill in all the fields.");
      return;
    }

    // Skip duplicate name check if the name hasn't changed
    if (
      productName.trim().toLowerCase() !== originalProductName.toLowerCase()
    ) {
      try {
        const allProductsResponse = await axios.get(
          "http://localhost:9000/api/kape-link/all-products"
        );
        const allProducts = allProductsResponse.data;

        // Check if the product name already exists (ignoring case sensitivity)
        const productNameExists = allProducts.some(
          (product) =>
            product.name.toLowerCase() === productName.trim().toLowerCase()
        );

        if (productNameExists) {
          setError(
            "Product name already exists. Please choose a different name."
          );
          return;
        }
      } catch (error) {
        console.error("Error fetching products:", error);
        setError("Error checking product name. Please try again later.");
        return;
      }
    }

    const updatedProductData = {
      name: productName.trim(),
      category: selectedCategory.trim(),
      menuCategory: selectedMenuCategory.trim(),
      salesReport: selectedSalesCategory.trim(),
      basePrice: parseFloat(basePrice.toString().trim()),
      markupRate: parseFloat(markup.toString().trim()),
    };

    try {
      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-product/${product.prodId}`,
        updatedProductData
      );
      setNotificationMessage("Product details edited successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
      onSaveSuccess();
      handleEditClosePopup();
    } catch (error) {
      console.error("Error updating product:", error);
      // Check if the error is a 400 Bad Request (e.g., duplicate product name)
      if (error.response && error.response.status === 400) {
        setError(error.response.data.error); // Display the backend error message
      } else {
        // Handle other types of errors
        setError("Failed to update product. Please try again later.");
      }
    }
  };

  /**
   * Updates selected menu category.
   *
   * @function handleMenuCategoryChange
   * @param {Object} e - Event object containing selected menu category value.
   * @returns {void}
   */
  const handleMenuCategoryChange = (e) => {
    setSelectedMenuCategory(e.target.value);
  };

  /**
   * Updates selected sales category.
   *
   * @function handleSalesCategoryChange
   * @param {Object} e - Event object containing selected sales category value.
   * @returns {void}
   */
  const handleSalesCategoryChange = (e) => {
    setSelectedSalesCategory(e.target.value);
  };

  /**
   * Closes the edit product popup.
   *
   * @function handleEditClosePopup
   * @returns {void}
   */
  const handleEditClosePopup = () => {
    setIsEditPopupOpen(false);
  };

  return (
    <div
      ref={menuRef}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20"
    >
      <div className="w-3/6 xl:w-2/6 bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleEditClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Edit Item
          </h2>
        </div>
        {error && <div className="text-red-500 mb-4">{error}</div>}
        <form>
          <div className="mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="mainCategory"
            >
              Main Category
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs mb-1"
              id="category"
              onChange={handleCategoryChange}
              value={selectedCategory}
              disabled={isBeverage}
            >
              <option value="">Select a category</option>
              {mainCategories
                .filter((category) => isBeverage || category !== "Beverages") // Exclude "Beverages" if not the current category
                .map((category, index) => (
                  <option key={index} value={category}>
                    {category}
                  </option>
                ))}
            </select>
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="menuCategory"
            >
              Menu Category
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs mb-1"
              id="menuCategory"
              onChange={handleMenuCategoryChange}
              value={selectedMenuCategory}
            >
              <option value="">Select a Menu Category</option>
              {menuCategories.map((menuCat, index) => (
                <option key={index} value={menuCat}>
                  {menuCat}
                </option>
              ))}
            </select>
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="salesCategory"
            >
              Sales Category
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs mb-1"
              id="salesCategory"
              onChange={handleSalesCategoryChange}
              value={selectedSalesCategory}
            >
              <option value="">Select a Sales Category</option>
              {salesCategories.map((salesCat, index) => (
                <option key={index} value={salesCat}>
                  {salesCat}
                </option>
              ))}
            </select>

            <label
              className="block text-gray-700 max-[640px]:text-xs"
              htmlFor="productName"
            >
              Product Name
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
              id="productName"
              value={productName || formData.name}
              onChange={(e) => setProductName(e.target.value)}
            />
          </div>

          <div className="flex mb-4 space-x-4">
            <div className="w-1/2">
              <label
                className="block text-gray-700 max-[640px]:text-xs"
                htmlFor="basePrice"
              >
                Base Price
              </label>
              <input
                type="number"
                className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                id="basePrice"
                value={basePrice}
                onChange={(e) => setBasePrice(e.target.value)}
              />
            </div>
            <div className="w-1/2">
              <label
                className="block text-gray-700 max-[640px]:text-xs"
                htmlFor="markup"
              >
                Markup (%)
              </label>
              <input
                type="number"
                className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                id="markup"
                value={markup}
                onChange={(e) => setMarkup(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              type="submit"
              className="custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditProductPopup;
