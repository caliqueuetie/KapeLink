/**
 * Popup component to add a new item to the product list.
 * Allows users to select categories, set pricing, and markups based on product type.
 * Handles form validation, duplicate checking, and displays a notification upon successful addition.
 *
 * @module AdminAddItemPopupButton
 * @param {Object} props - Component properties.
 * @param {Function} props.onSaveSuccess - Callback to refresh the product list after a successful addition.
 * @param {Function} props.setShowNotification - Function to control notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 */
import React, { useState, useEffect } from "react";
import { X, Loader } from "lucide-react";
import axios from "axios";

const AdminAddItemPopupButton = ({
  onSaveSuccess,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  /**
   * Opens the popup modal for adding a product.
   *
   * @function handleOpenPopup
   * @returns {void}
   */
  const handleOpenPopup = () => {
    setIsPopupOpen(true);
  };

  /**
   * Closes the popup modal and resets any existing errors.
   *
   * @function handleClosePopup
   * @returns {void}
   */
  const handleClosePopup = () => {
    setIsPopupOpen(false);
    setError("");
  };

  const [product, setProduct] = useState(null);
  const [formData, setFormData] = useState({});
  const [mainCategories, setMainCategories] = useState([]);
  const [menuCategories, setMenuCategories] = useState([]);
  const [salesCategories, setSalesCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSalesCategory, setSelectedSalesCategory] = useState("");
  const [selectedMenuCategory, setSelectedMenuCategory] = useState("");

  const [productName, setProductName] = useState("");
  const [basePrice, setBasePrice] = useState("");
  const [markup, setMarkup] = useState("");
  const [productType, setProductType] = useState({ hot: false, cold: false });
  const [basePriceHot, setBasePriceHot] = useState("");
  const [markupHot, setMarkupHot] = useState("");
  const [basePriceCold, setBasePriceCold] = useState("");
  const [markupCold, setMarkupCold] = useState("");

  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setFormData({ ...product });
    if (product) {
      setSelectedCategory(product.category || "");
      setSelectedMenuCategory(product.menuCategory || "");
      setSelectedSalesCategory(product.salesReport || "");
    }
  }, [product]);

  /**
   * Fetches all categories for main, menu, and sales categories from the backend.
   * Sets the fetched categories into their respective state variables.
   *
   * @useEffect
   */
  useEffect(() => {
    axios
      .get("http://localhost:9000/api/kape-link/get-categories")
      .then((response) => {
        const fetchedCategories = response.data;

        // Set categories based on the backend response structure
        setMainCategories(
          fetchedCategories.mainCategories.map((cat) => cat.name)
        );
        setMenuCategories(
          fetchedCategories.menuCategories.map((cat) => cat.name)
        );
        setSalesCategories(
          fetchedCategories.salesCategories.map((cat) => cat.name)
        );
      })
      .catch((error) => {
        console.error("Error fetching categories:", error);
      });
  }, []);

  /**
   * Updates state variables based on form field changes.
   *
   * @function handleChange
   * @param {Object} e - Event object containing form field name and value.
   * @returns {void}
   */
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "productName") setProductName(value);
    else if (name === "basePriceHot") setBasePriceHot(value);
    else if (name === "markupHot") setMarkupHot(value);
    else if (name === "basePriceCold") setBasePriceCold(value);
    else if (name === "markupCold") setMarkupCold(value);
    else if (name === "basePrice") setBasePrice(value);
    else if (name === "markup") setMarkup(value);
  };

  /**
   * Updates selected main category and resets menu and sales categories.
   *
   * @function handleCategoryChange
   * @param {Object} e - Event object containing selected category value.
   * @returns {void}
   */
  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
    setSelectedMenuCategory(""); // Reset menu category when category changes
    setSelectedSalesCategory(""); // Reset sales category when category changes
  };

  /**
   * Updates the selected menu category.
   *
   * @function handleMenuCategoryChange
   * @param {Object} e - Event object containing selected menu category value.
   * @returns {void}
   */
  const handleMenuCategoryChange = (e) => {
    setSelectedMenuCategory(e.target.value);
  };

  /**
   * Updates the selected sales category.
   *
   * @function handleSalesCategoryChange
   * @param {Object} e - Event object containing selected sales category value.
   * @returns {void}
   */
  const handleSalesCategoryChange = (e) => {
    setSelectedSalesCategory(e.target.value);
  };

  /**
   * Handles form submission for adding a new product.
   * Validates required fields, checks for duplicate products, and creates products based on category selection.
   * Displays success notification or error message depending on the result.
   *
   * @async
   * @function handleFormSubmit
   * @param {Object} e - Form submission event object.
   * @returns {Promise<void>}
   */
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    if (
      !productName.trim() ||
      !selectedCategory ||
      !selectedMenuCategory ||
      !selectedSalesCategory
    ) {
      setError("Please fill all required fields.");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    let existingProducts = [];
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link//all-products"
      );
      existingProducts = response.data;
    } catch (error) {
      console.error("Error fetching existing products:", error);
      return;
    }

    const isDuplicate = existingProducts.some(
      (product) => product.name.toLowerCase() === productName.toLowerCase()
    );
    if (isDuplicate) {
      setError("A product with this name already exists.");
      setLoading(false);
      return;
    }

    const productsToSubmit = [];

    if (selectedCategory === "Beverages") {
      if (basePriceHot > 0) {
        if (markupHot <= 0) {
          setError("Please fill the markup for hot products.");
          setLoading(false);
          return;
        }
        productsToSubmit.push({
          name: productName,
          basePrice: basePriceHot,
          markupRate: markupHot,
          category: selectedCategory,
          menuCategory: selectedMenuCategory,
          salesReport: selectedSalesCategory,
          type: "Hot",
        });
      }

      if (basePriceCold > 0) {
        if (markupCold <= 0) {
          setError("Please fill the markup for cold products.");
          setLoading(false);
          return;
        }
        productsToSubmit.push({
          name: productName,
          basePrice: basePriceCold,
          markupRate: markupCold,
          category: selectedCategory,
          menuCategory: selectedMenuCategory,
          salesReport: selectedSalesCategory,
          type: "Cold",
        });
      }
    } else {
      if (!productName.trim() || !basePrice || !markup) {
        setError("Please fill the product name, base price, and markup.");
        setLoading(false);
        return;
      }
      productsToSubmit.push({
        name: productName,
        basePrice: basePrice,
        markupRate: markup,
        category: selectedCategory,
        menuCategory: selectedMenuCategory,
        salesReport: selectedSalesCategory,
        type: null,
      });
    }

    if (productsToSubmit.length === 0) {
      setError("Please fill at least one type of product.");
      setLoading(false);
      return;
    }

    try {
      for (const productData of productsToSubmit) {
        await axios.post(
          "http://localhost:9000/api/kape-link/create-product",
          productData
        );
      }
      onSaveSuccess();
      handleClosePopup();
      setNotificationMessage("Product added successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    } catch (error) {
      console.error(
        "Error creating products:",
        error.response?.data || error.message
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex justify-center mt-5 xl:mt-10">
      <button
        className="custom-button-color text-white font-medium py-2 px-7 border border-transparent rounded-lg sm:rounded-xl max-[640px]:py-1 max-[640px]:px-5 max-[640px]:text-sm"
        onClick={handleOpenPopup}
      >
        Add a Product
      </button>

      {isPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
            <X
              size={30}
              className="cursor-pointer flex ml-auto mb-3"
              onClick={handleClosePopup}
            />

            <div className="text-center mb-5">
              <h2 className="font-semibold text-2xl max-[640px]:text-xl">
                Add an Item
              </h2>
            </div>

            <form>
              {/* Form fields go here */}

              {error && (
                <p className="text-red-500 text-center mb-4">{error}</p>
              )}

              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-xs"
                  htmlFor="category"
                >
                  Category
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs"
                  id="category"
                  onChange={handleCategoryChange}
                  value={selectedCategory}
                >
                  {/* Make this category options dynamic */}
                  <option value="">Select a category </option>
                  {mainCategories.map((category, index) => (
                    <option key={index} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-xs"
                  htmlFor="subcategory"
                >
                  Menu Category
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs"
                  id="subcategory"
                  onChange={handleMenuCategoryChange}
                  value={selectedMenuCategory}
                >
                  {/* Make this category options dynamic */}
                  <option value="">Select a subcategory</option>
                  {menuCategories.map((menuCat, index) => (
                    <option key={index} value={menuCat}>
                      {menuCat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-xs"
                  htmlFor="salesCategory"
                >
                  Sales Category
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-xs"
                  id="salesCategory"
                  onChange={handleSalesCategoryChange}
                  value={selectedSalesCategory}
                >
                  {/* Make this category options dynamic */}
                  <option value="">Select a sales category</option>
                  {salesCategories.map((salesCat, index) => (
                    <option key={index} value={salesCat}>
                      {salesCat}{" "}
                    </option>
                  ))}
                </select>
              </div>

              <div className="mb-4">
                <label
                  className="block text-gray-700 max-[640px]:text-xs"
                  htmlFor="productName"
                >
                  Product Name
                </label>
                <input
                  type="text"
                  name="productName"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0"
                  id="productName"
                  value={productName}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Conditional rendering if "Drinks" is not the selected category */}
              {selectedCategory !== "Beverages" && (
                <div className="flex mb-4 space-x-4">
                  <div className="w-1/2">
                    <label
                      className="block text-gray-700 max-[640px]:text-xs"
                      htmlFor="basePrice"
                    >
                      Base Price
                    </label>
                    <input
                      type="number"
                      name="basePrice"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                      id="basePrice"
                      value={basePrice}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="w-1/2">
                    <label
                      className="block text-gray-700 max-[640px]:text-xs"
                      htmlFor="markup"
                    >
                      Markup (%)
                    </label>
                    <input
                      type="number"
                      name="markup"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                      id="markup"
                      value={markup}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
              )}

              {/* Conditional rendering if "Drinks" category is selected */}
              {selectedCategory === "Beverages" && (
                <>
                  <div className="flex mb-4 space-x-4">
                    <div className="w-1/2">
                      <label
                        className="block text-gray-700 max-[640px]:text-xs"
                        htmlFor="basePriceHot"
                      >
                        Base Price (Hot)
                      </label>
                      <input
                        type="number"
                        name="basePriceHot"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                        id="basePriceHot"
                        value={basePriceHot}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="w-1/2">
                      <label
                        className="block text-gray-700 max-[640px]:text-xs"
                        htmlFor="markupHot"
                      >
                        Markup (%)
                      </label>
                      <input
                        type="number"
                        name="markupHot"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                        id="markupHot"
                        value={markupHot}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="flex mb-4 space-x-4">
                    <div className="w-1/2">
                      <label
                        className="block text-gray-700 max-[640px]:text-xs"
                        htmlFor="basePriceCold"
                      >
                        Base Price (Cold)
                      </label>
                      <input
                        type="number"
                        name="basePriceCold"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                        id="basePriceCold"
                        value={basePriceCold}
                        onChange={handleChange}
                      />
                    </div>
                    <div className="w-1/2">
                      <label
                        className="block text-gray-700 max-[640px]:text-xs"
                        htmlFor="markupCold"
                      >
                        Markup (%)
                      </label>
                      <input
                        type="number"
                        name="markupCold"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:text-xs max-[640px]:py-1"
                        id="markupCold"
                        value={markupCold}
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={loading}
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:text-xs ${
                    loading
                      ? "bg-gray-400 cursor-not-allowed"
                      : "custom-button-color text-white"
                  }`}
                  onClick={handleFormSubmit}
                >
                  {loading ? (
                    <Loader className="animate-spin" size={20} />
                  ) : (
                    "Add Product"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminAddItemPopupButton;
