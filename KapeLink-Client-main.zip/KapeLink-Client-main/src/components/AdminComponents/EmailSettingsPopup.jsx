import React, { useState, useEffect } from "react";
import { X, Loader, Settings } from "lucide-react"; // Import a loading icon
import axios from "/axios.config"; // Import configured axios with credentials

const EmailSettingsPopup = ({
  setShowNotification,
  setNotificationMessage,
}) => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [settings, setSettings] = useState(null); // Initialize settings as null
  const [loading, setLoading] = useState(true); // Set loading state initially to true
  const [errorMessage, setErrorMessage] = useState(""); // State for error messages

  // Fetch bot settings from the server when the component mounts
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/email"
        );

        const fetchedSettings = response.data; // Assuming the settings are in the first item of the array

        setSettings(fetchedSettings); // Set fetched settings
        setLoading(false); // Set loading to false after data is fetched
        setErrorMessage("");
      } catch (error) {
        setErrorMessage("Failed to load settings");
        console.error("Error fetching settings:", error);
        setLoading(false);
      }
    };

    fetchSettings();
  }, []);

  const handleOpenPopup = () => {
    setIsPopupOpen(true);
  };

  const handleClosePopup = () => {
    setIsPopupOpen(false);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    const [section, key] = name.split(".");
    setSettings((prevSettings) => ({
      ...prevSettings,
      [section]: {
        ...prevSettings[section],
        [key]: value,
      },
    }));
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    setLoading(true); // Set loading state to true
    try {
      // Send updated settings to the server
      await axios.put("http://localhost:9000/api/kape-link/email", settings);

      handleClosePopup();
      setNotificationMessage("Settings saved successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    } catch (error) {
      setErrorMessage("Error: " + error.message);
      console.error("Error:", error);
    } finally {
      setLoading(false); // Set loading state to false after the operation is done
    }
  };

  if (loading && settings === null) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
        <Loader className="animate-spin" size={40} />
      </div>
    );
  }

  return (
    <div className="flex justify-center">
      <button
        onClick={handleOpenPopup}
        className="flex items-center whitespace-nowrap text-white custom-button-black py-2 px-4 rounded-xl mr-2 max-[640px]:hidden"
      >
        <Settings className="mr-2" size={18} />
        <span>Email OTP Settings</span>
      </button>

      <button onClick={handleOpenPopup} className="sm:hidden">
        <Settings className="ml-3 text-gray-400" size={23} />
      </button>

      {isPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <div className="bg-white pl-6 pr-6 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-4 w-full max-w-3xl max-h-[90vh] overflow-y-auto">
            {/* Persistent X button and header */}
            <div className="sticky -top-4 bg-white z-30 flex justify-between items-center p-4">
              <h2 className="font-semibold text-2xl max-[640px]:text-xl">
                Email OTP Settings
              </h2>
              <X
                size={30}
                className="cursor-pointer"
                onClick={handleClosePopup}
              />
            </div>

            {/* Warning Message */}
            <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md mb-4">
              <p className="font-medium">⚠️ Warning: Please Review Carefully</p>
              <p>
                Before saving, ensure that all fields are filled out correctly.
                Any incorrect or incomplete data may cause the{" "}
                <strong>Nodemailer API</strong> to malfunction, potentially
                disrupting the functionality of your system.
              </p>
            </div>

            <form onSubmit={handleFormSubmit}>
              {/* Chatbot Fields */}
              <div className="mb-2">
                <h2 className="block text-m font-medium">
                  Nodemailer Credentials
                </h2>
                <h2 className="block text-sm font-medium text-gray-700">
                  This specifies the email to be used to send the OTP
                  verification code for new customer accounts.
                </h2>
              </div>
              <div className="block gap-4">
                <div className="mb-4" key="sender-email">
                  <label className="block text-sm font-medium text-gray-700">
                    Sender Email
                  </label>
                  <input
                    required
                    type="text"
                    name={`nodemailer.senderEmail`}
                    value={settings.nodemailer["senderEmail"]}
                    onChange={handleInputChange}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div className="mb-4" key="pass">
                  <label className="block text-sm font-medium text-gray-700">
                    Password
                  </label>
                  <input
                    required
                    type="text"
                    name={`nodemailer.pass`}
                    value={settings.nodemailer["pass"]}
                    onChange={handleInputChange}
                    className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>

              {/* Persistent Save button */}
              <div className="sticky -bottom-4 bg-white z-30 p-4">
                {/* Error Message */}
                {errorMessage && (
                  <p className="text-white border-l-4 border-red-700 bg-red-500 rounded-lg px-4 py-2 mt-2">
                    {errorMessage}
                  </p>
                )}

                <div className="flex justify-end my-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                ${
                  loading
                    ? "bg-gray-400 cursor-not-allowed"
                    : "custom-button-color text-white"
                }`}
                  >
                    {loading ? (
                      <Loader className="animate-spin" size={20} /> // Loading icon
                    ) : (
                      "Save"
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmailSettingsPopup;
