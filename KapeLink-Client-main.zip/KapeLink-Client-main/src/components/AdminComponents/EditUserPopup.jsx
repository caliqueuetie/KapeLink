import React, { useState } from "react";
import { X, Loader, Eye, EyeOff } from "lucide-react";
import axios from "axios";

const EditUserPopup = ({
  menuRef,
  setIsEditPopupOpen,
  user,
  onSaveSuccess,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [userProfile, setUserProfile] = useState({
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    contactNumber: user.contactNumber || "",
    password: "",
  });

  const [passwordConfirm, setPasswordConfirm] = useState(""); // New state for password confirmation
  const [loading, setLoading] = useState(false);
  const [confirmEdit, setConfirmEdit] = useState(false);
  const [confirmPassword, setConfirmPassword] = useState(false);
  const [error, setError] = useState(null);
  const [showPassword, setShowPassword] = useState(false); // New state for password visibility
  const [showConfirmPassword, setShowConfirmPassword] = useState(false); // New state for password visibility

  // Validation and submit handler
  const handleEdit = async () => {
    const { firstName, lastName, contactNumber, password } = userProfile;

    // Trim firstName and lastName here
    const trimmedFirstName = firstName.trim();
    const trimmedLastName = lastName.trim();

    // Validate fields
    if (
      !firstName ||
      !lastName ||
      !contactNumber ||
      (confirmPassword && (!password || !passwordConfirm))
    ) {
      setError(
        "All fields must be filled, including both password fields if changing password."
      );
      return;
    }

    // Ensure the contact number is exactly 13 digits
    if (contactNumber.length !== 13) {
      setError("Invalid Contact Number length.");
      return;
    }

    // Ensure password is at least 8 characters long if being set
    if (confirmPassword && password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }

    // Check if the passwords match
    if (confirmPassword && password !== passwordConfirm) {
      setError("Passwords do not match.");
      return;
    }

    // Prepare the updated data object
    const updatedData = {
      firstName: trimmedFirstName,
      lastName: trimmedLastName,
      contactNumber,
      ...(confirmPassword && { password }), // Only include password if it's being updated
    };

    try {
      setLoading(true);
      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-user/${user.userId}`,
        updatedData
      );

      if (!response.data.error) {
        setNotificationMessage("User edited successfully.");
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 3000);

        // Notify user on success
        onSaveSuccess(response.data);
        setIsEditPopupOpen(false);
      } else {
        setError(response.data.error || "An unexpected error occurred.");
      }
    } catch (error) {
      console.error("Error updating user profile:", error);
      setError(error.response?.data?.error || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;

    if (name === "firstName" || name === "lastName") {
      // Remove any symbols or numbers, allow only letters and spaces
      let filteredValue = value.replace(/[^a-zA-Z\s]/g, "");

      // Reduce multiple spaces to a single space
      filteredValue = filteredValue.replace(/\s+/g, " ");

      setUserProfile({ ...userProfile, [name]: filteredValue });
    } else if (name === "contactNumber") {
      // Ensure contact number starts with +639 and restrict remaining characters to 9 digits
      const prefix = "+639";
      if (value.startsWith(prefix)) {
        const remainingNumbers = value.slice(prefix.length);
        if (/^\d*$/.test(remainingNumbers) && remainingNumbers.length <= 9) {
          setUserProfile({ ...userProfile, contactNumber: value });
        }
      } else if (value === "" || value === "+") {
        // Allow clearing the field and maintain the prefix
        setUserProfile({ ...userProfile, [name]: prefix });
      }
    } else {
      setUserProfile({ ...userProfile, [name]: value });
    }
  };

  const handleClosePopup = () => {
    setIsEditPopupOpen(false);
  };

  const toggleEditConfirmation = () => {
    setConfirmEdit(!confirmEdit);
    setError(null); // Clear any errors on toggle
  };

  const togglePasswordConfirmation = () => {
    setConfirmPassword(!confirmPassword);
    setUserProfile({ ...userProfile, password: "" }); // Clear password field if toggled off
    setPasswordConfirm(""); // Clear password confirmation field as well
    setError(null); // Clear any errors on toggle
  };

  // Toggle password visibility
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  // Toggle password visibility
  const toggleShowConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <div
      ref={menuRef}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20"
    >
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-5">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Edit User
          </h2>
        </div>

        {/* Display user details */}
        <div className="mb-2 sm:mb-4 text-lg">
          <p>
            <span className="font-medium">Role:</span> {user.role}
          </p>
          <p>
            <span className="font-medium">Email:</span> {user.email || "N/A"}
          </p>
        </div>
        <hr className="mb-2 sm:mb-4" />

        <form
          onSubmit={(e) => {
            e.preventDefault();
            toggleEditConfirmation();
          }}
        >
          <div className="flex mb-2 sm:mb-4 space-x-4 max-[640px]:flex-col max-[640px]:space-x-0">
            <div className="w-1/2 max-[640px]:w-full max-[640px]:mb-2">
              <label
                className="block text-gray-700 max-[640px]:text-sm"
                htmlFor="firstName"
              >
                First Name
              </label>
              <input
                id="firstName"
                name="firstName"
                type="text"
                value={userProfile.firstName}
                className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="w-1/2 max-[640px]:w-full">
              <label
                className="block text-gray-700 max-[640px]:text-sm"
                htmlFor="lastName"
              >
                Last Name
              </label>
              <input
                id="lastName"
                name="lastName"
                type="text"
                value={userProfile.lastName}
                className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
                onChange={handleInputChange}
                required
              />
            </div>
          </div>
          <div className="mb-2 sm:mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-sm"
              htmlFor="contactNumber"
            >
              Contact Number
            </label>
            <input
              id="contactNumber"
              name="contactNumber"
              type="text"
              value={userProfile.contactNumber}
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1"
              onChange={handleInputChange}
              required
            />
          </div>

          <div className="block justify-end">
            <div>
              <div className="mb-2 sm:mb-4">
                {confirmPassword ? (
                  <div className="block justify-center items-center">
                    <label
                      className="block text-gray-700 max-[640px]:text-sm"
                      htmlFor="password"
                    >
                      Password
                    </label>
                    <div className="flex mb-2 sm:mb-4">
                      <div className="relative flex w-full">
                        <input
                          type={showPassword ? "text" : "password"}
                          id="password"
                          name="password"
                          className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                          placeholder="Enter new password"
                          value={userProfile.password}
                          onChange={handleInputChange}
                          required={confirmPassword}
                        />
                        <button
                          type="button"
                          onClick={toggleShowPassword}
                          className="absolute right-3 top-2"
                        >
                          {showPassword ? (
                            <Eye className="w-5" />
                          ) : (
                            <EyeOff className="w-5" />
                          )}
                        </button>
                      </div>
                    </div>
                    <div className="flex mb-2 sm:mb-4">
                      <div className="relative flex w-full">
                        <input
                          type={showConfirmPassword ? "text" : "password"}
                          className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                          placeholder="Confirm new password"
                          value={passwordConfirm}
                          onChange={(e) => setPasswordConfirm(e.target.value)}
                          required={confirmPassword}
                        />
                        <button
                          type="button"
                          onClick={toggleShowConfirmPassword}
                          className="absolute right-3 top-2"
                        >
                          {showConfirmPassword ? (
                            <Eye className="w-5" />
                          ) : (
                            <EyeOff className="w-5" />
                          )}
                        </button>
                      </div>
                    </div>

                    {confirmEdit ? (
                      <>
                        <div className="block justify-center items-center mt-4">
                          {error && (
                            <p className="text-red-500 text-center">{error}</p>
                          )}
                          <p className="text-gray-500 text-center">
                            Save edits to this user?
                          </p>
                        </div>

                        <div className="flex justify-center space-x-4 mt-4">
                          <button
                            type="button"
                            disabled={loading}
                            onClick={handleEdit}
                            className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                                ${
                                  loading
                                    ? "bg-gray-400 cursor-not-allowed"
                                    : "custom-button-color text-white "
                                }`}
                          >
                            {loading ? (
                              <Loader className="animate-spin" size={20} />
                            ) : (
                              "Save"
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={toggleEditConfirmation}
                            className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-400 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                          >
                            Cancel
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="flex items-center justify-center mt-4 w-full space-x-4">
                        <button
                          onClick={toggleEditConfirmation}
                          className="font-medium py-2 px-8 custom-button-color text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={togglePasswordConfirmation}
                          className="font-medium py-2 px-8 bg-red-500 hover:bg-red-400 duration-300 text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    {" "}
                    {confirmEdit ? (
                      <>
                        <div className="block justify-center items-center mt-4">
                          {error && (
                            <p className="text-red-500 text-center">{error}</p>
                          )}
                          <p className="text-gray-500 text-center">
                            Save edits to this user?
                          </p>
                        </div>

                        <div className="flex justify-center space-x-4 mt-4">
                          <button
                            type="button"
                            disabled={loading}
                            onClick={handleEdit}
                            className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
            ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "custom-button-color text-white "
            }`}
                          >
                            {loading ? (
                              <Loader className="animate-spin" size={20} />
                            ) : (
                              "Save"
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={toggleEditConfirmation}
                            className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-400 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                          >
                            Cancel
                          </button>
                        </div>
                      </>
                    ) : (
                      <div className="flex items-center justify-center mt-4 w-full space-x-4">
                        <button
                          onClick={toggleEditConfirmation}
                          className="font-medium py-2 px-8 custom-button-color text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={togglePasswordConfirmation}
                          className="font-medium py-2 px-8 custom-button-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                        >
                          Change Password
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditUserPopup;
