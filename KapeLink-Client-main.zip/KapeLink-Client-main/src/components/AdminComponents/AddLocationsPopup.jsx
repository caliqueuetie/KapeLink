/**
 * Popup component to add a new location.
 * This component includes form validation to check for duplicate locations
 * and error handling for form submission, allowing users to add a unique location
 * to the database.
 *
 * @module AddLocationsPopup
 * @param {Object} props - Component properties.
 * @param {Function} props.setAddLocationsPopupOpen - Function to control popup visibility.
 * @param {Function} props.onLocationUpdated - Callback to update the list of locations after adding a new one.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message.
 */
import { useState } from "react";
import { X } from "lucide-react";
import axios from "axios";

const AddLocationsPopup = ({
  setAddLocationsPopupOpen,
  onLocationUpdated,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [locationName, setLocationName] = useState("");
  const [error, setError] = useState("");

  /**
   * Closes the Add Locations Popup and triggers location update.
   * Calls `onLocationUpdated` to refresh the location list and closes the popup modal.
   *
   * @function handleAddLocationsClosePopup
   * @returns {void}
   */
  const handleAddLocationsClosePopup = () => {
    onLocationUpdated();
    setAddLocationsPopupOpen(false);
  };

  /**
   * Handles the form submission for adding a new location.
   * Validates if the location already exists in the database by making a GET request.
   * If no duplicate is found, it proceeds to create the location with a POST request.
   * Shows a success notification and closes the popup on successful addition, or displays
   * an error message if there is a duplicate or other error.
   *
   * @async
   * @function handleFormSubmit
   * @param {Object} e - The form submission event object.
   * @returns {Promise<void>}
   */
  const handleFormSubmit = async (e) => {
    e.preventDefault();

    const lowerCaseLocationName = locationName.toLowerCase();

    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-location-by-name/${lowerCaseLocationName}`
      );

      if (response.data && Object.keys(response.data).length > 0) {
        setError("The location already exists.");
        return;
      }
    } catch (error) {
      if (error.response) {
        console.error("Error checking for duplicates:", error);
        setError("Error checking for duplicates. Please try again.");
        return;
      }
    }
    try {
      const addResponse = await axios.post(
        "http://localhost:9000/api/kape-link/create-location",
        {
          locationName: locationName,
          status: "Available",
        }
      );

      onLocationUpdated();
      setAddLocationsPopupOpen(false);
      setNotificationMessage("Location added successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    } catch (error) {
      console.error("Error adding location:", error);
      setError("Error adding location. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-5"
          onClick={handleAddLocationsClosePopup}
        />
        <div className="text-center mb-2 md:mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Add Location
          </h2>
        </div>

        {/* Error message display */}
        <form onSubmit={handleFormSubmit}>
          <div className="mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="locationName"
            >
              Location Name
            </label>
            <input
              id="locationName"
              type="text"
              value={locationName}
              onChange={(e) => setLocationName(e.target.value)}
              className="w-96 px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 max-[640px]:w-full"
            />
            {error && (
              <div className="text-red-500 text-center mt-2">{error}</div>
            )}
          </div>

          <div className="flex justify-end mt-4">
            <button
              type="submit"
              className="custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
            >
              Add Location
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddLocationsPopup;
