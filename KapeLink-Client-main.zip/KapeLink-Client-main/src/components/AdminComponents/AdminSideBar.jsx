import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import Sidebar, { SidebarItem } from "../Global/SideBar";
import {
  PackageSearch,
  Users,
  BotMessageSquare,
  Tags,
  WalletCards,
  MapPinned,
} from "lucide-react";
import axios from "/axios.config"; // Import configured axios with credentials

const AdminSideBar = () => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const [user, setUser] = useState(null);

  const handleSetActive = (path) => setActiveItem(path);

  // Fetch user data from the server on component mount
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/auth",
          { withCredentials: true }
        );
        if (response.data) {
          setUser(response.data); // Set user data
        } else {
          console.error("Error fetching user data: Auth error");
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
      }
    };

    fetchUser();
  }, []);

  return (
    <Sidebar
      user={user ? `${user.firstName} ${user.lastName}` : "Loading..."}
      role={"Admin"}
    >
      <Link
        to="/manage-products"
        onClick={() => handleSetActive("/manage-products")}
      >
        <SidebarItem
          icon={<PackageSearch size={20} />}
          text="Manage Products"
          active={activeItem === "/manage-products"}
        />
      </Link>

      <Link
        to="/manage-product-category"
        onClick={() => handleSetActive("/manage-product-category")}
      >
        <SidebarItem
          icon={<Tags size={20} />}
          text="Manage Product Category"
          active={activeItem === "/manage-product-category"}
        />
      </Link>

      <Link to="/manage-users" onClick={() => handleSetActive("/manage-users")}>
        <SidebarItem
          icon={<Users size={20} />}
          text="Manage Users"
          active={activeItem === "/manage-users"}
        />
      </Link>

      <Link
        to="/manage-payment-options"
        onClick={() => handleSetActive("/manage-payment-options")}
      >
        <SidebarItem
          icon={<WalletCards size={20} />}
          text="Manage Payment Options"
          active={activeItem === "/manage-payment-options"}
        />
      </Link>

      <Link
        to="/manage-locations"
        onClick={() => handleSetActive("/manage-locations")}
      >
        <SidebarItem
          icon={<MapPinned size={20} />}
          text="Manage Locations"
          active={activeItem === "/manage-locations"}
        />
      </Link>

      <Link
        to="/manage-configurations"
        onClick={() => handleSetActive("/manage-configurations")}
      >
        <SidebarItem
          icon={<BotMessageSquare size={20} />}
          text="Manage Configurations"
          active={activeItem === "/manage-configurations"}
        />
      </Link>
    </Sidebar>
  );
};

export default AdminSideBar;
