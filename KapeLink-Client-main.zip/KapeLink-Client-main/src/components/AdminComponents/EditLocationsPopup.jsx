/**
 * Popup component to edit a location's details.
 * Allows users to update location name and status, with options to save or remove the location.
 * Displays confirmation before deleting and includes form validation for duplicate checking.
 *
 * @module EditLocationsPopup
 * @param {Object} props - Component properties.
 * @param {Function} props.setEditLocationsPopupOpen - Function to control popup visibility.
 * @param {Object} props.currentLocation - Object containing details of the location to edit.
 * @param {Function} props.onLocationUpdated - Callback to refresh the location list after updates.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 */
import React, { useState, useEffect } from "react";
import { X } from "lucide-react";
import axios from "axios";

const EditLocationsPopup = ({
  setEditLocationsPopupOpen,
  currentLocation,
  onLocationUpdated,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [locationName, setLocationName] = useState(
    currentLocation?.locationName || ""
  );
  const [status, setStatus] = useState(currentLocation?.status || "Available");
  const [locationId, setLocationId] = useState(null);

  const [confirmRemove, setConfirmRemove] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  /**
   * Fetches the location's ID based on its name when the popup opens.
   * Runs only when `currentLocation` is available, ensuring it is called once per mount.
   *
   * @async
   * @function fetchLocation
   * @returns {Promise<void>}
   */
  useEffect(() => {
    const fetchLocation = async () => {
      try {
        // Fetch the full location object based on currentLocation
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-location-by-name/${currentLocation.locationName}`
        );
        const fetchedLocation = response.data;

        // Extract locationID and _id from the response
        setLocationId(fetchedLocation._id); // Store locationID
      } catch (error) {
        console.error(
          "Error fetching location:",
          error.response?.data || error.message
        );
      }
    };

    if (currentLocation?.locationName) {
      fetchLocation(); // Only fetch once when the component is mounted and currentLocation is available
    }
  }, [currentLocation]); // Only runs when currentLocation changes

  /**
   * Updates location name and status states when `currentLocation` changes.
   *
   * @useEffect
   */
  useEffect(() => {
    if (currentLocation) {
      setLocationName(currentLocation.locationName);
      setStatus(currentLocation.status);
    }
  }, [currentLocation]);

  /**
   * Closes the edit locations popup.
   *
   * @function handleEditLocationsClosePopup
   * @returns {void}
   */
  const handleEditLocationsClosePopup = () => {
    setEditLocationsPopupOpen(false);
  };

  /**
   * Submits the form to update the location's details.
   * Checks for name and status changes and validates the name for duplicates before sending a patch request.
   * Shows a notification upon successful update or displays an error if validation or submission fails.
   *
   * @async
   * @function handleSubmit
   * @param {Object} e - The form submission event object.
   * @returns {Promise<void>}
   */
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const nameChanged = locationName !== currentLocation?.locationName;
      const statusChanged = status !== currentLocation?.status;

      // Prepare an object to store changes
      let updates = {};

      // Add changes to the updates object
      if (nameChanged) {
        updates.locationName = locationName;
      }

      if (statusChanged) {
        updates.status = status;
      }

      // Only check for duplicates if the name has changed
      if (nameChanged) {
        try {
          const response = await axios.get(
            `http://localhost:9000/api/kape-link/get-location-by-name/${locationName}`
          );

          // Check if location exists and has a different ID from the current one
          if (response.data && response.data._id !== currentLocation._id) {
            setError("The location already exists.");
            return; // Exit if a duplicate is found
          }
        } catch (error) {
          // If there's an error and it's not a 404 (no location found), log it
          if (error.response && error.response.status !== 404) {
            console.error("Error checking for duplicates:", error);
            setError("Error checking for duplicates. Please try again.");
            return;
          }
        }
      }

      // If updates exist, proceed to patch the location
      if (Object.keys(updates).length > 0) {
        await axios.patch(
          `http://localhost:9000/api/kape-link/update-location/${locationId}`,
          updates
        );
        setNotificationMessage("Location updated successfully.");
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 3000);
      }

      onLocationUpdated();
      setEditLocationsPopupOpen(false); // Close the popup
    } catch (error) {
      console.error("Error updating location:", error);
      setError("Error updating location. Please try again.");
    }
  };

  /**
   * Handles removal of the location by sending a delete request.
   * Displays a loading indicator during deletion and shows success or error notifications based on result.
   *
   * @async
   * @function handleRemoveLocation
   * @returns {Promise<void>}
   */
  const handleRemoveLocation = async () => {
    setLoading(true);
    try {
      await axios.delete(
        `http://localhost:9000/api/kape-link/delete-location/${locationId}`
      );
      onLocationUpdated();
      setEditLocationsPopupOpen(false);
      setNotificationMessage("Location removed successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
    } catch (error) {
      console.error(
        "Error deleting location:",
        error.response?.data || error.message
      );
    } finally {
      setLoading(false);
    }
  };

  /**
   * Toggles the confirmation step for location deletion.
   *
   * @function toggleRemoveConfirmation
   * @returns {void}
   */
  const toggleRemoveConfirmation = () => {
    setConfirmRemove(!confirmRemove);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-5"
          onClick={handleEditLocationsClosePopup}
        />
        <div className="text-center mb-2 md:mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-lg">
            Edit Location
          </h2>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Location Name Field */}
          <div className="mb-2">
            <label
              className="block text-gray-700 max-[640px]:text-xs"
              htmlFor="locationName"
            >
              Location Name
            </label>
            <input
              id="locationName"
              type="text"
              value={locationName}
              onChange={(e) => setLocationName(e.target.value)}
              className="w-96 text-xs md:text-base px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:w-full"
              required
            />
            {error && (
              <div className="text-center mb-4">
                <p className="text-red-500">{error}</p>
              </div>
            )}
          </div>

          {/* Status Radio Buttons */}
          <div>
            <h1 className="sm:mb-3 block text-gray-700 max-[640px]:text-xs">
              Status
            </h1>
            <label htmlFor="statusShow" className="text-xs sm:text-base">
              <input
                id="statusShow"
                className="custom-radio-button"
                type="radio"
                name="status"
                value="Available"
                checked={status === "Available"}
                onChange={() => setStatus("Available")}
              />
              Show
            </label>
            <label htmlFor="statusHide" className="ml-6 text-xs sm:text-base">
              <input
                id="statusHide"
                className="custom-radio-button"
                type="radio"
                name="status"
                value="Hidden"
                checked={status === "Hidden"}
                onChange={() => setStatus("Hidden")}
              />
              Hide
            </label>
          </div>
          {/* Confirm Remove Section */}
          {confirmRemove ? (
            <div className="mt-4">
              <p className="w-full text-red-500 my-4 text-center text-sm sm:text-base">
                Are you sure you want to remove this location?
              </p>
              <div className="flex justify-center space-x-2 sm:space-x-4 mt-4">
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleRemoveLocation}
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm  
                      ${
                        loading
                          ? "bg-gray-400 cursor-not-allowed"
                          : "bg-gray-800 hover:bg-gray-600 duration-300 text-white"
                      }`}
                >
                  {loading ? "Removing..." : "Confirm"}
                </button>
                <button
                  type="button"
                  onClick={toggleRemoveConfirmation}
                  className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-200 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex justify-end space-x-2 sm:space-x-4 mt-4">
              <button
                type="submit"
                className="custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Save
              </button>
              <button
                type="button"
                onClick={toggleRemoveConfirmation}
                className="font-medium py-0 px-7 md:px-8 bg-gray-800 hover:bg-gray-600 duration-300 text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Remove
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default EditLocationsPopup;
