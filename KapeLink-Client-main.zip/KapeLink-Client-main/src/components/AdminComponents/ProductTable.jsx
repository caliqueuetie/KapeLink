/**
 * Table component to display and manage products.
 * Allows sorting, filtering, and actions like edit, delete, and toggle status for each product.
 * Integrates popup modals for editing and deleting products.
 *
 * @module ProductTable
 * @param {Object} props - Component properties.
 * @param {string} props.activeTab - Filter for displaying products by their status (e.g., "All", "Available", "Hidden").
 * @param {string} props.searchQuery - Search string to filter displayed products.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message content.
 */
import { Ellipsis, SquarePen, EyeOff, Eye, Trash } from "lucide-react";
import React, { useEffect, useState, useRef } from "react";
import EditProductPopup from "./EditProductPopup";
import DeleteProductPopup from "./DeleteProductPopup";
import AdminAddItemPopupButton from "./AdminAddItemPopupButton";
import axios from "axios";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";

const ProductTable = ({
  activeTab,
  searchQuery,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [data, setData] = useState([]);
  const [isEditPopupOpen, setIsEditPopupOpen] = useState(false);
  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false);
  const [openMenuId, setOpenMenuId] = useState(null);
  const [sortField, setSortField] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [loading, setLoading] = useState(true);

  const cellFormat =
    "border-b border-gray-400 p-6 2xl:p-10 text-center sm:text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4";
  const headerFormat =
    "w-screen p-3 font-semibold whitespace-nowrap sm:text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";

  /**
   * Fetches the list of products from the server, applying active tab and search query filters.
   * Runs on component mount and updates the data on success.
   *
   * @async
   * @function fetchProducts
   * @returns {Promise<void>}
   */
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        let response = await axios.get(
          "http://localhost:9000/api/kape-link//all-products"
        );

        setData(response.data); // Update the state with the products
        setLoading(false);
      } catch (error) {
        console.error("Error fetching products:", error);
        setLoading(false);
      }
    };
    fetchProducts();
  });

  /**
   * Toggles the action menu visibility for the selected product.
   *
   * @function toggleMenu
   * @param {string} itemId - The ID of the product to toggle the menu for.
   * @returns {void}
   */
  const toggleMenu = (itemId) => {
    setOpenMenuId((prevId) => (prevId === itemId ? null : itemId));
  };

  /**
   * Opens the edit popup and sets the selected product to be edited.
   *
   * @function handleEditOpenPopup
   * @param {Object} product - The product object to be edited.
   * @returns {void}
   */
  const handleEditOpenPopup = (product) => {
    setSelectedProduct(product);
    setIsEditPopupOpen(true);
  };

  /**
   * Opens the delete confirmation popup and sets the selected product to be deleted.
   *
   * @function handleDeleteOpenPopup
   * @param {Object} product - The product object to be deleted.
   * @returns {void}
   */
  const handleDeleteOpenPopup = (product) => {
    setSelectedProduct(product);
    setIsDeletePopupOpen(true);
  };

  /**
   * Callback to refresh the product list after a successful save action (add, edit, or delete).
   *
   * @async
   * @function onSaveSuccess
   * @returns {Promise<void>}
   */
  const onSaveSuccess = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link//all-products"
      );
      setData(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  /**
   * Toggles the availability status of a product and updates it on the server.
   *
   * @async
   * @function handleStatusToggle
   * @param {string} prodId - The ID of the product to toggle status for.
   * @param {string} currentStatus - The current status of the product.
   * @returns {Promise<void>}
   */
  const handleStatusToggle = async (prodId, currentStatus) => {
    const newStatus =
      currentStatus === "Available" ? "Unavailable" : "Available";
    try {
      await axios.patch(
        `http://localhost:9000/api/kape-link/update-product-status/${prodId}`,
        { status: newStatus }
      );
      setData((prevData) =>
        prevData.map((item) =>
          item.prodId === prodId ? { ...item, status: newStatus } : item
        )
      );
    } catch (error) {
      console.error(
        "Error updating product status:",
        error.response ? error.response.data : error.message
      );
    }
  };

  /**
   * Sets the sorting field and toggles the sort order.
   *
   * @function handleSort
   * @param {string} field - The field by which to sort the data.
   * @returns {void}
   */
  const handleSort = (field) => {
    const order = sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(order);
  };

  /**
   * Retrieves the field value for sorting.
   *
   * @function getValue
   * @param {Object} item - The item from which to retrieve the field value.
   * @param {string} field - The field name.
   * @returns {string} The value of the specified field.
   */
  const getValue = (item, field) => {
    return item[field] ? item[field].toString().toLowerCase() : "";
  };

  /**
   * Sorts the product data based on the selected field and order.
   * Creates a copy of `data` and applies sorting to avoid mutating the original state.
   * The sorting order toggles between ascending and descending each time the same field is selected.
   *
   * @constant
   * @type {Array<Object>}
   * @param {Object} a - First product item to compare.
   * @param {Object} b - Second product item to compare.
   * @returns {number} - Comparison result to order products by the selected field.
   */
  const sortedData = [...data].sort((a, b) => {
    const valueA = getValue(a, sortField);
    const valueB = getValue(b, sortField);
    return valueA < valueB
      ? sortOrder === "asc"
        ? -1
        : 1
      : valueA > valueB
      ? sortOrder === "asc"
        ? 1
        : -1
      : 0;
  });

  /**
   * Filters the sorted product data based on the selected tab and search query.
   * Filters by status if a specific tab (e.g., "Hidden" or "Available") is selected,
   * then further filters by checking if any product field contains the search query.
   *
   * @constant
   * @type {Array<Object>}
   * @param {Object} item - The product item to filter.
   * @returns {boolean} - True if the item matches the active tab and search query.
   */
  const filteredData = sortedData.filter((item) => {
    const effectiveStatus = activeTab === "Hidden" ? "Unavailable" : activeTab;
    const matchesTab =
      effectiveStatus === "All" || item.status === effectiveStatus;
    const searchQueryLower = searchQuery.toLowerCase();
    const matchesSearch = [
      item.name,
      item.basePrice?.toString(),
      item.category,
      item.menuCategory,
      item.status,
    ].some((field) => field.toLowerCase().includes(searchQueryLower));
    return matchesTab && matchesSearch;
  });

  /**
   * Gets the appropriate sorting arrow icon based on the current sort order.
   *
   * @function getSortArrow
   * @param {string} field - The field to get the sort arrow for.
   * @returns {string|null} The sort arrow icon or null if not sorting by the field.
   */
  const getSortArrow = (field) => {
    if (sortField !== field) return null;
    return sortOrder === "asc" ? "↑" : "↓";
  };

  const menuRef = useRef(null);

  /**
   * Closes the menu if a click event occurs outside of the menu reference.
   *
   * @function handleClickOutside
   * @param {Event} event - The mouse click event.
   * @returns {void}
   */
  const handleClickOutside = (event) => {
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setOpenMenuId(null);
    }
  };
  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <>
      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[520px] 2xl:h-[690px] max-[640px]:max-w-80">
        {loading ? (
          <table className="h-[518px] 2xl:h-[688px] flex flex-col items-center justify-center">
            <thead>
              <tr>
                <th
                  className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center`}
                >
                  <Player
                    autoplay
                    loop
                    src={loader}
                    style={{ height: "150px", width: "150px" }}
                  />
                </th>
              </tr>
            </thead>
          </table>
        ) : (
          <table>
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-400">
                <th className={headerFormat} onClick={() => handleSort("name")}>
                  Name {getSortArrow("name")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("basePrice")}
                >
                  Price {getSortArrow("basePrice")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("category")}
                >
                  Category {getSortArrow("category")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("menuCategory")}
                >
                  Menu Category {getSortArrow("menuCategory")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("status")}
                >
                  Status {getSortArrow("status")}
                </th>
                <th className={headerFormat}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length > 0 ? (
                <>
                  {filteredData.map((item) => (
                    <tr key={item.prodId}>
                      <td className={cellFormat}>
                        {item.type ? `${item.name} (${item.type})` : item.name}
                      </td>
                      <td className={cellFormat}>
                        {item.basePrice != null
                          ? `P${item.basePrice.toFixed(2)}`
                          : "N/A"}
                      </td>
                      <td className={cellFormat}>{item.category}</td>
                      <td className={cellFormat}>{item.menuCategory}</td>
                      <td className={cellFormat}>{item.status}</td>
                      <td
                        className={`${cellFormat} text-center`}
                        style={{ verticalAlign: "middle" }}
                      >
                        <div className="relative inline-block align-middle">
                          <Ellipsis
                            onClick={() => toggleMenu(item.prodId)}
                            className="cursor-pointer w-3 sm:w-6"
                          />
                          {openMenuId === item.prodId && (
                            <div
                              ref={menuRef}
                              className="absolute top-8 custom-bg-color shadow-md rounded-l z-20 -left-24 max-[640px]:-left-14"
                            >
                              <ul>
                                <li
                                  onClick={() => handleEditOpenPopup(item)}
                                  className="flex border cursor-pointer items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                >
                                  <SquarePen className="mr-2 max-[640px]:w-4" />
                                  Edit
                                </li>
                                <li
                                  onClick={() =>
                                    handleStatusToggle(item.prodId, item.status)
                                  }
                                  className="flex border cursor-pointer items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                >
                                  {item.status === "Available" ? (
                                    <>
                                      <EyeOff className="mr-2 max-[640px]:w-4" />
                                      Hide
                                    </>
                                  ) : (
                                    <>
                                      <Eye className="mr-2 max-[640px]:w-4" />
                                      Unhide
                                    </>
                                  )}
                                </li>
                                <li
                                  onClick={() => handleDeleteOpenPopup(item)}
                                  className="flex border cursor-pointer items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                >
                                  <Trash className="mr-2 max-[640px]:w-4" />
                                  Delete
                                </li>
                              </ul>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </>
              ) : (
                <tr>
                  <td colSpan="6" className="text-center p-4">
                    No products found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>

      <AdminAddItemPopupButton
        onSaveSuccess={onSaveSuccess}
        setShowNotification={setShowNotification}
        setNotificationMessage={setNotificationMessage}
      />

      {isEditPopupOpen && (
        <EditProductPopup
          menuRef={menuRef}
          setIsEditPopupOpen={setIsEditPopupOpen}
          product={selectedProduct}
          onSaveSuccess={onSaveSuccess}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}

      {isDeletePopupOpen && (
        <DeleteProductPopup
          menuRef={menuRef}
          setIsDeletePopupOpen={setIsDeletePopupOpen}
          product={selectedProduct}
          onSaveSuccess={onSaveSuccess}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}
    </>
  );
};

export default ProductTable;
