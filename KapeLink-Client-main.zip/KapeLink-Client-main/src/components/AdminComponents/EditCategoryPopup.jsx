import { X, Loader } from "lucide-react";
import { useState, useEffect } from "react";
import axios from "axios";

const EditCategoryPopup = ({ setPopupOpen, refreshCategories, data, type }) => {
  const [categoryName, setCategoryName] = useState(data.name);
  const [description, setDescription] = useState(data.description || "");
  const [status, setStatus] = useState(data.show ? true : false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [confirmRemove, setConfirmRemove] = useState(false);

  useEffect(() => {
    setCategoryName(data.name);
    if (type === "main") setDescription(data.description);
  }, [data, confirmRemove]);

  const handleEditCategoryClosePopup = () => {
    setPopupOpen(false);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const updatedCategory = {
      type: type,
      id: data.id,
      name: categoryName,
      description: type === "main" ? description : null,
      show: status,
    };

    try {
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/get-category",
        { type: type }
      );
      const categories = response.data;

      const categoryExists = categories.some(
        (category) =>
          category.name.toLowerCase() === categoryName.toLowerCase() &&
          category.id !== data.id
      );

      if (categoryExists) {
        setError("A category with this name already exists.");
        setLoading(false);
        return;
      }

      if (!categoryName || (type === "main" && !description)) {
        setError("Please fill out all fields.");
        setLoading(false);
        return;
      }

      const filterField =
        type === "main"
          ? "mainCategory"
          : type === "menu"
            ? "menuCategory"
            : "salesCategory";
      // Fetch all products under the current category name (if it was changed)
      if (data.name !== categoryName) {
        console.log("changed categ")
        const productsResponse = await axios.post(
          "http://localhost:9000/api/kape-link/filter-products",
          { [filterField]: data.name }  // Pass the current category name in req.body
        );

        const products = productsResponse.data;

        const updateField =
        type === "main"
          ? "category"
          : type === "menu"
            ? "menuCategory"
            : "salesReport";
        // Update each product's category field to the new name
        for (const product of products) {
          await axios.patch(
            `http://localhost:9000/api/kape-link/update-product/${product.prodId}`,
            { [updateField]: categoryName }, // Update to new category name
            {
              headers: {
                "Content-Type": "application/json",
              },
            }
          );
        }
      }

      await axios.put(
        "http://localhost:9000/api/kape-link/update-category",
        updatedCategory,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      setPopupOpen(false);
      refreshCategories();
    } catch (err) {
      console.error("Error updating category:", err);
      setError("An error occurred while updating the category.");
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveCategory = async () => {
    setLoading(true);

    try {
      const filterField =
        type === "main"
          ? "mainCategory"
          : type === "menu"
            ? "menuCategory"
            : "salesCategory";

      const filterResponse = await axios.post(
        "http://localhost:9000/api/kape-link/filter-products",
        { [filterField]: data.name }
      );

      const products = filterResponse.data;

      if (products.length > 0) {
        setError("Category cannot be deleted as it still contains products.");
        setConfirmRemove(false);
        setLoading(false);
        return;
      }

      await axios.delete("http://localhost:9000/api/kape-link/delete-category", {
        data: { type: type, id: data.id },
      });

      setPopupOpen(false);
      refreshCategories();
    } catch (err) {
      console.error("Error deleting category:", err);
      setError("An error occurred while trying to delete the category.");
      setConfirmRemove(false);
    } finally {
      setLoading(false);
    }
  };

  const toggleRemoveConfirmation = () => {
    setConfirmRemove(!confirmRemove);
    setError(null); // Clear any existing error when toggling
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8 max-h-[80vh] overflow-y-auto">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleEditCategoryClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-lg">
            Edit {type.charAt(0).toUpperCase() + type.slice(1)} Category
          </h2>
        </div>

        <form onSubmit={handleFormSubmit}>
          <div className="w-full sm:w-80">
            {error && <p className="text-red-500 mb-4 text-center">{error}</p>}
          </div>

          <div className="mb-2">
            <label
              className="block text-gray-700 max-[640px]:text-xs mb-1"
              htmlFor="categoryName"
            >
              Category Name
            </label>
            <input
              id="categoryName"
              type="text"
              className={`w-full sm:w-80 text-xs md:text-base px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:w-full
                ${confirmRemove
                  ? "bg-gray-400 cursor-not-allowed"
                  : ""
                }`}
              value={categoryName}
              disabled={confirmRemove}
              onChange={(e) => setCategoryName(e.target.value)}
            />
          </div>

          {type === "main" && (
            <div className="mb-2">
              <label
                className="block text-gray-700 max-[640px]:text-xs mb-1"
                htmlFor="description"
              >
                Description
              </label>
              <textarea
                id="description"
                className={`w-full sm:w-80 text-xs md:text-base text-justify px-2 py-1 border border-gray-300 rounded-md h-28 overflow-y-auto
                  ${confirmRemove
                    ? "bg-gray-400 cursor-not-allowed"
                    : ""
                  }`}
                value={description}
                disabled={confirmRemove}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          )}

          <div>
            <h1 className="sm:mb-3 block text-gray-700 max-[640px]:text-xs">
              Status
            </h1>
            <label htmlFor="statusShow" className="text-xs sm:text-base">
              <input
                id="statusShow"
                className="custom-radio-button"
                type="radio"
                name="status"
                value="Active"
                checked={status === true}
                onChange={() => setStatus(true)}
                disabled={confirmRemove}
              />
              Show
            </label>
            <label htmlFor="statusHide" className="text-xs sm:text-base">
              <input
                id="statusHide"
                className="ml-6 custom-radio-button"
                type="radio"
                name="status"
                value="Hidden"
                checked={status === false}
                onChange={() => setStatus(false)}
                disabled={confirmRemove}
              />
              Hide
            </label>
          </div>

          {confirmRemove ? (
            <>
              {error && <p className="text-red-500 mb-4">{error}</p>}
              <p className="w-full sm:w-80 text-red-500 my-4 text-center text-sm sm:text-base">
                Are you sure you want to remove this category?
              </p>

              <div className="flex justify-center space-x-2 sm:space-x-4 mt-4">
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleRemoveCategory}
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                ${loading
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-gray-800 hover:bg-gray-600 duration-300 text-white "
                    }`}
                >
                  {loading ? (
                    <Loader className="animate-spin" size={20} />
                  ) : (
                    "Confirm"
                  )}
                </button>
                <button
                  type="button"
                  onClick={toggleRemoveConfirmation}
                  className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-200 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                >
                  Cancel
                </button>
              </div>
            </>
          ) : (
            <div className="flex justify-end space-x-2 sm:space-x-4 mt-4">
              <button
                type="submit"
                disabled={loading}
                className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                ${loading
                    ? "bg-gray-400 cursor-not-allowed"
                    : "custom-button-color text-white"
                  }`}
              >
                {loading ? (
                  <Loader className="animate-spin" size={20} />
                ) : (
                  "Save"
                )}
              </button>
              <button
                type="button"
                onClick={toggleRemoveConfirmation}
                className="font-medium py-0 px-7 md:px-8 bg-gray-800 hover:bg-gray-600 duration-300 text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Remove
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default EditCategoryPopup;
