import React, { useState } from "react";
import { X } from "lucide-react";

const EditMenuCategoryPopup = ({ setEditMenuCategoryPopupOpen }) => {
  const handleEditMenuCategoryClosePopup = () => {
    setEditMenuCategoryPopupOpen(false);
  };

  const [selectedCategory, setSelectedCategory] = useState("");
  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-5"
          onClick={handleEditMenuCategoryClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Edit Menu Category
          </h2>
        </div>

        <form>
          {/* Form fields go here */}

          <div className="mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-sm"
              htmlFor="subcategoryName"
            >
              Menu Category Name
            </label>
            <input
              type="text"
              className="w-96 px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 max-[640px]:w-full"
              id="subcategoryName"
            />
          </div>

          <div className="mb-4">
            <label
              className="block text-gray-700 max-[640px]:text-sm"
              htmlFor="category"
            >
              Menu Category
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              id="category"
              onChange={handleCategoryChange}
              value={selectedCategory}
            >
              {/* Make this category options dynamic */}
              <option value="">Select Under What Category</option>
              <option value="Heart Beat Classics">Beverages</option>
              <option value="Non-Palpitating">Pasta</option>
              <option value="Non-Palpitating">Others</option>
            </select>
          </div>

          <div>
            <h1 className="mb-3 block text-gray-700 max-[640px]:text-sm">
              Status
            </h1>
            <label htmlFor="statusShow">
              <input
                id="statusShow"
                className="custom-radio-button"
                type="radio"
                name="status"
                value="Active"
              />
              Show
            </label>
            <label htmlFor="statusHide">
              <input
                id="statusHide"
                className="ml-6 custom-radio-button"
                type="radio"
                name="status"
                value="Hidden"
              />
              Hide
            </label>
          </div>

          <div className="flex justify-end mt-4">
            <button
              type="submit"
              className="custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditMenuCategoryPopup;
