import React from "react";
import { X, Loader } from "lucide-react";
import { useState, useEffect } from "react";
import axios from "axios";

const DeleteUserPopup = ({
  menuRef,
  setIsDeletePopupOpen,
  user,
  onSaveSuccess,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [loading, setLoading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState(null);

  const handleDelete = async () => {
    setLoading(true);
    try {
      await axios.delete(
        `http://localhost:9000/api/kape-link/delete-user/${user.userId}`
      );
      setNotificationMessage("User deleted successfully.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);

      onSaveSuccess();
      handleClosePopup();
    } catch (error) {
      console.error("Error deleting user:", error);
      setNotificationMessage("Failed to delete the user. Please try again.");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000);
      setLoading(false);
    }
  };

  const handleClosePopup = () => {
    setIsDeletePopupOpen(false);
  };

  const toggleDeleteConfirmation = () => {
    setConfirmDelete(!confirmDelete);
    setError(null); // Clear any existing error when toggling
  };

  return (
    <div
      ref={menuRef}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20"
    >
      <div className="bg-white p-14 w-[500px] rounded-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Delete User
          </h2>
        </div>

        {/* Display user details */}
        <div className="mb-4">
          <p>
            <span className="font-semibold">First Name:</span> {user.firstName}
          </p>
          <p>
            <span className="font-semibold">Last Name:</span> {user.lastName}
          </p>
          <p>
            <span className="font-semibold">Contact Number:</span>{" "}
            {user.contactNumber}
          </p>
          <p>
            <span className="font-semibold">Email:</span>{" "}
            {user.email !== undefined ? user.email : "N/A"}
          </p>
          <p>
            <span className="font-semibold">Role:</span> {user.role}
          </p>
          <p>
            <span className="font-semibold">Status:</span> {user.status}
          </p>
        </div>

        <div className="block justify-end">
          {confirmDelete ? (
            <>
              {error && <p className="text-red-500 mb-4">{error}</p>}
              <p className="text-red-500 mb-4">
                Are you sure you want to delete this user?
              </p>

              <div className="flex justify-center space-x-4 mt-4">
                <button
                  type="button"
                  disabled={loading}
                  onClick={handleDelete}
                  className={`font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm 
                ${
                  loading
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-red-500 hover:bg-red-400 duration-300 text-white "
                }`}
                >
                  {loading ? (
                    <Loader className="animate-spin" size={20} />
                  ) : (
                    "Delete"
                  )}
                </button>
                <button
                  type="button"
                  onClick={toggleDeleteConfirmation}
                  className="font-medium py-2 px-8 bg-gray-300 hover:bg-gray-400 duration-300 text-black rounded-md max-[640px]:py-1 max-[640px]:text-sm"
                >
                  Cancel
                </button>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center mt-4">
              <button
                type="button"
                onClick={toggleDeleteConfirmation}
                className="font-medium py-2 px-8 bg-red-500 hover:bg-red-400 duration-300 text-white rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Delete
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DeleteUserPopup;
