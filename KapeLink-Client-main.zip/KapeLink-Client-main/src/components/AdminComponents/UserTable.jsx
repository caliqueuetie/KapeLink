import { Ellipsis, SquarePen, EyeOff, Eye, Trash } from "lucide-react";
import React, { useEffect, useState, useRef } from "react";
import EditUserPopup from "./EditUserPopup";
import DeleteUserPopup from "./DeleteUserPopup";
import axios from "axios";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import { io } from "socket.io-client";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";

const UserTable = ({ activeTab, searchQuery }) => {
  const [selectedUser, setSelectedUser] = useState(null);
  const [data, setData] = useState([]);
  const [sortField, setSortField] = useState("firstName"); // Default sort by first name
  const [sortOrder, setSortOrder] = useState("asc");
  const [openMenuId, setOpenMenuId] = useState(null); // Initialize openMenuId
  const menuRef = useRef(null);
  const [loading, setLoading] = useState(true);

  const [isEditPopupOpen, setIsEditPopupOpen] = useState(false);
  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  const cellFormat =
    "border-b border-gray-400 p-10 text-center text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4";
  const headerFormat =
    "w-screen p-3 font-semibold whitespace-nowrap text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";

  const fetchData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-users"
      );
      setData(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching users:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeTab, searchQuery]);

  useEffect(() => {
    const socket = io("http://localhost:9000");
    socket.on("users", () => {
      fetchData();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleSort = (field) => {
    const order = sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(order);
  };

  const getValue = (user, field) => {
    return user[field] ? user[field].toLowerCase() : "";
  };

  const sortedData = [...data].sort((a, b) => {
    const valueA = getValue(a, sortField);
    const valueB = getValue(b, sortField);
    return valueA < valueB
      ? sortOrder === "asc"
        ? -1
        : 1
      : valueA > valueB
      ? sortOrder === "asc"
        ? 1
        : -1
      : 0;
  });

  const filteredData = sortedData.filter((user) => {
    const matchesTab =
      activeTab === "All" ||
      user.status.toLowerCase() === activeTab.toLowerCase();
    const searchQueryLower = searchQuery.toLowerCase();
    const matchesSearch =
      user.firstName.toLowerCase().includes(searchQueryLower) ||
      user.lastName.toLowerCase().includes(searchQueryLower) ||
      user.role.toLowerCase().includes(searchQueryLower) ||
      user.status.toLowerCase().includes(searchQueryLower);
    return matchesTab && matchesSearch;
  });

  const toggleMenu = (userId) => {
    setOpenMenuId((prevId) => (prevId === userId ? null : userId)); // Toggle openMenuId
  };

  const handleClickOutside = (event) => {
    if (menuRef.current && !menuRef.current.contains(event.target)) {
      setOpenMenuId(null); // Close menu when clicking outside
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Function to toggle status between "active" and "restricted"
  const toggleStatus = async (userId, currentStatus) => {
    const newStatus = currentStatus === "active" ? "restricted" : "active";

    try {
      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-user-status/${userId}`,
        { status: newStatus }
      );

      if (response.status === 200) {
        // Update the state with the new status
        setData((prevData) =>
          prevData.map((user) =>
            user.userId === userId ? { ...user, status: newStatus } : user
          )
        );
      }
    } catch (error) {
      console.error(
        "Error updating user status:",
        error.response ? error.response.data : error.message
      );
    }
  };

  const handleEditOpenPopup = (user) => {
    setSelectedUser(user);
    setIsEditPopupOpen(true);
  };

  const handleDeleteOpenPopup = (user) => {
    setSelectedUser(user);
    setIsDeletePopupOpen(true);
  };

  const onSaveSuccess = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-users"
      );
      setData(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching users:", error);
      setLoading(false);
    }
  };

  return (
    <>
      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[520px] 2xl:h-[690px] max-[640px]:max-w-80">
        {loading ? (
          <table className="h-[518px] 2xl:h-[688px] flex flex-col items-center justify-center">
            <thead>
              <tr>
                <th
                  className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center`}
                >
                  <Player
                    autoplay
                    loop
                    src={loader}
                    style={{ height: "150px", width: "150px" }}
                  />
                </th>
              </tr>
            </thead>
          </table>
        ) : (
          <table>
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-400">
                <th
                  className={headerFormat}
                  onClick={() => handleSort("firstName")}
                >
                  Name{" "}
                  {sortField === "firstName" &&
                    (sortOrder === "asc" ? "↑" : "↓")}
                </th>
                <th className={headerFormat} onClick={() => handleSort("role")}>
                  Role{" "}
                  {sortField === "role" && (sortOrder === "asc" ? "↑" : "↓")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("status")}
                >
                  Status{" "}
                  {sortField === "status" && (sortOrder === "asc" ? "↑" : "↓")}
                </th>
                <th className={headerFormat}>Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length > 0 ? (
                <>
                  {filteredData.map((user) => (
                    <tr key={user._id}>
                      <td className={cellFormat}>
                        {user.firstName} {user.lastName}
                      </td>
                      <td className={cellFormat}>{user.role}</td>
                      <td className={cellFormat}>{user.status}</td>
                      <td
                        className={`${cellFormat} text-center`}
                        style={{ verticalAlign: "middle" }}
                      >
                        <div className="relative inline-block align-middle">
                          <Ellipsis
                            onClick={() => toggleMenu(user._id)}
                            className="cursor-pointer w-3 sm:w-6"
                          />
                          {openMenuId === user._id && (
                            <div
                              ref={menuRef}
                              className="absolute top-8 custom-bg-color shadow-md rounded-l z-20 -left-28 max-[640px]:-left-20"
                            >
                              <ul>
                                <li
                                  className="flex border cursor-pointer space-x-2 items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                  onClick={() => handleEditOpenPopup(user)} // Toggle edit on click
                                >
                                  <SquarePen className="max-[640px]:w-4" />
                                  <span>Edit</span>
                                </li>
                                <li
                                  className="flex border cursor-pointer space-x-2 items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                  onClick={() =>
                                    toggleStatus(user.userId, user.status)
                                  } // Toggle status on click
                                >
                                  {user.status.toLowerCase() === "active" ? (
                                    <>
                                      <EyeOff className="max-[640px]:w-4" />
                                      <span>Restrict</span>
                                    </>
                                  ) : (
                                    <>
                                      <Eye className="max-[640px]:w-4" />
                                      <span>Unrestrict</span>
                                    </>
                                  )}
                                </li>
                                <li
                                  className="flex border cursor-pointer space-x-2 items-center py-2 px-5 hover:bg-gray-200 max-[640px]:py-1 max-[640px]:px-3"
                                  onClick={() => handleDeleteOpenPopup(user)} // Toggle delete on click
                                >
                                  <Trash className="max-[640px]:w-4" />
                                  <span>Delete</span>
                                </li>
                              </ul>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </>
              ) : (
                <tr>
                  <td colSpan="4" className="text-center p-4">
                    No users found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
      {isEditPopupOpen && (
        <EditUserPopup
          menuRef={menuRef}
          setIsEditPopupOpen={setIsEditPopupOpen}
          user={selectedUser}
          onSaveSuccess={onSaveSuccess}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}
      {isDeletePopupOpen && (
        <DeleteUserPopup
          menuRef={menuRef}
          setIsDeletePopupOpen={setIsDeletePopupOpen}
          user={selectedUser}
          onSaveSuccess={onSaveSuccess}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}
      <FloatingSuccessfulNotification
        showNotification={showNotification}
        notificationMessage={notificationMessage}
      />
    </>
  );
};

export default UserTable;
