/**
 * Popup component to add a new payment method.
 * Allows users to enter payment details, optionally upload an image, and handles form submission
 * to add the payment method to the backend.
 *
 * @module AddPaymentPopup
 * @param {Object} props - Component properties.
 * @param {Function} props.setAddPaymentPopupOpen - Function to control popup visibility.
 * @param {Function} props.onPaymentAdded - Callback to update the list of payment methods after addition.
 * @param {Function} props.setShowNotification - Function to toggle notification visibility.
 * @param {Function} props.setNotificationMessage - Function to set the notification message.
 */
import React, { useState } from "react";
import { X } from "lucide-react";
import axios from "axios";

const AddPaymentPopup = ({
  setAddPaymentPopupOpen,
  onPaymentAdded,
  setShowNotification,
  setNotificationMessage,
}) => {
  const [paymentMethodName, setPaymentMethodName] = useState("");
  const [paymentDetails, setPaymentDetails] = useState("");
  const [img, setImg] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  /**
   * Closes the Add Payment Popup modal.
   *
   * @function handleAddPaymentClosePopup
   * @returns {void}
   */
  const handleAddPaymentClosePopup = () => {
    setAddPaymentPopupOpen(false);
  };

  /**
   * Handles form submission for adding a new payment method.
   * Validates the form data and, if valid, sends a POST request with the payment details and
   * optional image to the backend. Shows success or error messages based on the response.
   *
   * @async
   * @function handleSubmit
   * @param {Object} e - The form submission event object.
   * @returns {Promise<void>}
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const formData = new FormData();
    formData.append("name", paymentMethodName);
    formData.append("payment_details", paymentDetails);

    if (img) {
      formData.append("img", img);
    }

    try {
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/add-payment-method",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if (response.data) {
        onPaymentAdded(response.data);
        handleAddPaymentClosePopup();
        setNotificationMessage("Payment option added successfully.");
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 3000);
      }
    } catch (error) {
      if (error.response?.status === 400) {
        setError(error.response?.data?.error || "Error adding payment method.");
      } else {
        setError("Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={handleAddPaymentClosePopup}
        />
        <div className="text-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            Add Payment Option
          </h2>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-700 max-[640px]:text-xs">
              Payment Option Name
            </label>
            <input
              type="text"
              value={paymentMethodName}
              onChange={(e) => setPaymentMethodName(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 w-full text-sm sm:text-base"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 max-[640px]:text-xs">
              Payment Details
            </label>
            <input
              type="text"
              value={paymentDetails}
              onChange={(e) => setPaymentDetails(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md max-[640px]:py-0 w-full text-sm sm:text-base"
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 max-[640px]:text-xs mb-2">
              Payment Image (optional)
            </label>
            <input
              type="file"
              onChange={(e) => {
                setImg(e.target.files[0]);
              }}
              accept="image/*"
              className="text-xs"
            />
          </div>
          {error && <p className="text-red-500">{error}</p>}{" "}
          {/* Display error message */}
          <div className="flex justify-end mt-4">
            <button
              type="submit"
              className={`custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm ${
                loading ? "opacity-50 cursor-not-allowed" : ""
              }`}
              disabled={loading} // Disable button when loading
            >
              {loading ? "Adding..." : "Add Payment"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPaymentPopup;
