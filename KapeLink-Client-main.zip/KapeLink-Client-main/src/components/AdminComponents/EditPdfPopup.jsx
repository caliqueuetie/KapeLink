import React, { useState, useEffect } from "react";
import { X, Loader } from "lucide-react"; // Import a loading icon
import axios from "/axios.config"; // Import configured axios with credentials

const EditPdfPopup = ({
  setEditPdfPopupOpen,
  data: pdf,
  refreshKnowledgeBase,
}) => {
  const [loading, setLoading] = useState(true); // Set loading state initially to true
  const [credentials, setCredentials] = useState(null); // State for credentials
  const [errorMessage, setErrorMessage] = useState(""); // State for error messages
  const [confirmDelete, setConfirmDelete] = useState(false); // State for delete confirmation

  // Fetch credentials from the server when the component mounts
  useEffect(() => {
    const fetchCredentials = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/credentials"
        );
        setCredentials(response.data.credentials); // Assuming the credentials are in the first item of the array
        setLoading(false); // Set loading to false after data is fetched
      } catch (error) {
        setErrorMessage("Failed to load credentials");
        console.error("Error fetching credentials:", error);
        setLoading(false);
      }
    };

    fetchCredentials();
  }, []);

  const handleDelete = async () => {
    if (!credentials) return;

    setLoading(true); // Set loading state to true
    const url = `https://api.botpress.cloud/v1/files/${pdf.id}`;
    const options = {
      method: "DELETE",
      headers: {
        accept: "application/json",
        "x-bot-id": credentials.botId,
        "x-workspace-id": credentials.workspaceId,
        Authorization: `Bearer ${credentials.token}`,
      },
    };

    try {
      const response = await axios.delete(url, { headers: options.headers });

      if (response.status === 200) {
        setEditPdfPopupOpen(false); // Close the popup after deletion
        refreshKnowledgeBase(); // Refresh the knowledge base list
      } else {
        setErrorMessage("Failed to delete the file");
        console.error("Failed to delete the file:", response.data);
      }
    } catch (error) {
      setErrorMessage("Error deleting the file");
      console.error("Error deleting the file:", error);
    } finally {
      setLoading(false); // Set loading state to false after the operation is done
    }
  };

  const handleEditPdfClosePopup = () => {
    setEditPdfPopupOpen(false);
  };

  const handleViewPdfClick = () => {
    // Open the PDF file in a new tab
    window.open(pdf.url, "_blank");
  };

  const toggleDeleteConfirmation = () => {
    setConfirmDelete(!confirmDelete);
    setErrorMessage("");
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
        <Loader className="animate-spin" size={40} />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="w-1/4 bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        {/* Header section with title and close button */}
        <div className="flex justify-between items-center mb-5">
          <h2 className="font-semibold text-2xl max-[640px]:text-xl">
            PDF Details
          </h2>
          <X
            size={30}
            className="cursor-pointer"
            onClick={handleEditPdfClosePopup}
          />
        </div>

        <div className="mb-5">
          <h2 className="font-semibold text-xl text-center max-[640px]:text-xl">
            {pdf.tags.title}
          </h2>
          <hr className="my-4 border-gray-300" />
          <h2 className="max-[640px]:text-sm text-justify">
            You may download the file to view its contents, or delete it from
            the Knowledge Base.
          </h2>
        </div>
        {errorMessage && <p className="text-red-500 mb-4">{errorMessage}</p>}
          <div className="flex flex-col items-center space-y-3">
          <button
            onClick={handleViewPdfClick}
            className="custom-button-color text-white px-4 py-1 sm:py-2 rounded-lg"
          >
            Download
          </button>
          {confirmDelete ? (
            <>
              <p className="text-red-500">Are you sure you want to delete this file?</p>
              <button
                onClick={handleDelete}
                disabled={loading}
                className={`font-medium px-4 py-1 sm:py-2 rounded-lg 
                  ${loading ? "bg-gray-400 cursor-not-allowed" : "custom-button-black text-white"}`}
              >
                {loading ? (
                  <Loader className="animate-spin" size={20} />
                ) : (
                  "Delete"
                )}
              </button>
              <button
                onClick={toggleDeleteConfirmation}
                className="font-medium px-4 py-1 sm:py-2 rounded-lg bg-gray-300 hover:bg-gray-200"
              >
                Cancel
              </button>
            </>
          ) : (
            <div className="block items-center justify-center">
            <button
              onClick={toggleDeleteConfirmation}
              className="custom-button-black text-white px-4 py-1 sm:py-2 rounded-lg"
            >
              Delete
            </button>
            </div>
          )}
          </div>
      </div>
    </div>
  );
};

export default EditPdfPopup;
