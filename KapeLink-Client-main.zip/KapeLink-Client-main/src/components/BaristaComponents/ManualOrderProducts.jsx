import React, { useEffect, useState } from "react";
import axios from "axios";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import FloatingSuccessfulNotification from "../Global/FloatingSuccessfulNotification";
import { io } from "socket.io-client";

const ManualOrderProducts = ({
  activeTab,
  searchQuery,
  setOrderSummaryData,
  rowSelections,
  setRowSelections,
}) => {
  const cellformat =
    " md:min-w-14 xl:min-w-24 py-2 text-center md:text-sm xl:text-xl";
  const headerformat =
    "md:min-w-16 xl:min-w-24 md:py-1 xl:py-2 font-medium text-end md:text-sm xl:text-xl whitespace-nowrap border-t-2 border-b-2 border-gray-400";

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  /**
   * Fetches product data from the server, sets product data in state, initializes
   * selection states for each product, and handles loading state.
   *
   * @async
   * @function fetchProductsData
   * @returns {Promise<void>} - Resolves when product data is fetched, selections are initialized, and loading state is updated.
   * @throws Will throw an error if the fetch request fails, also sets loading state to false in case of an error.
   */
  const fetchProductsData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-products"
      );
      setProducts(response.data);

      const initialSelections = response.data.map((item) => ({
        id: item.prodId,
        selectedOption: null,
      }));

      setRowSelections(initialSelections);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching products:", error);
      setLoading(false);
    }
  };

  /**
   * Initializes product data fetch, sets up WebSocket listeners for real-time
   * product updates, and cleans up listeners on component unmount.
   *
   * @function useEffect
   * @returns {void} - This effect has no return.
   */
  useEffect(() => {
    fetchProductsData();

    const socket = io("http://localhost:9000");

    const handleProductUpdate = () => {
      fetchProductsData();
    };

    // Register the event listener for all relevant product events
    socket.on("products", handleProductUpdate);
    socket.on("updateProduct", handleProductUpdate);
    socket.on("updateProductStatus", handleProductUpdate);
    socket.on("deleteProduct", handleProductUpdate);

    return () => {
      socket.off("products", handleProductUpdate);
      socket.off("updateProduct", handleProductUpdate);
      socket.off("updateProductStatus", handleProductUpdate);
      socket.off("deleteProduct", handleProductUpdate);
      socket.disconnect();
    };
  }, []);

  /**
   * Updates the selected option for specific products based on the given product ID
   * and sets the modified selections in the state.
   *
   * @function handleOptionChange
   * @param {string} productId - The ID of the product for which the option is being changed.
   * @param {string} option - The new option to be selected for the product.
   * @param {string} hotId - The ID for the hot variant of the product.
   * @param {string} icedId - The ID for the iced variant of the product.
   * @returns {void} - No return value; updates the row selections in the state.
   */
  const handleOptionChange = (productId, option, hotId, icedId) => {
    const updatedSelections = rowSelections.map((row) => {
      if (row.id === hotId || row.id === icedId) {
        return {
          ...row,
          selectedOption:
            productId === hotId || productId === icedId ? option : null,
        };
      }
      return row;
    });
    setRowSelections(updatedSelections);
  };

  /**
   * Filters the products list based on availability, active category,
   * and search query to generate the filtered data for display.
   *
   * @const {Array} filteredData
   * @returns {Array} - Array of filtered products meeting the specified criteria.
   */
  const filteredData = products.filter((item) => {
    const isAvailableStatus = item.status === "Available";
    const matchesCategory = item.category === activeTab;
    const searchQueryLower = searchQuery.toLowerCase();
    const matchesSearch =
      item.name.toLowerCase().includes(searchQueryLower) ||
      item.menuCategory.toLowerCase().includes(searchQueryLower);

    return isAvailableStatus && matchesCategory && matchesSearch;
  });

  /**
   * Groups the filtered beverage data by menu category and name, then
   * organizes items into hot and iced variants.
   *
   * @const {Object} groupedBeverageData
   * @returns {Object} - Object categorizing beverages by menu category and name, with separate entries for hot and iced types.
   */
  const groupedBeverageData = filteredData.reduce((acc, item) => {
    const menuCategory = item.menuCategory;
    const name = item.name;

    if (!acc[menuCategory]) {
      acc[menuCategory] = {};
    }

    if (!acc[menuCategory][name]) {
      acc[menuCategory][name] = {
        name,
        hot: null,
        iced: null,
      };
    }

    if (item.type === "Hot") {
      acc[menuCategory][name].hot = item;
    } else if (item.type === "Iced") {
      acc[menuCategory][name].iced = item;
    }

    return acc;
  }, {});

  /**
   * Sorts each menu category in `groupedBeverageData` alphabetically by
   * beverage name.
   *
   * @function
   * @returns {void} - Modifies `groupedBeverageData` in place.
   */
  Object.keys(groupedBeverageData).forEach((menuCategory) => {
    groupedBeverageData[menuCategory] = Object.fromEntries(
      Object.entries(groupedBeverageData[menuCategory]).sort((a, b) =>
        a[0].localeCompare(b[0])
      )
    );
  });

  /**
   * Groups the filtered data by menu category for easier display and organization.
   *
   * @const {Object} groupedData
   * @returns {Object} - Object containing arrays of products grouped by menu category.
   */
  const groupedData = filteredData.reduce((acc, item) => {
    const menuCategory = item.menuCategory;

    if (!acc[menuCategory]) {
      acc[menuCategory] = [];
    }

    acc[menuCategory].push(item);
    return acc;
  }, {});

  /**
   * Sorts each category in `groupedData` alphabetically by product name.
   *
   * @function
   * @returns {void} - Modifies `groupedData` in place.
   */
  Object.keys(groupedData).forEach((menuCategory) => {
    groupedData[menuCategory].sort((a, b) => a.name.localeCompare(b.name));
  });

  // Check if there are no products
  const noProductsAvailable = filteredData.length === 0;

  /**
   * Adds a beverage product to the order summary if a valid type is selected (hot or iced),
   * ensuring it is not already in the order summary.
   *
   * @function handleAddClickForBeverages
   * @param {Object} product - The product object containing both hot and iced options.
   * @param {string} type - The selected beverage type ("hot" or "iced").
   * @returns {void} - Updates the order summary with the selected beverage or shows a notification if type is missing.
   */
  const handleAddClickForBeverages = (product, type) => {
    // Ensure that a valid type is selected (either "hot" or "iced")
    if (!type) {
      setNotificationMessage("Please select a type (hot or iced).");
      setShowNotification(true);
      setTimeout(() => setShowNotification(false), 3000); // Hide notification after 3 seconds
      return;
    }

    const selectedOption = type === "Hot" ? product.hot : product.iced;

    if (selectedOption) {
      const item = {
        productId: selectedOption.prodId,
        category: selectedOption.category,
        menuCategory: selectedOption.menuCategory,
        salesReport: selectedOption.salesReport,
        type, // Specify the type (hot/iced)
        name: product.name,
        quantity: 1,
        pricePerItem: selectedOption.basePrice,
        totalPrice: selectedOption.basePrice,
      };

      // Check if the item already exists based on name and type
      setOrderSummaryData((prevItems) => {
        const isDuplicate = prevItems.some(
          (existingItem) =>
            existingItem.name === item.name && existingItem.type === item.type
        );

        // Add only if not a duplicate
        if (!isDuplicate) {
          return [...prevItems, item];
        }

        return prevItems; // Return unchanged if duplicate found
      });
    }
  };

  /**
   * Adds a product to the order summary if it is not present.
   *
   * @function handleAddClick
   * @param {Object} product - The product object to add.
   * @returns {void} - Adds the product to the order summary or returns if duplicate.
   */
  const handleAddClick = (product) => {
    const item = {
      productId: product.prodId,
      category: product.category,
      menuCategory: product.menuCategory,
      salesReport: product.salesReport,
      type: null,
      name: product.name,
      quantity: 1,
      pricePerItem: product.basePrice,
      totalPrice: product.basePrice,
    };

    setOrderSummaryData((prevItems) => {
      const isDuplicate = prevItems.some(
        (existingItem) => existingItem.name === item.name
      );

      // Add only if not a duplicate
      if (!isDuplicate) {
        return [...prevItems, item];
      }

      return prevItems; // Return unchanged if duplicate found
    });
  };

  return (
    <div className="border-collapse border border-gray-400 rounded-lg overflow-y-auto mt-3 2xl:mt-5 h-[580px] 2xl:h-[820px]">
      {loading ? (
        <table className="h-[580px] 2xl:h-[820px] flex flex-col items-center justify-center">
          <thead>
            <tr>
              <th
                className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
              >
                <Player
                  autoplay
                  loop
                  src={loader}
                  style={{ height: "150px", width: "150px" }}
                />
              </th>
            </tr>
          </thead>
        </table>
      ) : (
        <div className="mx-4 2xl:mx-10 my-7">
          {/* If no product is available */}
          {noProductsAvailable ? (
            <table className="flex flex-col items-center">
              <thead>
                <tr>
                  <th
                    className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
                  >
                    No Product Available
                  </th>
                </tr>
              </thead>
            </table>
          ) : (
            <>
              {/* For Beverages */}
              {activeTab === "Beverages" && (
                <>
                  {Object.entries(groupedBeverageData).map(
                    ([menuCategory, products], subIndex) => (
                      <div key={subIndex}>
                        <h1 className="font-semibold text-2xl 2xl:text-3xl mb-3">
                          {menuCategory}
                        </h1>
                        <table className="flex flex-col mb-10">
                          <thead>
                            <tr>
                              <th
                                className={`w-screen whitespace-nowrap border-t-2 border-b-2 border-gray-400`}
                              ></th>
                              <th className={headerformat}>Iced</th>
                              <th className={headerformat}>Price</th>
                              <th className={headerformat}>Hot</th>
                              <th className={headerformat}>Price</th>
                              <th className="px-14 2xl:px-28 whitespace-nowrap border-t-2 border-b-2 border-gray-400"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {Object.values(products).map((product, index) => (
                              <tr key={index}>
                                <td
                                  className={
                                    "w-screen whitespace-nowrap font-medium text-base 2xl:text-2xl text-start pl-2 2xl:pl-5"
                                  }
                                >
                                  {product.name}
                                </td>
                                <td className={cellformat}>
                                  {product.iced && (
                                    <input
                                      type="radio"
                                      name={`Option-${product.name}`}
                                      onChange={() =>
                                        handleOptionChange(
                                          product.iced.prodId,
                                          "Iced",
                                          product.hot?.prodId,
                                          product.iced.prodId
                                        )
                                      }
                                      checked={
                                        rowSelections.find(
                                          (row) =>
                                            row.id === product.iced.prodId
                                        )?.selectedOption === "Iced"
                                      }
                                      className="custom-radio-button"
                                    />
                                  )}
                                </td>
                                <td className={cellformat}>
                                  {product.iced &&
                                    `P${product.iced.basePrice.toFixed(2)}`}
                                </td>
                                <td className={cellformat}>
                                  {product.hot && (
                                    <input
                                      type="radio"
                                      name={`Option-${product.name}`}
                                      onChange={() =>
                                        handleOptionChange(
                                          product.hot.prodId,
                                          "Hot",
                                          product.hot.prodId,
                                          product.iced?.prodId
                                        )
                                      }
                                      checked={
                                        rowSelections.find(
                                          (row) => row.id === product.hot.prodId
                                        )?.selectedOption === "Hot"
                                      }
                                      className="custom-radio-button"
                                    />
                                  )}
                                </td>
                                <td className={cellformat}>
                                  {product.hot &&
                                    `P${product.hot.basePrice.toFixed(2)}`}
                                </td>
                                <td>
                                  <button
                                    className="custom-button-color text-white text-xs 2xl:text-base rounded-full px-6 2xl:px-10 py-1 mx-3 2xl:mx-10"
                                    onClick={() => {
                                      const selectedRow = rowSelections.find(
                                        (row) =>
                                          row.id === product.hot?.prodId ||
                                          row.id === product.iced?.prodId
                                      );
                                      handleAddClickForBeverages(
                                        product,
                                        selectedRow?.selectedOption
                                      );
                                    }}
                                  >
                                    Add
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )
                  )}
                </>
              )}

              {/* For Other Categories */}
              {activeTab !== "Beverages" && (
                <>
                  {Object.entries(groupedData).map(
                    ([menuCategory, products], subIndex) => (
                      <div key={subIndex}>
                        <h1 className="font-semibold text-2xl 2xl:text-3xl mb-3">
                          {menuCategory}
                        </h1>
                        <table className="flex flex-col items-center mb-10">
                          <thead>
                            <tr>
                              <th
                                className={`w-screen px-10 font-medium whitespace-nowrap text-xl border-t-2 border-b-2 border-gray-400 text-start`}
                              ></th>
                              <th className="min-w-24 py-1 2xl:py-2 font-medium text-center text-sm 2xl:text-xl whitespace-nowrap border-t-2 border-b-2 border-gray-400">
                                Price
                              </th>
                              <th className="px-10 2xl:px-24 whitespace-nowrap border-t-2 border-b-2 border-gray-400"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {products.map((product, index) => (
                              <tr key={index}>
                                <td
                                  className={
                                    "w-screen font-medium text-base 2xl:text-2xl text-start pl-2 2xl:pl-5"
                                  }
                                >
                                  {product.name}
                                </td>
                                <td className="min-w-14 2xl:min-w-24 py-2 text-center text-sm 2xl:text-xl">
                                  P{product.basePrice.toFixed(2)}
                                </td>
                                <td>
                                  <button
                                    className="custom-button-color text-white text-xs 2xl:text-base rounded-full px-6 2xl:px-10 py-1 mx-3 2xl:mx-10"
                                    onClick={() => handleAddClick(product)}
                                  >
                                    Add
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )
                  )}
                </>
              )}

              <FloatingSuccessfulNotification
                showNotification={showNotification}
                notificationMessage={notificationMessage}
              />
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ManualOrderProducts;
