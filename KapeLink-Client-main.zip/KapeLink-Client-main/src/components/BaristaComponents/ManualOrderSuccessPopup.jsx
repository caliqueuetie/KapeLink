import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/manualPlaceOrder.json";

/**
 * ManualOrderSuccessPopup component displays a popup to notify the user that their order has been successfully placed.
 * It includes an animation and a button to close the popup.
 *
 * @function ManualOrderSuccessPopup
 * @param {Object} props - The component's props.
 * @param {Function} props.setOrderSuccessPopup - Function to control the visibility of the popup.
 * @returns {JSX.Element} - Renders the success popup with animation and close button.
 */
const ManualOrderSuccessPopup = ({ setOrderSuccessPopup }) => {
  /**
   * Handles closing of the popup when the "Cool!" button is clicked.
   * It sets the visibility of the popup to false.
   *
   * @function handleClosePopup
   * @returns {void}
   */
  const handleClosePopup = () => {
    setOrderSuccessPopup(false);
  };
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="w-[40%] xl:w-[40%] 2xl:w-[30%] bg-white py-10 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <div className="flex flex-col text-center items-center sm:mb-5">
          <Player
            autoplay
            loop
            src={loader}
            style={{ height: "200px", width: "200px" }}
          />
          <h2 className="text-sm md:text-lg lg:text-xl mx-4 mb-3 mt-5">
            Order Placed Successfully!
          </h2>
          <button
            onClick={handleClosePopup}
            className="custom-button-color text-white text-xs sm:text-base font-light sm:font-medium px-4 py-1 sm:py-2 rounded-lg"
          >
            Cool!
          </button>
        </div>
      </div>
    </div>
  );
};

export default ManualOrderSuccessPopup;
