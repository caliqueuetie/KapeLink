import React, { useEffect } from "react";
import { SquareMinus, SquarePlus, Trash2 } from "lucide-react";

const OrderDetailsPane = ({
  orderSummaryData,
  setOrderSummaryData,
  setTotalOrderPrice,
}) => {
  /**
   * Increases the quantity of a specific item and type in the order summary.
   *
   * @function increaseQuantity
   * @param {string} itemName - The name of the item.
   * @param {string} itemType - The type of the item (e.g., hot or iced).
   * @returns {void} - Updates the quantity and total price for the specified item.
   */
  const increaseQuantity = (itemName, itemType) => {
    const updatedOrderData = orderSummaryData.map((item) => {
      if (item.name === itemName && item.type === itemType) {
        const newQuantity = item.quantity + 1;
        const newTotalPrice = newQuantity * item.pricePerItem;
        return { ...item, quantity: newQuantity, totalPrice: newTotalPrice };
      }
      return item;
    });
    setOrderSummaryData(updatedOrderData);
  };

  /**
   * Decreases the quantity of a specific item and type in the order summary.
   *
   * @function decreaseQuantity
   * @param {string} itemName - The name of the item.
   * @param {string} itemType - The type of the item (e.g., hot or iced).
   * @returns {void} - Decreases the quantity and total price if quantity is greater than 1.
   */
  const decreaseQuantity = (itemName, itemType) => {
    const updatedOrderData = orderSummaryData.map((item) => {
      if (
        item.name === itemName &&
        item.type === itemType &&
        item.quantity > 1
      ) {
        const newQuantity = item.quantity - 1;
        const newTotalPrice = newQuantity * item.pricePerItem;
        return { ...item, quantity: newQuantity, totalPrice: newTotalPrice };
      }
      return item;
    });
    setOrderSummaryData(updatedOrderData);
  };

  /**
   * Manually sets the quantity of a specific item and type in the order summary.
   *
   * @function handleQuantityChange
   * @param {string} itemName - The name of the item.
   * @param {string} itemType - The type of the item (e.g., hot or iced).
   * @param {string} value - The new quantity value as a string input.
   * @returns {void} - Updates the quantity and total price for the specified item if input is valid.
   */
  const handleQuantityChange = (itemName, itemType, value) => {
    const parsedQuantity = parseInt(value, 10);
    if (isNaN(parsedQuantity) || parsedQuantity < 1) return;

    const updatedOrderData = orderSummaryData.map((item) => {
      if (item.name === itemName && item.type === itemType) {
        const newTotalPrice = parsedQuantity * item.pricePerItem;
        return { ...item, quantity: parsedQuantity, totalPrice: newTotalPrice };
      }
      return item;
    });
    setOrderSummaryData(updatedOrderData);
  };

  /**
   * Removes a specific item and type from the order summary.
   *
   * @function handleRemoveItem
   * @param {string} itemName - The name of the item.
   * @param {string} itemType - The type of the item (e.g., hot or iced).
   * @returns {void} - Updates the order summary by removing the specified item.
   */
  const handleRemoveItem = (itemName, itemType) => {
    const updatedOrderData = orderSummaryData.filter(
      (item) => !(item.name === itemName && item.type === itemType)
    );
    setOrderSummaryData(updatedOrderData);
  };

  /**
   * Calculates and updates the total order price whenever the order summary data changes.
   *
   * @function useEffect - Total Price Calculation Effect
   * @returns {void} - Sets the total order price based on the current items in the order summary.
   */
  useEffect(() => {
    const calculatedTotalPrice = orderSummaryData.reduce((total, item) => {
      return total + item.totalPrice;
    }, 0);
    setTotalOrderPrice(calculatedTotalPrice);
  }, [orderSummaryData, setTotalOrderPrice]);

  return (
    <div className="mx-8 h-60 2xl:h-[52%] overflow-auto items-center">
      {orderSummaryData.map((item) => {
        const key = `${item.name}-${item.type || "default"}`;
        return (
          <div className="w-full flex flex-col relative" key={key}>
            <div className="text-xl font-medium">
              <div className="flex pb-5">
                <h1 className="md:text-base mr-28">
                  {item.type ? `${item.name} (${item.type})` : item.name}
                </h1>
                <Trash2
                  size={23}
                  className="cursor-pointer text-red-700 absolute right-1"
                  onClick={() => handleRemoveItem(item.name, item.type)}
                />
              </div>

              <div className="flex items-center">
                <SquareMinus
                  onClick={() => decreaseQuantity(item.name, item.type)}
                  className="text-gray-500 cursor-pointer"
                />
                <input
                  type="text"
                  value={item.quantity}
                  onChange={(e) =>
                    handleQuantityChange(item.name, item.type, e.target.value)
                  }
                  className="mx-1 text-center border border-gray-300 rounded w-10 text-base 2xl:text-lg"
                />
                <SquarePlus
                  onClick={() => increaseQuantity(item.name, item.type)}
                  className="text-gray-500 cursor-pointer"
                />
                <span className="flex-grow text-right md:text-base">
                  P{item.totalPrice.toFixed(2)}
                </span>
              </div>
            </div>
            <hr className="border-t-1 border-gray-300 my-2"></hr>
          </div>
        );
      })}
    </div>
  );
};

export default OrderDetailsPane;
