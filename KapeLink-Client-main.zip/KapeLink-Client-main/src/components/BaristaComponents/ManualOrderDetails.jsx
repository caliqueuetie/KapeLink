import React, { useState, useEffect, useCallback } from "react";
import OrderDetailsPane from "./OrderDetailsPane";
import axios from "axios";
import ManualOrderSuccessPopup from "./ManualOrderSuccessPopup";

const ManualOrderDetails = ({
  orderSummaryData,
  setOrderSummaryData,
  setRowSelections,
}) => {
  const [selectedOption, setSelectedOption] = useState(true);
  const [totalOrderPrice, setTotalOrderPrice] = useState(0);
  const [payments, setPayments] = useState([]);
  const [selectedPaymentOption, setSelectedPaymentOption] = useState(0);
  const [orderSuccessPopup, setOrderSuccessPopup] = useState(false);

  // Continuously check orderSummaryData contents
  useEffect(() => {}, [orderSummaryData]);

  /**
   * Clears the order details pane, resetting the order summary and payment option.
   *
   * @function handleClearOrderDetails
   * @returns {void} - Resets order summary data and payment option to default.
   */
  const handleClearOrderDetails = () => {
    setOrderSummaryData([]);
    setSelectedPaymentOption(0);
  };

  /**
   * Sets the dining option for the order (dine-in or take-out) and updates the order details accordingly.
   *
   * @function handleOptionChange
   * @param {boolean} option - Indicates whether the order is dine-in (true) or take-out (false).
   * @returns {void} - Updates the dining option in order details.
   */
  const handleOptionChange = (option) => {
    setSelectedOption(option);
    setOrderDetails((prevDetails) => ({
      ...prevDetails,
      dineIn: option,
    }));
  };

  /**
   * Updates the payment option in order details based on user selection.
   *
   * @function handlePaymentOptionChange
   * @param {Object} e - Event object containing the selected payment option.
   * @returns {void} - Sets the selected payment method and updates order details.
   */
  const handlePaymentOptionChange = (e) => {
    const selectedValue = e.target.value;
    setSelectedPaymentOption(selectedValue);
    setOrderDetails((prevDetails) => ({
      ...prevDetails,
      paymentMethodId: selectedValue,
    }));
  };

  /**
   * Fetches available online payment options from the server.
   *
   * @async
   * @function useEffect (Fetch Payment Methods)
   * @returns {Promise<void>} - Sets the payment options from server response.
   * @throws Will log an error if fetching payment methods fails.
   */
  useEffect(() => {
    axios
      .get("http://localhost:9000/api/kape-link/get-payment-methods")
      .then((response) => {
        setPayments(response.data);
      })
      .catch((error) => console.error("Error fetching products:", error));
  }, []);

  // Order Details structure to be posted in the server
  const today = new Date().toISOString().split("T")[0]; // Formats date as 'YYYY-MM-DD'
  const [orderDetails, setOrderDetails] = useState({
    customerId: null,
    items: [],
    orderDate: today,
    timeOrdered: "",
    orderStatus: "Complete",
    orderOption: "In-store",
    dineIn: true,
    paymentMethodId: "",
  });

  /**
   * Debounce utility function to limit the rate at which a function can fire.
   *
   * @function debounce
   * @param {Function} func - The function to debounce.
   * @param {number} delay - Delay time in milliseconds.
   * @returns {Function} - Returns a debounced version of the input function.
   */
  function debounce(func, delay) {
    let timeoutId;
    return (...args) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        func(...args);
      }, delay);
    };
  }

  /**
   * Places an in-store order, including current order items and time.
   *
   * @async
   * @function handlePlaceOrder
   * @returns {Promise<void>} - Submits the order with current time and order details.
   * @throws Will log an error if placing the order fails.
   */
  const handlePlaceOrder = async () => {
    // Create a local updatedOrderDetails with updated items and timeOrdered
    const currentTime = new Date()
      .toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
        timeZone: "Asia/Manila",
      })
      .toLowerCase();

    const updatedOrderDetails = {
      ...orderDetails,
      items: orderSummaryData,
      timeOrdered: currentTime, // Set the current time in the desired format
    };

    /**
     * Submits the order to the server and resets order-related states upon success.
     *
     * @async
     * @function placeOrder
     * @returns {Promise<void>} - Sends order data to the server, shows a success popup, and resets order states to default.
     * @throws Will log an error if order submission fails, displaying server or generic error message.
     */
    try {
      // Make POST request to server
      const response = await axios.post(
        "http://localhost:9000/api/kape-link/create-order",
        updatedOrderDetails
      );
      setOrderSuccessPopup(true);
      // Return all use states to default values
      setOrderSummaryData([]);
      setSelectedOption(true);
      setTotalOrderPrice(0);
      setSelectedPaymentOption(0);
      setRowSelections((prevSelections) =>
        prevSelections.map((row) => ({
          ...row,
          selectedOption: null,
        }))
      );
    } catch (error) {
      console.error(
        "Error placing order:",
        error.response?.data?.error || error.message
      );
    }
  };

  // Use debounce on handlePlaceOrder
  const debouncedHandlePlaceOrder = useCallback(
    debounce(handlePlaceOrder, 500),
    [handlePlaceOrder]
  );

  // Checks if there is added item in the order details and if there is a selected payment option
  const isDisabled = !selectedPaymentOption || orderSummaryData.length === 0;

  return (
    <div className="w-full border-collapse border border-gray-400 rounded-lg mt-3 2xl:mt-5 h-[580px] 2xl:h-[820px]">
      <div className="flex justify-center mt-6 2xl:mt-10">
        <button
          className={`px-6 xl:px-8 2xl:px-10 2xl:text-lg text-sm py-1 mx-2 border-2 border-black rounded-full whitespace-nowrap ${
            selectedOption === true
              ? "bg-black text-white"
              : "bg-white text-black"
          }`}
          onClick={() => handleOptionChange(true)}
        >
          Dine In
        </button>
        <button
          className={`px-6 xl:px-8 2xl:px-10 2xl:text-lg text-sm py-1 mx-2 border-2 border-black rounded-full whitespace-nowrap ${
            selectedOption === false
              ? "bg-black text-white"
              : "bg-white text-black"
          }`}
          onClick={() => handleOptionChange(false)}
        >
          Take Out
        </button>
      </div>

      <h1 className="font-semibold text-xl 2xl:text-2xl ml-7 2xl:ml-10 my-5">
        Order Details
      </h1>
      <OrderDetailsPane
        orderSummaryData={orderSummaryData}
        setOrderSummaryData={setOrderSummaryData}
        setTotalOrderPrice={setTotalOrderPrice}
      />
      <div className="md:mx-5 xl:mx-10 flex flex-col justify-between">
        <hr className="border-t-2 border-gray-300 border-dashed w-full my-1 2xl:my-2"></hr>
        <span className="text-base 2xl:text-xl font-medium text-right">
          Total Amount:{" "}
          <span className="font-normal">
            P
            {totalOrderPrice.toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        </span>
        <hr className="border-t-2 border-gray-300 border-dashed w-full my-1 2xl:my-2"></hr>

        <div className="mb-2 2xl:mb-4">
          <label
            className="font-semibold text-base 2xl:text-xl mt-0 2xl:mt-5"
            htmlFor="paymentOption"
          >
            Payment Method
          </label>
          <select
            className="w-full px-3 py-1 border mt-1 2xl:mt-2 border-gray-300 rounded-md text-sm 2xl:text-base"
            id="paymentOption"
            onChange={handlePaymentOptionChange}
            value={selectedPaymentOption}
            required
          >
            <option value="">Select Payment</option>
            {payments
              .filter((payment) => payment.name !== "Cash on Delivery")
              .map((payment, index) => (
                <option key={index} value={payment.opid}>
                  {payment.name}
                </option>
              ))}
          </select>
        </div>

        <div className="flex gap-2 2xl:gap-4 ml-auto">
          <button
            className={`${
              isDisabled
                ? "bg-gray-300 cursor-not-allowed"
                : "custom-button-color text-white"
            } font-medium rounded-full px-4 2xl:px-7 py-2 whitespace-nowrap xl:text-sm 2xl:text-base`}
            onClick={debouncedHandlePlaceOrder}
            disabled={isDisabled}
          >
            Place Order
          </button>

          <button
            className="custom-button-black text-white font-medium rounded-full px-6 2xl:px-7 py-2 xl:text-sm 2xl:text-base"
            onClick={handleClearOrderDetails}
          >
            Clear
          </button>
        </div>
      </div>
      {orderSuccessPopup && (
        <ManualOrderSuccessPopup setOrderSuccessPopup={setOrderSuccessPopup} />
      )}
    </div>
  );
};

export default ManualOrderDetails;
