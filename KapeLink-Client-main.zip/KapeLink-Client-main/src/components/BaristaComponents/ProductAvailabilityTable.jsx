import { EyeOff, Eye } from "lucide-react";
import React, { useEffect, useState } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import axios from "axios";

/**
 * Component to display and manage the product availability table with sorting, filtering, and status toggling functionality.
 *
 * @component ProductAvailabilityTable
 * @param {string} activeTab - The active tab to filter products by availability status (e.g., "All", "Available", "Hidden").
 * @param {string} searchQuery - The search query for filtering products by name, category, menu category, or status.
 *
 * @returns {JSX.Element} - Returns the JSX for rendering the product availability table with sorting, filtering, and status toggling.
 */
const ProductAvailabilityTable = ({ activeTab, searchQuery }) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sortField, setSortField] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubCategory, setSelectedSubCategory] = useState("");
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [subCategoryOptions, setSubCategoryOptions] = useState([]);

  const cellFormat =
    "border-b border-gray-400 p-10 text-center text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4";
  const headerFormat =
    "w-screen p-3 font-semibold whitespace-nowrap text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";

  /**
   * Fetches product data from the API and sets the category options.
   *
   * @async
   * @function fetchData
   */
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/all-products"
        );
        const result = response.data;
        setData(result);

        const categories = [...new Set(result.map((item) => item.category))];
        setCategoryOptions(categories);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  /**
   * Updates the subcategory options based on the selected category.
   *
   * @function useEffect
   * @param {string} selectedCategory - The category selected by the user.
   * @param {Array} data - The product data array.
   */
  useEffect(() => {
    const filteredSubCategories = selectedCategory
      ? [
          ...new Set(
            data
              .filter((item) => item.category === selectedCategory)
              .map((item) => item.menuCategory)
          ),
        ]
      : [];
    setSubCategoryOptions(filteredSubCategories);
  }, [selectedCategory, data]);

  /**
   * Toggles the availability status of a product.
   *
   * @async
   * @function toggleVisibility
   * @param {string} prodId - The product ID of the item being toggled.
   * @param {string} currentStatus - The current availability status of the product.
   */
  const toggleVisibility = async (prodId, currentStatus) => {
    const newStatus =
      currentStatus === "Available" ? "Unavailable" : "Available";
    try {
      await axios.patch(
        `http://localhost:9000/api/kape-link/update-product-status/${prodId}`,
        { status: newStatus }
      );

      setData((prevData) =>
        prevData.map((item) =>
          item.prodId === prodId ? { ...item, status: newStatus } : item
        )
      );
    } catch (error) {
      console.error(
        "Error updating product status:",
        error.response ? error.response.data : error.message
      );
    }
  };

  /**
   * Handles sorting of the product data based on the selected field.
   *
   * @function handleSort
   * @param {string} field - The field to sort by (e.g., name, category).
   */
  const handleSort = (field) => {
    const order = sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(order);
  };

  /**
   * Retrieves the value of a given field from a product, converting it to lowercase for case-insensitive comparison.
   *
   * @function getValue
   * @param {Object} item - The product item.
   * @param {string} field - The field to retrieve (e.g., name, category).
   * @returns {string} - The value of the field, converted to lowercase.
   */
  const getValue = (item, field) => {
    return item[field] ? item[field].toLowerCase() : "";
  };

  /**
   * Sorts the product data based on the selected sort field and order.
   *
   * @function sortedData
   * @returns {Array} - Sorted product data array.
   */
  const sortedData = [...data].sort((a, b) => {
    const valueA = getValue(a, sortField);
    const valueB = getValue(b, sortField);
    return valueA < valueB
      ? sortOrder === "asc"
        ? -1
        : 1
      : valueA > valueB
      ? sortOrder === "asc"
        ? 1
        : -1
      : 0;
  });

  /**
   * Filters the product data based on the selected category, subcategory, tab, and search query.
   *
   * @function filteredData
   * @returns {Array} - Filtered product data array.
   */
  const filteredData = sortedData.filter((item) => {
    const matchesCategory = selectedCategory
      ? item.category === selectedCategory
      : true;
    const matchesSubCategory = selectedSubCategory
      ? item.menuCategory === selectedSubCategory
      : true;
    const matchesTab =
      activeTab === "All" ||
      (activeTab === "Available" && item.status === "Available") ||
      (activeTab === "Hidden" && item.status === "Unavailable");
    const matchesSearchQuery = searchQuery
      ? getValue(item, "name").includes(searchQuery.toLowerCase()) ||
        getValue(item, "category").includes(searchQuery.toLowerCase()) ||
        getValue(item, "menuCategory").includes(searchQuery.toLowerCase()) ||
        getValue(item, "status").includes(searchQuery.toLowerCase())
      : true;

    return (
      matchesCategory && matchesSubCategory && matchesTab && matchesSearchQuery
    );
  });

  /**
   * Determines the sort arrow direction based on the current sorting field and order.
   *
   * @function getSortArrow
   * @param {string} field - The field being sorted (e.g., name, category).
   * @returns {string|null} - The sort direction arrow (↑ or ↓), or null if no sorting is applied.
   */
  const getSortArrow = (field) => {
    if (sortField !== field) return null;
    return sortOrder === "asc" ? "↑" : "↓";
  };

  /**
   * Resets the category and subcategory filters.
   *
   * @function resetFilters
   */
  const resetFilters = () => {
    setSelectedCategory("");
    setSelectedSubCategory("");
  };

  return (
    <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[550px] 2xl:h-[760px] max-[640px]:max-w-80">
      <div className="flex justify-between p-4">
        <div className="flex items-center">
          <select
            className="border rounded mr-2 px-2 md:p-2"
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setSelectedSubCategory("");
            }}
          >
            <option value="">Select Category</option>
            {categoryOptions.map((category, index) => (
              <option key={index} value={category}>
                {category}
              </option>
            ))}
          </select>
          <select
            className="border rounded mr-3 px-2 md:p-2"
            value={selectedSubCategory}
            onChange={(e) => setSelectedSubCategory(e.target.value)}
          >
            <option value="">Select Subcategory</option>
            {subCategoryOptions.map((subCategory, index) => (
              <option key={index} value={subCategory}>
                {subCategory}
              </option>
            ))}
          </select>
        </div>
        <button
          className="bg-gray-500 hover:bg-gray-400 duration-200 text-white font-normal ml-5 py-1 px-5 border border-transparent rounded-md max-[640px]:py-0 max-[640px]:px-5 max-[640px]:text-sm"
          onClick={resetFilters}
        >
          Reset
        </button>
      </div>

      {loading ? (
        <table className="h-[469px] 2xl:h-[679px] flex flex-col items-center justify-center">
          <thead>
            <tr>
              <th
                className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
              >
                <Player
                  autoplay
                  loop
                  src={loader}
                  style={{ height: "150px", width: "150px" }}
                />
              </th>
            </tr>
          </thead>
        </table>
      ) : (
        <table>
          <thead className="sticky top-0 bg-white z-10">
            <tr className="border-b border-gray-400 bg-gray-100">
              <th className={headerFormat} onClick={() => handleSort("name")}>
                Name {getSortArrow("name")}
              </th>
              <th className={headerFormat}>Category</th>
              <th className={headerFormat}>Subcategory</th>
              <th className={headerFormat}>Status</th>
              <th className={headerFormat}>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map((item) => (
                <tr key={item.prodId}>
                  <td className={cellFormat}>
                    {item.name} {item.type !== null ? `(${item.type})` : ""}
                  </td>
                  <td className={cellFormat}>{item.category}</td>
                  <td className={cellFormat}>{item.menuCategory}</td>
                  <td className={cellFormat}>{item.status}</td>
                  <td
                    className={`${cellFormat} text-center`}
                    style={{ verticalAlign: "middle" }}
                  >
                    <div className="relative inline-block align-middle">
                      <button
                        onClick={() =>
                          toggleVisibility(item.prodId, item.status)
                        }
                        className="flex items-center custom-button-black text-white px-5 py-2 rounded-full"
                      >
                        <span className="mr-2">
                          {item.status === "Available" ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </span>
                        {item.status === "Available" ? "Hide" : "Show"}
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center p-4">
                  No products found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ProductAvailabilityTable;
