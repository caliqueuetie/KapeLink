import React, { useState } from "react";
import { X, Loader } from "lucide-react";
import { useNavigate } from "react-router-dom";
import axios from "/axios.config";

const LogoutPopup = ({ setLogoutPopupOpen, user }) => {
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();
  
  const handleLogout = async () => {
    setLoading(true);



    try {
      await axios.post("/save-subscription", {
        subscription: null,  // This clears the push subscription
        userId: user,
      });


      await axios.post("/logout");

      // Clear local storage and cookies
      localStorage.clear();
      document.cookie.split(";").forEach((cookie) => {
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie =
          name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
      });

      // Redirect to login page after successful logout
      navigate("/login");
    } catch (error) {
      console.error("Logout failed", error);
      setErrorMessage("Failed to log out. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleClosePopup = () => {
    setLogoutPopupOpen(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="w-[34%] xl:w-[25%] bg-white py-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-8">
        <div className="text-center sm:mb-5">
          <h2 className="text-sm md:text-lg lg:text-xl mx-4">
            Are you sure you want to log out?
          </h2>
        </div>

        {errorMessage && (
          <div className="mb-4 text-red-500 text-center">{errorMessage}</div>
        )}

        <div className="flex justify-center space-x-2 sm:space-x-4 mt-4">
          <button
            onClick={handleLogout}
            disabled={loading}
            className={`text-xs sm:text-base font-light sm:font-medium px-4 py-1 sm:py-2 rounded-lg 
            ${
              loading
                ? "bg-gray-400 cursor-not-allowed"
                : "text-white bg-red-500 hover:bg-red-400 duration-300"
            }`}
          >
            {loading ? (
              <Loader className="animate-spin" size={20} />
            ) : (
              "Log Out"
            )}
          </button>
          <button
            onClick={handleClosePopup}
            className="bg-gray-300 hover:bg-gray-200 duration-300 text-gray-700 text-xs sm:text-base font-light sm:font-medium px-4 py-1 sm:py-2 rounded-lg"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default LogoutPopup;
