import React from "react";
import { useFloating } from "@floating-ui/react";
import { motion } from "framer-motion";

const FloatingSuccessfulNotification = ({
  showNotification,
  notificationMessage,
}) => {
  const { refs } = useFloating({
    placement: "top",
  });
  return (
    <>
      {/* Floating Notification */}
      {showNotification && (
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          ref={refs.setFloating}
          className="fixed inset-x-0 top-11 flex items-center justify-center"
        >
          <div className="p-4 bg-[#A79277] text-xs xl:text-base text-white rounded-lg z-50">
            {notificationMessage}
          </div>
        </motion.div>
      )}
    </>
  );
};

export default FloatingSuccessfulNotification;
