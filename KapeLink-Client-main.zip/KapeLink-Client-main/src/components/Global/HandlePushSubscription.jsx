// pushSubscription.js
import axios from "axios";

const vapidPublicKey = "BPS_7mTXWgrxKlol9cuAajX5WQ5GnZpQ7x3F367aWNAgCuP-9TMSL6bEcgSri1HbGFxp9Jo64OxOfE-ySQEPURI";

/**
 * Handles push subscription by requesting notification permission, checking if the user already has a subscription,
 * and saving a new or updated subscription to the backend.
 *
 * @async
 * @function HandlePushSubscription
 * @returns {Promise<void>} - Handles push subscription logic, including checking existing subscription status and saving a new or updated subscription to the server
 */
export const HandlePushSubscription = async () => {
  
  // Retrieve loginCreds from localStorage
  const loginData = JSON.parse(localStorage.getItem("loginSuccess"));
  const loginCreds = loginData?.loginCreds;

  if (!loginCreds) {
    console.warn("No login credentials found in localStorage.");
    return;
  }

  // Check for service worker and PushManager support in the browser
  if ("serviceWorker" in navigator && "PushManager" in window) {
    try {
      // Request permission for notifications if not already granted
      if (Notification.permission === "default") {
        const permission = await Notification.requestPermission();
        if (permission !== "granted") {
          console.warn("Notifications permission was denied or dismissed");
          return;
        }
      }

      if (Notification.permission === "granted") {
        const registration = await navigator.serviceWorker.ready;
        const existingSubscription = await registration.pushManager.getSubscription();

        // Check if a subscription already exists in the database        
        const response = await axios.get(`/check-subscription/${loginCreds}`);
        const subscriptionInDb = response.data.subscription;

        // If no subscription exists, subscribe the user
        if (!subscriptionInDb) {
          const newSubscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: vapidPublicKey,
          });

          // Save the new subscription to the backend
          await axios.post("/save-subscription", {
            subscription: newSubscription,
            userId: loginCreds,
          });
        } else if (existingSubscription) {
          // If an existing subscription doesn't match the one in the database, update it
          if (existingSubscription.endpoint !== subscriptionInDb.endpoint) {
            await axios.post("/save-subscription", {
              subscription: existingSubscription,
              userId: loginCreds,
            });
          }
        } else {
          // If no subscription exists, subscribe the user
          const newSubscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: vapidPublicKey,
          });
          
          // Save the new subscription to the backend
          await axios.post("/save-subscription", {
            subscription: newSubscription,
            userId: loginCreds,
          });
        }
      } else {
        console.warn("Push notifications are not allowed by the user");
      }
    } catch (error) {
      console.error("Push subscription failed:", error);
    }
  } else {
    console.warn("Push notifications are not supported in this browser.");
  }
};
