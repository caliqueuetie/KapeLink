import React from "react";

const ListOfItems = ({ selectedOrder }) => {
  const cellFormat =
    "border-b border-gray-400 py-10 2xl:px-10 text-gray-600 text-center lg:text-base text-xs 2xl:font-normal font-thin 2xl:p-10 px-2 py-8 whitespace-nowrap";
  const headerFormat =
    "cursor-pointer w-screen lg:text-base text-xs lg:font-semibold font-normal lg:p-3 p-1";

  // Make this table dynamic based on the database, the values here are just placeholders and can be
  // removed after the implementation.
  return (
    <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto mt-5 h-[400px]">
      <table>
        <thead className="sticky top-0 bg-white border-b border-gray-400">
          <tr className="border-b border-gray-400">
            <th className={headerFormat}>Item</th>
            <th className={headerFormat}>Category</th>
            <th className={headerFormat}>Quantity</th>
            <th className={headerFormat}>Unit Cost</th>
            <th className={headerFormat}>Cost</th>
          </tr>
        </thead>
        <tbody>
          {selectedOrder.items.map((item, index) => (
            <tr key={index}>
              <td className={cellFormat}>
                {item.name} {item.name} {item?.type && `(${item.type})`}
                {" "}
              </td>
              <td className={cellFormat}>{item.category}</td>
              <td className={cellFormat}>{item.quantity}</td>
              <td className={cellFormat}>
                P
                {item.pricePerItem.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </td>
              <td className={cellFormat}>
  P
  {(item.pricePerItem * item.quantity).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}
</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ListOfItems;
