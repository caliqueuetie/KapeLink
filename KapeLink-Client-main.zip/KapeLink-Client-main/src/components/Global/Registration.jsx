import React, { useState } from "react";
import TermsAndConditions from "./TermsAndConditions";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import bcrypt from "bcryptjs";
import kapeLinkLogo from "../../images/KapeLinkNameLogo.png";
import { Loader, Eye, EyeOff } from "lucide-react";

const Registration = () => {
  const navigate = useNavigate();
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [loading, setLoading] = useState(false); // Loading state
  const [showPassword, setShowPassword] = useState(false); // New state for password visibility
  const [showConfirmPassword, setShowConfirmPassword] = useState(false); // New state for password visibility
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    contactNumber: "+639",
    email: "", // Add email field
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});

  const toggleTermsPopup = async () => {
    setLoading(true); // Start loading state

    // Await form validation
    const isValid = await validateForm();
    setLoading(false); // Stop loading state after validation completes

    if (isValid) {
      setIsTermsOpen(!isTermsOpen);
    }
  };
  const validateForm = async () => {
    const newErrors = {};

    // Check if all fields are filled out
    if (!formData.firstName) newErrors.firstName = "First name is required.";
    if (!formData.lastName) newErrors.lastName = "Last name is required.";

    // Validate email field
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) {
      newErrors.email = "Email is required.";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    try {
      const response = await axios.get(`/check-user/${formData.email}`);

      if (response.data.exists) {
        newErrors.email = "That email is already taken.";
      }
    } catch (error) {

    }

    if (!formData.password) newErrors.password = "Password is required.";
    if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters long.';
    }

    if (!formData.confirmPassword)
      newErrors.confirmPassword = "Please confirm your password.";


    // Validate contact number (must start with +639 and have exactly 9 digits after the prefix)
    const contactRegex = /^\+639\d{9}$/;
    if (!formData.contactNumber) {
      newErrors.contactNumber = "Contact number is required.";
    } else if (!contactRegex.test(formData.contactNumber)) {
      newErrors.contactNumber = "Invalid contact number.";
    }

    try {
      const response = await axios.get(`/check-user/${formData.contactNumber}`);
      if (response.data.exists) {
        newErrors.contactNumber = "That number is already taken.";
      }
    } catch (error) {

    }

    // Validate that password and confirm password match
    if (
      formData.password &&
      formData.confirmPassword &&
      formData.password !== formData.confirmPassword
    ) {
      newErrors.confirmPassword = "Passwords do not match.";
    }

    setErrors(newErrors);

    // Return true if there are no errors
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    if (!loading) { // Prevent input change during loading
      const { id, value } = e.target;

      if (id === "firstName" || id === "lastName") {
        // Remove any symbols or numbers, allow only letters and spaces
        let filteredValue = value.replace(/[^a-zA-Z\s]/g, "");

        // Reduce multiple spaces to a single space
        filteredValue = filteredValue.replace(/\s+/g, " ");

        setFormData({ ...formData, [id]: filteredValue });
      } else if (id === "contactNumber") {
        // Ensure contact number starts with +639 and restrict the remaining characters to 9 digits
        const prefix = "+639";
        if (value.startsWith(prefix)) {
          const remainingNumbers = value.slice(4);
          if (/^\d*$/.test(remainingNumbers) && remainingNumbers.length <= 9) {
            setFormData({ ...formData, contactNumber: value });
          }
        } else if (value === "") {
          // Allow clearing the field if needed
          setFormData({ ...formData, contactNumber: prefix });
        }
      } else {
        setFormData({ ...formData, [id]: value });
      }
    }
  };

  const handleTermsConfirm = async (setLoading) => {
    if (await validateForm()) {
      handleFormSubmit(setLoading); // Call the handleFormSubmit with loading state
    }
  };

  const handleFormSubmit = async (setLoading) => {
    setLoading(true); // Set loading state to true

    // Trim firstName and lastName here
    const trimmedFirstName = formData.firstName.trim();
    const trimmedLastName = formData.lastName.trim();

    try {
      // Hash the password before submission
      const saltRounds = 12; // Adjust the salt rounds as needed
      const hashedPassword = await bcrypt.hash(formData.password, saltRounds);

      // Fetch the latest user ID from the database
      const customersResponse = await axios.get("/get-latest");
      const customers = customersResponse.data;

      // Get the highest userId among users and increment it by 1
      const latestUserId = customers.reduce((maxId, customer) => {
        const currentUserId = parseInt(customer.userId, 10); // Convert to integer
        return currentUserId > maxId ? currentUserId : maxId;
      }, 0);

      const newUserId = latestUserId + 1; // Increment by 1

      // Create a new customer with the new userId
      const response = await axios.post("/create-customer", {
        ...formData,
        firstName: trimmedFirstName,
        lastName: trimmedLastName,
        password: hashedPassword,
        role: "customer",
        status: "temporary",
        userId: newUserId,
        otp: "",
        pushSubscription: null,
      });

      navigate("/successful-registration", {
        state: { formData: response.data },
      });
    } catch (error) {
      console.error("Error creating user:", error);
      setErrors({ submit: "Error creating user. Please try again." });
    } finally {
      setLoading(false);
    }
  };

  // Toggle password visibility
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  // Toggle password visibility
  const toggleShowConfirmPassword = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  return (
    <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
      <div className="w-full max-w-md p-7 sm:bg-white sm:shadow-md rounded-lg">
        <div className="mb-6 text-center">
          <img
            src={kapeLinkLogo}
            alt="Logo"
            className="w-1/2 mx-auto my-10"
          />
        </div>
        <form>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="mb-4">
              <label
                className="block text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="firstName"
              >
                First Name
              </label>
              <input
                type="text"
                id="firstName"
                className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                placeholder="Enter your first name"
                value={formData.firstName}
                onChange={handleInputChange}
                disabled={loading} // Disable input during loading
              />
              {errors.firstName && (
                <p className="text-red-500 text-sm">{errors.firstName}</p>
              )}
            </div>
            <div className="mb-4">
              <label
                className="block text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="lastName"
              >
                Last Name
              </label>
              <input
                type="text"
                id="lastName"
                className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                placeholder="Enter your last name"
                value={formData.lastName}
                onChange={handleInputChange}
                disabled={loading} // Disable input during loading
              />
              {errors.lastName && (
                <p className="text-red-500 text-sm">{errors.lastName}</p>
              )}
            </div>

            <div className="mb-4">
              <label
                className="flex justify-between text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="email"
              >
                Email Address
              </label>
              <input
                type="text"
                id="email"
                className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                placeholder="Enter your Email address"
                value={formData.email}
                onChange={handleInputChange}
                disabled={loading} // Disable input during loading
              />
              {errors.email && (
                <p className="text-red-500 text-sm">{errors.email}</p>
              )}
            </div>

            <div className="mb-4">
              <label
                className="block text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="contactNumber"
              >
                Contact Number
              </label>
              <input
                type="text"
                id="contactNumber"
                className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                placeholder="Enter your contact number"
                value={formData.contactNumber}
                onChange={handleInputChange}
                disabled={loading} // Disable input during loading
              />
              {errors.contactNumber && (
                <p className="text-red-500 text-sm">{errors.contactNumber}</p>
              )}
            </div>
            <div className="mb-4">
              <label
                className="block text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="password"
              >
                Password
              </label>
              <div className="relative flex w-full">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277] pr-10"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleInputChange}
                  disabled={loading} // Disable input during loading
                />
                <button
                  type="button"
                  onClick={toggleShowPassword}
                  className="absolute right-3 top-2"
                >
                  {showPassword ? <Eye /> : <EyeOff />}
                </button>
              </div>
              {errors.password && (
                <p className="text-red-500 text-sm">{errors.password}</p>
              )}
            </div>
            <div className="mb-4">
              <label
                className="block text-gray-700 text-lg mb-2 font-semibold"
                htmlFor="confirmPassword"
              >
                Confirm Password
              </label>
              <div className="relative flex w-full">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  id="confirmPassword"
                  className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277] pr-10"
                  placeholder="Confirm your password"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  disabled={loading} // Disable input during loading
                />
                <button
                  type="button"
                  onClick={toggleShowConfirmPassword}
                  className="absolute right-3 top-2"
                >
                  {showConfirmPassword ? <Eye /> : <EyeOff />}
                </button>
              </div>
              {errors.confirmPassword && (
                <p className="text-red-500 text-sm">{errors.confirmPassword}</p>
              )}
            </div>
            {errors.submit && (
              <p className="text-red-500 text-sm">{errors.submit}</p>
            )}
          </div>
          <div className="mb-4">
            <button
              type="button"
              disabled={loading} // Disable input during loading
              onClick={toggleTermsPopup}
              className={`flex justify-center w-full px-4 py-2 font-semibold rounded-md ${loading ? 'bg-gray-400 cursor-not-allowed' : 'custom-button-color text-white'}`}
            >
              {loading ? <Loader className="animate-spin" size={20} /> : "Continue"}
            </button>
          </div>
        </form>
        <div className="text-center mb-10">
          <p className="text-gray-600 text-sm">
            Already have an account?{" "}
            <Link to="/login" className="text-[#A79277] hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </div>
      {isTermsOpen && (
        <TermsAndConditions
          isOpen={isTermsOpen}
          onConfirm={handleTermsConfirm}
          onClose={toggleTermsPopup}
        />
      )}
    </div>
  );
};

export default Registration;
