import React, { useContext, createContext, useState } from "react";
import { LogOut, ChevronLast, ChevronFirst } from "lucide-react";
import { motion } from "framer-motion";
import LogoutPopup from "./LogoutPopup";
import kapeLinkLogo from "../../images/KapeLinkLogo.png";

const SidebarContext = createContext();

export default function Sidebar({ children, user, role }) {
  const [expanded, setExpanded] = useState(true);
  const [logoutPopupOpen, setLogoutPopupOpen] = useState(false); // State to control logout popup visibility
  const loginData = JSON.parse(localStorage.getItem("loginSuccess"));
  const loginCreds = loginData?.loginCreds;

  return (
    <aside className="min-h-screen flex">
      <motion.nav
        animate={{ width: expanded ? 256 : 68 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className={`h-full flex flex-col bg-white border-r`}
      >
        <div className="border-b p-4 pb-2 flex justify-between items-center">
          <motion.img
            src={kapeLinkLogo}
            animate={{ opacity: expanded ? 1 : 0, width: expanded ? 40 : 0 }}
            transition={{ duration: 0.3 }}
            alt="KapeLink Logo"
          />
          <motion.h2
            className="font-bold overflow-hidden whitespace-nowrap"
            animate={{ opacity: expanded ? 1 : 0, width: expanded ? 120 : 0 }}
            transition={{ duration: 0 }}
          >
            KAPE LINK
          </motion.h2>
          <button
            onClick={() => setExpanded((curr) => !curr)}
            className="p-1.5 rounded-lg bg-gray-50 hover:bg-gray-100"
          >
            {expanded ? <ChevronFirst /> : <ChevronLast />}
          </button>
        </div>

        <SidebarContext.Provider value={{ expanded }}>
          <ul className="flex-1 px-3">{children}</ul>
        </SidebarContext.Provider>

        <div className="border-t flex p-3">
          <motion.div
            className={`flex justify-between items-center overflow-hidden`}
            animate={{ opacity: expanded ? 1 : 0, width: expanded ? 208 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="leading-4 whitespace-nowrap">
              <h4 className="font-semibold">{user}</h4>
              <span className="text-xs text-gray-600">{role}</span>
            </div>
            <LogOut
              size={20}
              className="cursor-pointer"
              onClick={() => setLogoutPopupOpen(true)} // Open the logout popup when clicking the logout icon
            />
          </motion.div>
        </div>
      </motion.nav>

      {/* Render the LogoutPopup if logoutPopupOpen is true */}
      {logoutPopupOpen && (
        <LogoutPopup setLogoutPopupOpen={setLogoutPopupOpen} user={loginCreds} />
      )}
    </aside>
  );
}

export function SidebarItem({ icon, text, active }) {
  const { expanded } = useContext(SidebarContext);

  return (
    <motion.li
      className={`relative flex items-center py-2 px-3 my-3 font-medium rounded-md cursor-pointer group ${
        active ? "bg-gray-200 text-custom-active" : "text-black-600"
      } hover:bg-gray-200`}
      animate={{ width: expanded ? 230 : 44 }}
      transition={{ duration: 0.3 }}
    >
      {icon}
      <span
        className={`overflow-hidden ${
          expanded ? "w-40 ml-3 opacity-100" : "w-0 opacity-0"
        } ${expanded ? "" : "whitespace-nowrap"} ${
          active ? "text-custom-active" : ""
        }`}
      >
        {text}
      </span>
    </motion.li>
  );
}
