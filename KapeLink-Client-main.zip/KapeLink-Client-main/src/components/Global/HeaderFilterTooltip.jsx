import React, { useMemo, useState, useEffect } from "react";
import { Tooltip } from "antd";
import { CircleHelp } from "lucide-react";

const text = (
  <span className="max-[640px]:text-xs">
    Click on the column header you want the data to be sort by.
  </span>
);

const HeaderFilterTooltip = () => {
  const [arrow] = useState("Show");
  const [tooltipWidth, setTooltipWidth] = useState(280); // Default width

  /**
   * Updates the tooltip width dynamically based on the screen size.
   *
   * - For screens smaller than or equal to 640px, the tooltip width is set to 200px.
   * - For larger screens, the tooltip width is set to 280px.
   *
   * This effect runs when the component mounts and also updates the tooltip width
   * on window resize.
   *
   * @function useEffect
   * @returns {void} - Sets the initial tooltip width and updates it on window resize.
   */
  useEffect(() => {
    const updateWidth = () => {
      if (window.innerWidth <= 640) {
        setTooltipWidth(200); // Smaller width for devices <= 640px
      } else {
        setTooltipWidth(280); // Default width for larger devices
      }
    };

    // Set initial width on component mount
    updateWidth();

    // Add a listener to window resize to update width dynamically
    window.addEventListener("resize", updateWidth);

    // Cleanup event listener on unmount
    return () => {
      window.removeEventListener("resize", updateWidth);
    };
  }, []);

  /**
   * Determines the tooltip arrow visibility and alignment.
   * - If `arrow` is "Hide", no arrow is shown.
   * - If `arrow` is "Show", the arrow is displayed.
   * - Otherwise, the arrow is positioned at the center by default.
   *
   * @function useMemo
   * @returns {boolean|object} - A boolean indicating whether to show the arrow or an object to center it.
   */
  const mergedArrow = useMemo(() => {
    if (arrow === "Hide") {
      return false;
    }
    if (arrow === "Show") {
      return true;
    }
    return {
      pointAtCenter: true,
    };
  }, [arrow]);

  return (
    <Tooltip
      placement="topRight"
      title={text}
      arrow={mergedArrow}
      overlayInnerStyle={{ width: tooltipWidth }} // Dynamic width based on screen size
    >
      <CircleHelp
        style={{ cursor: "pointer" }}
        className="text-gray-400 pr-1 md:pr-0"
      />
    </Tooltip>
  );
};

export default HeaderFilterTooltip;
