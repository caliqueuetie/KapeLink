import React, { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import ListOfItems from "./ListOfItems";
import CancelOrderMessagePopup from "./CancelOrderMessagePopup";
import axios from "/axios.config";
import { io } from "socket.io-client";
import { Loader } from "lucide-react";

const ForDeliveryDetails = ({
  selectedOrder,
  setSelectedOrder,
  fetchOrdersData,
}) => {
  const formattedOrderDate = new Date(selectedOrder.orderDate)
    .toISOString()
    .slice(0, 10);
  const [user, setUser] = useState([]);
  const [payment, setPayment] = useState([]);
  const [loading, setLoading] = useState(false);
  const headerDetailsFormat =
    "xl:text-lg 2xl:texl-xl text-lg font-semibold mb-2 max-[640px]:mb-0";
  const contentDetailsFormat =
    "xl:text-lg 2xl:texl-xl text-lg text-color-custom font-regular max-w-72 min-w-44";
  const [isMessagePopupOpen, setIsMessagePopupOpen] = useState(false);

  /**
   * Handles the back button click by fetching the latest orders and clearing the selected order.
   *
   * @function handleBackButtonClick
   * @returns {void} - Fetches the orders data and resets the selected order.
   */
  const handleBackButtonClick = () => {
    fetchOrdersData();
    setSelectedOrder(null);
  };

  /**
   * Opens the message popup by setting the state to true.
   *
   * @function handleMessageOpenPopup
   * @returns {void} - Sets the message popup state to open.
   */
  const handleMessageOpenPopup = () => {
    setIsMessagePopupOpen(true);
  };

  /**
   * Calculates the total price of all items in the selected order.
   *
   * @constant {string} totalPrice - The total price of the selected order's items, rounded to two decimal places.
   * @returns {string} - Returns the total price of the selected order.
   */
  const totalPrice = selectedOrder.items
    .reduce((total, item) => total + item.totalPrice, 0)
    .toFixed(2);

  /**
   * Sets up a WebSocket listener for order status updates. If the status of the selected order changes,
   * the selected order is updated in the UI.
   *
   * @function useEffect
   * @param {Array} selectedOrder.orderId - The orderId of the selected order.
   * @returns {void} - Listens for the "orderStatusUpdated" event and updates the selected order.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("orderStatusUpdated", (updatedOrder) => {
      if (updatedOrder.orderId === selectedOrder.orderId) {
        // Update UI if the relevant order's status changes
        setSelectedOrder(updatedOrder);
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [selectedOrder.orderId]);

  /**
   * Fetches the user data for the customer associated with the selected order.
   *
   * @function useEffect
   * @param {string} selectedOrder.customerId - The customerId of the selected order.
   * @returns {void} - Fetches the user data and sets it in the state.
   */
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-user/${selectedOrder.customerId}`
        );
        const userData = response.data;
        setUser(userData);
      } catch (error) {
        console.error("Error fetching user data:", error);
      }
    };

    fetchUserData();
  }, [selectedOrder.customerId]);

  /**
   * Fetches the payment method data for the selected order's payment method.
   *
   * @function useEffect
   * @param {string} selectedOrder.paymentMethodId - The paymentMethodId of the selected order.
   * @returns {void} - Fetches the payment data and sets it in the state.
   */
  useEffect(() => {
    const fetchPaymentData = async () => {
      try {
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-payment-methods/${selectedOrder.paymentMethodId}`
        );
        const paymentData = response.data;
        setPayment(paymentData);
      } catch (error) {
        console.error("Error fetching payment data:", error);
      }
    };

    fetchPaymentData();
  }, [selectedOrder.paymentMethodId]);

  /**
   * Updates the tracking status of the selected order and sends a notification to the customer.
   *
   * @function updateOrderTracking
   * @param {string} newStatus - The new status for the order.
   * @param {string|null} message - Optional custom message for the notification.
   * @returns {void} - Sends a patch request to update the order tracking and sends a notification.
   */
  const updateOrderTracking = async (newStatus, message = null) => {
    setLoading(true);
    try {
      const newTrackingEntry = {
        timestamp: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        }),
        orderStatus: newStatus,
      };

      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-order-tracking`,
        {
          order: selectedOrder,
          newTrackingEntry,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      const updatedOrder = response.data;

      // Update the selectedOrder with the new tracking status in the UI
      setSelectedOrder((prevOrder) => ({
        ...prevOrder,
        tracking: [...prevOrder.tracking, newTrackingEntry], // Add new entry to tracking array
      }));

      const notificationMessage =
        message ||
        `Order ${selectedOrder.orderId} now has the following status: ${newStatus}`;
      const notificationData = {
        receiver: selectedOrder.customerId, // or 'all' for multiple users
        roles: ["customer"], // adjust based on who should get the notification
        message: notificationMessage,
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          hour12: false,
        }),
        readStatus: false,
      };

      // Send notification
      await axios.post(
        `http://localhost:9000/api/kape-link/create-notification`,
        notificationData
      );
    } catch (error) {
      console.error(
        "Error updating order tracking or sending notification:",
        error
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {loading && (
        <div className="fixed inset-0 flex items-center justify-center z-20">
          <div className="absolute inset-0 bg-black bg-opacity-30" />
          <Loader className="animate-spin z-30" size={40} />
        </div>
      )}
      <div className="flex flex-col">
        <div className="flex justify-between items-center mt-4 mb-10 max-[640px]:flex-col max-[640px]:mb-4 max-[640px]:items-start">
          <div className="flex items-center mr-5">
            <ArrowLeft
              onClick={handleBackButtonClick}
              className="cursor-pointer"
            />
            <h1 className="text-3xl font-semibold ml-5 max-[640px]:text-xl whitespace-nowrap">
              Order Details
            </h1>
            <h2 className="for-delivery-label text-xl font-medium rounded-full px-10 py-1 ml-5 max-[640px]:px-5 max-[640px]:text-sm whitespace-nowrap">
              Delivery
            </h2>
          </div>
          <div className="ml-auto text-3xl font-semibold max-[640px]:text-lg max-[640px]:ml-0 max-[640px]:mt-7">
            {/* Make the ID # here dynamic based on the order selected value */}
            <h1 className="whitespace-nowrap">
              Order ID #
              <span className="order-id-num max-[640px]:block">
                {selectedOrder.orderId}
              </span>
            </h1>
          </div>
        </div>
        <div className="flex lg:ml-14 ml-0 2xl:mb-9 mb-5 max-[640px]:flex-col gap-6 lg:gap-24 2xl:gap-32">
          {user?.firstName && (
            <div className="flex flex-col">
              <h1 className={headerDetailsFormat}>Name</h1>
              <h1 className={contentDetailsFormat}>
                {user.firstName} {user.lastName}
              </h1>
            </div>
          )}
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Date</h1>
            <h1 className={contentDetailsFormat}>{formattedOrderDate}</h1>
          </div>
          {selectedOrder.deliveryDetails?.deliveryTime && (
            <div className="flex flex-col">
              <h1 className={headerDetailsFormat}>Delivery Time</h1>
              <h1 className={contentDetailsFormat}>
                {selectedOrder.deliveryDetails.deliveryTime}
              </h1>
            </div>
          )}
        </div>
        <div className="flex lg:ml-14 ml-0 2xl:mb-9 mb-0 max-[640px]:flex-col gap-6 lg:gap-24 2xl:gap-32">
          {user?.contactNumber && (
            <div className="flex flex-col">
              <h1 className={headerDetailsFormat}>Contact No.</h1>
              <h1 className={contentDetailsFormat}>{user.contactNumber}</h1>
            </div>
          )}
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Mode Of Payment</h1>
            <h1 className={contentDetailsFormat}>{payment.name}</h1>
          </div>
          {selectedOrder.deliveryDetails?.building && (
            <div className="flex flex-col">
              <h1 className={headerDetailsFormat}>Delivery Location</h1>
              <h1 className={contentDetailsFormat}>
                {selectedOrder.deliveryDetails.building}{" "}
                {selectedOrder.deliveryDetails.description}
              </h1>
            </div>
          )}
        </div>
        <div className="flex-col lg:ml-14 lg:mt-5 ml-0 mt-4 max-[640px]:max-w-80">
          <h1 className={headerDetailsFormat}>List of Items</h1>
          <ListOfItems selectedOrder={selectedOrder} />
          <h1 className="text-xl font-semibold mt-3 max-[640px]:text-lg max-[640px]:font-medium text-right">
            Total Price: P{totalPrice}
          </h1>
        </div>

        {/* Dynamic Status Buttons */}
        <div className="self-end mb-6">
          {(() => {
            const latestStatus =
              selectedOrder.tracking[selectedOrder.tracking.length - 1]
                .orderStatus;

            if (latestStatus === "Preparing") {
              return (
                <>
                  <button
                    className="custom-button-color text-lg text-white font-semibold rounded-full px-10 py-2 mt-5 max-[640px]:px-7 max-[640px]:py-1 max-[640px]:text-base max-[640px]:font-medium max-[640px]:mt-2"
                    onClick={() => updateOrderTracking("Out For Delivery")}
                  >
                    Dispatch
                  </button>

                  <button
                    className="custom-button-black text-lg font-semibold rounded-full px-10 py-2 ml-5 mt-5 max-[640px]:px-7 max-[640px]:py-1 max-[640px]:text-base max-[640px]:font-medium max-[640px]:mt-2 max-[640px]:ml-2"
                    onClick={handleMessageOpenPopup} //Cancelled (Manager/Barista will decide)
                  >
                    Cancel
                  </button>
                </>
              );
            } else if (latestStatus === "Out For Delivery") {
              return (
                <>
                  <button
                    className="custom-button-color text-lg text-white font-semibold rounded-full px-10 py-2 mt-5 max-[640px]:px-7 max-[640px]:py-1 max-[640px]:text-base max-[640px]:font-medium max-[640px]:mt-2"
                    onClick={() => updateOrderTracking("Complete")}
                  >
                    Complete
                  </button>

                  <button
                    className="custom-button-black text-lg font-semibold rounded-full px-10 py-2 ml-5 mt-5 max-[640px]:px-7 max-[640px]:py-1 max-[640px]:text-base max-[640px]:font-medium max-[640px]:mt-2 max-[640px]:ml-2"
                    onClick={() => updateOrderTracking("Failed")}
                  >
                    Failed Delivery
                  </button>
                </>
              );
            } else if (latestStatus === "Complete") {
              return (
                <>
                  <h1 className="mt-5 mb-5 font-semibold self-end border-2 border-custom-brown-border rounded-full py-2 px-10 text-color-custom text-base sm:text-xs md:text-sm xl:text-xl">
                    Completed
                  </h1>
                </>
              );
            } else if (latestStatus === "Failed") {
              return (
                <>
                  <h1 className="mt-5 mb-5 font-semibold self-end border-2 border-gray-400 rounded-full py-2 px-10 text-gray-400 text-base sm:text-xs md:text-sm xl:text-xl">
                    Failed
                  </h1>
                </>
              );
            } else if (latestStatus === "Cancelled") {
              return (
                <>
                  <h1 className="mt-5 mb-5 font-semibold self-end border-2 border-black rounded-full py-2 px-10 text-base sm:text-xs md:text-sm xl:text-xl">
                    Cancelled
                  </h1>
                </>
              );
            } else {
              return null; // Handle other statuses or show nothing
            }
          })()}
        </div>

        {isMessagePopupOpen && (
          <CancelOrderMessagePopup
            setIsMessagePopupOpen={setIsMessagePopupOpen}
            updateOrderTracking={updateOrderTracking}
          />
        )}
      </div>
    </>
  );
};

export default ForDeliveryDetails;
