import { Link } from "react-router-dom";
import { FaExclamationTriangle } from "react-icons/fa";

const Unauthorized = () => {
  return (
    <section className="flex flex-col justify-center items-center h-96 mt-24">
      <FaExclamationTriangle className="text-yellow-400 text-6xl mb-4" />
      <h1 className="text-6xl font-bold mb-4">Unauthorized!</h1>
      <p className="text-xl mb-5">You are accessing a restricted page.</p>
      <Link
        to="/login-switch"
        className="text-white rounded-md px-3 py-2 mt-4 custom-button-color"
      >
        Go Back
      </Link>
    </section>
  );
};

export default Unauthorized;
