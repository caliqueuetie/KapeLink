import React from "react";

const TabFilters = ({ tabNames, activeTab, setActiveTab, markAllAsRead }) => {
  return (
    <div className="flex items-center justify-between ml-5 max-[640px]:ml-0 max-[640px]:space-x-3">
      {/* Tab Filters */}
      <div className="flex space-x-10 max-[640px]:space-x-3">
        {tabNames.map((tab) => (
          <p
            key={tab}
            className={`cursor-pointer font-medium max-[640px]:text-xs max-[640px]:font-normal ${
              activeTab === tab ? "text-color-custom" : "text-gray-700"
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </p>
        ))}
      </div>

      {/* Mark All as Read button */}
      {markAllAsRead && (
        <div className="flex-grow flex justify-end">
          <button
            onClick={markAllAsRead}
            className="custom-button-color text-white px-4 py-2 rounded-lg max-[640px]:text-xs"
          >
            Mark All as Read
          </button>
        </div>
      )}
    </div>
  );
};

export default TabFilters;
