import React, { useState, useEffect } from "react";
import axios from "axios";
import TabFilters from "../../components/Global/TabFilters";
import noNotification from "../../assets/noNotifications.gif";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import { io } from "socket.io-client";

const NotificationPane = ({ receivers, roles }) => {
  const tabNames = ["All", "Read", "Unread"];
  const [activeTab, setActiveTab] = useState("All");
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  /**
   * Fetches notifications from the server based on the provided receivers and roles.
   * Sorts the notifications in descending order by notificationId and updates the state.
   *
   * @async
   * @function fetchNotifications
   * @returns {void} - Fetches and sorts notifications, and updates the state accordingly.
   */
  const fetchNotifications = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-notifications",
        {
          params: {
            receiver: receivers,
            roles: roles,
          },
        }
      );
      const notificationData = response.data;

      // Sort notifications by notificationId in descending order
      const sortedNotifications = notificationData.sort(
        (a, b) => b.notificationId - a.notificationId
      );

      setNotifications(sortedNotifications);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      setLoading(false);
    }
  };

  /**
   * Sets up socket connection to listen for "newOrder" and "readNotificationBM" events.
   * Fetches notifications when those events are triggered.
   * Cleans up the socket connection when the component unmounts.
   *
   * @useEffect
   */
  useEffect(() => {
    fetchNotifications();

    const socket = io("http://localhost:9000");

    socket.on("newOrder", () => {
      fetchNotifications();
    });

    socket.on("readNotificationBM", () => {
      fetchNotifications();
    });

    return () => {
      socket.disconnect();
    };
  }, [receivers, roles]);

  /**
   * Logs notifications each time they change.
   *
   * @useEffect
   */
  useEffect(() => {}, [notifications]); // This will log the notifications every time they change

  /**
   * Toggles the read status of a specific notification.
   *
   * @async
   * @function toggleNotificationRead
   * @param {string} notificationId - The ID of the notification to toggle.
   * @returns {void} - Updates the read status of the notification and updates the state.
   */
  const toggleNotificationRead = async (notificationId) => {
    try {
      const response = await axios.put(
        `http://localhost:9000/api/kape-link/toggle-notification-read/${notificationId}`
      );
      const updatedNotification = response.data;

      setNotifications((prevNotifications) =>
        prevNotifications.map((notification) =>
          notification._id === updatedNotification._id
            ? updatedNotification
            : notification
        )
      );
      setLoading(false);
    } catch (error) {
      console.error("Error toggling notification read status:", error);
      setLoading(false);
    }
  };

  /**
   * Marks all notifications as read.
   *
   * @async
   * @function markAllAsRead
   * @returns {void} - Marks all notifications as read and updates the state.
   */
  const markAllAsRead = async () => {
    try {
      // Define the roles you want to mark notifications as read for
      const body = { roles: ["barista", "manager"] };
  
      // Send the request to the backend to mark notifications for these roles as read
      const response = await axios.put(
        'http://localhost:9000/api/kape-link/toggle-notifications-read',
        body
      );
  
      // Update local notifications state to reflect the changes
      const updatedNotifications = notifications.map((notification) => {
        if (notification.read === false && body.roles.includes(notification.role)) {
          // If the notification is not read and matches the roles, set it as read
          notification.read = true;
        }
        return notification;
      });
  
      // Set the updated notifications to the state
      setNotifications(updatedNotifications);
  
      // Optionally, hide the loading state if desired
      setLoading(false);
    } catch (error) {
      console.error("Error marking notifications as read:", error);
      setLoading(false);
    }
  };
  

  
  




  /**
   * Filters notifications based on the active tab ("All", "Read", "Unread").
   *
   * @const filteredNotifications
   * @returns {Array} - The filtered list of notifications based on the selected tab.
   */
  const filteredNotifications = notifications.filter((notification) => {
    const isRead = notification.read;
    const matchesTab =
      activeTab === "All" ||
      (activeTab === "Read" && isRead) ||
      (activeTab === "Unread" && !isRead);
    return matchesTab;
  });

  return (
    <>
      <TabFilters
        tabNames={tabNames}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        markAllAsRead={markAllAsRead}
      />

      {loading ? (
        <div className="w-[900px] flex flex-col justify-center items-center border-collapse border lg:px-56 sm:px-44 border-gray-400 rounded-lg mt-5 h-[550px] sm:h-[750px] px-10 ml-5 mb-6 max-[640px]:w-80 max-[640px]:p-6 max-[640px]:ml-0">
          <Player
            autoplay
            loop
            src={loader}
            style={{ height: "150px", width: "150px" }}
          />
        </div>
      ) : (
        <>
          {filteredNotifications.length > 0 ? (
            <div className=" flex flex-col w-[900px] overflow-y-auto border-collapse border border-gray-400 rounded-lg mt-5 h-[550px] sm:h-[750px] p-10 ml-5 mb-6 max-[640px]:w-80 max-[640px]:p-6 max-[640px]:ml-0">
              {filteredNotifications.map((notification) => (
                <React.Fragment key={notification._id}>
                  <div
                    key={notification._id}
                    className={`rounded-lg px-2 pt-4 pb-3 sm:px-10 sm:py-6 ${
                      notification.read ? "" : "bg-gray-100"
                    }`}
                  >
                    <div className="flex justify-between mb-3">
                      <div></div>
                      <h2 className="text-right text-sm max-[640px]:text-xs max-[640px]:whitespace-nowrap">
                        {notification.time}
                      </h2>
                    </div>

                    <div className="flex flex-col">
                      <h1 className="text-lg font-medium max-[640px]:text-xs max-[640px]:font-light break-words text-justify">
                        {notification.message}
                      </h1>
                    </div>

                    <div className="flex justify-between items-center mt-2">
                      <p className="font-normal sm:font-semibold text-xs text-gray-500 max-[640px]:text-xs">
                        {new Date(notification.date).toLocaleDateString()}
                      </p>
                      <button
                        className="custom-button-black px-7 py-2 rounded-full max-[640px]:px-5 max-[640px]:py-1 max-[640px]:text-xs"
                        onClick={() => toggleNotificationRead(notification._id)}
                      >
                        {notification.read ? "Unread" : "Read"}
                      </button>
                    </div>
                  </div>
                  <hr className="border-t-1 border-gray-300 my-2 sm:my-5" />
                </React.Fragment>
              ))}
            </div>
          ) : (
            <div className="w-[900px] flex flex-col justify-center items-center border-collapse border lg:px-56 sm:px-44 border-gray-400 rounded-lg mt-5 h-[550px] sm:h-[750px] px-10 ml-5 mb-6 max-[640px]:w-80 max-[640px]:p-6 max-[640px]:ml-0">
              <img
                src={noNotification}
                alt="empty notification logo"
                className="h-12 w-12 lg:h-16 lg:w-16 mb-3"
              />
              <p className="whitespace-nowrap text-center text-sm lg:text-lg">
                No notifications available.
              </p>
            </div>
          )}
        </>
      )}
    </>
  );
};

export default NotificationPane;
