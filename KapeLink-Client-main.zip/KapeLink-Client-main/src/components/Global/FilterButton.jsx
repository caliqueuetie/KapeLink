import React, { useEffect, useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";

const FilterButton = ({
  setActiveFilter,
  users,
  orderOptions,
  paymentMethods,
  salesReports,
  pageKey,
}) => {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState(() => {
    // Get the initial value for this specific page from localStorage or set it to an empty string
    return localStorage.getItem(`${pageKey}Filter`) || "";
  });

  /**
   * Opens the filter popup by setting the `isFilterOpen` state to `true`.
   *
   * @function handleOpenFilterPopup
   * @returns {void} - Updates the state to show the filter popup.
   */
  const handleOpenFilterPopup = () => {
    setIsFilterOpen(true);
  };

  /**
   * Closes the filter popup by setting the `isFilterOpen` state to `false`.
   *
   * @function handleCloseFilterPopup
   * @returns {void} - Updates the state to hide the filter popup.
   */
  const handleCloseFilterPopup = () => {
    setIsFilterOpen(false);
  };

  /**
   * Sets the selected filter in the state.
   *
   * @function handleFilterSelection
   * @param {string} filter - The selected filter value.
   * @returns {void} - Updates the selected filter in the state.
   */
  const handleFilterSelection = (filter) => {
    setSelectedFilter(filter);
  };

  /**
   * Resets the filter by clearing the active filter and the selected filter,
   * and removing the stored filter from `localStorage` for the specific page.
   *
   * @function handleResetFilter
   * @returns {void} - Clears the filters and closes the filter popup.
   */
  const handleResetFilter = () => {
    setActiveFilter("");
    setSelectedFilter("");
    localStorage.removeItem(`${pageKey}Filter`); // Remove the filter for the specific page
    setIsFilterOpen(false);
  };

  /**
   * Updates the active filter when the `selectedFilter` state changes.
   * This effect runs whenever `selectedFilter` is updated.
   *
   * @function useEffect
   * @returns {void} - Sets the active filter to the selected filter.
   */
  useEffect(() => {
    // Update active filter when selectedFilter changes
    setActiveFilter(selectedFilter);
  }, [selectedFilter, setActiveFilter]);

  return (
    <>
      <button
        onClick={handleOpenFilterPopup}
        className="flex custom-button-black py-2 px-4 rounded-xl max-[640px]:px-4 max-[640px]:py-0 max-[640px]:rounded-lg"
      >
        <span className="mr-2 max-[640px]:mr-0">
          <SlidersHorizontal className="max-[640px]:w-4" />
        </span>
        <span className="max-[640px]:hidden">Filter</span>
      </button>

      {isFilterOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center m-0 z-50">
          <div className="bg-white p-10 rounded-lg shadow-lg relative w-[40%] xl:w-[30%] 2xl:w-[20%] max-[640px]:w-80 max-[640px]:p-8">
            <X
              size={30}
              className="cursor-pointer flex ml-auto mb-3"
              onClick={handleCloseFilterPopup}
            />

            <div className="text-center mb-5">
              <h2 className="font-semibold text-2xl max-[640px]:text-xl">
                Filters
              </h2>
            </div>

            {users && users.length > 0 && (
              <div>
                <p className="text-left text-gray-600">Roles</p>
                <div className="flex flex-wrap mb-6 space-x-1 max-[640px]:ml-0">
                  {users.map((roles, index) => (
                    <p
                      key={index}
                      className={`cursor-pointer mt-2 text-gray-600 text-sm rounded-md p-2 font-normal max-[640px]:text-xs max-[640px]:font-normal ${
                        selectedFilter === roles
                          ? "text-color-custom font-medium border-2 border-color-custom"
                          : "text-gray-700 border border-gray-400"
                      }`}
                      onClick={() => handleFilterSelection(roles)}
                    >
                      {roles}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {orderOptions && orderOptions.length > 0 && (
              <div>
                <p className="text-sm sm:text-base text-left text-gray-600">
                  Order Options
                </p>
                <div className="flex flex-wrap mb-6 space-x-1 max-[640px]:ml-0">
                  {orderOptions.map((orderOption, index) => (
                    <p
                      key={index}
                      className={`cursor-pointer mt-2 text-gray-600 text-sm rounded-md p-2 font-normal max-[640px]:text-xs max-[640px]:font-normal ${
                        selectedFilter === orderOption
                          ? "text-color-custom font-medium border-2 border-color-custom"
                          : "text-gray-700 border border-gray-400"
                      }`}
                      onClick={() => handleFilterSelection(orderOption)}
                    >
                      {orderOption}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {paymentMethods && Object.keys(paymentMethods).length > 0 && (
              <div className="-mt-6">
                <p className="text-sm sm:text-base text-left mt-8 text-gray-600">
                  Payment Options
                </p>
                <div className="flex flex-wrap mb-6 space-x-1 max-[640px]:ml-0">
                  {Object.values(paymentMethods).map((paymentMethod, index) => (
                    <p
                      key={index}
                      className={`cursor-pointer mt-2 text-gray-600 text-sm rounded-md p-2 font-normal max-[640px]:text-xs max-[640px]:font-normal ${
                        selectedFilter === paymentMethod
                          ? "text-color-custom font-medium border-2 border-color-custom"
                          : "text-gray-700 border border-gray-400"
                      }`}
                      onClick={() => handleFilterSelection(paymentMethod)}
                    >
                      {paymentMethod}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {salesReports && salesReports.length > 0 && (
              <div className="-mt-6">
                <p className="text-sm sm:text-base text-left mt-8 text-gray-600 font">
                  Sales Reports
                </p>
                <div className="flex flex-wrap mb-6 space-x-1 max-[640px]:ml-0">
                  {Object.values(salesReports).map((salesReports, index) => (
                    <p
                      key={index}
                      className={`cursor-pointer mt-2 text-gray-600 text-sm rounded-md p-2 font-normal max-[640px]:text-xs max-[640px]:font-normal ${
                        selectedFilter === salesReports
                          ? "text-color-custom font-medium border-2 border-color-custom"
                          : "text-gray-700 border border-gray-400"
                      }`}
                      onClick={() => handleFilterSelection(salesReports)}
                    >
                      {salesReports}
                    </p>
                  ))}
                </div>
              </div>
            )}

            <div className="text-center whitespace-nowrap">
              <button
                onClick={handleResetFilter}
                className="custom-button-color text-white font-normal py-1 px-5 border border-transparent rounded-md max-[640px]:py-1 max-[640px]:px-5 max-[640px]:text-sm"
              >
                Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default FilterButton;
