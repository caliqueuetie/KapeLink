import { Search } from "lucide-react";

const SearchBar = ({ searchQuery, setSearchQuery }) => {
  return (
    <div
      className="flex items-center border border-gray-400 rounded-3xl w-full md:p-1 md:w-80"
      role="search"
    >
      <Search className="mx-2 text-gray-400" aria-label="Search" />
      <input
        id="search-input"
        type="text"
        placeholder="Search here"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="flex-grow outline-none text-sm"
      />
    </div>
  );
};

export default SearchBar;
