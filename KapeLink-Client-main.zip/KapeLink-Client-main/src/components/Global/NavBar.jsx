import React, { useState } from "react";
import { Menu, LogOut } from "lucide-react";
import LogoutPopup from "./LogoutPopup"; // Import the LogoutPopup component
import kapeLinkLogo from "../../images/KapeLinkLogo.png";

const NavBar = ({ children, user, role }) => {
  const [expanded, setExpanded] = useState(false);
  const [logoutPopupOpen, setLogoutPopupOpen] = useState(false); // State to control logout popup visibility

  const handleLogout = () => {
    setLogoutPopupOpen(true);
    setExpanded(false);
  };
  return (
    <>
      <nav className="w-full">
        <div className="h-14 border flex items-center justify-between">
          <div className="flex items-center">
            <img
              src={kapeLinkLogo}
              className="w-fit py-2 px-3"
              alt="KapeLink Logo"
            />
            <h1 className="font-bold">KAPE LINK</h1>
          </div>
          <div className="relative mr-5">
            <button onClick={() => setExpanded(!expanded)}>
              <Menu />
            </button>
          </div>
        </div>
        {expanded && (
          <div className="absolute top-12 right-0 bg-white border rounded shadow-lg z-50">
            <ul className="list-none p-3">{children}</ul>
            <hr className="border-t-1 border-gray-300 mb-4"></hr>
            <div className="leading-4 px-7 pb-4">
              <div className="flex justify-between text-right items-center">
                <LogOut
                  className="cursor-pointer"
                  onClick={handleLogout} // Open the logout popup when clicking the logout icon
                />
                <div className="ml-5">
                  <h4 className="font-semibold">{`${user.firstName} ${user.lastName}`}</h4>
                  <span className="text-xs text-gray-600">{role}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Render the LogoutPopup if logoutPopupOpen is true */}
      {logoutPopupOpen && (
        <LogoutPopup setLogoutPopupOpen={setLogoutPopupOpen} user={user.contactNumber}/>
      )}
    </>
  );
};

export default NavBar;

export function NavbarItem({ text, active }) {
  return (
    <li
      className={`${
        active ? "bg-gray-200 text-custom-active" : "text-black-600"
      } hover:bg-gray-200 `}
    >
      <span
        className={`block px-4 py-2 text-right ${
          active ? "text-custom-active" : ""
        }`}
      >
        {text}
      </span>
    </li>
  );
}
