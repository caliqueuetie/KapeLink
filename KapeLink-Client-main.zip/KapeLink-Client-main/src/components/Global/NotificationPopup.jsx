import React, { useState, useEffect } from 'react';
import { X } from "lucide-react";

const NotificationPopup = ({ header, message, style, onTimeout, onClose }) => {
  const [isVisible, setIsVisible] = useState(true);
  const [isSlidingOut, setIsSlidingOut] = useState(false); // Track sliding out state
  const [slideIn, setSlideIn] = useState(false);

  useEffect(() => {
    setSlideIn(true); 


    const timer = setTimeout(() => {
      setIsSlidingOut(true); 
      setTimeout(() => {
        setIsVisible(false); 
        if (onTimeout) {
          onTimeout(); 
        }
      }, 500); 
    }, 5000);

    return () => clearTimeout(timer);
  }, [onTimeout]);

  const handleClose = (e) => {
    e.stopPropagation();
    setIsSlidingOut(true); 
    setTimeout(() => {
      setIsVisible(false);
      onClose();
    }, 500); 
  };

  const truncateMessage = (text, limit) => {
    return text.length > limit ? `${text.substring(0, limit)}...` : text;
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div
      className={`fixed flex w-80 bg-gray-50 border border-gray-300 rounded-lg shadow-lg transition-transform duration-500 ease-in-out ${slideIn && !isSlidingOut ? 'translate-x-0' : 'translate-x-full'}`}
      style={style} 
    >

      <div className="w-1/6 bg-[#A79277] hover:bg-[#8d6f5e] flex items-center justify-center relative">
        <X
          size={20}
          className="cursor-pointer text-white"
          onClick={handleClose}
        />
      </div>
      <div 
      className="w-4/5 bg-gray-50 px-4 py-3 text-left">
        <span className="block text-lg font-semibold text-gray-800 mb-1">
          {header}
        </span>
        <span className="block text-sm text-gray-600">
          {message}
        </span>
      </div>
    </div>
  );
};

export default NotificationPopup;
