import React, { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import kapeLinkLogo from "../../images/KapeLinkNameLogo.png";

const SuccessfulRegistration = () => {
  const { state } = useLocation();
  const { formData } = state || {};
  const [isAccountDetailsOpen, setIsAccountDetailsOpen] = useState(false);

  const toggleAccountDetailsPopup = () => {
    setIsAccountDetailsOpen(!isAccountDetailsOpen);
  };

  return (
    <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
      <div className="w-full max-w-sm p-8 sm:bg-white sm:shadow-md rounded-lg">
        <div className="text-center">
          <img
            src={kapeLinkLogo}
            alt="Logo"
            className="w-1/2 mx-auto my-10"
          />
        </div>
        <form>
          <div className="mb-10">
            <p className="text-center text-gray-700 text-lg mb-2 font-semibold">
              Account Successfully Created
            </p>
            <p className="text-gray-700 text-sm mb-6 text-justify">
              Finish setting up your account by logging in to KapeLink and
              entering the verification code sent to your email
              <span className="font-bold text-blue-500 underline">
                {formData.email}
              </span>
              . After being successfully verified, you will be able to place
              orders.
            </p>
            <p className="text-gray-700 text-sm mb-6 text-justify">
              Let’s get you brewing!
            </p>
          </div>
          <div className="mb-10">
            <Link
              to="/login"
              className="flex justify-center w-full px-4 py-2 text-white custom-button-color rounded-md focus:outline-none focus:bg-[#A79277] font-semibold"
            >
              Back to Sign In
            </Link>
          </div>
        </form>
      </div>
      {isAccountDetailsOpen && (
        <AccountDetails
          isOpen={isAccountDetailsOpen}
          onClose={toggleAccountDetailsPopup}
          formData={formData}
        />
      )}
    </div>
  );
};

export default SuccessfulRegistration;
