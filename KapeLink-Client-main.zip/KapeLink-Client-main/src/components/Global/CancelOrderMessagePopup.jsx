import { X } from "lucide-react";
import { useState } from "react";

const CancelOrderMessagePopup = ({
  setIsMessagePopupOpen,
  updateOrderTracking,
}) => {
  const [message, setMessage] = useState(""); // State to store textarea value

  const handleMessageClosePopup = () => {
    setIsMessagePopupOpen(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    updateOrderTracking("Cancelled", message); // Pass the status and message to updateOrderTracking
    handleMessageClosePopup();
  };

  const handleTextareaChange = (event) => {
    setMessage(event.target.value); // Update the state with the textarea value
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="xl:w-2/5 2xl:w-1/4 bg-white p-7 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-5">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-5"
          onClick={handleMessageClosePopup}
        />
        <div className="text-center mb-3">
          <h2 className="font-medium text-2xl max-[640px]:text-xl">
            Cancel Orders
          </h2>
        </div>
        <div className="flex justify-center items-center">
          <form onSubmit={handleSubmit}>
            <textarea
              id="message"
              placeholder="Message to customer"
              className="w-80 h-40 px-3 py-2 mb-4 border-2 border-gray-300 rounded-md max-[640px]:py-0 max-[640px]:w-64 max-[640px]:h-36"
              value={message} // Bind the textarea to the state
              onChange={handleTextareaChange} // Update state on change
            />
            <div className="flex justify-end">
              <button
                type="submit"
                className="custom-button-color text-white font-medium py-2 px-8 rounded-md max-[640px]:py-1 max-[640px]:text-sm"
              >
                Send
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CancelOrderMessagePopup;
