import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Loader } from "lucide-react";
import kapeLinkLogo from "../../images/KapeLinkNameLogo.png";

const ResetPassword = () => {
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [finished, setFinished] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [formData, setFormData] = useState({ email: "" });
  const [errors, setErrors] = useState({});
  const [dotCount, setDotCount] = useState(1);

  useEffect(() => {
    let interval;

    if (loading) {
      interval = setInterval(() => {
        setDotCount((prev) => (prev === 3 ? 1 : prev + 1));
      }, 500);
    }

    return () => clearInterval(interval);
  }, [loading]);

  const handleFormSubmit = async () => {
    setErrorMessage("");
    setLoading(true);

    try {
      const response = await axios.post(
        `http://localhost:9000/api/kape-link/forgot-password`,
        {
          email: formData.email,
        }
      );

      if (response.status === 200) {
        setErrorMessage("");
        handleSuccess("Password Reset has been sent to your email!");
        setFinished(true);
      } else {
        console.error("Failed to send Password:", response);
        setErrorMessage("Failed to send Password. Please try again.");
      }
    } catch (err) {
      setLoading(false);
      const parsedResponse = JSON.parse(err.request.response);
      setErrorMessage(parsedResponse.error || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleFormConfirm = (e) => {
    e.preventDefault();
    if (validateForm()) {
      handleFormSubmit();
    }
  };

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[^\s@]+@gmail\.com$/;

    if (!formData.email) {
      newErrors.email = "Email is required.";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSuccess = (message) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(""), 3000);
  };

  return (
    <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
      <div className="w-full max-w-sm p-8 sm:bg-white sm:shadow-md rounded-lg">
        {successMessage && <p className="success-message">{successMessage}</p>}

        <div className="mb-6 text-center">
          <img
            src={kapeLinkLogo}
            alt="Logo"
            className="w-1/2 mx-auto my-10"
          />
        </div>
        <form onSubmit={handleFormConfirm}>
          <div className="mb-4">
            <label
              className="block text-gray-700 text-lg mb-2 font-semibold"
              htmlFor="email"
            >
              Password Reset
            </label>
            <label className="block text-gray-700 text-sm mb-2">
              A code will be sent to your email for password reset.
            </label>
            <input
              type="text"
              id="email"
              className={`w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]
                ${
                  finished
                    ? "border-green-500 text-green-500 cursor-not-allowed"
                    : ""
                }`}
              placeholder="example@email.com"
              value={formData.email}
              onChange={handleInputChange}
              disabled={loading || finished}
            />
            {errors.email && (
              <p className="text-red-500 mt-1 text-sm">{errors.email}</p>
            )}
          </div>
          {errorMessage && (
            <div className="mb-4 text-red-500 text-center">{errorMessage}</div>
          )}
          <div className="mb-4 flex flex-col items-center justify-center">
            <div>
              <button
                type="submit"
                disabled={loading || finished}
                className={`flex justify-center px-6 py-2 text-sm sm:text-base text-white font-bold rounded-md custom-button-color 
                  ${
                    loading
                      ? "bg-gray-500 hover:bg-gray-500 cursor-not-allowed"
                      : "custom-button-color"
                  }
                   ${finished ? "hidden" : ""}`}
              >
                {loading ? (
                  <Loader className="animate-spin" />
                ) : (
                  "Reset Password"
                )}
              </button>
            </div>
            {loading && (
              <p className="text-gray-500 font-bold text-center mt-2">
                Verifying if your account exists{".".repeat(dotCount)}
              </p>
            )}
            <div>
              <p className="text-green-500 text-center text-sm sm:font-bold">
                {finished
                  ? "We sent you an email confirmation. Check your email inbox to reset your password."
                  : ""}
              </p>
            </div>
          </div>
        </form>
        <div className="text-center mt-10">
          <p className="text-gray-600 text-sm mb-10">
            Password issue resolved?{" "}
            <Link
              to="/login"
              className="text-sm text-[#A79277] hover:underline"
            >
              Back to Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
