import React, { useState, useEffect } from "react";
import { X, Loader } from "lucide-react";

const TermsAndConditions = ({ isOpen, onConfirm, onClose }) => {
  const [isChecked, setIsChecked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dotCount, setDotCount] = useState(1);

  useEffect(() => {
    let interval;

    if (loading) {
      interval = setInterval(() => {
        setDotCount((prev) => (prev === 3 ? 1 : prev + 1));
      }, 500);
    }

    return () => clearInterval(interval);
  }, [loading]);

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked);
  };

  if (!isOpen) {
    return null; // Don't render anything if the modal is not open
  }

  const handleTermsConfirm = async () => {
    if (isChecked) {
      // Call handleFormSubmit from the parent component
      await onConfirm(setLoading); // Pass the setLoading function to update loading state
    }
  };

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-lg w-full text-justify">
        <X
          size={30}
          className="cursor-pointer flex ml-auto mb-3"
          onClick={onClose}
        />
        <h2 className="text-lg font-semibold mb-4 text-center">
          Terms and Conditions
        </h2>
        <div className="mb-4 overflow-y-auto" style={{ maxHeight: "400px" }}>
          <h3 className="text-lg font-bold my-2">1. Order Policy</h3>
          <ul className="list-disc list-inside mb-4">
            <li>
              Once an order is placed, cancellations, returns, and refunds are
              not accepted under normal circumstances. Please review your order
              carefully before finalizing.
            </li>
            <li>
              If a delivery fails due to customer negligence, the account will
              be restricted and will not be able to place further orders. To
              lift these restrictions, please contact the manager directly.
            </li>
          </ul>
          <h3 className="text-lg font-bold my-2">2. Scheduled Delivery</h3>
          <ul className="list-disc list-inside mb-4">
            <li>
              Customers may choose scheduled delivery based on available time
              slots. These intervals are designed to provide sufficient time for
              our baristas to prepare orders effectively.
            </li>
            <li>
              The availability of delivery slots may vary based on the volume of
              orders and operational capacity. We appreciate your understanding
              that during peak times, available delivery slots may be limited.
            </li>
          </ul>
          <h3 className="text-lg font-bold my-2">3. Refunds</h3>
          <ul className="list-disc list-inside mb-4">
            <li>
              Refunds are only issued in cases of sudden unavailability of an
              item after an order has been confirmed. The café will offer a full
              refund for the unavailable item.
            </li>
            <li>
              Refunds will be processed using the original method of payment,
              and we aim to complete these promptly.
            </li>
          </ul>
          <h3 className="text-lg font-bold my-2">4. Payment Methods</h3>
          <p className="mb-4">
            We accept cash on delivery and payments via Gcash. Ensure your
            payment method is set up and available to facilitate a smooth
            transaction.
          </p>
          <h3 className="text-lg font-bold my-2">5. Liability</h3>
          <p className="mb-4">
            The café is not responsible for delays or failures in order
            processing that arise from inaccuracies provided by the customer in
            order details or payment information.
          </p>
          <h3 className="text-lg font-bold my-2">6. Amendments</h3>
          <p className="mb-4">
            The café reserves the right to update these terms and conditions at
            any time. Changes will be effective immediately upon posting the
            updated terms on our platform.
          </p>
          <h3 className="text-lg font-bold my-2">7. Contact Information</h3>
          <p className="mb-4">
            For any queries or concerns regarding your order or these terms,
            please contact our management at the café's official contact points
            provided at our premises and online platforms.
          </p>
          <p className="mt-6">
            By placing an order at our café, you agree to these terms and
            conditions. Please ensure that you understand them fully to enjoy a
            seamless service experience.
          </p>
          <p className="mt-6">
            <strong>Disclaimer:</strong> Please note that verification will be
            required for your first transaction. After placing your initial
            order, expect a call or message from the barista or manager to
            confirm the details before your order is prepared. This process
            helps prevent fraudulent orders.
          </p>
          Please read and accept the terms and conditions before proceeding.
        </div>
        <div className="mb-4 flex flex-col items-center justify-center">
          <div className="flex items-center mb-4">
            <input
              type="checkbox"
              checked={isChecked}
              onChange={handleCheckboxChange}
              className="mr-2"
            />
            <label>I accept the terms and conditions.</label>
          </div>
          <div>
            <button
              onClick={handleTermsConfirm}
              disabled={!isChecked || loading}
              className={`px-4 py-2 rounded-md ${
                isChecked && !loading
                  ? "px-4 py-2 text-white custom-button-color font-semibold cursor-pointer"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              } ${
                isChecked && loading
                  ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                  : ""
              }`}
            >
              {loading ? <Loader className="animate-spin" /> : "Confirm"}
            </button>
          </div>
          <div>
            {loading && (
              <p className="text-green-500 font-bold text-center mt-2">
                Creating your account{".".repeat(dotCount)}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsAndConditions;
