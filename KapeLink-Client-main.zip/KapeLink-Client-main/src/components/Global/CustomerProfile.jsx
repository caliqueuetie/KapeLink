import React, { useState, useEffect } from "react";
import axios from "axios";
import { ArrowLeft, Phone, Clock } from "lucide-react";
import SearchBar from "../../components/Global/SearchBar";
import FilterButton from "./FilterButton";
import HeaderFilterTooltip from "./HeaderFilterTooltip";

/**
 * Component to display and manage customer profile details and order information.
 *
 * @component CustomerProfile
 * @param {Object} selectedCustomer - The selected customer object containing customer details.
 * @param {Function} setSelectedCustomer - Function to set the selected customer.
 *
 * @returns {JSX.Element} - Returns the JSX for rendering the customer profile and orders table.
 */
const CustomerProfile = ({ selectedCustomer, setSelectedCustomer }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("");
  const [orders, setOrders] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState({});
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleString());
  const [sortField, setSortField] = useState("orderId");
  const [sortOrder, setSortOrder] = useState("asc");
  const filters = [];

  const cellFormat =
    "border-b border-gray-400 p-10 text-gray-600 text-center min-[640px]:text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4";
  const headerFormat =
    "w-screen p-3 font-medium min-[640px]:text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1 whitespace-nowrap";

  /**
   * Handles the back button click event, resetting the selected customer.
   */
  const handleBackButtonClick = () => {
    setSelectedCustomer(null);
  };

  /**
   * Fetches orders for the selected customer and updates the state.
   */
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-orders/customer/${selectedCustomer.userId}`
        );

        if (response.status === 200) {
          const ordersData = Array.isArray(response.data) ? response.data : [];

          const updatedOrders = ordersData.map((order) => ({
            ...order,
            items: order.items.map((item) => ({
              ...item,
              totalPrice: item.quantity * item.pricePerItem,
            })),
          }));

          setOrders(updatedOrders);

          if (updatedOrders.length > 0) {
            await fetchPaymentMethods(updatedOrders);
          } else {
            setPaymentMethods({});
          }
        } else if (response.status === 204) {
          // Handle the 204 No Content response
          console.warn("No orders found for this customer.");
          setOrders([]);
          setPaymentMethods({});
        }
      } catch (error) {
        if (error.response) {
          console.error("Error fetching orders:", error);
          setOrders([]);
        } else {
          // Handle network errors or unexpected errors
          console.error("Network error or unexpected error:", error);
          setOrders([]);
        }
      }
    };

    if (selectedCustomer) {
      fetchOrders();
    }
  }, [selectedCustomer]);

  /**
   * Fetches payment methods for a list of orders.
   * @param {Array} orders - The list of orders to fetch payment methods for.
   */
  const fetchPaymentMethods = async (orders) => {
    const paymentMethodIds = [
      ...new Set(orders.map((order) => order.paymentMethodId)),
    ];

    const paymentMethodPromises = paymentMethodIds.map((id) =>
      fetchPaymentMethod(id)
    );

    try {
      const methods = await Promise.all(paymentMethodPromises);
      const validMethods = methods.filter((method) => method !== null);

      const methodsMap = validMethods.reduce((acc, method) => {
        if (method && method.opid && method.name) {
          acc[method.opid] = method.name;
        } else {
          console.warn(`Invalid method found: ${JSON.stringify(method)}`);
        }
        return acc;
      }, {});

      setPaymentMethods(methodsMap);
    } catch (error) {
      console.error("Error fetching payment methods:", error);
    }
  };

  /**
   * Fetches a single payment method by ID.
   * @param {string} methodId - The ID of the payment method to fetch.
   * @returns {Object|null} - Returns the payment method data or null if not found.
   */
  const fetchPaymentMethod = async (methodId) => {
    if (!methodId) {
      console.warn("Method ID is undefined or invalid.");
      return null;
    }

    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-payment-methods/${methodId}`
      );

      return response.data;
    } catch (error) {
      console.error(`Error fetching payment method for ${methodId}:`, error);
      return null;
    }
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentTime(new Date().toLocaleString());
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  /**
   * Filters orders based on search query and active filter.
   * @returns {Array} - Returns the filtered orders.
   */
  const filteredOrders = orders.filter((order) => {
    const matchesSearch = order.items.some(
      (item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        order.orderId.toString().includes(searchQuery)
    );

    const matchesFilter =
      activeFilter === "" ||
      paymentMethods[order.paymentMethodId] === activeFilter;

    return matchesSearch && matchesFilter;
  });

  /**
   * Sorts orders based on the selected field and toggle sort order.
   * @param {string} field - The field to sort orders by.
   */
  const sortOrders = (field) => {
    const newSortOrder =
      sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(newSortOrder);
  };

  /**
   * Sorts the orders array based on the selected field and order.
   * @returns {Array} - Returns the sorted orders array.
   */
  const sortedOrders = [...filteredOrders].sort((a, b) => {
    const getValue = (order, field) => {
      switch (field) {
        case "orderId":
          return order.orderId;
        case "orderDetails":
          return order.items[0].name;
        case "orderDate":
          return new Date(order.orderDate);
        case "timeOrdered":
          return order.timeOrdered;
        case "paymentMethod":
          return paymentMethods[order.paymentMethodId] || "";
        case "totalPrice":
          return order.items.reduce((sum, item) => sum + item.totalPrice, 0);
        case "status":
          return order.verificationStatus;
        default:
          return 0;
      }
    };

    const valueA = getValue(a, sortField);
    const valueB = getValue(b, sortField);
    return valueA < valueB
      ? sortOrder === "asc"
        ? -1
        : 1
      : valueA > valueB
      ? sortOrder === "asc"
        ? 1
        : -1
      : 0;
  });

  /**
   * Returns the sorting arrow (↑ or ↓) based on the current sort field and order.
   * @param {string} field - The field to check the sort order for.
   * @returns {string|null} - Returns the sort arrow (↑ or ↓) or null if not applicable.
   */
  const getSortArrow = (field) => {
    if (sortField !== field) return null;
    return sortOrder === "asc" ? "↑" : "↓";
  };

  return (
    <div className="flex flex-col">
      <div className="flex items-center mt-4 mb-3 sm:mb-5">
        <ArrowLeft onClick={handleBackButtonClick} className="cursor-pointer" />
        <h1 className="font-semibold ml-6 text-3xl max-[640px]:text-xl max-[640px]:ml-3">
          Customer Profile
        </h1>
      </div>

      <div className="w-full border-collapse border border-gray-400 rounded-lg mt-5 mb-10 max-[640px]:mt-0 h-[640px] max-[640px]:w-[360px] 2xl:h-[760px] overflow-hidden">
        <div className="flex flex-col bg-gray-100 p-10 max-[640px]:p-5">
          <div className="flex font-semibold max-[640px]:flex-col">
            <h1 className="text-3xl max-[640px]:text-2xl">
              {selectedCustomer?.firstName} {selectedCustomer?.lastName}
            </h1>
            <div className="flex ml-auto max-[640px]:ml-0 max-[640px]:mt-1">
              <Phone className="max-[640px]:w-4 max-[640px]:mr-1" />
              <h2 className="text-xl ml-2 max-[640px]:text-base max-[640px]:ml-0">
                {selectedCustomer?.contactNumber}
              </h2>
            </div>
          </div>
          <div className="flex text-gray-500 ml-2 mt-1 max-[640px]:ml-0">
            <Clock className="max-[640px]:w-4 max-[640px]:mr-1" />
            <h1 className="font-medium ml-1 max-[640px]:ml-0 max-[640px]:text-base">
              {currentTime}
            </h1>
          </div>
        </div>

        <div className="flex justify-between items-center mt-4 mb-4 max-[640px]:flex-col max-[640px]:items-start">
          <p className="ml-5 font-medium text-2xl max-[640px]:ml-3 max-[640px]:text-xl">
            Account Activity
          </p>
          <div className="flex-col mt-2 mr-5 max-[640px]:mt-1 max-[640px]:mr-0 max-[640px]:w-full">
            <div className="inline-flex items-center space-x-3 max-[640px]:mx-2 max-[640px]:w-full">
              <div className="w-[70%]">
                <SearchBar
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                />
              </div>

              <FilterButton
                filters={filters}
                activeFilter={activeFilter}
                setActiveFilter={setActiveFilter}
                paymentMethods={paymentMethods}
                pageKey="customerProfile"
              />
              <HeaderFilterTooltip />
            </div>
          </div>
        </div>

        <div className="overflow-auto h-[550px]">
          <table className="w-full border-collapse border border-gray-400">
            <thead>
              <tr className="border-b border-gray-400 bg-gray-100">
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("orderId")}
                >
                  Order ID {getSortArrow("orderId")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("orderDetails")}
                >
                  Order Details {getSortArrow("orderDetails")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("orderDate")}
                >
                  Order Date {getSortArrow("orderDate")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("timeOrdered")}
                >
                  Time Ordered {getSortArrow("timeOrdered")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("paymentMethod")}
                >
                  Payment Method {getSortArrow("paymentMethod")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("totalPrice")}
                >
                  Total Price {getSortArrow("totalPrice")}
                </th>
                <th
                  className={`${headerFormat} cursor-pointer`}
                  onClick={() => sortOrders("status")}
                >
                  Status {getSortArrow("status")}
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedOrders.length === 0 ? (
                <tr>
                  <td colSpan="7" className={cellFormat}>
                    No orders found.
                  </td>
                </tr>
              ) : (
                sortedOrders.map((order) => (
                  <tr key={order.orderId}>
                    <td className={cellFormat}>{order.orderId}</td>
                    <td className={cellFormat}>
                      {order.items.map((item, idx) => (
                        <p key={idx}>
                          {item.name} ({item.quantity})
                        </p>
                      ))}
                    </td>
                    <td className={cellFormat}>
                      {new Date(order.orderDate).toLocaleDateString()}
                    </td>
                    <td className={cellFormat}>{order.timeOrdered}</td>
                    <td className={cellFormat}>
                      {paymentMethods[order.paymentMethodId] || "Unknown"}
                    </td>
                    <td className={cellFormat}>
                      P
                      {order.items
                        .reduce((sum, item) => sum + item.totalPrice, 0)
                        .toFixed(2)}
                    </td>
                    <td className={cellFormat}>
                      {paymentMethods[order.paymentMethodId] === "Cash"
                        ? "N/A"
                        : order.verificationStatus}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerProfile;
