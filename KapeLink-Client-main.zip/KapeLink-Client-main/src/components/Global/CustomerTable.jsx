import { useEffect, useState } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import { io } from "socket.io-client";
import axios from "axios";

/**
 * Component to display and manage the customer table with sorting and filtering functionality.
 *
 * @component CustomerTable
 * @param {string} searchQuery - The search query for filtering customers by name or contact number.
 * @param {Function} setSelectedCustomer - Function to set the selected customer when a row is clicked.
 *
 * @returns {JSX.Element} - Returns the JSX for rendering the customer table with sorting, filtering, and loading state.
 */
const CustomerTable = ({ searchQuery = "", setSelectedCustomer }) => {
  const [customers, setCustomers] = useState([]);
  const [sortField, setSortField] = useState("userId"); // Default sort field
  const [sortOrder, setSortOrder] = useState("asc"); // Default sort order
  const [loading, setLoading] = useState(true);

  /**
   * Fetches the list of customers from the API.
   *
   * @function fetchCustomers
   * @async
   * @returns {void}
   */
  const fetchCustomers = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-customers"
      );

      setCustomers(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching customers:", error);
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchCustomers();

    const socket = io("http://localhost:9000");

    socket.on("createCustomer", fetchCustomers());

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Filters the customers based on the search query.
   *
   * @function filteredCustomers
   * @returns {Array} - An array of filtered customer objects
   */
  const filteredCustomers = customers.filter((customer) => {
    const fullName = `${customer.firstName} ${customer.lastName}`.toLowerCase();
    return (
      fullName.includes(searchQuery.toLowerCase()) ||
      customer.contactNumber.includes(searchQuery)
    );
  });

   /**
   * Sorts the customers based on the selected field and order.
   *
   * @function sortedCustomers
   * @returns {Array} - An array of sorted customer objects
   */
  const sortedCustomers = [...filteredCustomers].sort((a, b) => {
    const valueA =
      sortField === "name" ? `${a.firstName} ${a.lastName}` : a[sortField];
    const valueB =
      sortField === "name" ? `${b.firstName} ${b.lastName}` : b[sortField];

    return valueA < valueB
      ? sortOrder === "asc"
        ? -1
        : 1
      : valueA > valueB
      ? sortOrder === "asc"
        ? 1
        : -1
      : 0;
  });

  const cellFormat =
    "border-b border-gray-400 py-10 2xl:px-10 text-center lg:text-base text-xs 2xl:font-normal font-thin 2xl:p-10 px-2 py-8 whitespace-nowrap";
  const headerFormat =
    "cursor-pointer w-screen lg:text-base text-xs font-semibold lg:p-3 p-1";

    /**
   * Handles the click event for selecting a customer.
   *
   * @function handleCellClick
   * @param {Object} customer - The customer object that was clicked
   * @returns {void}
   */
  const handleCellClick = (customer) => setSelectedCustomer(customer);

  /**
   * Handles the sorting action when a column header is clicked.
   *
   * @function handleSort
   * @param {string} field - The field by which to sort (e.g., userId, name)
   * @returns {void}
   */
  const handleSort = (field) => {
    const isAsc = sortField === field && sortOrder === "asc";
    setSortField(field);
    setSortOrder(isAsc ? "desc" : "asc");
  };

  return (
    <div className="flex justify-center items-center w-full h-full mt-2 md:mt-5">
      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[550px] 2xl:h-[760px] max-[640px]:max-w-80">
        {loading ? (
          <table className="h-[548px] 2xl:h-[758px] flex flex-col items-center justify-center">
            <thead>
              <tr>
                <th
                  className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
                >
                  <Player
                    autoplay
                    loop
                    src={loader}
                    style={{ height: "150px", width: "150px" }}
                  />
                </th>
              </tr>
            </thead>
          </table>
        ) : (
          <table>
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-400">
                <th
                  className={headerFormat}
                  onClick={() => handleSort("userId")}
                >
                  Customer ID{" "}
                  {sortField === "userId"
                    ? sortOrder === "asc"
                      ? "↑"
                      : "↓"
                    : null}
                </th>
                <th className={headerFormat} onClick={() => handleSort("name")}>
                  Name{" "}
                  {sortField === "name"
                    ? sortOrder === "asc"
                      ? "↑"
                      : "↓"
                    : null}
                </th>
                <th className={headerFormat}>Contact No.</th>
              </tr>
            </thead>
            <tbody>
              {sortedCustomers.length > 0 ? (
                sortedCustomers.map((customer) => (
                  <tr
                    key={customer.userId}
                    onClick={() => handleCellClick(customer)} // Set the selected customer
                    className="cursor-pointer hover:bg-gray-100"
                  >
                    <td className={cellFormat}>{customer.userId}</td>
                    <td
                      className={cellFormat}
                    >{`${customer.firstName} ${customer.lastName}`}</td>
                    <td className={cellFormat}>{customer.contactNumber}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td className={cellFormat} colSpan={3}>
                    No customers found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default CustomerTable;
