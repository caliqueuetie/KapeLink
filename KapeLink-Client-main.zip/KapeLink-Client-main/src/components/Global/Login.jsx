import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios"; // Assuming axios is used for API calls
import { Eye, EyeOff } from 'lucide-react';
import { HandlePushSubscription } from "./HandlePushSubscription";
import kapeLinkLogo from "../../images/KapeLinkNameLogo.png";

const Login = ({ login }) => {
  const [loginCreds, setContactOrEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage(""); // Clear any previous error message

    // Try login with both contactNumber and email
    const response = await login(loginCreds, password);

    if (response === "success") {
      // Save login success flag with user info (email or contactNumber)
      localStorage.setItem(
        "loginSuccess",
        JSON.stringify({
          loginCreds
        })
      );

      // Call the function to handle push subscription
      HandlePushSubscription();

      navigate("/login-switch");
    } else {
      setErrorMessage(response || "Login failed");
    }
  };

  const handleContactOrIdChange = (e) => {
    setContactOrEmail(e.target.value);
  };

  return (
    <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
      <div className="w-full max-w-sm p-8 sm:bg-white sm:shadow-md rounded-lg">
        <div className="mb-6 text-center">
          <img
            src={kapeLinkLogo}
            alt="Logo"
            className="w-1/2 mx-auto my-10"
          />
        </div>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label
              className="block text-gray-700 text-lg mb-2 font-semibold"
              htmlFor="contact-or-id"
            >
              Email / Contact Number
            </label>
            <input
              type="text"
              id="contact-or-id"
              className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
              placeholder="Enter your email or contact number"
              value={loginCreds}
              onChange={handleContactOrIdChange}
              required
            />
          </div>
          <div className="mb-2">
            <label
              className="block text-gray-700 text-lg mb-2 font-semibold"
              htmlFor="password"
            >
              Password
            </label>
            <div className="relative flex w-full">
              <input
                type={showPassword ? 'text' : 'password'}
                id="password"
                className="w-full px-3 py-2 border text-sm border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#A79277]"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              <button
                type="button"
                onClick={togglePasswordVisibility}
                className="absolute right-3 top-2"
              >
                {showPassword ? <Eye /> : <EyeOff />}
              </button>
            </div>

            <Link
              to="/reset-password"
              className="texst-sm text-[#A79277] hover:underline"
            >
              Forgot Password?
            </Link>
          </div>
          {errorMessage && (
            <div className="mb-4 text-red-500 text-center">{errorMessage}</div>
          )}
          <div className="mb-4">
            <button
              type="submit"
              className="flex justify-center w-full px-4 py-2 text-white custom-button-color rounded-md focus:outline-none focus:bg-[#A79277] font-semibold"
            >
              Sign In
            </button>
          </div>
        </form>
        <div className="text-center">
          <p className="text-gray-600 text-sm">
            Don't have an account yet?{" "}
            <Link to="/registration" className="text-[#A79277] hover:underline">
              Sign Up
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
