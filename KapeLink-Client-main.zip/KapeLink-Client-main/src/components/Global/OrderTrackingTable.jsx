import React, { useState } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";

const OrderTrackingTable = ({
  activeTab,
  data,
  searchQuery,
  setSelectedOrder,
  activeFilter,
  userNames,
  loading,
}) => {
  const cellFormat =
    "border-b border-gray-400 py-10 2xl:px-10 text-center lg:text-base text-xs 2xl:font-normal font-thin 2xl:p-10 px-2 py-8 whitespace-nowrap";
  const headerFormat =
    "cursor-pointer w-screen lg:text-base text-xs font-semibold lg:p-3 p-1";

  // Set default sorting to "Date Ordered" and "Time Ordered" in descending order
  const [activeColumn, setActiveColumn] = useState("Date Ordered");
  const [sortDirection, setSortDirection] = useState("desc");

  /**
   * Handles the click event on an order cell and updates the selected order in the state.
   *
   * @function handleCellClick
   * @param {Object} order - The order object that was clicked.
   * @returns {void}
   */
  const handleCellClick = (order) => {
    setSelectedOrder(order);
  };

  /**
   * Returns the appropriate sort arrow (↑ or ↓) based on the current active column and sort direction.
   *
   * @function getSortArrow
   * @param {string} field - The name of the column field to check.
   * @returns {string|null} - Returns "↑" for ascending or "↓" for descending, or null if the field is not active.
   */
  const getSortArrow = (field) => {
    if (activeColumn !== field) return null;
    return sortDirection === "asc" ? "↑" : "↓";
  };

  /**
   * Handles sorting logic by toggling the sort direction if the same column is clicked, or setting a new active column.
   *
   * @function handleSort
   * @param {string} column - The column name to sort by.
   * @returns {void}
   */
  const handleSort = (column) => {
    if (activeColumn === column) {
      // Toggle the sort direction if the same column is clicked again
      setSortDirection((prevDirection) =>
        prevDirection === "asc" ? "desc" : "asc"
      );
    } else {
      // Set the clicked column as the active one and reset sort direction to 'asc'
      setActiveColumn(column);
      setSortDirection("asc");
    }
  };

  /**
   * Filters and sorts order data based on tab, search query, active filter, and sort direction.
   *
   * @constant
   * @type {Array<Object>}
   */
  const filteredData = data
    .filter((order) => {
      // Remove orders that are not payment verified
      if (order.verificationStatus && order.verificationStatus !== "Verified") {
        return false;
      }

      const orderStatus =
        order.tracking && order.tracking.length > 0
          ? order.tracking[order.tracking.length - 1].orderStatus.toLowerCase()
          : "";

      // Exclude order that has a status of Preparing, Out For Delivery, and For Pickup
      if (
        order.orderStatus === "Preparing" ||
        order.orderStatus === "Out For Delivery" ||
        order.orderStatus === "For Pickup"
      ) {
        return false;
      }

      if (
        orderStatus === "preparing" ||
        orderStatus === "out for delivery" ||
        orderStatus === "for pickup"
      ) {
        return false;
      }

      const matchesTab =
        activeTab === "All" ||
        orderStatus === activeTab.toLowerCase() ||
        order.orderStatus === activeTab;

      const searchQueryLower = searchQuery.toLowerCase();

      const userName = userNames[order.orderId] || "NA";
      const matchesSearch =
        userName.toLowerCase().includes(searchQueryLower) ||
        order.orderOption.toLowerCase().includes(searchQueryLower) ||
        order.orderDate.toLowerCase().includes(searchQueryLower) ||
        order.timeOrdered.toLowerCase().includes(searchQueryLower);

      const matchesActiveFilter =
        !activeFilter ||
        (activeFilter === "Delivery" && order.orderOption === "Delivery") ||
        (activeFilter === "Pickup" && order.orderOption === "Pickup") ||
        (activeFilter === "In-store" && order.orderOption === "In-store");

      return matchesTab && matchesSearch && matchesActiveFilter;
    })
    .sort((a, b) => {
      let comparison = 0;

      // First compare by Date Ordered
      const dateOrderedA = new Date(a.orderDate);
      const dateOrderedB = new Date(b.orderDate);
      comparison = dateOrderedA - dateOrderedB;

      // If dates are equal, compare by Time Ordered
      if (comparison === 0) {
        const timeOrderedA = a.timeOrdered || "00:00";
        const timeOrderedB = b.timeOrdered || "00:00";
        const dateA = new Date(`1970-01-01T${timeOrderedA}:00Z`);
        const dateB = new Date(`1970-01-01T${timeOrderedB}:00Z`);
        comparison = dateA - dateB;
      }

      // Apply sorting direction
      return sortDirection === "asc" ? comparison : -comparison;
    });

  return (
    <div className="flex justify-center items-center w-full h-full mt-5">
      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[550px] 2xl:h-[760px] max-[640px]:max-w-xs">
        {loading ? (
          <table className="h-[490px] 2xl:h-[700px] flex flex-col items-center justify-center">
            <thead>
              <tr>
                <th
                  className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
                >
                  <Player
                    autoplay
                    loop
                    src={loader}
                    style={{ height: "150px", width: "150px" }}
                  />
                </th>
              </tr>
            </thead>
          </table>
        ) : (
          <table>
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-400">
                <th className={headerFormat} onClick={() => handleSort("Name")}>
                  Name {getSortArrow("Name")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("Order Option")}
                >
                  Order Option {getSortArrow("Order Option")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("Time Ordered")}
                >
                  Time Ordered {getSortArrow("Time Ordered")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("Date Ordered")}
                >
                  Date Ordered {getSortArrow("Date Ordered")}
                </th>
                <th
                  className={headerFormat}
                  onClick={() => handleSort("Total Price")}
                >
                  Total Price {getSortArrow("Total Price")}
                </th>
                <th className={headerFormat}>Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length > 0 ? (
                <>
                  {filteredData.map((order) => {
                    const status =
                      order.tracking && order.tracking.length > 0
                        ? order.tracking[order.tracking.length - 1].orderStatus
                        : order.orderStatus;
                    const orderTotalPrice = order.items.reduce(
                      (total, item) =>
                        total + item.quantity * item.pricePerItem,
                      0
                    );
                    const userName = userNames[order.orderId] || "NA";
                    return (
                      <tr
                        key={order.orderId}
                        onClick={() => handleCellClick(order)}
                        className="cursor-pointer hover:bg-gray-100"
                      >
                        <td className={cellFormat}>{userName}</td>
                        <td className={cellFormat}>{order.orderOption}</td>
                        <td className={cellFormat}>{order.timeOrdered}</td>
                        <td className={cellFormat}>{order.orderDate}</td>
                        <td className={cellFormat}>
                          {" "}
                          P
                          {orderTotalPrice.toLocaleString("en-US", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                          })}
                        </td>
                        <td className={cellFormat}>{status}</td>
                      </tr>
                    );
                  })}
                </>
              ) : (
                <tr>
                  <td colSpan="6" className="text-center p-4">
                    No orders found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default OrderTrackingTable;
