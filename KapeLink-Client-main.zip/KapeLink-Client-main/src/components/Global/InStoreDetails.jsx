import { ArrowLeft } from "lucide-react";
import ListOfItems from "./ListOfItems";

const InStoreDetails = ({
  selectedOrder,
  setSelectedOrder,
  fetchOrdersData,
}) => {
  const headerDetailsFormat =
    "xl:text-lg 2xl:texl-xl text-lg font-semibold mb-2 max-[640px]:mb-0";
  const contentDetailsFormat =
    "xl:text-lg 2xl:texl-xl text-lg text-color-custom font-regular max-w-72 min-w-44";

  /**
   * Calculates the total price of all items in the selected order, rounded to two decimal places.
   *
   * @constant {string} totalPrice - The total price of all the items in the selected order.
   * @returns {string} - The total price, formatted to two decimal places.
   */
  const totalPrice = selectedOrder.items
    .reduce((total, item) => total + item.totalPrice, 0)
    .toFixed(2);

  /**
   * Handles the back button click event by fetching the latest orders and resetting the selected order.
   *
   * @function handleBackButtonClick
   * @returns {void} - Fetches the orders data and resets the selected order to null.
   */
  const handleBackButtonClick = () => {
    fetchOrdersData();
    setSelectedOrder(null);
  };

  return (
    <>
      <div className="flex flex-col">
        <div className="flex justify-between items-center mt-4 mb-10 max-[640px]:flex-col max-[640px]:mb-4 max-[640px]:items-start">
          <div className="flex items-center mr-5">
            <ArrowLeft
              onClick={handleBackButtonClick}
              className="cursor-pointer"
            />
            <h1 className="text-3xl font-semibold ml-5 max-[640px]:text-xl whitespace-nowrap">
              Order Details
            </h1>
            <h2 className="in-store-label text-white text-xl font-medium rounded-full px-10 py-1 ml-5 max-[640px]:px-5 max-[640px]:text-sm whitespace-nowrap">
              In-Store
            </h2>
          </div>
          <div className="ml-auto text-3xl font-semibold max-[640px]:text-lg max-[640px]:ml-0 max-[640px]:mt-7">
            {/* Make the ID # here dynamic based on the order selected value */}
            <h1 className="whitespace-nowrap">
              Order ID #
              <span className="order-id-num max-[640px]:block">
                {selectedOrder.orderId}
              </span>
            </h1>
          </div>
        </div>

        <div className="flex lg:ml-14 ml-0 2xl:mb-9 mb-5 max-[640px]:flex-col gap-6 lg:gap-24 2xl:gap-32">
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Date</h1>
            <h1 className={contentDetailsFormat}>{selectedOrder.orderDate}</h1>
          </div>
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Time Ordered</h1>
            <h1 className={contentDetailsFormat}>
              {selectedOrder.timeOrdered}
            </h1>
          </div>
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Dining Option</h1>
            <h1 className={contentDetailsFormat}>
              {selectedOrder.dineIn ? "Dine In" : "Take Out"}
            </h1>
          </div>
        </div>

        <div className="flex flex-col lg:ml-14 lg:mt-5 ml-0 mt-4 max-[640px]:max-w-80">
          <h1 className={headerDetailsFormat}>List of Items</h1>
          <ListOfItems selectedOrder={selectedOrder} />
          <h1 className="text-xl font-semibold mt-3 max-[640px]:text-lg max-[640px]:font-medium text-right">
            Total Price: P{totalPrice}
          </h1>

          <h1 className="mt-5 mb-5 font-semibold self-end border-2 border-custom-brown-border rounded-full py-2 px-10 text-color-custom text-base sm:text-xs md:text-sm xl:text-xl">
            Completed
          </h1>
        </div>
      </div>
    </>
  );
};

export default InStoreDetails;
