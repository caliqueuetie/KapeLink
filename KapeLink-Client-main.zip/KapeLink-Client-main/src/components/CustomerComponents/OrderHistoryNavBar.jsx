import React, { useState, useRef } from "react";

/**
 * A navigation bar component for filtering order history.
 *
 * - Provides options to set filters for viewing orders.
 * - Calls `setFilter` to update the filter state when a filter option is selected.
 *
 * @function OrderHistoryNavBar
 * @param {function} setFilter - The function to update the filter state.
 */
const OrderHistoryNavBar = ({ setFilter }) => {
  const [selectedFilter, setSelectedFilter] = useState("All");
  const containerRef = useRef(null);

  /**
   * Handles the click event on a filter button to update the filter and scroll to the selected button.
   *
   * - Sets the selected filter using `setFilter`.
   * - Scrolls the container to bring the selected button into view if it's not fully visible.
   *
   * @function handleFilterClick
   * @param {string} filter - The filter value to apply.
   * @param {number} index - The index of the selected filter button.
   */
  const handleFilterClick = (filter, index) => {
    setFilter(filter);
    setSelectedFilter(filter);

    const container = containerRef.current;
    const selectedButton = document.getElementById(`filter-${index}`);

    if (selectedButton && container) {
      // Calculate the offset of the selected button
      const buttonLeft = selectedButton.offsetLeft;
      const containerRight = container.scrollLeft + container.offsetWidth;

      // Scroll to the selected button if it's not fully visible
      if (buttonLeft + selectedButton.offsetWidth > containerRight) {
        container.scrollTo({
          left:
            buttonLeft -
            container.offsetWidth / 2 +
            selectedButton.offsetWidth / 2,
          behavior: "smooth",
        });
      }
    }
  };

  /**
   * Defines a list of filters used for filtering order statuses.
   *
   * - Each filter object contains a `label` (display name) and a `status` (corresponding order status value).
   * - The filters represent various order statuses, such as "Under Verification", "Preparing", "Out for Delivery", etc.
   *
   * @constant filters
   * @type {Array<Object>}
   * @property {string} label - The label to display for the filter.
   * @property {string} status - The corresponding status to filter orders by.
   */
  const filters = [
    { label: "All", status: "All" },
    { label: "Under Verification", status: "Not Verified" },
    { label: "Preparing", status: "Preparing" },
    { label: "Out for Delivery", status: "Out for Delivery" },
    { label: "For Pickup", status: "For Pickup" },
    { label: "Completed", status: "Complete" },
    { label: "Cancelled", status: "Cancelled" },
  ];

  return (
    <nav className="mt-10 container mx-auto px-5">
      <div
        ref={containerRef}
        className="flex font-medium overflow-x-auto hide-scrollbar scroll-smooth"
      >
        {filters.map((filter, index) => (
          <button
            key={filter.label}
            id={`filter-${index}`}
            className={`px-4 py-3 whitespace-nowrap transition-colors duration-200 ease-in-out
                ${
                  selectedFilter === filter.status
                    ? "text-[#A79277] border-b-2 border-[#A79277]"
                    : "text-black"
                }
                hover:text-[#A79277]`}
            onClick={() => handleFilterClick(filter.status, index)}
          >
            {filter.label}
          </button>
        ))}
      </div>
    </nav>
  );
};

export default OrderHistoryNavBar;
