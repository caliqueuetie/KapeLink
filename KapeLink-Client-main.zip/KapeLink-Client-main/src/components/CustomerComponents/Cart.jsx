import React, { useState, useEffect, useRef } from "react";
import { Plus, Minus, Trash2 } from "lucide-react";
import axios from "/axios.config";
import { io } from "socket.io-client";
import { motion } from "framer-motion";
import exitIcon from "../../images/ExitIcon.png";

/**
 * A cart component that displays the user's selected items in the cart.
 *
 * This component allows the user to view the items they've added to the cart, update the quantities
 * of those items, and remove items from the cart. It provides buttons for reviewing the order and
 * closing the cart.
 *
 * @param {boolean} isCartOpen Boolean indicating if the cart is currently open or closed.
 * @param {Function} onClose Function to handle closing the cart when the user is done.
 * @param {Array} cartItems List of items currently in the cart, each containing details like
 * product name, price, quantity, etc.
 * @param {Function} onReviewOrder Function to trigger the order review process when the user is
 * ready to proceed to checkout.
 * @param {Function} updateCartItemQuantity Function to update the quantity of a specific cart item.
 * @param {Function} removeCartItem Function to remove a specific item from the cart.
 */

const Cart = ({
  isCartOpen,
  onClose,
  cartItems,
  onReviewOrder,
  updateCartItemQuantity,
  removeCartItem,
}) => {
  const [locations, setLocations] = useState([]);
  const [deliveryOption, setDeliveryOption] = useState("pick-up");
  const [showDeliveryDropdown, setShowDeliveryDropdown] = useState(false);
  const [preferredDeliveryTime, setPreferredDeliveryTime] = useState("");
  const [preferredDeliveryLocation, setPreferredDeliveryLocation] =
    useState("");
  const [preferredFloor, setPreferredFloor] = useState("");
  const [showLocationError, setShowLocationError] = useState(false);
  const [showFloorError, setShowFloorError] = useState(false);
  const [orderTime, setOrderTime] = useState({});
  const [showTimeError, setShowTimeError] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [locationNotFoundError, setLocationNotFoundError] = useState(false);
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);
  const [loading, setLoading] = useState(true);

  /**
   * Fetches location data from the API endpoint and updates the state with the fetched data.
   * If the response content type is 'text/html', it sets the locations state to an empty array.
   *
   * @async
   * @function fetchLocations
   * @returns {Promise<void>}
   * @throws Will log an error message if the fetch operation fails.
   */
  const fetchLocations = async () => {
    try {
      const locationsResponse = await axios.get(
        "http://localhost:9000/api/kape-link/get-locations"
      );
      if (locationsResponse.headers["content-type"] !== "text/html") {
        setLocations(locationsResponse.data);
      } else {
        setLocations([]);
      }
    } catch (error) {
      console.error("Error fetching location data:", error);
    }
  };

  /**
   * useEffect hook to fetch location data and set up a WebSocket connection.
   *
   * - Calls fetchLocations() to initially fetch and set location data.
   * - Sets up a WebSocket connection.
   * - Listens for "locations" events on the WebSocket and calls fetchLocations() upon receiving the event.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   */
  useEffect(() => {
    fetchLocations();
    const socket = io("http://localhost:9000");
    socket.on("locations", () => {
      fetchLocations();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Asynchronous function to fetch order time data from the API.
   *
   * - Sets the loading state to true before starting the data fetch.
   * - Sends a GET request to fetch possible order time.
   * - Sets the fetched order time data to the state if the request is successful.
   * - Logs any errors encountered during the fetch operation.
   * - Sets the loading state to false after the fetch operation is completed, regardless of success or failure.
   *
   * @function fetchOrderTime
   */
  const fetchOrderTime = async () => {
    setLoading(true);
    try {
      const orderTimeResponse = await axios.get(
        "http://localhost:9000/api/kape-link/get-time"
      );
      setOrderTime(orderTimeResponse.data);
    } catch (error) {
      console.error("Error fetching time data:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Filters the locations array based on the following criteria:
   *
   * - Ensures `locations` is an array before applying the filter.
   * - Excludes locations with a status of "Hidden".
   * - Includes locations where the `locationName` contains the search term (case-insensitive).
   *
   * @constant {Array} filteredLocations - The filtered array of location objects.
   */
  const filteredLocations = Array.isArray(locations)
    ? locations.filter(
        (location) =>
          location.status !== "Hidden" &&
          location.locationName.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  /**
   * useEffect hook to fetch order time data and set up a WebSocket connection.
   *
   * - Calls fetchOrderTime() to initially fetch and set the order time data.
   * - Sets up a WebSocket connection.
   * - Listens for "orderTime" events on the WebSocket and calls fetchOrderTime() upon receiving the event.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   */
  useEffect(() => {
    fetchOrderTime();
    const socket = io("http://localhost:9000");
    socket.on("orderTime", () => {
      fetchOrderTime();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Handles the change in delivery option selection.
   *
   * - Updates the deliveryOption state with the selected option.
   * - Toggles visibility of the delivery dropdown based on the selected option.
   * - Resets error states related to location, floor, time, and location not found.
   *
   * @function handleDeliveryOptionChange
   * @param {Object} event - The change event triggered by selecting a delivery option.
   * @param {string} event.target.value - The value of the selected delivery option.
   */
  const handleDeliveryOptionChange = (event) => {
    const selectedOption = event.target.value;
    setDeliveryOption(selectedOption);
    setShowDeliveryDropdown(selectedOption === "delivery");
    setShowLocationError(false);
    setShowFloorError(false);
    setShowTimeError(false);
    setLocationNotFoundError(false);
  };

  /**
   * Handles the selection of a location.
   *
   * - Calls handlePreferredDeliveryLocationChange with the selected location's name.
   * - Sets the searchTerm state to the selected location's name.
   * - Closes the location dropdown by setting isOpen to false.
   *
   * @function handleLocationSelect
   * @param {Object} location - The selected location object.
   * @param {string} location.locationName - The name of the selected location.
   */
  const handleLocationSelect = (location) => {
    handlePreferredDeliveryLocationChange({
      target: { value: location.locationName },
    });
    setSearchTerm(location.locationName);
    setIsOpen(false);
  };

  /**
   * Handles the change in the search term input.
   *
   * - Updates the searchTerm state with the new value from the input field.
   * - Sets the isOpen state to true, which likely opens the location dropdown.
   * - Resets the locationNotFoundError state to false to clear any error messages.
   *
   * @function handleSearchTermChange
   * @param {Object} event - The event object from the input field change.
   * @param {string} event.target.value - The new value from the search term input field.
   */
  const handleSearchTermChange = (event) => {
    setSearchTerm(event.target.value);
    setIsOpen(true);
    setLocationNotFoundError(false);
  };

  /**
   * Handles the change in the preferred delivery location.
   *
   * - Updates the preferredDeliveryLocation state with the new value from the input field.
   * - Resets the showLocationError and locationNotFoundError states to false to clear any error messages.
   *
   * @function handlePreferredDeliveryLocationChange
   * @param {Object} event - The event object from the input field change.
   * @param {string} event.target.value - The new value for the preferred delivery location.
   */
  const handlePreferredDeliveryLocationChange = (event) => {
    setPreferredDeliveryLocation(event.target.value);
    setShowLocationError(false);
    setLocationNotFoundError(false);
  };

  /**
   * Toggles the state of the dropdown visibility.
   *
   * - Sets the `isOpen` state to the opposite of its current value, either opening or closing the dropdown.
   *
   * @function toggleDropdown
   */
  const toggleDropdown = () => {
    setIsOpen((prev) => !prev);
  };

  /**
   * useEffect hook to handle closing the dropdown when clicking outside.
   *
   * - Sets up an event listener for the "mousedown" event to detect clicks outside the dropdown.
   * - Closes the dropdown by setting `isOpen` to `false` if the click occurs outside the dropdown and search input.
   * - Cleans up the event listener when the component unmounts or dependencies change.
   *
   * @function useEffect
   */
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target) &&
        event.target !== searchInputRef.current
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [dropdownRef, searchInputRef]);

  /**
   * Handles the change of preferred delivery time.
   *
   * - Updates the state for preferred delivery time based on the selected value.
   * - Resets the time error state when a new value is selected.
   *
   * @function handlePreferredDeliveryTimeChange
   * @param {Object} event - The change event object.
   * @param {string} event.target.value - The selected preferred delivery time.
   */
  const handlePreferredDeliveryTimeChange = (event) => {
    setPreferredDeliveryTime(event.target.value);
    setShowTimeError(false);
  };

  /**
   * Handles the review order action with validation and order summary generation.
   *
   * - Checks if the cart is empty and exits early if no items are in the cart.
   * - Validates location selection for delivery option and sets appropriate error states.
   * - Validates time, location, and floor selection based on delivery option.
   * - Resets error states and prepares an order summary.
   * - Formats cart items into the order summary and calls `onReviewOrder` with the generated data.
   *
   * @function handleReviewOrder
   */
  const handleReviewOrder = () => {
    if (cartItems.length === 0) {
      return;
    }

    const locationExists =
      Array.isArray(locations) &&
      locations.some(
        (location) =>
          location.locationName.toLowerCase() === searchTerm.toLowerCase()
      );

    if (deliveryOption === "delivery" && !locationExists) {
      setLocationNotFoundError(true);
      return;
    } else {
      setPreferredDeliveryLocation(searchTerm);
    }

    if (!preferredDeliveryTime) {
      setShowTimeError(true);
      return;
    } else if (deliveryOption === "delivery" && !preferredDeliveryLocation) {
      setShowLocationError(true);
      return;
    } else if (deliveryOption === "delivery" && !preferredFloor) {
      setShowFloorError(true);
      return;
    }

    setShowTimeError(false);
    setShowLocationError(false);
    setShowFloorError(false);
    setLocationNotFoundError(false);

    const formattedItems = cartItems.map((item) => ({
      productId: item.prodId,
      category: item.category,
      menuCategory: item.menuCategory,
      salesReport: item.salesReport,
      type: item.type,
      name: item.name,
      quantity: item.quantity,
      pricePerItem: item.price,
      totalPrice: item.price * item.quantity,
    }));

    const orderSummary = {
      items: formattedItems,
      orderDate: orderTime.date,
      orderOption: deliveryOption === "pick-up" ? "Pickup" : "Delivery",
      paymentMethodId: "",
      ...(deliveryOption === "pick-up"
        ? { pickUpTime: preferredDeliveryTime }
        : {
            deliveryDetails: {
              building: preferredDeliveryLocation,
              description: preferredFloor,
              deliveryTime: preferredDeliveryTime,
            },
          }),
    };
    onReviewOrder(orderSummary);
  };

  /**
   * Defines animation variants for the cart component.
   *
   * - `open`: Defines the animation for when the cart is open, setting its position to the default (`x: 0`) and fully visible (`opacity: 1`).
   * - `closed`: Defines the animation for when the cart is closed, moving it off-screen (`x: "100%"`) and making it invisible (`opacity: 0`).
   * - Both variants have a `transition` specifying a 0.5-second duration with an "easeInOut" easing function.
   *
   * @constant cartVariants
   */
  const cartVariants = {
    open: {
      x: 0,
      opacity: 1,
      transition: { duration: 0.5, ease: "easeInOut" },
    },
    closed: {
      x: "100%",
      opacity: 0,
      transition: { duration: 0.5, ease: "easeInOut" },
    },
  };

  return (
    !loading && (
      <motion.div
        className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-lg overflow-y-auto"
        initial="closed"
        animate={isCartOpen ? "open" : "closed"}
        exit="exit"
        variants={cartVariants}
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Shopping Bag</h2>
            <button
              onClick={onClose}
              className="text-gray-500 hover:text-gray-700"
            >
              <img src={exitIcon} alt="Close" className="h-4 w-4" />
            </button>
          </div>

          {cartItems.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            cartItems.map((item, index) => (
              <div
                key={index}
                className="border p-4 mb-2 flex justify-between items-center"
              >
                <div>
                  <p className="font-medium">
                    {item.name}{" "}
                    {item.type
                      ? item.type.charAt(0).toUpperCase() + item.type.slice(1)
                      : ""}
                  </p>
                  <p>P{item.price}</p>
                </div>
                <div className="flex items-center space-x-3">
                  <button
                    className="px-1 py-1 text-white bg-[#A79277] rounded"
                    onClick={() => {
                      const newQuantity = item.quantity - 1;
                      if (newQuantity > 0) {
                        updateCartItemQuantity(item, newQuantity);
                      } else {
                        removeCartItem(item);
                      }
                    }}
                  >
                    <Minus size={15} />
                  </button>
                  <input
                    type="text"
                    value={item.quantity}
                    onChange={(e) => {
                      const newQuantity = parseInt(e.target.value, 10);
                      if (!isNaN(newQuantity) && newQuantity > 0) {
                        updateCartItemQuantity(item, newQuantity);
                      } else if (newQuantity <= 0) {
                        removeCartItem(item);
                      }
                    }}
                    className="mx-1 text-center border border-gray-300 rounded w-10"
                  />
                  <button
                    className="px-1 py-1 text-white bg-[#A79277] rounded"
                    onClick={() =>
                      updateCartItemQuantity(item, item.quantity + 1)
                    }
                  >
                    <Plus size={15} />
                  </button>
                  <button onClick={() => removeCartItem(item)} className="ml-4">
                    <Trash2 size={20} color="#E6676B" />
                  </button>
                </div>
              </div>
            ))
          )}

          <div className="mt-4">
            <h3 className="text-lg font-medium mb-2">Pick up or Delivery</h3>
            <div className="flex items-center mb-4">
              <label className="mr-4">
                <input
                  type="radio"
                  value="pick-up"
                  checked={deliveryOption === "pick-up"}
                  onChange={handleDeliveryOptionChange}
                  className="custom-radio-button"
                />
                Pick-up
              </label>
              <label>
                <input
                  type="radio"
                  value="delivery"
                  checked={deliveryOption === "delivery"}
                  onChange={handleDeliveryOptionChange}
                  className="custom-radio-button"
                />
                Delivery
              </label>
            </div>

            {showDeliveryDropdown && (
              <div>
                <h4 className="sm:text-lg font-medium mb-2">
                  Select Delivery Location
                </h4>
                <input
                  type="text"
                  placeholder="Type Your Deliver Location"
                  value={searchTerm}
                  onChange={handleSearchTermChange}
                  onClick={toggleDropdown}
                  className="w-full border border-gray-300 rounded p-1 sm:p-2"
                  ref={searchInputRef}
                />
                {isOpen && (
                  <div
                    ref={dropdownRef}
                    className="w-full p-2 rounded border border-t-0 bg-white z-10 max-h-60 overflow-y-auto"
                  >
                    {filteredLocations.length > 0 ? (
                      filteredLocations.map((location, index) => (
                        <div
                          key={index}
                          onClick={() => handleLocationSelect(location)}
                          className="p-2 hover:bg-gray-200 cursor-pointer"
                        >
                          {location.locationName}
                        </div>
                      ))
                    ) : (
                      <div className="text-gray-600 rounded">
                        Location not found
                      </div>
                    )}
                  </div>
                )}
                {showLocationError && (
                  <p className="text-red-500 text-sm">
                    Please enter a delivery location.
                  </p>
                )}
                {locationNotFoundError && (
                  <p className="text-red-500 text-sm mt-1">
                    Location not found. Please select a valid location.
                  </p>
                )}
                <>
                  <h3 className="sm:text-lg font-medium mt-4 mb-2">
                    Choose Floor and Room No.
                  </h3>
                  <input
                    type="text"
                    className="w-full p-1 sm:p-2 rounded mb-4 border"
                    value={preferredFloor}
                    onChange={(e) => setPreferredFloor(e.target.value)}
                  />

                  {showFloorError && (
                    <p className="text-red-500 -mt-2 mb-2">
                      Please input a Floor and Room Number.
                    </p>
                  )}
                </>
              </div>
            )}
            <h3 className="sm:text-lg font-medium mb-2">
              Choose Preferred Time
            </h3>
            <p className="text-sm text-gray-600 mb-2">
              Note that order fulfillment times may be adjusted based on order
              volume.
            </p>
            <select
              className="w-full border p-1 sm:p-2 rounded"
              value={preferredDeliveryTime}
              onChange={handlePreferredDeliveryTimeChange}
            >
              <option value="">Select a preferred time range</option>{" "}
              {/* Default option */}
              {orderTime &&
              Array.isArray(orderTime.timeSlots) &&
              orderTime.timeSlots.length > 0 ? (
                orderTime.timeSlots.map((slot) => (
                  <option key={slot} value={slot}>
                    {slot}
                  </option>
                ))
              ) : (
                <option disabled>No available time slots</option> // Fallback option
              )}
            </select>
            {showTimeError && (
              <p className="text-red-500 mt-2">
                Please select a preferred pickup time.
              </p>
            )}
          </div>
          {orderTime.timeSlots && orderTime.timeSlots.length === 0 ? (
            <p className="text-gray-500 text-sm mt-4 self-center">
              The store is currently closed
            </p>
          ) : (
            <button
              onClick={handleReviewOrder}
              className="custom-button-color text-white font-medium px-5 py-2 rounded-full mt-4 self-center"
            >
              Review Order
            </button>
          )}
        </div>
      </motion.div>
    )
  );
};

export default Cart;
