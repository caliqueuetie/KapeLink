import React from "react";

/**
 * ReuploadSuccessPopup component that displays a success message after reuploading proof of payment.
 *
 * - Displays a modal with a success message confirming the successful reupload.
 * - Includes an "Okay" button that triggers the `onClose` function to close the popup.
 *
 * @component ReuploadSuccessPopup
 * @param {Function} onClose - Function to close the success popup when the "Okay" button is clicked.
 */
const ReuploadSuccessPopup = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="w-1/4 bg-white p-14 rounded-lg shadow-lg relative max-[640px]:w-80 max-[640px]:p-5">
        <div className="text-center mb-5">
          <h2 className="text-lg">
            Proof of payment has been successfully reuploaded.
          </h2>
        </div>
        <div className="flex justify-center">
          <button
            className="bg-[#A79277] hover:bg-[#8d6f5e] text-white font-bold py-2 px-8 rounded-full"
            onClick={onClose}
          >
            Okay
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReuploadSuccessPopup;
