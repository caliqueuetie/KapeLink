import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

/**
 * Renders an individual order history card displaying the order details.
 *
 * @function OrderHistoryCard
 * @param {Object} order - The order details to display.
 * @param {Array} paymentOptions - The list of payment options available for the order.
 * @returns {JSX.Element} - The rendered order history card component.
 */
const OrderHistoryCard = ({ order, paymentOptions }) => {
  const [type, setType] = useState("");

  /**
   * Retrieves the name of a payment method based on its opid.
   *
   * - Searches through the `paymentOptions` array to find a payment method with the matching opid.
   * - Returns the name of the payment method if found, otherwise returns "Not available".
   *
   * @function getPaymentMethodName
   * @param {number} opid - The unique identifier of the payment method.
   * @returns {string} - The name of the payment method or "Not available" if not found.
   */
  const getPaymentMethodName = (opid) => {
    const paymentMethod = paymentOptions.find((method) => method.opid === opid);
    return paymentMethod ? paymentMethod.name : "Not available";
  };

  /**
   * Effect that sets the type based on the presence of a pickUpTime in the order.
   *
   * - If `order.pickUpTime` is defined, sets the type to "Pick Up Time:".
   * - If `order.pickUpTime` is not defined, sets the type to "Delivery Time:".
   *
   * @function useEffect
   * @dependency [order.pickUpTime] - Runs when `order.pickUpTime` is updated.
   */
  useEffect(() => {
    if (order.pickUpTime) {
      setType("Pick Up Time:");
    } else {
      setType("Delivery Time:");
    }
  }, [order.pickUpTime]);

  /**
   * Retrieves the latest tracking status from the order.
   *
   * - If `order.tracking` has any items, the latest tracking status is taken from the last element in the `tracking` array.
   * - If `order.tracking` is empty or not defined, the `verificationStatus` is used as the fallback status.
   *
   * @const latestTrackingStatus
   */
  const latestTrackingStatus =
    order.tracking?.length > 0
      ? order.tracking[order.tracking.length - 1].orderStatus
      : order.verificationStatus;

  return (
    <div className="border border-gray-200 rounded-lg p-6 shadow-md bg-white transition-transform transform hover:scale-105 hover:shadow-lg flex flex-col justify-between">
      <div>
        {/* Order Info */}
        <div className="sm:flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-800">
            Order Date:{" "}
            <span className="font-normal">
              {order.orderDate || "Not available"}
            </span>
          </h3>
          <p className="md:ml-5 text-sm text-gray-600">
            <span className="font-semibold">Status:</span>{" "}
            {latestTrackingStatus}
          </p>
        </div>

        {/* Order Option and Time */}
        <div className="mb-4">
          <p className="text-sm text-gray-600">
            <span className="font-semibold">Order Option:</span>{" "}
            {order.orderOption || "Not available"}
          </p>
          <p className="text-sm text-gray-600">
            <span className="font-semibold">{type}</span>{" "}
            {order.pickUpTime ||
              order.deliveryDetails?.deliveryTime ||
              "Not available"}
          </p>
        </div>

        {/* Payment Method */}
        <div className="text-sm text-gray-600">
          <span className="font-semibold">Payment Method:</span>{" "}
          {getPaymentMethodName(order.paymentMethodId) || "Not available"}
        </div>
      </div>

      {/* Button Aligned to Bottom Right */}
      <div className="flex justify-end mt-4">
        <Link
          to={`/order/${order.orderId}`}
          className="max-[640px]:px-4 max-[640px]:py-1 max-[640px]:text-base px-5 py-2 custom-button-color text-white sm:font-semibold rounded-full shadow-md transition-transform transform hover:scale-105"
        >
          View Details
        </Link>
      </div>
    </div>
  );
};

export default OrderHistoryCard;
