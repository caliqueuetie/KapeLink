import React, { useState, useEffect, useRef, deliveryOption } from "react";
import axios from "/axios.config";
import PlaceOrderPopUp from "./PlaceOrderPopUp"; // Import the popup
import { io } from "socket.io-client";
import { Loader } from "lucide-react";

/**
 * A component that handles the review and payment process for an order.
 *
 * This component displays order details to the user and allows them to review
 * and confirm their payment method. It also provides navigation options to
 * go back to the previous screen or close the review screen.
 *
 * @param {boolean} isOpen Determines whether the ReviewPayment modal is visible.
 * @param {function} onClose Function to handle closing the ReviewPayment modal.
 * @param {object} orders Contains the order details to be reviewed.
 * @param {function} onBack Function to handle going back to the previous screen.
 * @param {object} user Contains the user details for displaying payment information.
 */
const ReviewPayment = ({ isOpen, onClose, orders, onBack, user }) => {
  const [paymentMethod, setPaymentMethod] = useState({});
  const [file, setFile] = useState(null);
  const [options, setOptions] = useState([]);
  const [warningMessage, setWarningMessage] = useState("");
  const [fileName, setFileName] = useState("");
  const [isMessagePopupOpen, setIsMessagePopupOpen] = useState(false); // State for popup
  const [loading, setLoading] = useState(false);

  /**
   * Effect that fetches payment methods when the component mounts.
   *
   * - Calls `fetchPaymentMethods()` to retrieve the available payment methods from the server.
   *
   * @function useEffect
   */
  useEffect(() => {
    fetchPaymentMethods();
  }, []);

  /**
   * Effect that sets the initial payment method when options are available.
   *
   * - If there are payment method options available (`options.length > 0`) and no payment method is currently selected (`!paymentMethod`), it sets the payment method to the first option.
   *
   * @function useEffect
   * @dependency options - Array of available payment method options.
   * @dependency paymentMethod - Currently selected payment method.
   */
  useEffect(() => {
    if (options.length > 0 && !paymentMethod) {
      setPaymentMethod(options[0]);
    }
  }, [options, paymentMethod]);

  /**
   * Effect that sets up a WebSocket connection to listen for updates to payment methods.
   *
   * - Establishes a WebSocket connection listens for the "paymentMethods" event.
   * - Calls `fetchPaymentMethods` to update the payment methods when the event is triggered.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");
    socket.on("paymentMethods", () => {
      fetchPaymentMethods();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Fetches and updates the payment methods.
   *
   * - Updates the `options` state with the fetched payment methods data.
   * - Handles errors by logging them and ensures the `options` state is set to an empty array in case of failure.
   *
   * @function fetchPaymentMethods
   */
  const fetchPaymentMethods = async () => {
    try {
      const paymentResponse = await axios.get(
        "http://localhost:9000/api/kape-link/get-payment-methods"
      );
      if (paymentResponse.headers["content-type"] !== "text/html") {
        setOptions(paymentResponse.data);
      } else {
        setOptions([]);
      }
    } catch (error) {
      console.error("Error fetching payment method data:", error);
    }
  };

  /**
   * Handles the payment method change event.
   *
   * - Clears the warning message upon change.
   * - If a valid payment method is selected, it updates the `paymentMethod` state with the selected option.
   * - If no payment method is selected, it resets the `paymentMethod` state to an empty object.
   *
   * @function handlePaymentMethodChange
   * @param {Object} event - The change event triggered by selecting a payment method.
   */
  const handlePaymentMethodChange = (event) => {
    setWarningMessage("");
    if (event.target.value != "") {
      const selectedOpid = Number(event.target.value);
      const selectedOption = options.find(
        (option) => option.opid === selectedOpid
      );
      setPaymentMethod(selectedOption);
    } else {
      setPaymentMethod({});
    }
  };

  const fileInputProof = useRef(null);

  /**
   * Handles the file change event for uploading a proof of payment image.
   *
   * - Verifies if the selected file is of an allowed type (PNG, JPEG, JPG).
   * - If valid, updates the `file` and `fileName` states, and clears any warning message.
   * - If the file type is not valid, resets the `file` and `fileName` states and sets a warning message.
   *
   * @function handleFileChange
   * @param {Object} event - The change event triggered when selecting a file.
   */
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg"];

    if (selectedFile) {
      if (allowedTypes.includes(selectedFile.type)) {
        setFile(selectedFile);
        setFileName(selectedFile.name);
        setWarningMessage("");
      } else {
        setFile(null);
        setFileName("");
        setWarningMessage("Please upload a valid image file (PNG, JPEG, JPG).");
      }
    }
  };

  /**
   * Handles the placement of an order by sending the finalized order data to the server.
   *
   * - Ensures that a payment method is selected and a valid image is attached if required.
   * - Prepares the order data and appends it to a `FormData` object, including the proof image if necessary.
   * - Sends the order details to the server via a POST request.
   * - Displays a success message or logs any errors if the request fails.
   *
   * @function handlePlaceOrder
   * @throws {Error} If there is an error during the order placement process.
   */
  const handlePlaceOrder = async () => {
    if (Object.keys(paymentMethod).length === 0) {
      setWarningMessage("Please select a payment method");
      return;
    }

    if (paymentMethod.img !== null && !file) {
      setWarningMessage("Please attach an image.");
      return;
    }

    const finalizedOrder = { ...orders };
    finalizedOrder.paymentMethodId = paymentMethod.opid;

    const formData = new FormData();

    for (const key in finalizedOrder) {
      if (
        typeof finalizedOrder[key] === "object" &&
        finalizedOrder[key] !== null
      ) {
        formData.append(key, JSON.stringify(finalizedOrder[key]));
      } else {
        formData.append(key, finalizedOrder[key]);
      }
    }

    if (paymentMethod.img !== null && file) {
      formData.append("proofImage", file);
    }

    formData.append("custName", user.firstName);

    setLoading(true);
    try {
      await axios.post(
        "http://localhost:9000/api/kape-link/create-order",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
      localStorage.removeItem("cartItems");
      setIsMessagePopupOpen(true);
    } catch (error) {
      console.error(
        "Error placing order:",
        error.response?.data || error.message
      );
      console.error("Error sending notification:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Closes both the PlaceOrderPopUp and the ReviewPayment popup.
   *
   * This function sets the state for closing both popups when called:
   * - Closes the PlaceOrderPopUp by setting `isMessagePopupOpen` to `false`.
   * - Closes the ReviewPayment popup by calling the `onClose` function passed as a prop.
   *
   * @function handleCloseBothPopups
   */
  const handleCloseBothPopups = () => {
    setIsMessagePopupOpen(false); // Close PlaceOrderPopUp
    onClose(); // Close ReviewPayment popup
  };

  if (!isOpen) return null;

  /**
   * Finds the selected payment method from the options.
   *
   * This code checks if a `paymentMethod` is selected (i.e., it has keys). If so,
   * it finds the corresponding option in the `options` array using the `opid` from
   * the `paymentMethod`. If no payment method is selected, it returns `null`.
   *
   * @constant selectedOption
   */
  const selectedOption =
    paymentMethod && Object.keys(paymentMethod).length > 0
      ? options.find((option) => option.opid === paymentMethod.opid)
      : null;

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50">
      <div
        className={
          "max-w-2xl bg-white rounded-lg shadow-lg p-8 w-11/12 sm:w-full h-4/6 overflow-y-auto"
        }
      >
        <h2 className="text-xl font-semibold text-center mb-4">
          Review Payment
        </h2>
        <hr className="mb-4" />
        <div className="mb-4">
          <h3 className="sm:text-lg font-medium sm:font-semibold mb-2">
            Choose Payment Method
          </h3>
          <div className="mb-2">
            <select
              className="w-full border p-1 sm:p-2 text-xs sm:text-base rounded"
              value={paymentMethod.opid}
              onChange={(e) => handlePaymentMethodChange(e)}
            >
              <option value="">Select a payment method</option>
              {(Array.isArray(options) ? options : []).map((option) => (
                <option key={option.opid} value={option.opid}>
                  {option.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {selectedOption && (
          <div className="mb-4">
            <h3 className="sm:text-lg font-semibold mb-2">
              {selectedOption.name} Payment
            </h3>
            <p className="text-sm text-justify sm:text-base mb-2">
              {selectedOption.payment_details}
            </p>
          </div>
        )}

        {paymentMethod.img !== null && selectedOption && (
          <>
            <div className="mb-4">
              <h3 className="sm:text-lg font-semibold mb-2">
                Upload Proof of Payment
              </h3>
              <p className="text-sm text-justify sm:text-base mb-2">
                This is required for the {selectedOption.name} payment method.
              </p>
              {/* <input type="file" onChange={handleFileChange} /> */}
            </div>
            <div className="flex justify-center mb-4">
              <img
                src={`http://localhost:9000/${paymentMethod.img}`}
                alt={`${selectedOption.name} QR Code`}
                className="w-80 h-90 max-w-full"
              />
            </div>
            <div className="flex justify-center items-center space-x-4 mb-6">
              <label className=" 2xl:mt-4">
                <input
                  type="file"
                  ref={fileInputProof}
                  onChange={handleFileChange}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputProof.current.click()}
                  className="px-8 py-1 bg-black hover:bg-gray-900 text-white duration-300 sm:py-2 rounded-lg text-sm shadow-md"
                >
                  Upload
                </button>
              </label>
              {/* Display the file name next to the button */}
              {fileName && (
                <span className="mt-4 text-sm text-gray-600 max-w-xs truncate">
                  {fileName}
                </span>
              )}
            </div>
          </>
        )}

        <div className="mb-4">
          <p className="font-semibold text-sm sm:text-base">Please Note:</p>
          <br />
          <ul className="text-sm text-justify sm:text-base list-disc pl-5">
            <li className="mb-2">
              For online payments, the manager will manually verify whether the
              payment has been completed, supported by proof. You will be
              notified again once the payment is verified and your order is
              preparing, or if further action is required.
            </li>
            <li className="mb-2">
              For CASH, once you click 'Proceed,' your order will be queued for
              preparation by our barista.
            </li>
            <li className="mb-2">
              For online payments PLEASE PAY THE EXACT TOTAL AMOUNT.
            </li>
            <li className="mb-2">
              After clicking proceed, you can track your order’s status via the
              ORDER HISTORY tab.
            </li>
          </ul>

          <div className="mt-4">
            <p className="text-xs sm:text-sm text-gray-600">
              By clicking “Place Order”, I agree to all terms & conditions
            </p>
            <div>
              {warningMessage && (
                <p className="text-center text-red-500 mt-2 mb-4 sm:text-base text-sm">
                  {warningMessage}
                </p>
              )}
            </div>
            <div className="flex justify-end mt-4">
              <button
                className="custom-button-color text-white text-sm sm:text-base font-medium sm:font-semibold py-2 px-4 rounded-full mr-2"
                onClick={handlePlaceOrder}
                disabled={loading}
              >
                {loading ? (
                  <Loader className="animate-spin" size={20} /> // Loader in the button
                ) : (
                  "Place Order"
                )}
              </button>
              <button
                onClick={onBack}
                className="custom-button-black text-white text-sm sm:text-base font-medium sm:font-semibold py-2 px-4 rounded-full"
              >
                Back
              </button>
            </div>
          </div>
        </div>
      </div>
      {isMessagePopupOpen && (
        <PlaceOrderPopUp setIsMessagePopupOpen={handleCloseBothPopups} />
      )}
    </div>
  );
};

export default ReviewPayment;
