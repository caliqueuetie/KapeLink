import React, { useState, useEffect } from "react";
import axios from "/axios.config"; // Import configured axios with credentials
import { io } from "socket.io-client";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/manualPlaceOrder.json";

/**
 * A component to display menu categories and handle category selection.
 *
 * This component renders a list of menu categories and allows users to select
 * a category to view products related to it. When a category is selected,
 * it triggers the `onCategoryChange` callback to notify the parent component.
 *
 * @param {function} onCategoryChange A callback function that is called when
 * a new category is selected. It receives the selected category as an argument.
 */

const MenuCategories = ({ onCategoryChange }) => {
  const [selectedCategory, setSelectedCategory] = useState();
  const [categoriesData, setCategoriesData] = useState({});
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  /**
   * Effect that fetches product data when the component mounts.
   *
   * - Calls `fetchProductData()` to initially fetch and set the product data when the component mounts.
   * - This effect has an empty dependency array, meaning it runs only once, right after the initial render.
   *
   * @function useEffect
   * @dependency [] - Empty dependency array, so this effect only runs once when the component mounts.
   */
  useEffect(() => {
    fetchProductData();
  }, []);

  /**
   * Effect that handles category change when the categories array is updated.
   *
   * - If `categories` array has items, it calls `handleCategoryChange` with the first category in the array.
   * - This effect runs whenever the `categories` array changes.
   *
   * @function useEffect
   * @dependency categories - The array of categories that triggers the effect when it is updated.
   */
  useEffect(() => {
    if (categories.length > 0) {
      handleCategoryChange(categories[0]);
    }
  }, [categories]);

  /**
   * Fetches product and category data from the server.
   *
   * - Makes a request to fetch product data and category data from the API.
   * - Extracts unique categories from the product data and updates the `categories` state.
   * - Updates the `categoriesData` state with the category data.
   * - Handles errors by logging them and resetting the state to default values.
   * - Sets the `loading` state to true while fetching data and false when done.
   *
   * @function fetchProductData
   */
  const fetchProductData = async () => {
    setLoading(true);
    try {
      const responseProd = await axios.get(
        "http://localhost:9000/api/kape-link/get-products"
      );
      const productData = responseProd.data;

      const responseCat = await axios.get(
        "http://localhost:9000/api/kape-link/get-categories"
      );
      const categoryData = responseCat.data;

      if (Array.isArray(productData)) {
        const uniqueCategories = [
          ...new Set(productData.map((item) => item.category)),
        ];
        setCategories(uniqueCategories);
      } else {
        setCategories([]);
      }

      if (Array.isArray(categoryData)) {
        setCategoriesData(categoryData);
      } else {
        setCategoriesData({});
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setCategories([]);
      setCategoriesData({});
    } finally {
      setLoading(false);
    }
  };

  /**
   * Effect that sets up a WebSocket connection to listen for product updates.
   *
   * - Establishes a connection to the WebSocket server at "http://localhost:9000".
   * - Listens for the "products" event and triggers `fetchProductData` when the event is received.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   * @dependency [] - This effect runs only once when the component mounts.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");
    socket.on("products", () => {
      fetchProductData();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Handles the category change and notifies the parent component.
   *
   * - Updates the selected category in the state using `setSelectedCategory`.
   * - Calls the `onCategoryChange` function passed from the parent to notify about the category change.
   *
   * @function handleCategoryChange
   * @param {string} category - The selected category to set.
   */
  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
    onCategoryChange(category); // Notify parent about the category change
  };

  /**
   * Retrieves the description of a selected category from the categories data.
   *
   * - Iterates through the values of `categoriesData` (which is expected to be an object).
   * - Searches for the category within each category group, and if found, returns the description of the category.
   * - Returns an empty string if the category is not found or the data is not in the expected format.
   *
   * @function getCategoryDescription
   * @param {string} selectedCategory - The name of the category for which the description is to be retrieved.
   * @returns {string} The description of the selected category, or an empty string if not found.
   */
  const getCategoryDescription = (selectedCategory) => {
    if (categoriesData && typeof categoriesData === "object") {
      for (const categoryGroup of Object.values(categoriesData)) {
        if (Array.isArray(categoryGroup)) {
          const category = categoryGroup.find(
            (item) => item.name === selectedCategory
          );
          if (category) {
            return category.description;
          }
        }
      }
    }
    return "";
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Player
          autoplay
          loop
          src={loader}
          style={{ height: "200px", width: "200px" }}
        />
      </div>
    );
  }

  return (
    <div>
      {/* Categories Navbar */}
      <div className="bg-white py-4 mx-2 sm:mx-0">
        <div className="container mx-auto flex sm:justify-center">
          <div className="flex items-center whitespace-nowrap">
            {categories.map((category) => (
              <CategoryItem
                key={category}
                category={category}
                isSelected={selectedCategory === category}
                onClick={() => handleCategoryChange(category)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Selected Category Header */}
      <div className="py-2 px-5 md:px-10 lg:px-20">
        <div className="container mx-auto">
          <h1 className="text-2xl sm:text-3xl font-semibold lg:w-1/2">
            {selectedCategory}
          </h1>
          <p className="text-gray-700 mt-2 lg:w-1/2 text-justify sm:text-start">
            {getCategoryDescription(selectedCategory)}
          </p>
        </div>
      </div>
    </div>
  );
};

// Category Item Component
const CategoryItem = ({ category, isSelected, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`cursor-pointer text-sm sm:text-base py-2 px-3 overflow-x-auto sm:px-4 duration-300 ${
        isSelected
          ? "text-[#A79277] font-semibold"
          : "text-gray-700 hover:text-[#A79277]"
      } font-semibold`}
    >
      {category}
    </div>
  );
};

export default MenuCategories;
