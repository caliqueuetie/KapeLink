import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import ReuploadSuccessPopup from "./ReuploadSuccessPopup";
import { io } from "socket.io-client";
import OfflinePage from "../../pages/OfflinePage";

/**
 * A component for handling the re-uploading of proof of payment images.
 *
 * This component allows the user to upload a new image for proof of payment
 * related to a specific order.
 *
 * @param {boolean} isOpen Determines whether the ReuploadProofImage modal is visible.
 * @param {function} onClose Function to handle closing the ReuploadProofImage modal.
 * @param {string} orderId The ID of the order for which the proof image is being re-uploaded.
 */

const ReuploadProofImage = ({ isOpen, onClose, orderId }) => {
  const [file, setFile] = useState(null);
  const [warningMessage, setWarningMessage] = useState("");
  const [showSuccessPopup, setShowSuccessPopup] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState({});
  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);
  const [fileName, setFileName] = useState("");
  const [isOffline, setIsOffline] = useState(false);

  /**
   * Effect that fetches the payment methods when the component mounts.
   *
   * - Calls `fetchPaymentMethods` to retrieve payment methods data from the server.
   *
   * @function useEffect
   * @dependency fetchPaymentMethods - Function to fetch payment methods from the server.
   */
  useEffect(() => {
    fetchPaymentMethods();
  }, []);

  /**
   * Effect that sets the default payment method if one is not already selected.
   *
   * - Checks if there are available options and no payment method is currently selected.
   * - If true, sets the first option as the default payment method.
   *
   * @function useEffect
   * @dependency options - Array of available payment method options.
   * @dependency paymentMethod - Currently selected payment method.
   */

  useEffect(() => {
    if (options.length > 0 && !paymentMethod) {
      setPaymentMethod(options[0]);
    }
  }, [options, paymentMethod]);

  /**
   * Effect that sets up a WebSocket connection to listen for payment method updates.
   *
   * - Establishes a WebSocket connection
   * - Listens for "paymentMethods" events on the WebSocket and calls fetchPaymentMethods() upon receiving the event.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   * @dependency fetchPaymentMethods - Function to fetch and update payment methods.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");
    socket.on("paymentMethods", () => {
      fetchPaymentMethods();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Function to fetch payment methods from the server.
   *
   * - Sends a GET request to "get-payment-methods".
   * - If the response's content type is "text/html", sets the offline status.
   * - Otherwise, updates the payment options state with the received data.
   * - Logs any errors encountered during the request.
   *
   * @async
   * @function fetchPaymentMethods
   */
  const fetchPaymentMethods = async () => {
    try {
      const paymentResponse = await axios.get(
        "http://localhost:9000/api/kape-link/get-payment-methods"
      );
      if (paymentResponse.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        setOptions(paymentResponse.data);
      }
    } catch (error) {
      console.error("Error fetching payment method data:", error);
    }
  };

  /**
   * Handles the change in the selected payment method.
   *
   * - Clears any existing warning messages.
   * - If a valid option is selected, finds and sets the selected payment method from the options.
   * - If no valid option is selected, resets the payment method and selected option.
   *
   * @function handlePaymentMethodChange
   * @param {Event} event - The event object triggered by the change in payment method selection.
   */
  const handlePaymentMethodChange = (event) => {
    setWarningMessage("");
    if (event.target.value != "") {
      const selectedOpid = Number(event.target.value);
      const selectedOption = options.find(
        (option) => option.opid === selectedOpid
      );
      setPaymentMethod(selectedOption);
      setSelectedOption(selectedOption);
    } else {
      setPaymentMethod({});
      setSelectedOption(null);
    }
  };

  const fileInputProof = useRef(null);

  /**
   * Handles the change in the file input.
   *
   * - Checks if a file is selected.
   * - Validates the file type against allowed image formats (PNG, JPEG, JPG).
   * - Sets the selected file and file name if valid, or shows a warning message if invalid.
   *
   * @function handleFileChange
   * @param {Event} event - The event object triggered by the file input change.
   */
  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    const allowedTypes = ["image/png", "image/jpeg", "image/jpg"];

    if (selectedFile) {
      if (allowedTypes.includes(selectedFile.type)) {
        setFile(selectedFile);
        setFileName(selectedFile.name);
        setWarningMessage("");
      } else {
        setFile(null);
        setFileName("");
        setWarningMessage("Please upload a valid image file (PNG, JPEG, JPG).");
      }
    }
  };

  /**
   * Handles the reupload of payment proof.
   *
   * - Validates if a payment method is selected and either an image is attached or the selected payment method has no image.
   * - Constructs a FormData object with the necessary fields: proofImage (if available), orderId, and paymentMethodId.
   * - Sends a PATCH request to reupload the payment proof.
   * - Displays a success popup on successful upload and clears the file input.
   * - Sets a warning message if no payment method is selected or no image is attached.
   *
   * @function handleReupload
   */
  const handleReupload = async () => {
    // Check if the selected payment method has a null img or if a file is uploaded
    if (Object.keys(paymentMethod).length === 0) {
      setWarningMessage("Please select a payment method");
      return;
    }

    if (paymentMethod.img === null || file) {
      const formData = new FormData();
      if (file) {
        formData.append("proofImage", file);
      }
      formData.append("orderId", orderId);
      formData.append("paymentMethodId", paymentMethod.opid); // Ensure paymentMethod.opid corresponds to the correct payment ID

      try {
        await axios.patch(
          `http://localhost:9000/api/kape-link/reupload-payment/${orderId}`,
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        setShowSuccessPopup(true);
        setFile(null); // Clear the file input
      } catch (error) {
        console.error(
          "Error reuploading proof image:",
          error.response?.data || error.message
        );
      }
    } else {
      setWarningMessage("Please attach an image.");
    }
  };

  /**
   * Closes the success popup and also closes the reupload modal.
   *
   * - Sets `showSuccessPopup` state to false.
   * - Calls the `onClose` function to close the reupload modal.
   *
   * @function handleSuccessPopupClose
   */
  const handleSuccessPopupClose = () => {
    setShowSuccessPopup(false);
    onClose(); // Close the reupload modal as well
  };

  if (!isOpen) return null;

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div>
      <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-2xl h-[80vh] overflow-y-auto">
          <h2 className="text-2xl font-bold text-center mb-4">
            Re-upload Proof of Payment
          </h2>
          <p className="text-red-600 mb-4">
            Your order has been rejected due to the attached image. Please
            submit a new image as proof of payment.
          </p>
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">
              Choose Payment Method
            </h3>
            <div className="mb-2">
              <select
                className="w-full border p-2 rounded"
                value={paymentMethod.opid}
                onChange={(e) => handlePaymentMethodChange(e)}
              >
                <option value="">Select a payment method</option>
                {options.map((option) => (
                  <option key={option.opid} value={option.opid}>
                    {option.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          {selectedOption && (
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">
                {selectedOption.name} Payment
              </h3>
              <p className="mb-2">{selectedOption.payment_details}</p>
            </div>
          )}
          {paymentMethod.img !== null && selectedOption && (
            <>
              <div className="mb-4">
                <h3 className="text-lg font-semibold mb-2">
                  Upload Proof of Payment
                </h3>
                <p className="mb-2">
                  This is required for the {selectedOption.name} payment method.
                </p>
                {/* <input type="file" onChange={handleFileChange} /> */}
              </div>
              <div className="flex justify-center mb-4">
                <img
                  src={`http://localhost:9000/${paymentMethod.img}`}
                  alt={`${selectedOption.name} QR Code`}
                  className="w-80 h-90 max-w-full"
                />
              </div>
              <div className="flex justify-center items-center space-x-4 mb-6">
                <label className=" 2xl:mt-4">
                  <input
                    type="file"
                    ref={fileInputProof}
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputProof.current.click()}
                    className="border px-8 py-1 hover:bg-gray-100 duration-300 sm:py-2 rounded-lg text-sm shadow-md"
                  >
                    Upload
                  </button>
                </label>
                {/* Display the file name next to the button */}
                {fileName && (
                  <span className="mt-4 text-sm text-gray-600 max-w-xs truncate">
                    {fileName}
                  </span>
                )}
              </div>
            </>
          )}
          <div>
            {warningMessage && (
              <p className="text-center text-red-500 mt-2  mb-4">
                {warningMessage}
              </p>
            )}
          </div>
          <div className="flex justify-end">
            <button
              className="bg-[#A79277] hover:bg-[#8d6f5e] text-white font-bold py-2 px-4 rounded-full mr-2"
              onClick={handleReupload}
            >
              Re-upload
            </button>
            <button
              className="bg-[#29262C] hover:bg-[#484547] text-white font-bold py-2 px-4 rounded-full"
              onClick={onClose}
            >
              Cancel
            </button>
          </div>
        </div>
      </div>

      {showSuccessPopup && (
        <ReuploadSuccessPopup onClose={handleSuccessPopupClose} />
      )}
    </div>
  );
};

export default ReuploadProofImage;
