import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/manualPlaceOrder.json";

/**
 * A component for handling the Place Order popup.
 *
 * This popup is shown when the user has successfully placed an order.
 *
 * @param {function} setIsMessagePopupOpen Function to control the visibility of the
 *        success message popup after placing an order.
 */
const PlaceOrderPopUp = ({ setIsMessagePopupOpen }) => {
  /**
   * Handles the closure of the message popup.
   *
   * - Calls the `setIsMessagePopupOpen` function to close the popup.
   *
   * @function handleMessageClosePopup
   * @dependency setIsMessagePopupOpen - Function that controls the state of the message popup visibility.
   */
  const handleMessageClosePopup = () => {
    setIsMessagePopupOpen(); // Call the function to close both popups
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="w-80 sm:w-4/12 bg-white p-14 rounded-lg shadow-lg relative max-[640px]:p-9">
        <div className="text-center">
          <div className="mb-4">
            <Player autoplay loop src={loader} className="w-40" />
          </div>

          <h2 className="font-medium text-lg sm:text-xl mb-1">
            Your order has been placed!
          </h2>
          <span className="text-xs sm:text-sm text-gray-500">
            Please keep an eye on your notifications to stay informed for the
            updates of the status of your order.
          </span>
        </div>
        <div className="flex justify-center mt-5">
          <button
            className="custom-button-color text-white font-semibold py-2 px-10 rounded-full"
            onClick={handleMessageClosePopup}
          >
            Okay
          </button>
        </div>
      </div>
    </div>
  );
};

export default PlaceOrderPopUp;
