import { React, useEffect, useState } from "react";
import NotificationCard from "./NotificationCard";
import axios from "axios";
import exitIcon from "../../images/ExitIcon.png";
import OfflinePage from "../../pages/OfflinePage";
import { Check } from "lucide-react";

/**
 * A component that displays a list of notifications for a specific user.
 *
 * This component fetches notifications based on the user's ID and shows them in a list format.
 * It also allows the user to close the notifications panel and mark notifications as read or unread.
 *
 * @param {boolean} isOpen A flag to determine if the notifications panel is open.
 * @param {Function} onClose Function to close the notifications panel.
 * @param {string} userId The ID of the user whose notifications are being fetched.
 */
const Notifications = ({ isOpen, onClose, userId }) => {
  const [fetchedNotifications, setFetchedNotifications] = useState([]);
  const [filter, setFilter] = useState("all");
  const [unreadCount, setUnreadCount] = useState(0);
  const [error, setError] = useState(null);
  const [isOffline, setIsOffline] = useState(false);

  /**
   * Fetches notifications for the specified user from the server and updates the state accordingly.
   *
   * - Sends a `GET` request to retrieve notifications for the user identified by `userId`.
   * - Checks the response content type to determine if the server is offline.
   * - Parses and sorts the notifications by `notificationId` in descending order.
   * - Updates the state with fetched notifications and the count of unread notifications.
   * - Logs any errors encountered during the request and updates the error state.
   *
   * @function fetchNotifications
   */
  const fetchNotifications = () => {
    axios
      .get(
        `http://localhost:9000/api/kape-link/get-notifications-by-customerid/${userId}`,
        { withCredentials: true }
      )
      .then((response) => {
        if (response.headers["content-type"] === "text/html") {
          setIsOffline(true);
        } else {
          let notifications = response.data;

          if (!Array.isArray(notifications)) {
            notifications = [];
          }

          if (notifications.length) {
            notifications = notifications.sort(
              (a, b) => b.notificationId - a.notificationId
            );
          }

          setFetchedNotifications(notifications);

          const unreadNotifications = notifications.filter(
            (notification) => !notification.read
          );
          setUnreadCount(unreadNotifications.length);
        }
      })
      .catch((error) => {
        console.error("Error fetching notifications:", error);
        setError(error.message);
      });
  };

  /**
   * Effect that periodically fetches notifications for the specified user.
   *
   * - Triggers the `fetchNotifications` function when the component mounts if `isOpen` or `userId` is true.
   * - Sets up an interval to repeatedly call `fetchNotifications` every second if `isOpen` or `userId` is true.
   * - Clears the interval when the component unmounts or when dependencies change.
   *
   * @function useEffect
   * @dependency [isOpen, userId] - Runs whenever `isOpen` or `userId` changes.
   */
  useEffect(() => {
    if (isOpen || userId) {
      fetchNotifications();
    }

    const intervalId = setInterval(() => {
      if (isOpen || userId) {
        fetchNotifications();
      }
    }, 1000);

    return () => clearInterval(intervalId);
  }, [isOpen, userId]);

  /**
   * Toggles the read status of a notification.
   *
   * - Sends a PUT request to update the read status of the notification with the given `notificationId`.
   * - Updates the `fetchedNotifications` state with the updated notification data.
   * - Adjusts the `unreadCount` based on the new read status of the notification.
   *
   * @async
   * @function toggleNotificationRead
   * @param {string} notificationId - The ID of the notification to toggle.
   * @returns {Promise<void>}
   */
  const toggleNotificationRead = async (notificationId) => {
    try {
      const response = await axios.put(
        `http://localhost:9000/api/kape-link/toggle-notification-read/${notificationId}`
      );
      const updatedNotification = response.data;

      setFetchedNotifications((prev) =>
        prev.map((notification) =>
          notification._id === updatedNotification._id
            ? updatedNotification
            : notification
        )
      );

      if (!updatedNotification.read) {
        setUnreadCount((prev) => prev + 1);
      } else {
        setUnreadCount((prev) => prev - 1);
      }
    } catch (error) {
      console.error("Error toggling notification read status:", error);
    }
  };

  /**
   * Marks all unread notifications as read by calling `toggleNotificationRead` for each unread notification.
   *
   * - Iterates over all fetched notifications.
   * - Calls `toggleNotificationRead` for each notification that is not already read.
   *
   * @function markAllAsRead
   */
  const markAllAsRead = () => {
    fetchedNotifications.forEach((notification) => {
      if (!notification.read) {
        toggleNotificationRead(notification._id);
      }
    });
  };

  /**
   * Filters notifications based on the specified filter criterion ("read", "unread", or no filter).
   *
   * - Filters notifications by their `read` status based on the provided `filter` value.
   * - Returns all notifications if no filter is specified.
   *
   * @function filteredNotifications
   * @param {string} filter - The filter criteria ("read", "unread", or other values to return all).
   * @returns {Array} - A filtered array of notifications based on the filter.
   */
  const filteredNotifications = fetchedNotifications.filter((notification) => {
    if (filter === "read") return notification.read === true;
    if (filter === "unread") return notification.read === false;
    return true;
  });

  if (!isOpen) return null;

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50 z-50">
      <div className="bg-white rounded-lg shadow-lg p-8 sm:w-full max-w-2xl w-11/12 h-3/4 overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-semibold">Notifications</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <img src={exitIcon} alt="Close" className="h-auto w-4 sm:w-5" />
          </button>
        </div>

        <div className="flex justify-start sm:mb-4 text-sm sm:text-base space-x-3 sm:space-x-6 sm:font-semibold">
          <button
            onClick={() => setFilter("all")}
            className={`py-2 ${
              filter === "all"
                ? "border-b-2 border-[#A79277] text-[#A79277] "
                : "text-gray-500"
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter("read")}
            className={`py-2 ${
              filter === "read"
                ? "border-b-2 border-[#A79277] text-[#A79277] "
                : "text-gray-500"
            }`}
          >
            Read
          </button>
          <button
            onClick={() => setFilter("unread")}
            className={`py-2 ${
              filter === "unread"
                ? "border-b-2 border-[#A79277] text-[#A79277] "
                : "text-gray-500"
            }`}
          >
            Unread
          </button>

          <div className="flex-grow justify-end hidden sm:flex">
            <button
              onClick={markAllAsRead}
              className="custom-button-color text-white px-4 py-2 rounded-lg max-[640px]:text-xs"
            >
              Mark All as Read
            </button>
          </div>
          <div className="flex flex-grow justify-end sm:hidden mb-2">
            <button
              onClick={markAllAsRead}
              className="flex items-center justify-center custom-button-color text-white px-3  rounded-lg max-[640px]:text-xs"
            >
              <Check className="h-auto w-4 mr-2" />
              All
            </button>
          </div>
        </div>

        <hr className="mb-4" />

        {error ? (
          <p className="text-red-500">{error}</p>
        ) : filteredNotifications.length === 0 ? (
          <p>No notifications available.</p>
        ) : (
          <div className="flex flex-col space-y-2 sm:space-y-4">
            {filteredNotifications.map((notification) => (
              <NotificationCard
                key={notification._id}
                notification={notification}
                toggleNotificationRead={toggleNotificationRead}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
