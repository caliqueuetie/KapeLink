import React, { useState, useEffect } from "react";
import Notifications from "./Notifications";
import { NavLink } from "react-router-dom";
import Logo from "../../images/KapeLinkNameLogo.png";
import { LogOut } from "lucide-react";
import axios from "/axios.config"; // Import your configured axios
import LogoutPopup from "../Global/LogoutPopup"; // Import LogoutPopup component
import { io } from "socket.io-client";
import { Bell, Settings, Menu } from "lucide-react";
import kapeLinkLogo from "../../images/KapeLinkLogo.png";
import OfflinePage from "../../pages/OfflinePage";

/**
 * A header component that displays user information and navigational elements.
 *
 * This component renders a header section that typically includes the
 * user's name and navigation options. It helps to provide
 * a consistent interface for navigation and user management throughout the app.
 *
 * @param {Object} user The user object containing user data
 */
const Header = ({ user }) => {
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isLogoutPopupOpen, setIsLogoutPopupOpen] = useState(false); // Track logout popup state
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isOffline, setIsOffline] = useState(false);

  /**
   * Fetches the notifications for the current user from the server and updates the unread notifications count.
   *
   * This `useEffect` hook is triggered when the `user.userId` changes. It sends an HTTP GET request to the
   * server to retrieve the notifications associated with the user. If the response indicates the user is offline,
   * the state is updated accordingly. The unread notifications count is calculated based on the response data.
   *
   * @function
   * @async
   * @returns {void}
   * @throws {Error} Throws an error if there is an issue with fetching notifications.
   */
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-notifications-by-customerid/${user.userId}`,
          { withCredentials: true }
        );

        if (response.headers["content-type"] === "text/html") {
          setIsOffline(true);
        } else {
          const notifications = response.data;

          // Count unread notifications
          const unreadNotifications = notifications.filter(
            (notification) => !notification.read
          );
          setUnreadCount(unreadNotifications.length);
        }
      } catch (error) {
        console.error("Error fetching notifications:", error);
      }
    };

    fetchNotifications();
  }, [user.userId]);

  /**
   * Establishes a socket connection to listen for real-time notifications.
   *
   * This `useEffect` hook sets up socket event listeners to handle incoming notifications:
   * - "newNotification": Increments the unread notifications count when a new notification is received.
   * - "readNotification": Decrements the unread notifications count when a notification is marked as read.
   *
   * The socket connection is cleaned up when the component is unmounted by calling `socket.disconnect()`.
   *
   * @function
   * @returns {void}
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    // Listen for new notifications
    socket.on("newNotification", (newNotification) => {
      setUnreadCount((prevCount) => prevCount + 1);
    });

    // Listen for notification read updates
    socket.on("readNotification", () => {
      setUnreadCount((prevCount) => Math.max(0, prevCount - 1));
    });

    // Cleanup socket connection when component unmounts
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Opens the notifications panel by setting `isNotificationsOpen` to `true`.
   *
   * This function is used to trigger the UI state change when the user opens the notifications section.
   *
   * @function
   * @returns {void}
   */
  const handleNotificationsOpen = () => {
    setIsNotificationsOpen(true);
  };

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <header className="shadow-md bg-white py-4">
      <div className="container mx-auto flex items-center">
        <div className="flex items-center space-x-12 max-[768px]:space-x-6">
          <div className="flex md:hidden items-center">
            <img
              src={kapeLinkLogo}
              className="w-fit py-2 px-3"
              alt="KapeLink Logo"
            />
            <h1 className="font-bold">KAPE LINK</h1>
          </div>

          <div className="hidden md:block">
            <img
              src={Logo}
              alt="Logo"
              className="w-16 my-2 h-auto max-[768px]:w-10 max-[768px]:ml-5"
            />
          </div>

          <nav className="hidden md:flex">
            <NavLink
              to="/menu"
              className={({ isActive }) =>
                isActive
                  ? "text-[#A79277] px-4 py-2 text-sm sm:text-base font-medium "
                  : "text-gray-700 text-sm sm:text-base font-medium px-4 py-2 hover:text-[#A79277] duration-300"
              }
            >
              Menu
            </NavLink>
            <NavLink
              to="/order-history"
              className={({ isActive }) =>
                isActive
                  ? "text-[#A79277] px-4 py-2 text-sm sm:text-base font-medium whitespace-nowrap"
                  : "text-gray-700 font-medium text-sm sm:text-base px-4 py-2 hover:text-[#A79277] duration-300 whitespace-nowrap"
              }
            >
              Order History
            </NavLink>
          </nav>
        </div>

        <div className="hidden md:flex items-center space-x-8 ml-auto">
          <button
            onClick={handleNotificationsOpen}
            title="Notifications"
            className="relative text-gray-700 hover:text-[#A79277] transition duration-200 ease-in-out"
          >
            <Bell size={20} />
            {unreadCount > 0 && (
              <span className="absolute top-[2px] right-1 transform translate-x-1/2 -translate-y-1/2 h-2 w-2 bg-red-500 rounded-full"></span>
            )}
          </button>

          <p className="text-gray-700">Hello, {user.firstName}!</p>

          <NavLink
            to="/profile-settings"
            className={({ isActive }) =>
              isActive
                ? "text-[#A79277] transition duration-200 ease-in-out"
                : "text-gray-700 transition duration-200 ease-in-out hover:text-[#A79277]"
            }
            title="Settings"
          >
            <Settings className="h-5 w-5" />
          </NavLink>

          <button
            onClick={() => setIsLogoutPopupOpen(true)}
            title="Log Out"
            className="flex text-gray-700 hover:text-[#A79277] transition duration-200 ease-in-out"
          >
            <LogOut size={20} className="cursor-pointer" />
          </button>
        </div>

        {/* Hamburger Menu Icon for Mobile */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="relative md:hidden text-gray-700 ml-auto mr-4"
        >
          <Menu className="h-6 w-6" />
          {unreadCount > 0 && (
            <span className="absolute top-1 left-3 transform translate-x-1/2 -translate-y-1/2 h-2 w-2 bg-red-500 rounded-full"></span>
          )}
        </button>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="absolute top-20 right-0 bg-white border rounded shadow-lg z-50 w-56 transform transition-transform duration-300 ease-in-out">
            <div className="flex justify-between px-4"></div>
            <ul className="list-none p-3 text-right">
              <li className="hover:bg-gray-200">
                <NavLink
                  to="/menu"
                  exact="true"
                  className={({ isActive }) =>
                    isActive
                      ? "text-[#A79277] bg-gray-200 block px-4 py-2 rounded-md transition duration-200 ease-in-out"
                      : "text-gray-700 block px-4 py-2 transition duration-200 ease-in-out hover:bg-gray-200 rounded-md"
                  }
                >
                  Menu
                </NavLink>
              </li>
              <li className="hover:bg-gray-200">
                <NavLink
                  to="/order-history"
                  exact="true"
                  className={({ isActive }) =>
                    isActive
                      ? "text-[#A79277] bg-gray-200 block px-4 py-2 rounded-md transition duration-200 ease-in-out"
                      : "text-gray-700 block px-4 py-2 transition duration-200 ease-in-out hover:bg-gray-200 rounded-md"
                  }
                >
                  Order History
                </NavLink>
              </li>
              <li className="hover:bg-gray-200 relative">
                <button
                  onClick={() => setIsNotificationsOpen(true)}
                  className="block px-4 py-2 text-right w-full"
                >
                  Notifications
                </button>
                {unreadCount > 0 && (
                  <span className="absolute top-4 left-2 h-2 w-2 bg-red-500 rounded-full"></span>
                )}
              </li>
              <li className="hover:bg-gray-200">
                <NavLink
                  to="/profile-settings"
                  exact="true"
                  className={({ isActive }) =>
                    isActive
                      ? "text-[#A79277] bg-gray-100 block px-4 py-2 rounded-md transition duration-200 ease-in-out"
                      : "text-gray-700 block px-4 py-2 transition duration-200 ease-in-out hover:bg-gray-200 rounded-md"
                  }
                >
                  Profile Settings
                </NavLink>
              </li>
            </ul>
            <hr className="border-t-1 border-gray-300"></hr>
            <div className="leading-4 px-7 pb-4 mt-4">
              <div className="flex justify-between items-center">
                <LogOut
                  className="cursor-pointer"
                  onClick={() => setIsLogoutPopupOpen(true)}
                />
                <div className="ml-5">
                  <h4 className="font-semibold">{user.firstName}</h4>
                  <span className="text-xs text-gray-600">{user.role}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <Notifications
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          reciever={user.userId}
        />
      </div>

      {isLogoutPopupOpen && (
        <LogoutPopup
          setLogoutPopupOpen={setIsLogoutPopupOpen}
          user={user.contactNumber}
        />
      )}
    </header>
  );
};

export default Header;
