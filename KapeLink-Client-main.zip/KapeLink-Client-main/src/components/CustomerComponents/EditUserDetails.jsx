import React, { useEffect, useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import axios from "/axios.config";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";
import OfflinePage from "../../pages/OfflinePage";
import { CircleUser, ShieldCheck, UserRoundPen } from "lucide-react";

/**
 * A page component for editing user profile information.
 *
 * This component allows the user to update their profile details. It provides input fields for the user to modify
 * their personal information, and a button to submit the updated profile data.
 *
 * @param {Object} user The user object containing current profile data to pre-fill the form.
 * @param {Function} onUpdateProfile The callback function that will be called when the user submits
 * the updated profile data.
 */
const EditProfilePage = ({ user, onUpdateProfile }) => {
  const [userProfile, setUserProfile] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    contactNumber: user.contactNumber.replace("+639", ""),
  });

  const [originalProfile, setOriginalProfile] = useState({ ...userProfile });
  const [showOldPassword, setShowOldPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showRetypePassword, setShowRetypePassword] = useState(false);
  const [updateProfileData, setUpdateProfileData] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [changePassword, setChangePassword] = useState(false);
  const [message, setMessage] = useState("");
  const [showNotification, setShowNotification] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [passwordDetails, setPasswordDetails] = useState({
    oldPassword: "",
    newPassword: "",
    retypeNewPassword: "",
  });

  /**
   * Handles input changes for the user profile form.
   *
   * - Updates the `userProfile` state with the new value from the input field.
   * - If the input field is "contactNumber", it validates the value to ensure it contains only digits and is at most 10 characters long.
   * - For all other input fields, the value is directly updated in the state.
   *
   * @function handleInputChange
   * @param {Object} event - The event object triggered by the input change.
   * @param {string} event.target.name - The name of the input field that triggered the change.
   * @param {string} event.target.value - The new value of the input field.
   */
  const handleInputChange = (event) => {
    const { name, value } = event.target;

    if (name === "contactNumber") {
      if (/^\d{0,10}$/.test(value)) {
        setUserProfile({
          ...userProfile,
          [name]: value,
        });
      }
    } else {
      setUserProfile({
        ...userProfile,
        [name]: value,
      });
    }
  };

  /**
   * Handles the change in password fields for the password change form.
   *
   * - Updates the `passwordDetails` state with the new value for the password field.
   *
   * @function handlePasswordChange
   * @param {Object} event - The event triggered by an input change.
   * @param {string} event.target.name - The name of the input field (e.g., "password", "confirmPassword").
   * @param {string} event.target.value - The new value of the input field.
   */
  const handlePasswordChange = (event) => {
    const { name, value } = event.target;
    setPasswordDetails({
      ...passwordDetails,
      [name]: value,
    });
  };

  /**
   * Effect that handles hiding the notification after a specified time and updating the profile data.
   *
   * - If `showNotification` is true, it sets a timer to hide the notification after 2550ms.
   * - Once the notification is hidden, it checks if `updateProfileData` exists. If so, it calls `onUpdateProfile` with the update data and resets `updateProfileData` to null.
   * - Cleans up the timer when the component unmounts or when `showNotification`, `updateProfileData`, or `onUpdateProfile` changes.
   *
   * @function useEffect
   * @dependency showNotification - Controls whether the notification should be shown.
   * @dependency updateProfileData - Contains the profile update data to be passed to `onUpdateProfile`.
   * @dependency onUpdateProfile - The function to call for updating the profile with the new data.
   */
  useEffect(() => {
    if (showNotification) {
      const timer = setTimeout(() => {
        setShowNotification(false);
        if (updateProfileData) {
          onUpdateProfile(updateProfileData);
          setUpdateProfileData(null);
        }
      }, 2550);
      return () => clearTimeout(timer);
    }
  }, [showNotification, updateProfileData, onUpdateProfile]);

  /**
   * Sets the `isEditing` state to `true`, indicating that the user is in the process of editing their profile.
   *
   * - This function is typically triggered when the user clicks an "Edit" button to enable editing mode.
   *
   * @function handleEditProfile
   */
  const handleEditProfile = () => {
    setIsEditing(true);
  };

  /**
   * Sets the `changePassword` state to `true` and `isEditing` state to `false`.
   * This function is typically triggered when the user decides to change their password.
   *
   * - It enables the password change mode by setting `changePassword` to `true`.
   * - It disables the profile edit mode by setting `isEditing` to `false`.
   *
   * @function handleChangePassword
   */
  const handleChangePassword = () => {
    setChangePassword(true);
    setIsEditing(false);
  };

  /**
   * Handles the cancellation of either the password change or profile edit process.
   *
   * - If the user is changing their password (`changePassword` is `true`), it resets the password details to empty strings and sets `changePassword` to `false`.
   * - If the user is editing their profile (`changePassword` is `false`), it restores the profile to its original state and sets `isEditing` to `false`.
   *
   * @function handleCancel
   */
  const handleCancel = () => {
    if (changePassword) {
      setPasswordDetails({
        oldPassword: "",
        newPassword: "",
        retypeNewPassword: "",
      });
      setChangePassword(false);
    } else {
      setUserProfile({ ...originalProfile });
      setIsEditing(false);
    }
  };

  /**
   * Checks if the given name contains invalid characters or extra spaces.
   *
   * - Invalid characters are any characters that are not alphabetic (a-z, A-Z) or spaces.
   * - Extra spaces refer to more than one consecutive space between words.
   *
   * @function containsInvalidCharsOrSpaces
   * @param {string} name - The name to be checked for invalid characters or extra spaces.
   * @returns {boolean} `true` if the name contains invalid characters or extra spaces, `false` otherwise.
   */
  const containsInvalidCharsOrSpaces = (name) => {
    const hasSymbols = /[^a-zA-Z ]/.test(name);
    const hasExtraSpaces = /\s{2,}/.test(name);
    return hasSymbols || hasExtraSpaces;
  };

  /**
   * Handles saving changes to the user profile.
   *
   * This function performs the following tasks:
   * - Verifies if the updated profile data has changed. If not, it exits early.
   * - Validates the contact number to ensure it is 9 digits long and prepends the country code (+639).
   * - Ensures that the first name, last name, and contact number are not empty and do not contain invalid characters or extra spaces.
   * - Sends an API request to update the user profile data.
   * - Handles errors, including checking if the contact number is already in use.
   * - Displays success or error messages as notifications.
   *
   * @async
   * @function handleSaveChanges
   * @returns {Promise<void>} No return value.
   */
  const handleSaveChanges = async () => {
    const { firstName, lastName, contactNumber } = userProfile;

    const updatedData = {
      firstName,
      lastName,
      contactNumber: `+639${contactNumber}`,
    };

    if (
      firstName === user.firstName &&
      lastName === user.lastName &&
      (contactNumber === user.contactNumber.replace("+639", "") ||
        contactNumber === "")
    ) {
      setIsEditing(false);
      return;
    }

    if (contactNumber.length !== 9) {
      setMessage("Invalid Contact Number.");
      setShowNotification(true);
      return;
    }

    if (firstName === "" || lastName === "" || contactNumber === "") {
      setMessage("Please ensure all input fields are completed");
      setShowNotification(true);
      return;
    }

    if (
      containsInvalidCharsOrSpaces(firstName) ||
      containsInvalidCharsOrSpaces(lastName)
    ) {
      setMessage(
        "Please remove any special characters or extra spaces in the first and last names"
      );
      setShowNotification(true);
      return;
    }

    try {
      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-user/${user.userId}`,
        updatedData
      );

      if (response.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        setMessage("User profile updated successfully!");
        setShowNotification(true);
        setUpdateProfileData(response.data);
        setOriginalProfile({ ...userProfile });
        setIsEditing(false);
      }
    } catch (error) {
      let errorMessage = "An unexpected error occurred.";
      if (error.response?.data?.error?.includes("E11000")) {
        errorMessage =
          "This contact number is already in use. Please use a different one.";
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      }
      setMessage(errorMessage);
      setShowNotification(true);
    }
  };

  /**
   * Handles saving the password change.
   *
   * This function performs the following tasks:
   * - Validates that all required fields (old password, new password, retype new password) are filled in.
   * - Ensures that the new password is at least 8 characters long.
   * - Verifies that the new password and the retyped password match.
   * - Sends an API request to update the user's password.
   * - Handles errors, including displaying messages for any validation or server-side errors.
   * - Resets the password form and closes the password change process on success.
   *
   * @async
   * @function handleSavePasswordChange
   * @returns {Promise<void>} No return value.
   */
  const handleSavePasswordChange = async () => {
    const { oldPassword, newPassword, retypeNewPassword } = passwordDetails;

    if (!oldPassword || !newPassword || !retypeNewPassword) {
      setMessage("All fields are required.");
      setShowNotification(true);
      return;
    }

    if (newPassword.length < 8) {
      setMessage("New password must be at least 8 characters long.");
      setShowNotification(true);
      return;
    }

    if (newPassword !== retypeNewPassword) {
      setMessage("Password do not match.");
      setShowNotification(true);
      return;
    }

    try {
      const response = await axios.patch(
        `http://localhost:9000/api/kape-link/update-customer-password/${user.userId}`,
        passwordDetails
      );

      if (response.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        setMessage(response.data.message);
        setShowNotification(true);
        setIsEditing(false);
        setChangePassword(false);
        setPasswordDetails({
          oldPassword: "",
          newPassword: "",
          retypeNewPassword: "",
        });
      }
    } catch (error) {
      const errorMessage =
        error.response?.data?.error || "An unexpected error occurred.";
      setMessage(errorMessage);
      setShowNotification(true);
    }
  };

  /**
   * Checks if the user profile has been modified compared to the original profile.
   *
   * This constant performs a comparison between the current `userProfile` and the `originalProfile`
   * to determine if any of the following fields have changed:
   * - First name
   * - Last name
   * - Contact number (excluding the country code prefix "+639")
   *
   * @constant
   * @type {boolean}
   * @default
   * @returns {boolean} Returns `true` if any of the profile fields are changed, otherwise `false`.
   */
  const isUserProfileChanged =
    userProfile.firstName !== originalProfile.firstName ||
    userProfile.lastName !== originalProfile.lastName ||
    userProfile.contactNumber !==
      originalProfile.contactNumber.replace("+639", "");

  /**
   * Checks if all the required password fields have been filled.
   *
   * This constant checks if the following fields in the `passwordDetails` object are populated:
   * - Old password
   * - New password
   * - Retyped new password
   *
   * @constant
   * @type {boolean}
   * @default
   * @returns {boolean} Returns `true` if all password fields are filled, otherwise `false`.
   */
  const isPasswordFieldsComplete =
    passwordDetails.oldPassword &&
    passwordDetails.newPassword &&
    passwordDetails.retypeNewPassword;

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div>
      <Header user={user} />

      <FloatingSuccessfulNotification
        showNotification={showNotification}
        notificationMessage={message}
      />

      <div className="max-w-4xl mx-auto px-8 pt-5 sm:pt-20 pb-1 sm:mt-10 mt-5 max-[640px]:px-5 md:px-14">
        <h1 className="text-xl sm:font-semibold font-medium mb-10 sm:mb-0">
          {isEditing ? (
            <div className="flex flex-col items-center mb-2 sm:mb-4 justify-center sm:justify-normal sm:flex-row">
              <UserRoundPen className="h-auto w-14 sm:w-6 sm:mr-4 mb-2 sm:mb-0" />
              <span>Edit Your Details</span>
            </div>
          ) : changePassword ? (
            <div className="flex flex-col items-center mb-2 sm:mb-4 justify-center sm:justify-normal sm:flex-row">
              <ShieldCheck className="h-auto w-14 sm:w-6 sm:mr-4 mb-2 sm:mb-0" />
              <span>Change Your Password</span>
            </div>
          ) : (
            <div className="flex flex-col items-center mb-2 sm:mb-4 justify-center sm:justify-normal sm:flex-row">
              <CircleUser className="h-auto w-14 sm:w-6 sm:mr-4 mb-2 sm:mb-0" />
              <span>Your details</span>
            </div>
          )}
        </h1>

        <hr className="mb-6 hidden sm:block" />

        <div className="my-20 mt-8">
          {changePassword ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="col-start-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  Old Password
                </label>
                <div className="relative">
                  <input
                    type={showOldPassword ? "text" : "password"}
                    name="oldPassword"
                    className="w-full p-2 border rounded text-sm sm:text-base"
                    value={passwordDetails.oldPassword}
                    onChange={handlePasswordChange}
                  />
                  <FontAwesomeIcon
                    icon={showOldPassword ? faEye : faEyeSlash}
                    onClick={() => setShowOldPassword(!showOldPassword)}
                    className="absolute top-1/2 right-3 transform -translate-y-1/2 cursor-pointer w-4 sm:w-5"
                  />
                </div>
              </div>
              <div className="col-start-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  New Password
                </label>
                <div className="relative">
                  <input
                    type={showNewPassword ? "text" : "password"}
                    name="newPassword"
                    className="w-full p-2 border rounded text-sm sm:text-base"
                    value={passwordDetails.newPassword}
                    onChange={handlePasswordChange}
                  />
                  <FontAwesomeIcon
                    icon={showNewPassword ? faEye : faEyeSlash}
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute top-1/2 right-3 transform -translate-y-1/2 cursor-pointer w-4 sm:w-5"
                  />
                </div>
              </div>
              <div className="col-start-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  Confirm New Password
                </label>
                <div className="relative">
                  <input
                    type={showRetypePassword ? "text" : "password"}
                    name="retypeNewPassword"
                    className="w-full p-2 border rounded text-sm sm:text-base"
                    value={passwordDetails.retypeNewPassword}
                    onChange={handlePasswordChange}
                  />
                  <FontAwesomeIcon
                    icon={showRetypePassword ? faEye : faEyeSlash}
                    onClick={() => setShowRetypePassword(!showRetypePassword)}
                    className="absolute top-1/2 right-3 transform -translate-y-1/2 cursor-pointer h-auto w-4 sm:w-5"
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="col-span-2 md:col-span-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  First Name
                </label>
                <input
                  type="text"
                  name="firstName"
                  className="w-full p-2 border rounded text-sm sm:text-base"
                  value={userProfile.firstName}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="col-span-2 md:col-span-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  Last Name
                </label>
                <input
                  type="text"
                  name="lastName"
                  className="w-full p-2 border rounded text-sm sm:text-base"
                  value={userProfile.lastName}
                  onChange={handleInputChange}
                  disabled={!isEditing}
                />
              </div>
              <div className="col-span-2 md:col-span-1">
                <label className="block mb-2 text-sm sm:text-base font-medium sm:font-semibold">
                  Contact Number
                </label>
                <div className="flex items-center">
                  <span className="mr-2">+639</span>
                  <input
                    type="text"
                    name="contactNumber"
                    className="w-full p-2 border rounded text-sm sm:text-base"
                    value={userProfile.contactNumber}
                    onChange={handleInputChange}
                    maxLength={9}
                    disabled={!isEditing}
                  />
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-2 sm:space-x-4 mt-7">
            {isEditing || changePassword ? (
              <>
                <button
                  onClick={
                    changePassword
                      ? handleSavePasswordChange
                      : handleSaveChanges
                  }
                  className={`px-6 py-2 ${
                    isUserProfileChanged ||
                    (changePassword && isPasswordFieldsComplete)
                      ? "custom-button-color"
                      : "bg-gray-400"
                  } text-sm sm:text-base text-white font-medium sm:font-semibold rounded-full`}
                  disabled={
                    !(
                      isUserProfileChanged ||
                      (changePassword && isPasswordFieldsComplete)
                    )
                  }
                >
                  Save Changes
                </button>
                <button
                  onClick={handleCancel}
                  className="px-6 py-2 bg-gray-900 hover:bg-gray-700 duration-300 text-sm sm:text-base text-white font-medium sm:font-semibold rounded-full whitespace-nowrap"
                >
                  Cancel
                </button>
              </>
            ) : (
              <div className="flex justify-end space-x-2 sm:space-x-4 mt-4">
                <button
                  onClick={handleEditProfile}
                  className="px-6 py-2 custom-button-color text-sm sm:text-base text-white font-medium sm:font-semibold rounded-full whitespace-nowrap"
                >
                  Edit Profile
                </button>
                <button
                  onClick={handleChangePassword}
                  className="px-6 py-2 bg-gray-900 hover:bg-gray-700 duration-300 text-sm sm:text-base text-white font-medium sm:font-semibold rounded-full whitespace-nowrap"
                >
                  Change Password
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default EditProfilePage;
