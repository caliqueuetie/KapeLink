import React from "react";
import aboutUs from "../../images/HomepageAboutUs.png";

/**
 * AboutUs component that displays information about the organization
 * along with an image and text content.
 *
 * @component
 */
const AboutUs = () => {
  return (
    <section className="pb-16 sm:px-4 px-10">
      {" "}
      {/* Background color for the section */}
      <div className="sm:w-[71%] mx-auto">
        {" "}
        {/* Increased max-width for the card */}
        <div className="flex flex-col lg:flex-row bg-[#efe6dc] shadow-lg overflow-hidden">
          {/* Image on the left */}
          <div className="flex-shrink-0 lg:w-1/2 relative">
            <img
              src={aboutUs} // Updated image path
              alt="About Us"
              className="object-cover w-full h-full" // Ensure image covers its container
            />
          </div>

          {/* Text on the right */}
          <div className="lg:w-1/2 flex flex-col justify-center sm:p-20 p-10">
            <h2 className="text-4xl font-bold mb-4">Get to Know Us Better</h2>
            <p className="text-sm mb-4">
              Discover more about us and our products/services through our
              informative chat-bot.
            </p>
            <p className="text-sm">
              Click on the icon in the lower right corner to start exploring.
              Our chat-bot is here to provide you with helpful information and
              answers to your questions. Let's get started!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
