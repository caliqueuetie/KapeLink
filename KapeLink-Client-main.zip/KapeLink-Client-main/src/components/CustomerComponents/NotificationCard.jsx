import React from "react";

/**
 * A component that displays a notification card with its details.
 *
 * This component shows the notification's content and allows the user to mark the notification as read
 * or unread. Additionally, the user can mark all notifications as read using the provided function.
 *
 * @param {Object} notification The notification object containing details like message, date, and read status.
 * @param {Function} toggleNotificationRead Function to toggle the read status of the notification.
 * @param {Function} markAllAsRead Function to mark all notifications as read.
 */
const NotificationCard = ({
  notification,
  toggleNotificationRead,
  markAllAsRead,
}) => {
  const cardClassName = notification.read
    ? "border-b rounded-lg sm:p-4 p-4 bg-white"
    : "border-b rounded-lg sm:p-4 p-4 bg-gray-100 my-4 ";

  return (
    <div className={cardClassName}>
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm sm:text-lg sm:font-semibold">
          {notification.date}
        </h3>
        <p className="text-sm sm:text-base text-gray-500">
          {notification.time}
        </p>
      </div>
      <p className="text-gray-700 mb-2 text-xs sm:text-base">
        {notification.message}
      </p>
      <div className="flex justify-end sm:mt-2 mt-4">
        <button
          className="custom-button-black text-white py-1 sm:py-2 px-4 sm:px-7 rounded-full text-xs sm:text-base"
          onClick={() => toggleNotificationRead(notification._id)}
        >
          {notification.read ? "Unread" : "Read"}
        </button>
      </div>
    </div>
  );
};

export default NotificationCard;
