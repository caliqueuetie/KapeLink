import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import Header from "./Header";
import Footer from "./Footer";
import { ArrowLeft } from "lucide-react";
import ReuploadProofImage from "./ReuploadProofImage";
import { io } from "socket.io-client";
import OfflinePage from "../../pages/OfflinePage";

/**
 * A component to display the detailed information of a user's order.
 *
 * This component fetches and displays the full details of a user's order,
 * such as the items, payment method, and order status. It shows a loading
 * indicator while fetching the data and provides an error message if the
 * order details cannot be retrieved.
 *
 * @param {object} user Contains user details such as name and ID. This is
 * used to fetch the order details associated with the user.
 */
const OrderDetails = ({ user }) => {
  const [order, setOrder] = useState(null);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showProof, setShowProof] = useState(false);
  const [isReturned, setIsReturned] = useState(false);
  const { orderId } = useParams();
  const [isOffline, setIsOffline] = useState(false);

  /**
   * Fetches order details from the server based on the provided `orderId`.
   *
   * - Sends a GET request to fetch the order details using the `orderId`.
   * - If the response's content type is "text/html", it sets the `isOffline` state to true.
   * - Otherwise, it sets the order details and changes the loading state to false.
   * - In case of an error, it sets an error message and stops the loading state.
   *
   * @function fetchOrderDetails
   * @returns {void}
   */
  const fetchOrderDetails = async () => {
    try {
      const orderResponse = await axios.get(
        `http://localhost:9000/api/kape-link/get-order/${orderId}`
      );

      if (orderResponse.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        setOrder(orderResponse.data);
        setLoading(false);
      }
    } catch (err) {
      setError("Failed to fetch order details.");
      setLoading(false);
    }
  };

  /**
   * Effect that fetches order details and listens for updates via WebSocket.
   *
   * - Initially calls `fetchOrderDetails()` to fetch the order details.
   * - Sets up a WebSocket connection to listen for "orderDetails" events, triggering a re-fetch of the order details when an event is received.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    fetchOrderDetails();
    const socket = io("http://localhost:9000");
    socket.on("orderDetails", () => {
      fetchOrderDetails();
    });
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Effect that fetches payment methods when the component is mounted.
   *
   * - Calls `fetchPaymentMethods()` to fetch payment methods from the server.
   * - Sets the retrieved payment methods in the state.
   * - Catches and logs any errors if the request fails.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    const fetchPaymentMethods = async () => {
      try {
        const paymentResponse = await axios.get(
          "http://localhost:9000/api/kape-link/get-payment-methods"
        );
        setPaymentMethods(paymentResponse.data);
      } catch (error) {
        console.error("Failed to fetch data from the server:", error);
      }
    };

    fetchPaymentMethods();
  }, []);

  /**
   * Retrieves the name of a payment method based on the provided `opid`.
   *
   * - Searches through the `paymentMethods` array to find the payment method with the matching `opid`.
   * - Returns the name of the payment method if found, otherwise returns "Not available".
   *
   * @function getPaymentMethodName
   * @param {string} opid - The `opid` of the payment method to search for.
   * @returns {string} The name of the payment method or "Not available" if not found.
   */
  const getPaymentMethodName = (opid) => {
    const paymentMethod = paymentMethods.find((method) => method.opid === opid);
    return paymentMethod ? paymentMethod.name : "Not available";
  };

  if (loading) return <p>Loading order details...</p>;
  if (error) return <p>{error}</p>;

  if (!order || !order.items) return <p>No order details found.</p>;

  /**
   * Calculates the total quantity of items in an order.
   *
   * - Uses the `reduce` method to sum the `quantity` of each item in the `order.items` array.
   * - Starts with an initial value of `0` and adds each item's quantity to the sum.
   *
   * @function totalQuantity
   * @returns {number} The total quantity of items in the order.
   */
  const totalQuantity = order.items.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  /**
   * Calculates the total price of items in an order.
   *
   * - Uses the `reduce` method to sum the product of each item's `quantity` and `pricePerItem` in the `order.items` array.
   * - Starts with an initial value of `0` and adds the total price of each item to the sum.
   *
   * @function totalPrice
   * @returns {number} The total price of items in the order.
   */
  const totalPrice = order.items.reduce(
    (sum, item) => sum + item.quantity * item.pricePerItem,
    0
  );

  const handleProofClick = () => {
    setShowProof(true);
  };

  const handleReUploadClick = () => {
    setIsReturned(true);
  };

  const handleCloseReuploadModal = () => {
    setIsReturned(false);
  };

  let orderDetails;
  if (order.deliveryDetails?.deliveryTime) {
    orderDetails = (
      <>
        <div>
          <span>Order Option:</span> {order.orderOption}
        </div>
        <div className="sm:mt-2">
          <span>Delivery Location:</span> {order.deliveryDetails?.building} -{" "}
          {order.deliveryDetails?.description}
        </div>
        <div className="sm:mt-2">
          <span>Delivery Time:</span> {order.deliveryDetails?.deliveryTime}
        </div>
        <div className="sm:mt-2">
          <span>Payment Method:</span>{" "}
          {getPaymentMethodName(order.paymentMethodId)}
        </div>
      </>
    );
  } else {
    orderDetails = (
      <>
        <div>
          <span>Order Option:</span> {order.orderOption}
        </div>
        <div className="sm:mt-2">
          <span>Pick Up Time:</span> {order.pickUpTime || "Not available"}
        </div>
        <div className="sm:mt-2">
          <span>Payment Method:</span>{" "}
          {getPaymentMethodName(order.paymentMethodId)}
        </div>
      </>
    );
  }

  const latestTrackingStatus =
    order.tracking?.length > 0
      ? order.tracking[order.tracking.length - 1].orderStatus
      : order.verificationStatus;

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div>
      <Header user={user} />
      <div className="container mx-auto py-5 sm:px-20 px-8">
        <Link
          to="/order-history"
          className="hover:text-[#A79277] px-4 py-2 text-black font-semibold rounded-full"
        >
          <ArrowLeft className="mr-2" />
        </Link>
        <h1 className="text-2xl text-center font-semibold mb-4">
          Order Details
        </h1>

        <div className="sm:mb-8 mb-6">
          <div className="sm:flex justify-between">
            <div>
              <h2 className="text-xl">
                <span className="font-semibold">Order ID:</span> {order.orderId}
              </h2>
            </div>
            <div>
              <span className="font-semibold">Order Date:</span>{" "}
              {order.orderDate}
            </div>
          </div>
          <div className="sm:mt-2">
            <span className="font-semibold">Status:</span>{" "}
            {latestTrackingStatus}
          </div>
          {(latestTrackingStatus === "Returned" ||
            latestTrackingStatus === "Rejected") && (
            <div className="sm:mt-2">
              <span className="font-semibold">Reason:</span> {order.reason}
            </div>
          )}
        </div>

        <div className="sm:mb-8 mb-6">
          <h2 className="text-xl font-semibold mb-2">Recipient</h2>
          <hr className="border-t-4 border-[#A79277] w-16 mb-4" />
          <div className="ml-4">
            <div>
              <span className="font-semibold">Name:</span> {user.firstName}{" "}
              {user.lastName}
            </div>
            <div className="sm:mt-2">
              <span className="font-semibold">Contact Number:</span>{" "}
              {user.contactNumber}
            </div>
          </div>
        </div>

        <div className="sm:mb-8 mb-6">
          <h2 className="text-xl font-semibold mb-2">Other Details</h2>
          <hr className="border-t-4 border-[#A79277] w-16 mb-4" />
          <div className="ml-4">{orderDetails}</div>
        </div>

        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-2">Purchase Breakdown</h2>
          <hr className="border-t-4 border-[#A79277] w-16 mb-4" />

          <table className="w-full mb-4">
            <thead>
              <tr className="bg-gray-200">
                <th className="px-4 py-2">Items</th>
                <th className="px-4 py-2">Qty</th>
                <th className="px-4 py-2">Price</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((item, index) => (
                <tr key={index} className="border-b">
                  <td className="px-4 py-2">{item.name}</td>
                  <td className="px-4 py-2 text-center">{item.quantity}</td>
                  <td className="px-4 py-2 text-right">
                    P{item.pricePerItem.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Total Table */}
          <table className="w-full mb-8">
            <tbody className="border-t">
              <tr>
                <td className="px-4 py-2">
                  <span className="font-semibold">Total Item(s)</span>
                </td>
                <td className="px-4 py-2 text-right">{totalQuantity}</td>
              </tr>
              <tr className="border-b border-t">
                <td className="px-4 py-2">
                  <span className="font-semibold">Total</span>
                </td>
                <td className="px-4 py-2 text-right">
                  P{totalPrice.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>

          {order?.proofOfPayment && (
            <div className="flex justify-end space-x-2 mt-4">
              <button
                className="px-5 py-2 custom-button-color text-white font-semibold rounded-full shadow-md transition-transform transform"
                onClick={handleProofClick}
              >
                View Proof of Payment
              </button>
              {latestTrackingStatus === "Returned" && (
                <button
                  className="px-4 py-2 bg-black hover:bg-black text-white font-semibold rounded-full"
                  onClick={handleReUploadClick}
                >
                  Re-upload Proof of Payment
                </button>
              )}
            </div>
          )}

          {/* Modal to show proof of payment */}
          {showProof && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
              <div className="bg-white p-4 rounded-md shadow-lg max-w-lg w-full">
                <h2 className="text-lg font-semibold mb-4">Proof of Payment</h2>
                <img
                  src={`http://localhost:9000/${order.proofOfPayment}`}
                  alt="Proof of Payment"
                  className="w-11/12 max-h-80 object-contain mx-auto"
                />
                <div className="flex justify-end mt-4">
                  <button
                    className="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-md"
                    onClick={() => setShowProof(false)}
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Re-upload proof of payment modal */}
          <ReuploadProofImage
            isOpen={isReturned}
            onClose={handleCloseReuploadModal}
            orderId={orderId}
          />
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default OrderDetails;
