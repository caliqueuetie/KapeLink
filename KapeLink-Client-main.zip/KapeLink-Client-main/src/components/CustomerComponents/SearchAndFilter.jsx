import React from "react";

/**
 * A component for a search input with customizable placeholder text.
 *
 * This component allows the user to input a search query and filters based on the
 * provided `searchQuery`. It also accepts a custom `placeholderText` to display
 * within the input field, and updates the search query whenever the user types.
 *
 * @param {string} searchQuery The current search query.
 * @param {function} setSearchQuery Function to update the search query state.
 * @param {string} placeholderText Custom placeholder text for the input field.
 */
const SearchAndFilter = ({
  searchQuery,
  setSearchQuery,
  placeholderText, // New prop for placeholder
}) => {
  return (
    <div className="flex items-center w-full max-w-lg border border-gray-400 rounded-full px-4 py-2 bg-white shadow-sm">
      <input
        type="text"
        placeholder={placeholderText}
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="w-full outline-none text-gray-700"
      />
    </div>
  );
};

export default SearchAndFilter;
