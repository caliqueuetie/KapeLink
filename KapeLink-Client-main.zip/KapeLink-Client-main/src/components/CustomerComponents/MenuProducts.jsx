import React, { useState } from "react";
import { Plus, Minus, ShoppingBag } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * A component to display products in a specific menu category.
 *
 * This component takes a list of products and renders them under a specified
 * menu category. Each product is displayed with an option to add it to the cart.
 * It allows users to view and select products based on the menu category they are
 * browsing.
 *
 * @param {Array} items The list of products to display, each item containing
 * product details such as name, price, and description.
 * @param {string} menucategory The category name that the products belong to.
 * @param {function} onAddToCart A function to handle adding a product to the cart.
 */

const MenuProducts = ({ items, menucategory, onAddToCart }) => {
  const [expandedIndex, setExpandedIndex] = useState(null);
  const [selectedRow, setSelectedRow] = useState(null);
  const [quantities, setQuantities] = useState({});
  const [selectedTemperature, setSelectedTemperature] = useState({});

  /**
   * Toggles the expansion of an item based on its index.
   *
   * - If the clicked index matches the current `expandedIndex`, it collapses the item by setting `expandedIndex` to `null`.
   * - If the clicked index does not match the current `expandedIndex`, it expands the item by setting `expandedIndex` to the clicked index.
   *
   * @function handleExpandToggle
   * @param {number} index - The index of the item to be toggled for expansion or collapse.
   */
  const handleExpandToggle = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  /**
   * Selects a row based on the provided index.
   *
   * - Sets the `selectedRow` state to the clicked row's index, marking it as the selected row.
   *
   * @function handleRowSelect
   * @param {number} index - The index of the row to be selected.
   */
  const handleRowSelect = (index) => {
    setSelectedRow(index);
  };

  /**
   * Updates the quantity for the item at the given index by the specified delta.
   *
   * - Increments or decrements the quantity of the item at the specified index.
   * - Ensures that the quantity doesn't go below 0.
   *
   * @function handleQuantityChange
   * @param {number} index - The index of the item whose quantity is being changed.
   * @param {number} delta - The change in quantity (positive or negative).
   */
  const handleQuantityChange = (index, delta) => {
    setQuantities((prev) => {
      const newQty = (prev[index] || 0) + delta;
      return { ...prev, [index]: Math.max(newQty, 0) };
    });
  };

  /**
   * Updates the temperature for the item at the given index.
   *
   * - Sets the temperature for the item at the specified index.
   * - Updates the `selectedTemperature` state with the new temperature value.
   *
   * @function handleTemperatureChange
   * @param {number} index - The index of the item whose temperature is being updated.
   * @param {number} temperature - The new temperature value to be set for the item.
   */
  const handleTemperatureChange = (index, temperature) => {
    setSelectedTemperature((prev) => ({ ...prev, [index]: temperature }));
  };

  /**
   * Groups items by their name and returns the grouped product items.
   *
   * - Iterates over the `items` array and groups them based on the `name` property.
   * - Returns an array of grouped items where each group contains items with the same name.
   *
   * @function getProductGroups
   * @returns {Array} An array of grouped product items, where each group is an array of items with the same name.
   */
  const getProductGroups = () => {
    const groupedItems = items.reduce((acc, item) => {
      if (!acc[item.name]) {
        acc[item.name] = [];
      }
      acc[item.name].push(item);
      return acc;
    }, {});

    return Object.values(groupedItems);
  };

  /**
   * Calculates the price of a product based on the selected type and its markup rate.
   *
   * - Searches for the item within the `productGroup` that matches the `selectedType`.
   * - Calculates the price by adding the `basePrice` and the markup rate to it.
   * - Returns the calculated price rounded to two decimal places.
   *
   * @function getProductPrice
   * @param {Array} productGroup - The group of products to search within.
   * @param {string} selectedType - The type of product to find within the group.
   * @returns {number} The calculated price of the selected product type.
   */
  const getProductPrice = (productGroup, selectedType) => {
    const selectedItem = productGroup.find(
      (item) => item.type === selectedType
    );

    const price = selectedItem
      ? selectedItem.basePrice +
        selectedItem.basePrice * selectedItem.markupRate
      : 0;

    // Return the price formatted to 2 decimal places
    return parseFloat(price.toFixed(2));
  };

  const productGroups = getProductGroups();
  const hasTypeColumn = items.some((item) => item.type);

  return (
    <div className="container mx-auto my-8 ">
      <hr className="border-t-4 border-[#A79277] w-16 mb-4" />
      <h2 className="text-xl sm:text-2xl font-semibold mb-4">{menucategory}</h2>

      {/* Desktop View */}
      <div className="hidden sm:block">
        <div className="overflow-x-auto ">
          <table
            className="min-w-full bg-white mb-4"
            style={{ tableLayout: "fixed" }}
          >
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="py-2 px-4 w-1/3">Item</th>
                {hasTypeColumn && <th className="py-2 px-4 w-1/6">Type</th>}
                <th className="py-2 px-4 w-1/6">Price</th>
                <th className="py-2 px-4 w-1/6">Qty</th>
                <th className="py-2 px-4 w-1/6"></th>
              </tr>
            </thead>
            <tbody>
              {productGroups.map((productGroup, index) => {
                const firstProduct = productGroup[0];
                return (
                  <tr
                    key={index}
                    className="bg-white"
                    onClick={() => handleRowSelect(index)}
                  >
                    <td className="py-2 px-4 capitalize">
                      {firstProduct.name}
                    </td>
                    {hasTypeColumn && (
                      <td className="py-2 px-4 text-center">
                        {productGroup.length > 1 ? (
                          <select
                            value={
                              selectedTemperature[index] || firstProduct.type
                            }
                            onChange={(e) =>
                              handleTemperatureChange(index, e.target.value)
                            }
                          >
                            {productGroup.map((opt) => (
                              <option key={opt.type} value={opt.type}>
                                {opt.type.charAt(0).toUpperCase() +
                                  opt.type.slice(1)}
                              </option>
                            ))}
                          </select>
                        ) : (
                          firstProduct.type.charAt(0).toUpperCase() +
                          firstProduct.type.slice(1)
                        )}
                      </td>
                    )}
                    <td className="py-2 px-4 text-center">
                      P
                      {getProductPrice(
                        productGroup,
                        selectedTemperature[index] || firstProduct.type
                      ).toFixed(2)}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {selectedRow === index && (
                        <div className="flex items-center justify-center">
                          <button
                            className="px-1 py-1 text-white custom-button-color rounded"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleQuantityChange(index, -1);
                            }}
                          >
                            <Minus size={18} />
                          </button>
                          <input
                            type="text"
                            value={quantities[index] || 0}
                            onChange={(e) => {
                              const newQuantity = parseInt(e.target.value, 10);
                              if (!isNaN(newQuantity) && newQuantity > 0) {
                                handleQuantityChange(
                                  index,
                                  newQuantity - (quantities[index] || 0)
                                );
                              } else if (newQuantity <= 0) {
                                setQuantities((prev) => ({
                                  ...prev,
                                  [index]: 0,
                                }));
                              }
                            }}
                            className="mx-1 text-center border border-gray-300 rounded w-10"
                          />
                          <button
                            className="px-1 py-1 text-white custom-button-color rounded"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleQuantityChange(index, 1);
                            }}
                          >
                            <Plus size={18} />
                          </button>
                        </div>
                      )}
                    </td>
                    <td className="py-2 px-4 text-center">
                      {selectedRow === index && (
                        <button
                          className="px-10 py-1 text-white custom-button-color rounded-3xl font-semibold"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (quantities[index]) {
                              const selectedItem = {
                                prodId: firstProduct.prodId,
                                category: firstProduct.category,
                                menuCategory: firstProduct.menuCategory,
                                salesReport: firstProduct.salesReport,
                                type:
                                  selectedTemperature[index] ||
                                  firstProduct.type,
                                name: firstProduct.name,
                                price: getProductPrice(
                                  productGroup,
                                  selectedTemperature[index] ||
                                    firstProduct.type
                                ),
                                quantity: quantities[index],
                              };
                              onAddToCart(selectedItem);
                              setQuantities(0);
                            }
                          }}
                        >
                          <ShoppingBag size={22} className="text-white" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile View */}
      <div className="block sm:hidden">
        {productGroups.map((productGroup, index) => {
          const firstProduct = productGroup[0];
          return (
            <div key={index} className="mb-4">
              <div
                className="bg-white shadow-md rounded-lg overflow-hidden cursor-pointer"
                onClick={() => handleExpandToggle(index)}
              >
                <div className="p-4 flex justify-between">
                  <h3 className="sm:text-lg capitalize">{firstProduct.name}</h3>
                  <p className="sm:text-lg">
                    P
                    {getProductPrice(
                      productGroup,
                      selectedTemperature[index] || firstProduct.type
                    ).toFixed(2)}
                  </p>
                </div>

                <AnimatePresence>
                  {expandedIndex === index && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.4, ease: "easeInOut" }}
                    >
                      <div className="p-4 border-t border-gray-200">
                        <div className="flex justify-between">
                          {productGroup.length > 1 && (
                            <select
                              value={
                                selectedTemperature[index] || firstProduct.type
                              }
                              onChange={(e) =>
                                handleTemperatureChange(index, e.target.value)
                              }
                              onClick={(e) => e.stopPropagation()} // Prevent the card from closing
                              className="mb-4"
                            >
                              {productGroup.map((opt) => (
                                <option key={opt.type} value={opt.type}>
                                  {opt.type.charAt(0).toUpperCase() +
                                    opt.type.slice(1)}
                                </option>
                              ))}
                            </select>
                          )}

                          <div className="flex items-center mb-4 ml-auto">
                            <button
                              className="px-1 py-1 text-white bg-[#A79277] rounded"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleQuantityChange(index, -1);
                              }}
                            >
                              <Minus size={18} />
                            </button>
                            <span className="px-4">
                              {quantities[index] || 0}
                            </span>
                            <button
                              className="px-1 py-1 text-white bg-[#A79277] rounded"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleQuantityChange(index, 1);
                              }}
                            >
                              <Plus size={18} />
                            </button>
                          </div>
                        </div>
                        <div className="flex w-full">
                          <button
                            className="ml-auto py-2 px-5 mt-4 text-white rounded-full custom-button-color"
                            onClick={() => {
                              if (quantities[index]) {
                                const selectedItem = {
                                  prodId: firstProduct.prodId,
                                  category: firstProduct.category,
                                  menuCategory: firstProduct.menuCategory,
                                  salesReport: firstProduct.salesReport,
                                  type:
                                    selectedTemperature[index] ||
                                    firstProduct.type,
                                  name: firstProduct.name,
                                  price: getProductPrice(
                                    productGroup,
                                    selectedTemperature[index] ||
                                      firstProduct.type
                                  ),
                                  quantity: quantities[index],
                                };
                                onAddToCart(selectedItem);
                                setQuantities(0);
                              }
                            }}
                          >
                            Add to Bag
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MenuProducts;
