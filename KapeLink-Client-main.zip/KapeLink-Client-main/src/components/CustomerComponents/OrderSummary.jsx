import React, { useState, useEffect } from "react";
import axios from "/axios.config";

const cellFormat =
  "border-b border-gray-400 p-2 2xl:p-4 text-center sm:text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4";
const headerFormat =
  "w-screen p-3 font-medium whitespace-nowrap sm:text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";

/**
 * A component for displaying the order summary.
 *
 * This component shows the details of the user's order, including the items
 * in the cart, the total price, and quantities. It allows the user to review
 * their selected items before proceeding to checkout. It also provides options
 * to navigate back or proceed with the checkout process.
 *
 * @param {boolean} isOpen Flag to control the visibility of the order summary.
 * @param {function} onClose Function to close the order summary.
 * @param {object} orders Contains the details of the items in the user's order.
 * @param {function} onCheckOut Function to handle the checkout process.
 * @param {object} user Contains user details such as name and ID.
 */

const OrderSummary = ({ isOpen, onClose, orders, onCheckOut, user }) => {
  const [recentOrders, setRecentOrders] = useState([]);
  const [matchedItems, setMatchedItems] = useState([]);
  const [loading, setLoading] = useState(true);

  if (!isOpen) return null;

  /**
   * Effect that fetches recent orders when the component mounts.
   *
   * - Calls `fetchRecentOrders()` to retrieve and display recent orders when the component is first rendered.
   * - The effect runs only once when the component mounts, due to the empty dependency array `[]`.
   *
   * @function useEffect
   * @dependency None - This effect runs once when the component mounts.
   */
  useEffect(() => {
    fetchRecentOrders();
  }, []);

  /**
   * Fetches recent orders from the server and updates the `recentOrders` state.
   *
   * - Sets loading state to true before making the API request.
   * - Sends a GET request to retrieve recent orders for the user from the server.
   * - If the response is not in HTML format, updates the `recentOrders` state with the fetched data.
   * - If an error occurs, logs it to the console.
   * - Sets the loading state to false after the request is completed.
   *
   * @function fetchRecentOrders
   * @async
   * @returns {Promise<void>} - Fetches recent orders and updates the state.
   */
  const fetchRecentOrders = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-recent-orders/${user.userId}`
      );

      if (response.headers["content-type"] !== "text/html") {
        setRecentOrders(response.data);
      } else {
        setRecentOrders([]);
      }
    } catch (error) {
      console.error("Error fetching product data:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Effect that checks for matching recent orders and updates the `matchedItems` state.
   *
   * - Iterates over the `recentOrders` array and compares each order's items with the current `orders.items`.
   * - For each item in a recent order, checks if it matches the productId, type, and quantity with the corresponding item in `orders.items`.
   * - If all items of a recent order match, the order is added to the `matchedItems` array.
   * - Updates the `matchedItems` state with the matching orders.
   *
   * @function useEffect
   * @dependency recentOrders - Contains the list of recent orders to compare with the current order.
   * @dependency orders - Contains the current order data.
   */
  useEffect(() => {
    const orderItems = orders.items || [];
    const matchedItems = [];

    if (Array.isArray(recentOrders)) {
      recentOrders.forEach((recentOrder) => {
        const recentItems = recentOrder.items || [];

        const isMatchingOrder =
          Array.isArray(recentItems) &&
          recentItems.every((recentItem) => {
            const matchingOrderItem = orderItems.find((orderItem) => {
              const isMatchingProductId =
                parseInt(orderItem.productId) === recentItem.productId;
              const isMatchingType = orderItem.type === recentItem.type;
              const isMatchingQuantity =
                orderItem.quantity === recentItem.quantity;
              return (
                isMatchingProductId && isMatchingType && isMatchingQuantity
              );
            });

            return !!matchingOrderItem;
          });

        if (isMatchingOrder) {
          matchedItems.push(recentOrder);
        }
      });
    }

    setMatchedItems(matchedItems);
  }, [recentOrders, orders]);

  /**
   * Calculates the total quantity of items in the current order.
   *
   * - Iterates over the `orders.items` array and sums up the `quantity` field of each item.
   * - Returns the total quantity as a number.
   *
   * @function totalQuantity
   * @dependency orders.items - The list of items in the current order, each with a `quantity` field.
   */
  const totalQuantity = orders.items.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  /**
   * Calculates the total price of items in the current order.
   *
   * - Iterates over the `orders.items` array and sums up the `totalPrice` field of each item.
   * - Returns the total price as a number.
   *
   * @function totalPrice
   * @dependency orders.items - The list of items in the current order, each with a `totalPrice` field.
   */
  const totalPrice = orders.items.reduce(
    (sum, item) => sum + item.totalPrice,
    0
  );

  return (
    !loading &&
    isOpen && (
      <div className="fixed top-0 left-0 w-full h-full flex justify-center items-center bg-black bg-opacity-50">
        <div className="bg-white rounded-lg shadow-lg p-8 h-4/6 w-11/12 sm:w-full max-w-2xl overflow-y-auto">
          <h2 className="text-2xl font-semibold text-center mb-4">
            Order Summary
          </h2>
          <hr className="mb-4" />
          <p className="mb-4">
            {" "}
            <span className="font-medium">Order Date: </span> {orders.orderDate}
          </p>
          <div className="mb-4">
            <p>
              <span className="font-medium">Name:</span> {user.firstName}{" "}
              {user.lastName}
            </p>
            <p>
              <span className="font-medium">Contact #:</span>{" "}
              {user.contactNumber}
            </p>
            {orders.orderOption === "Delivery" ? (
              <>
                <p>
                  <span className="font-medium">Delivery Location:</span>{" "}
                  {orders.deliveryDetails.building} -{" "}
                  {orders.deliveryDetails.description}
                </p>
                <p>
                  <span className="font-medium">Preferred Delivery Time:</span>{" "}
                  {orders.deliveryDetails.deliveryTime}
                </p>
              </>
            ) : (
              <p>
                <span className="font-medium">Preferred Pick Up Time</span>{" "}
                {orders.pickUpTime}
              </p>
            )}
          </div>
          <div className="w-full border-collapse border border-gray-400 overflow-y-auto h-auto max-[640px]:max-w-80">
            <table>
              <thead>
                <tr className="border-b border-gray-400">
                  <th className={headerFormat}>Items</th>
                  <th className={headerFormat}>Qty</th>
                  <th className={headerFormat}>Unit Cost</th>
                  <th className={headerFormat}>Cost</th>
                </tr>
              </thead>
              <tbody>
                {orders.items.map((order, index) => (
                  <tr key={index} className="border-b">
                    <td className={cellFormat}>
                      {order.name + (order.type ? ` (${order.type})` : "")}
                    </td>
                    <td className={cellFormat}>{order.quantity}</td>

                    {/* Conditionally render "P" only in the first row */}
                    <td className={cellFormat}>
                      {index === 0
                        ? `P${order.pricePerItem.toFixed(2)}`
                        : order.pricePerItem.toFixed(2)}
                    </td>

                    <td className={`${cellFormat}`}>
                      {index === 0
                        ? `P${(order.pricePerItem * order.quantity).toFixed(2)}`
                        : (order.pricePerItem * order.quantity).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="w-full border-collapse border border-gray-400 overflow-y-auto h-auto max-[640px]:max-w-80 mt-2">
            <table className="w-full">
              <tbody className="border-t">
                <tr className="border-b border-gray-400">
                  <td className="px-4 py-3">
                    <span className="text-sm sm:text-base sm:font-semibold">
                      Total Item(s)
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right text-sm sm:text-base">
                    {totalQuantity}
                  </td>
                </tr>
                <tr>
                  <td className="px-4 py-3">
                    <span className="text-sm sm:text-base sm:font-semibold">
                      Total
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right text-sm sm:text-base">
                    P{totalPrice.toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <div>
            {matchedItems.length > 0 && (
              <div className="p-3 rounded-md mb-4">
                <p className="text-sm text-justify">
                  <span className="font-semibold">Note:</span> You have ordered
                  this product/s before at{" "}
                  {matchedItems[matchedItems.length - 1].timeOrdered}. Would you
                  like to proceed with your order?
                </p>
              </div>
            )}
          </div>
          <div className="flex justify-end mt-4">
            <button
              onClick={onCheckOut}
              className="custom-button-color text-white font-medium sm:font-semibold text-sm sm:text-base py-2 px-4 rounded-full mr-2"
            >
              Check Out
            </button>
            <button
              onClick={onClose}
              className="bg-gray-900 hover:bg-gray-700 duration-300 text-white font-medium sm:font-semibold text-sm sm:text-base py-2 px-4 rounded-full"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    )
  );
};

export default OrderSummary;
