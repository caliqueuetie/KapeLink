import React from "react";
import Logo from "../../images/BCPLogo.png";
import Facebook from "../../images/FacebookIcon.png";
import Email from "../../images/EmailIcon.png";

/**
 * Displays the footer
 *
 * @component
 */
const Footer = () => {
  return (
    <footer className="bg-[#1F1405] text-white sm:py-8 pb-8 sm:mt-10 mt-5">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-start space-y-8 md:space-y-0 px-8">
        {/* Left Side */}
        <div className="hidden sm:block w-full md:w-1/2 space-y-8">
          {/* Top Section */}
          <div className="flex items-center space-x-4">
            <img
              src={Logo}
              alt="Benguet Coffee Project"
              className="w-10 h-10"
            />
            <div>
              <h2 className="text-xl font-semibold">Benguet Coffee Project</h2>
              <p className="text-sm leading-relaxed">
                We're more than just a cafe. Join us in giving the limelight{" "}
                <br />
                to local farmers. Learn more, do more!
              </p>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="flex items-center space-x-4">
            <img src={Logo} alt="KapeLink" className="w-10 h-10" />
            <div>
              <h2 className="text-xl font-semibold">KapeLink</h2>
              <p className="text-sm leading-relaxed">
                KapeLink is BCP’s first online ordering platform.
              </p>
            </div>
          </div>
        </div>

        {/* Right Side */}
        <div className="w-full md:w-1/4 ml-auto space-y-4">
          <h2 className="text-xl font-semibold">Contact Us</h2>
          <hr className="border-t-4 border-white-600 w-16" />
          <div className="flex items-center space-x-4">
            <img src={Facebook} alt="Facebook" className="w-6 h-6" />
            <p className="text-sm">
              Saint Louis University-Benguet Coffee Project
            </p>
          </div>
          <div className="flex items-center space-x-4">
            <img src={Email} alt="Email" className="w-6 h-5" />
            <p className="text-sm">bcp@slu.edu.ph</p>
          </div>
        </div>
      </div>

      {/* Bottom Center */}
      <div className="max-[640px]:px-8 mt-8 text-center">
        <p className="text-sm">
          Copyright © 2024 KapeLink. All Rights Reserved | Created by DataBeasts
        </p>
      </div>
    </footer>
  );
};

export default Footer;
