import React, { useState, useEffect } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import axios from "axios";

/**
 * Renders a custom tooltip with revenue information when hovered over a chart element.
 *
 * @param {boolean} active - Whether the tooltip is active.
 * @param {Array} payload - The data payload passed to the tooltip.
 * @param {string} label - The label to display in the tooltip.
 * @returns {JSX.Element|null} - Returns the tooltip component if active, otherwise null.
 */
const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const revenueData = payload.find((p) => p.dataKey === "revenue");

    return (
      <div className="p-4 bg-white flex flex-col rounded-md">
        <p className="text-color-custom font-medium text-2xl max-[640px]:text-lg">
          {label}
        </p>
        {revenueData && (
          <p className="text-xl text-black max-[640px]:text-base">
            Revenue:{" "}
            <span className="ml-2 text-xl max-[640px]:text-base">
              P{revenueData.value}
            </span>
          </p>
        )}
      </div>
    );
  }
  return null;
};

/**
 * Generates an array of 12 objects representing months with zero revenue.
 * Each object contains an id, the abbreviated month name, and a revenue value of 0.
 *
 * @returns {Array} - Array of objects, each representing a month with a revenue of 0.
 */
const generateEmptyMonths = () => {
  return Array.from({ length: 12 }, (_, i) => ({
    id: `empty-${i}`, // Unique key for each month
    name: new Date(0, i).toLocaleString("default", { month: "short" }),
    revenue: 0,
  }));
};

/**
 * Merges fetched revenue data with empty month objects.
 * If a matching month is found in the fetched data, it updates the month with the revenue data.
 * If no match is found, it returns the empty month.
 *
 * @param {Array} fetchedData - Array of objects containing fetched revenue data.
 * @param {Array} emptyMonths - Array of objects representing months with zero revenue.
 * @returns {Array} - Array of merged month objects with updated revenue data.
 */
const mergeRevenueData = (fetchedData, emptyMonths) => {
  return emptyMonths.map((month, index) => {
    const matchingMonth = fetchedData.find((data) => data.name === month.name);
    return matchingMonth ? { ...matchingMonth, id: `data-${index}` } : month;
  });
};

/**
 * Displays a bar chart showing monthly revenue for a selected year.
 * Fetches the revenue data from the API based on the selected year, merges it with empty month data, and filters for current and past months.
 * Adjusts the chart's appearance for small screen sizes and updates the data whenever the selected year changes.
 *
 * @param {string} selectedYear - The year for which the revenue data is fetched and displayed.
 * @returns {JSX.Element} - A responsive bar chart component displaying monthly revenue data.
 */
const BarChartComponent = ({ selectedYear }) => {
  const [revenueData, setRevenueData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth <= 640);

  /**
   * Fetches monthly revenue data for the selected year, processes it, and updates the state with the merged and filtered data.
   * The data is merged with empty months and filtered to show only the current and past months.
   *
   * @async
   * @function fetchRevenueData
   * @returns {Promise<void>}
   * @throws {Error} - Logs any errors during the API request.
   */
  const fetchRevenueData = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-monthly-revenue/${selectedYear}`
      );
      const fetchedData = response.data.map((item) => ({
        name: new Date(0, item._id - 1).toLocaleString("default", {
          month: "short",
        }),
        revenue: item.totalRevenue,
        id: item._id,
      }));

      const emptyMonths = generateEmptyMonths();
      const mergedData = mergeRevenueData(fetchedData, emptyMonths);

      setRevenueData(mergedData);

      const currentMonth = new Date().getMonth();
      const filtered = mergedData.filter((_, index) => index <= currentMonth);
      setFilteredData(filtered);
    } catch (error) {
      console.error("Error fetching revenue data:", error);
    }
  };

  /**
   * Handles screen resizing by updating the `isSmallScreen` state and fetches revenue data when the selected year changes.
   * The chart is rendered with responsive font sizes for the X and Y axes based on screen size.
   *
   * @function handleResize
   * @returns {void}
   */
  const handleResize = () => setIsSmallScreen(window.innerWidth <= 640);

  /**
   * Fetches revenue data when the selected year changes and updates the screen size status.
   * The chart is rendered with responsive font sizes for the X and Y axes based on screen size.
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    fetchRevenueData(); // Fetch revenue data whenever the selected year changes
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [selectedYear]);

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart data={filteredData} margin={{ right: 30 }}>
        <CartesianGrid strokeDasharray="3 5" />
        <XAxis dataKey="name" tick={{ fontSize: isSmallScreen ? 7 : 14 }} />
        <YAxis tick={{ fontSize: isSmallScreen ? 7 : 14 }} />
        <Tooltip content={<CustomTooltip />} />
        <Bar
          dataKey="revenue"
          key={(entry) => `${entry.id}-${entry.revenue}`}
          fill="#A79277"
        />
      </BarChart>
    </ResponsiveContainer>
  );
};

export default BarChartComponent;
