import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import Sidebar, { SidebarItem } from "../Global/SideBar";
import {
  History,
  FileBox,
  HandCoins,
  Bell,
  ChartArea,
  CircleUser,
} from "lucide-react";
import { io } from "socket.io-client";
import axios from "axios";

const ManagerSideBar = () => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const [unreadCount, setUnreadCount] = useState(0);
  const [user, setUser] = useState(null);

  /**
   * Fetches notifications from the server and updates the unread notifications count.
   * This effect runs once on component mount.
   *
   * @function useEffect
   * @returns {void} - Initiates a GET request to fetch notifications for "manager" and "barista" roles.
   *                   It then filters and updates the unread notifications count.
   */
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/get-notifications",
          {
            params: {
              receiver: "all",
              roles: ["manager", "barista"],
            },
          }
        );

        const notifications = response.data;

        const unreadNotifications = notifications.filter(
          (notification) => notification.read === false
        );

        setUnreadCount(unreadNotifications.length);
      } catch (error) {
        console.error("Error fetching notifications:", error);
      }
    };

    fetchNotifications();
  }, []);

  /**
   * Connects to the server using Socket.IO to listen for notifications and updates
   * the unread count accordingly. This effect runs once on component mount and handles
   * the socket connection and event listening for "newOrder" and "readNotificationBM".
   *
   * @function useEffect
   * @returns {void} - Listens for the "newOrder" event to increment the unread count and
   *                   for "readNotificationBM" to decrement the unread count when a notification
   *                   is marked as read.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    // Listen for new notifications
    socket.on("newOrder", () => {
      setUnreadCount((prev) => prev + 1); // Increment unread count if notification is unread
    });

    // Listen for read/unread notifications
    socket.on("readNotificationBM", (read) => {
      setUnreadCount((prev) => {
        const newCount = prev + (read ? -1 : 1);
        return newCount;
      });
    });

    // Cleanup on component unmount
    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Fetches user data from the server on component mount.
   *
   * @function useEffect
   * @returns {void} - Initiates a GET request to fetch the authenticated user's data and
   *                   sets the user data in the state if successful.
   */
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/auth",
          {
            withCredentials: true, // Ensure credentials are included
          }
        );
        if (response.data) {
          setUser(response.data); // Set user data
        } else {
          console.error("Error fetching user data: Auth error");
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
      }
    };

    fetchUser();
  }, []);

  /**
   * Sets the active menu item based on the given path.
   *
   * @function handleSetActive
   * @param {string} path - The path representing the menu item to set as active.
   * @returns {void} - Updates the active item in the state.
   */
  const handleSetActive = (path) => {
    setActiveItem(path);
  };

  return (
    <>
      <Sidebar
        user={user ? `${user.firstName} ${user.lastName}` : "Loading..."}
        role={"Manager"}
      >
        <Link
          to="/manager-manage-payment"
          onClick={() => handleSetActive("/manager-manage-payment")}
        >
          <SidebarItem
            icon={<HandCoins size={20} />}
            text="Payment Management"
            active={activeItem === "/manager-manage-payment"}
          />
        </Link>

        <Link
          to="/manager-manage-order"
          onClick={() => handleSetActive("/manager-manage-order")}
        >
          <SidebarItem
            icon={<FileBox size={20} />}
            text="Order Management"
            active={activeItem === "/manager-manage-order"}
          />
        </Link>

        <Link
          to="/manager-order-tracking"
          onClick={() => handleSetActive("/manager-order-tracking")}
        >
          <SidebarItem
            icon={<History size={20} />}
            text="Order Tracking"
            active={activeItem === "/manager-order-tracking"}
          />
        </Link>

        <Link
          to="/manager-notifications"
          onClick={() => handleSetActive("/manager-notifications")}
        >
          <SidebarItem
            icon={
              <div className="relative">
                <Bell size={20} />
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span> // Red circular indicator
                )}
              </div>
            }
            text="Notifications"
            active={activeItem === "/manager-notifications"}
          />
        </Link>

        <Link
          to="/manager-analytics"
          onClick={() => handleSetActive("/manager-analytics")}
        >
          <SidebarItem
            icon={<ChartArea size={20} />}
            text="Analytics"
            active={activeItem === "/manager-analytics"}
          />
        </Link>

        <Link
          to="/manager-customer-profile"
          onClick={() => handleSetActive("/manager-customer-profile")}
        >
          <SidebarItem
            icon={<CircleUser size={20} />}
            text="Customer Profile"
            active={activeItem === "/manager-customer-profile"}
          />
        </Link>
      </Sidebar>
    </>
  );
};

export default ManagerSideBar;
