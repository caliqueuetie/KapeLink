import React, { useState, useEffect } from "react";
import axios from "axios";

const SliderButton = ({ statuses }) => {
  const [isChecked, setIsChecked] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  /**
   * Sets the initial checked state based on payment statuses. If all statuses are "Active", sets the state to true.
   * Also sets the loading state to false after processing.
   *
   * @function useEffect
   * @param {Array} statuses - The list of payment statuses.
   * @returns {void}
   */
  useEffect(() => {
    if (statuses && statuses.length > 0) {
      // Ensure statuses are available before setting the state
      const allActive = statuses.every((status) => status.status === "Active");
      setIsChecked(allActive); // Set the state based on payment statuses
    }
    setIsLoading(false); // Set loading to false after processing
  }, [statuses]);

  /**
   * Toggles the checked state and updates the payment status accordingly.
   *
   * @async
   * @function handleToggle
   * @returns {Promise<void>}
   */
  const handleToggle = async () => {
    const newCheckedState = !isChecked;
    setIsChecked(newCheckedState); // Toggle the checked state
    await updatePaymentStatus(newCheckedState); // Update the payment status
  };

  /**
   * Updates the payment status to "Active" or "Inactive" based on the input.
   *
   * @async
   * @function updatePaymentStatus
   * @param {boolean} status - True for "Active", false for "Inactive".
   * @returns {Promise<void>}
   * @throws {Error} - Logs any errors during the API request.
   */
  const updatePaymentStatus = async (status) => {
    try {
      const paymentStatus = status ? "Active" : "Inactive";

      await axios.patch(
        "http://localhost:9000/api/kape-link/update-payment-status",
        {
          status: paymentStatus,
          excludeOids: ["1"], // Exclude OIDs if needed
        }
      );
    } catch (error) {
      console.error("Error updating payment status:", error);
    }
  };

  if (isLoading) {
    // Optionally show a loading state until the status is checked
    return <div>Loading...</div>;
  }

  return (
    <label
      className="relative inline-block w-14 h-7 max-[640px]:w-10 max-[640px]:h-5"
      htmlFor="sliderButton"
    >
      <input
        id="sliderButton"
        type="checkbox"
        className="opacity-0 w-0 h-0"
        checked={isChecked}
        onChange={handleToggle}
      />
      <span
        className={`absolute cursor-pointer top-0 left-0 right-0 bottom-0 bg-gray-300 rounded-full transition ${
          isChecked ? "bg-brown" : "bg-gray-300"
        }`}
      >
        <span
          className={`absolute left-1 top-1 h-5 w-5 bg-white rounded-full transition-transform max-[640px]:h-3 max-[640px]:w-3 ${
            isChecked ? "transform translate-x-7 max-[640px]:translate-x-5" : ""
          }`}
        ></span>
      </span>
    </label>
  );
};

export default SliderButton;
