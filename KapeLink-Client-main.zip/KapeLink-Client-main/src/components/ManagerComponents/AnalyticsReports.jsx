import React, { useState, useEffect } from "react";
import axios from "axios";
import SearchBar from "../Global/SearchBar";
import FilterButton from "../Global/FilterButton";
import DateRangeFilter from "./DateRangeFilter";
import { Download } from "lucide-react";
import ExcelJS from "exceljs";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import dayjs from "dayjs";
import isBetween from "dayjs/plugin/isBetween";
import isSameOrAfter from "dayjs/plugin/isSameOrAfter";
import isSameOrBefore from "dayjs/plugin/isSameOrBefore";

dayjs.extend(isSameOrAfter);
dayjs.extend(isSameOrBefore);
dayjs.extend(isBetween);

const AnalyticsReports = () => {
  const cellformat =
    "border-b border-gray-400 p-10 text-center min-[640px]:text-lg max-[640px]:text-xs max-[640px]:font-thin max-[640px]:p-4 whitespace-nowrap";
  const headerformat =
    "w-screen p-3 font-medium min-[640px]:text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";
  const footerformat =
    "w-screen p-3 px-10 font-medium min-[640px]:text-lg max-[640px]:text-xs max-[640px]:font-normal max-[640px]:p-1";
  const [data, setData] = useState([]);
  const [exportData, setExportData] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("");
  const [salesReports, setSalesReports] = useState([]);
  const [activeColumn, setActiveColumn] = useState(null);
  const [sortDirection, setSortDirection] = useState("asc");
  const [dateRange, setDateRange] = useState([null, null]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  /**
   * Fetches products and orders data from the API, processes the data, and updates the state with export data,
   * unique sales reports, and processed report data.
   * Handles errors and sets loading state.
   *
   * @async
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const fetchData = async () => {
      try {
        const productsResponse = await axios.get(
          "http://localhost:9000/api/kape-link/get-products"
        );
        const ordersResponse = await axios.get(
          "http://localhost:9000/api/kape-link/get-orders"
        );

        const products = productsResponse.data;
        const orders = ordersResponse.data;

        setExportData(orders);

        const uniqueSalesReports = [
          ...new Set(products.map((p) => p.salesReport)),
        ];

        setSalesReports(uniqueSalesReports);

        const reportData = processReports(products, orders);
        setData(reportData);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  /**
   * Processes product and order data to generate a sales report with total revenue, times ordered,
   * peak hour, and other relevant details.
   *
   * @function processReports
   * @param {Array} products - List of products to process.
   * @param {Array} orders - List of completed orders containing items and tracking information.
   * @returns {Array} - Processed report data with product sales statistics.
   */
  const processReports = (products, orders) => {
    const reportData = products.map((product) => {
      let totalRevenue = 0;
      let timesOrdered = 0;
      const hourCount = {};
      const orderDates = [];
      let unitPrice = product.basePrice;

      orders.forEach((order) => {
        const isOrderComplete =
          order.orderStatus === "Complete" ||
          (order.tracking &&
            order.tracking.some((status) => status.orderStatus === "Complete"));

        if (isOrderComplete) {
          order.items.forEach((item) => {
            if (String(item.productId) === product.prodId) {
              totalRevenue += item.totalPrice;
              timesOrdered += item.quantity;

              orderDates.push(new Date(order.orderDate));

              const hour = new Date(
                `1970-01-01T${order.timeOrdered}:00Z`
              ).getUTCHours();
              hourCount[hour] = (hourCount[hour] || 0) + 1;
            }
          });
        }
      });

      const peakHour = Object.keys(hourCount).reduce(
        (a, b) => (hourCount[a] > hourCount[b] ? a : b),
        null
      );

      const productName = product.type
        ? `${product.name} (${product.type})`
        : product.name;

      return {
        productName,
        timesOrdered,
        totalRevenue,
        unitPrice,
        peakHour: peakHour !== null ? `${peakHour}:00` : "N/A",
        salesReport: product.salesReport,
        orderDates,
      };
    });

    return reportData;
  };

  /**
   * Handles the export of sales report data to an Excel file, including validation,
   * formatting, and applying styles to the spreadsheet. Filters data based on the selected
   * date range, organizes it by product categories, and calculates total revenue.
   * The resulting Excel file is downloaded with the appropriate date range in the filename.
   *
   * @async
   * @function handleExport
   * @returns {void}
   */
  const handleExport = async () => {
    if (!dateRange[0] || !dateRange[1]) {
      setError("Please select a date range before exporting.");
      return;
    }

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("SalesReports");

    // Helper function to apply border to a specific cell
    const borderCell = (cell) => {
      worksheet.getCell(cell).border = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
      };
    };

    // Helper function to style categories
    const borderCategories = (cell) => {
      worksheet.getCell(cell).alignment = {
        horizontal: "center",
        vertical: "middle",
      };
      worksheet.getCell(cell).fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFD2B48C" },
      };
      borderCell(cell);
    };

    // Helper function to style title cells
    const styleTitleCell = (cell) => {
      worksheet.getCell(cell).font = { bold: true };
      worksheet.getCell(cell).alignment = {
        horizontal: "center",
        vertical: "middle",
      };
      worksheet.getCell(cell).fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFD2B48C" },
      };
      borderCell(cell);
    };

    // Helper function to format cells with currency format (₱ with two decimal places)
    const formatCurrencyCell = (cellAddress, identify) => {
      if (identify == "unitPrice") {
        formatCurrencyCell(cellAddress);
        worksheet.getCell(cellAddress).fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FFFF8F" },
        };
      } else {
        const cell = worksheet.getCell(cellAddress);
        cell.numFmt = '"₱"#,##0.00';
      }
    };

    // Function to format currency without Peso sign for subsequent rows
    const formatCurrencyCellWithoutSymbol = (cellAddress, identify) => {
      if (identify == "unitPrice") {
        const cell = worksheet.getCell(cellAddress);
        cell.numFmt = "#,##0.00";
        worksheet.getCell(cellAddress).fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FFFF8F" },
        };
      } else {
        const cell = worksheet.getCell(cellAddress);
        cell.numFmt = "#,##0.00";
      }
    };

    // Helper function to add and style rows
    const addStyledRow = (data, isHeader = false) => {
      const row = worksheet.addRow(data);
      row.eachCell((cell) => {
        if (isHeader) {
          cell.font = { bold: true };
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "E3735E" },
          };
        }
        borderCell(cell.address);
      });
    };

    // Spreadsheet Title
    worksheet.mergeCells("A1:D1");
    worksheet.getCell("A1").value =
      "BENGUET COFFEE PROJECT X FARM TO CUP PHILIPPINES";
    styleTitleCell("A1");

    // Spreadsheet Date Range
    worksheet.mergeCells("A3:D3");
    worksheet.getCell("B3").value = "Date Range";
    styleTitleCell("B3");

    // Start and End Date
    worksheet.mergeCells("B4:D4");
    worksheet.getCell("A4").value = "Start Date:";
    styleTitleCell("A4");
    worksheet.getCell("B4").value = dayjs(dateRange[0]).format("YYYY-MM-DD");
    borderCell("B4");

    worksheet.mergeCells("B5:D5");
    worksheet.getCell("A5").value = "End Date:";
    styleTitleCell("A5");
    worksheet.getCell("B5").value = dayjs(dateRange[1]).format("YYYY-MM-DD");
    borderCell("B5");

    worksheet.addRow([]);

    const filteredData = getFilteredData();
    const organizedData = {};

    let grandTotal = 0;

    filteredData.forEach((report) => {
      const category = report.salesReport;

      if (!organizedData[category]) {
        organizedData[category] = {
          products: [],
          headers: ["Product Name", "Quantity", "Unit Price", "Total Amount"],
        };
      }

      organizedData[category].products.push({
        name: report.productName,
        quantity: report.timesOrdered,
        unitPrice: report.unitPrice,
        totalAmount: report.totalRevenue,
      });

      grandTotal += report.totalRevenue;
    });

    // Loop through each category and apply styles
    Object.keys(organizedData).forEach((category) => {
      addStyledRow([category], true);

      const headers = organizedData[category].headers;
      const headerRow = worksheet.addRow(headers);

      headers.forEach((_, index) => {
        const cellAddress = headerRow.getCell(index + 1).address;
        borderCategories(cellAddress);
      });

      organizedData[category].products.sort((a, b) =>
        a.name.localeCompare(b.name)
      );

      organizedData[category].products.forEach((product, index) => {
        const row = worksheet.addRow(Object.values(product));
        const rowIndex = row.number;

        if (index === 0) {
          formatCurrencyCell(`C${rowIndex}`, "unitPrice");
          formatCurrencyCell(`D${rowIndex}`, "totalAmount");
        } else {
          formatCurrencyCellWithoutSymbol(`C${rowIndex}`, "unitPrice");
          formatCurrencyCellWithoutSymbol(`D${rowIndex}`, "totalAmount");
        }
      });

      worksheet.addRow([]);
    });
    const styleGrandTotalRow = (cell) => {
      worksheet.getCell(cell).fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "FFD9D9D9" },
      };
      borderCell(cell);
    };

    const grandTotalRow = worksheet.addRow(["Grand Total", "", "", grandTotal]);
    grandTotalRow.getCell(1).font = { bold: true };
    grandTotalRow.getCell(4).numFmt = '"₱"#,##0.00';
    formatCurrencyCell(`D${grandTotalRow.number}`);

    // Apply the styles using the helper function
    grandTotalRow.eachCell((cell) => {
      styleGrandTotalRow(cell.address);
    });

    worksheet.columns = [
      { width: 30 },
      { width: 19 },
      { width: 19 },
      { width: 19 },
      { width: 19 },
      { width: 19 },
      { width: 19 },
    ];

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: "application/octet-stream" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const startDate = dayjs(dateRange[0]).format("YYYY-MM-DD");
    const endDate = dayjs(dateRange[1]).format("YYYY-MM-DD");
    a.download = `SalesReports_${startDate}_to_${endDate}.xlsx`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  /**
   * Filters and processes the sales data based on the order status, date range, and search query.
   * Combines multiple orders for the same product, summing the quantities and total revenue.
   * Returns a list of combined product reports that meet the filtering criteria.
   *
   * @function getFilteredData
   * @returns {Array} - An array of objects containing filtered and combined product sales reports.
   */
  const getFilteredData = () => {
    const filtered = exportData.filter((order) => {
      const isOrderComplete =
        order.orderStatus === "Complete" ||
        (order.tracking &&
          order.tracking.some((status) => status.orderStatus === "Complete"));

      const orderDate = dayjs(order.orderDate);

      const isWithinDateRange =
        (!dateRange[0] ||
          orderDate.isSameOrAfter(dayjs(dateRange[0]), "day")) &&
        (!dateRange[1] ||
          orderDate.isSameOrBefore(dayjs(dateRange[1]).endOf("day"), "day"));

      const isMatchSearchQuery = order.items.some((item) =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      );

      return isOrderComplete && isWithinDateRange && isMatchSearchQuery;
    });

    const combinedReports = {};

    filtered.forEach((order) => {
      order.items.forEach((item) => {
        const productName = item.type
          ? `${item.name} (${item.type})`
          : item.name;

        if (combinedReports[productName]) {
          combinedReports[productName].timesOrdered += item.quantity;
          combinedReports[productName].totalRevenue += item.totalPrice;
        } else {
          combinedReports[productName] = {
            productName: productName,
            salesReport: item.salesReport,
            timesOrdered: item.quantity,
            totalRevenue: item.totalPrice,
            unitPrice: item.pricePerItem,
            orderDate: order.orderDate,
          };
        }
      });
    });

    const reports = Object.values(combinedReports);

    return reports;
  };

  /**
   * Handles sorting of the table by a specific column. Toggles the sort direction if the same column is clicked again,
   * or sets the column to be sorted in ascending order if a different column is clicked.
   *
   * @function handleSort
   * @param {string} column - The column name to be sorted.
   */
  const handleSort = (column) => {
    if (activeColumn === column) {
      setSortDirection((prevDirection) =>
        prevDirection === "asc" ? "desc" : "asc"
      );
    } else {
      setActiveColumn(column);
      setSortDirection("asc");
    }
  };

  /**
   * Returns the sort arrow ("↑" or "↓") based on the active column and sort direction.
   *
   * @param {string} field - The field being checked for sorting.
   * @returns {string|null} - The sort arrow or null if the field is not active.
   */
  const getSortArrow = (field) => {
    if (activeColumn !== field) return null;
    return sortDirection === "asc" ? "↑" : "↓";
  };

  /**
   * Sorts the data array based on the active column and sort direction.
   * It supports sorting by "Product Name", "Times Ordered", "Total Revenue", and "Peak Hour".
   *
   * @function sortedData
   * @returns {Array} - Sorted data array.
   */
  const sortedData = [...data].sort((a, b) => {
    let comparison = 0;
    if (activeColumn === "Product Name") {
      comparison = a.productName.localeCompare(b.productName);
    } else if (activeColumn === "Times Ordered") {
      comparison = a.timesOrdered - b.timesOrdered;
    } else if (activeColumn === "Total Revenue") {
      comparison = a.totalRevenue - b.totalRevenue;
    } else if (activeColumn === "Peak Hour") {
      comparison = a.peakHour.localeCompare(b.peakHour);
    }

    return sortDirection === "asc" ? comparison : -comparison;
  });

  /**
   * Filters the sorted data based on the search query and active filter.
   *
   * @function
   * @returns {Array} - The filtered array of reports matching the search query and filter criteria.
   */
  const filteredData = sortedData.filter((report) => {
    const searchQueryLower = searchQuery.toLowerCase();

    const productMatch = report.productName
      .toLowerCase()
      .includes(searchQueryLower);
    const timesOrderedMatch = report.timesOrdered
      ?.toString()
      .toLowerCase()
      .includes(searchQueryLower);
    const totalRevenueMatch = report.totalRevenue
      ?.toString()
      .toLowerCase()
      .includes(searchQueryLower);
    const peakHourMatch = report.peakHour
      ?.toString()
      .toLowerCase()
      .includes(searchQueryLower);

    const salesReportFilterMatch = activeFilter
      ? report.salesReport === activeFilter
      : true;

    return (
      (productMatch ||
        timesOrderedMatch ||
        totalRevenueMatch ||
        peakHourMatch) &&
      salesReportFilterMatch
    );
  });

  return (
    <div className="flex flex-col justify-center items-center w-full mt-5 max-[640px]:mt-2">
      <div className="flex w-full mb-10 max-[640px]:flex-col-reverse max-[640px]:mb-4">
        <div className="flex items-center space-x-3">
          <DateRangeFilter onDateChange={setDateRange} />
          <button
            onClick={handleExport}
            className="flex custom-button-black py-2 px-4 rounded-xl max-[640px]:px-4 max-[640px]:py-0 max-[640px]:rounded-lg"
          >
            <span className="mr-2 max-[640px]:mr-0">
              <Download className="max-[640px]:w-4" />
            </span>
            <span className="max-[640px]:hidden">Export</span>
          </button>
          {error && <div className="text-red-500">{error}</div>}{" "}
          {/* Display error message */}
        </div>

        <div className="flex ml-auto space-x-3 max-[640px]:mb-3 max-[640px]:w-full ">
          <SearchBar
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
          <FilterButton
            activeFilter={activeFilter}
            setActiveFilter={setActiveFilter}
            salesReports={salesReports}
            pageKey="analytics"
          />
        </div>
      </div>
      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[450px] 2xl:h-[760px] max-[640px]:max-w-80">
        {loading ? (
          <table className="max-[640px]:h-[450px] h-[720px] flex flex-col items-center justify-center ">
            <thead>
              <tr>
                <th
                  className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center`}
                >
                  <Player
                    autoplay
                    loop
                    src={loader}
                    style={{ height: "150px", width: "150px" }}
                  />
                </th>
              </tr>
            </thead>
          </table>
        ) : (
          <table>
            <thead className="sticky top-0 bg-white z-10">
              <tr className="border-b border-gray-400">
                <th
                  className={headerformat}
                  onClick={() => handleSort("Product Name")}
                >
                  Product Name {getSortArrow("Product Name")}
                </th>
                <th
                  className={headerformat}
                  onClick={() => handleSort("Times Ordered")}
                >
                  Times Ordered {getSortArrow("Times Ordered")}
                </th>
                <th
                  className={headerformat}
                  onClick={() => handleSort("Total Revenue")}
                >
                  Total Revenue {getSortArrow("Total Revenue")}
                </th>
                <th
                  className={headerformat}
                  onClick={() => handleSort("Peak Hour")}
                >
                  Peak Hour {getSortArrow("Peak Hour")}
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredData.map((reports, index) => (
                <tr key={index}>
                  <td className={cellformat}>{reports.productName}</td>
                  <td className={cellformat}>{reports.timesOrdered}</td>
                  <td className={cellformat}>
                    P
                    {reports.totalRevenue.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </td>
                  <td className={cellformat}>{reports.peakHour}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto mt-5 max-[640px]:max-w-80">
        <table>
          <thead>
            <tr>
              <th className={footerformat}>Total</th>
              <th className={footerformat}>
                {filteredData.reduce((acc, curr) => acc + curr.timesOrdered, 0)}
              </th>
              <th className={footerformat}>
                P
                {filteredData
                  .reduce((acc, curr) => acc + curr.totalRevenue, 0)
                  .toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
              </th>
              <th className={footerformat}></th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  );
};

export default AnalyticsReports;
