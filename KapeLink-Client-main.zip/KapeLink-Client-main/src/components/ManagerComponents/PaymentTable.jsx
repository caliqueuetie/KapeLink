import React, { useState, useEffect } from "react";
import PaymentSummaryPopup from "./PaymentSummaryPopup";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/kapelinkLoader.json";
import axios from "axios";

const PaymentTable = ({
  activeTab,
  activeFilter,
  searchQuery,
  data,
  loading,
}) => {
  const cellFormat =
    "border-b border-gray-400 py-10 2xl:px-10 text-gray-600 text-center lg:text-base text-xs 2xl:font-normal font-thin 2xl:p-10 px-2 py-8 whitespace-nowrap";
  const headerFormat =
    "cursor-pointer w-screen lg:text-base text-xs lg:font-semibold font-normal lg:p-3 p-1 whitespace-nowrap";

  const [isPaymentSummaryPopupOpen, setPaymentSummaryPopupOpen] =
    useState(false);
  const [buttonText, setButtonText] = useState("View Proof");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [sortField, setSortField] = useState("Order Date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [paymentMethods, setPaymentMethods] = useState({});

  /**
   * Opens the payment summary popup for the selected order.
   *
   * @function handlePaymentSummaryOpenPopup
   * @param {Object} order - The selected order to display in the payment summary popup.
   */
  const handlePaymentSummaryOpenPopup = (order) => {
    if (order) {
      setSelectedOrder(order);
      setPaymentSummaryPopupOpen(true);
    }
  };

  /**
   * Sets the button text based on the window width (responsive behavior).
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const handleResize = () => {
      setButtonText(window.innerWidth <= 640 ? "View" : "View Proof");
    };
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  /**
   * Calculates the total price of all items in an order.
   *
   * @function calculateTotalPrice
   * @param {Array} items - The items in the order to calculate the total price for.
   * @returns {string} - The total price, formatted to two decimal places.
   */
  const calculateTotalPrice = (items) => {
    const total = items.reduce(
      (total, item) => total + (item.totalPrice || 0),
      0
    );
    return total.toFixed(2);
  };

  /**
   * Sorts the orders based on the specified field and updates the sorting order.
   *
   * @function sortOrders
   * @param {string} field - The field by which the orders should be sorted.
   */
  const sortOrders = (field) => {
    const newSortOrder =
      sortField === field && sortOrder === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortOrder(newSortOrder);
  };

  /**
   * Retrieves the value to be used for sorting based on the selected field.
   *
   * @function getSortValue
   * @param {Object} item - The order item to be sorted.
   * @param {string} field - The field to sort by (e.g., Order ID, Order Date).
   * @returns {string|number} - The value used for sorting based on the field.
   */
  const getSortValue = (item, field) => {
    switch (field) {
      case "Order ID":
        return item.orderId;
      case "Order Date":
        return new Date(item.orderDate);
      case "Time Ordered":
        const timeParts = item.timeOrdered.split(":");
        return +timeParts[0] * 60 + +timeParts[1];
      case "Total Price":
        return calculateTotalPrice(item.items);
      default:
        return 0;
    }
  };

  /**
   * Sorts the data based on the selected field and order.
   *
   * @function sortedData
   * @returns {Array} - The sorted data based on the selected sort field and order.
   */
  const sortedData = [...data].sort((a, b) => {
    const valueA = getSortValue(a, sortField);
    const valueB = getSortValue(b, sortField);
    return sortOrder === "asc" ? valueA - valueB : valueB - valueA;
  });

  /**
   * Filters the orders based on the selected tab.
   *
   * @function filterDataByTab
   * @param {Array} orders - The list of orders to filter.
   * @returns {Array} - The filtered orders based on the active tab.
   */
  const filterDataByTab = (orders) => {
    switch (activeTab) {
      case "Pending":
        return orders.filter(
          (order) => order.verificationStatus === "Not Verified"
        );
      case "Confirmed":
        return orders.filter(
          (order) => order.verificationStatus === "Verified"
        );
      case "Returned":
        return orders.filter(
          (order) => order.verificationStatus === "Returned"
        );
      case "Rejected":
        return orders.filter(
          (order) => order.verificationStatus === "Rejected"
        );
      default:
        return orders;
    }
  };

  /**
   * Filters and applies the active filter and search query to the sorted data.
   *
   * @function filteredData
   * @returns {Array} - The filtered data based on the active tab, search query, and payment method filter.
   */
  const filteredData = filterDataByTab(sortedData).filter((item) => {
    const searchQueryLower = searchQuery.toLowerCase();
    const orderIDMatches = item.orderId
      ?.toString()
      .toLowerCase()
      .includes(searchQueryLower);
    const orderDateMatches = item.orderDate
      ?.toLowerCase()
      .includes(searchQueryLower);
    const timeOrderedMatches = item.timeOrdered
      ?.toLowerCase()
      .includes(searchQueryLower);
    const totalPriceMatches = calculateTotalPrice(item.items)
      .toString()
      .toLowerCase()
      .includes(searchQueryLower);

    const searchMatches =
      orderIDMatches ||
      orderDateMatches ||
      timeOrderedMatches ||
      totalPriceMatches;

    const filterMatches = activeFilter
      ? item.paymentMethodName === activeFilter
      : true;

    return searchMatches && filterMatches;
  });

  return (
    <>
      <div className="flex justify-center items-center w-full mt-4">
        <div className="w-full border-collapse border border-gray-400 rounded-lg overflow-y-auto h-[550px] 2xl:h-[760px] max-[640px]:max-w-80">
          {loading ? (
            <table className="h-[548px] 2xl:h-[758px] flex flex-col items-center justify-center">
              <thead>
                <tr>
                  <th
                    className={`w-screen px-10 font-semibold whitespace-nowrap text-4xl border-gray-400 text-center `}
                  >
                    <Player
                      autoplay
                      loop
                      src={loader}
                      style={{ height: "150px", width: "150px" }}
                    />
                  </th>
                </tr>
              </thead>
            </table>
          ) : (
            <table>
              <thead className="sticky top-0 bg-white z-10">
                <tr className="border-b border-gray-400">
                  <th
                    className={headerFormat}
                    onClick={() => sortOrders("Order ID")}
                  >
                    Order ID{" "}
                    {sortField === "Order ID"
                      ? sortOrder === "asc"
                        ? "↑"
                        : "↓"
                      : ""}
                  </th>
                  <th
                    className={headerFormat}
                    onClick={() => sortOrders("Order Date")}
                  >
                    Order Date{" "}
                    {sortField === "Order Date"
                      ? sortOrder === "asc"
                        ? "↑"
                        : "↓"
                      : ""}
                  </th>
                  <th
                    className={headerFormat}
                    onClick={() => sortOrders("Time Ordered")}
                  >
                    Time Ordered{" "}
                    {sortField === "Time Ordered"
                      ? sortOrder === "asc"
                        ? "↑"
                        : "↓"
                      : ""}
                  </th>
                  <th
                    className={headerFormat}
                    onClick={() => sortOrders("Total Price")}
                  >
                    Total Price{" "}
                    {sortField === "Total Price"
                      ? sortOrder === "asc"
                        ? "↑"
                        : "↓"
                      : ""}
                  </th>
                  <th className={headerFormat}>Payment Method</th>
                  <th className={headerFormat}>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.length > 0 ? (
                  <>
                    {filteredData.map((item) => (
                      <tr key={item.orderId}>
                        <td className={cellFormat}>{item.orderId}</td>
                        <td className={cellFormat}>{item.orderDate}</td>
                        <td className={cellFormat}>{item.timeOrdered}</td>
                        <td className={cellFormat}>
                          P{calculateTotalPrice(item.items)}
                        </td>
                        <td className={cellFormat}>{item.paymentMethodName}</td>
                        <td
                          className={`${cellFormat} text-center`}
                          style={{ verticalAlign: "middle" }}
                        >
                          <div className="relative inline-block align-middle">
                            <button
                              onClick={() =>
                                handlePaymentSummaryOpenPopup(item)
                              }
                              className="custom-button-black rounded-full px-6 2xl:px-10 py-2 font-medium text-sm max-[640px]:px-5 max-[640px]:py-1 max-[640px]:font-thin whitespace-nowrap"
                            >
                              {item.verificationStatus === "Verified"
                                ? "View Details"
                                : buttonText}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </>
                ) : (
                  <tr>
                    <td colSpan="6" className="text-center p-4">
                      No payment found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
      {isPaymentSummaryPopupOpen && (
        <PaymentSummaryPopup
          order={selectedOrder}
          onClose={() => setPaymentSummaryPopupOpen(false)}
        />
      )}
    </>
  );
};

export default PaymentTable;
