import CountUp from "react-countup";

const StatCard = ({ title, value }) => {
  /**
   * Formats the value based on the title.
   * If the title includes "Sales", it returns the value formatted to 2 decimal places.
   * Otherwise, it returns the original value.
   *
   * @function formatValue
   * @returns {string | number} - Formatted value based on the title.
   */
  const formatValue = () => {
    if (title.includes("Sales")) {
      return value.toFixed(2);
    }
    return value;
  };

  /**
   * Appends appropriate text based on the title and value.
   * - For "Sales", appends "P".
   * - For "Cups Sold", appends "cup" or "cups" based on the value.
   * - For "Orders", appends "order" or "orders" based on the value.
   * - Defaults to no extra text if none of the conditions are met.
   *
   * @function appendText
   * @returns {string} - The appended text based on the title and value.
   */
  const appendText = () => {
    if (title.includes("Sales")) {
      return "P";
    }
    if (title.includes("Cups Sold")) {
      return value === 1 ? " cup" : " cups";
    }
    if (title.includes("Orders")) {
      return value === 1 ? " order" : " orders";
    }
    return "";
  };

  return (
    <div className="bg-brown py-7 xl:py-10 px-4 rounded-lg shadow-md text-white max-[640px]:mx-0 max-[640px]:w-80">
      <p className="font-medium text-xl mb-3 max-[640px]:text-lg max-[640px]:mb-1">
        {title}
      </p>
      <p className="font-normal text-5xl max-[640px]:text-3xl max-[640px]:font-semibold">
        <>
          {title.includes("Sales") ? appendText() : ""}
          <CountUp
            end={Number(formatValue())}
            duration={3}
            decimals={title.includes("Sales") ? 2 : 0}
          />
          {title.includes("Sales") ? "" : appendText()}
        </>
      </p>
    </div>
  );
};

export default StatCard;
