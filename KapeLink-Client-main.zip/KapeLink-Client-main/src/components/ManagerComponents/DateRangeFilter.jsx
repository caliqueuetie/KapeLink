import React from "react";
import { DatePicker, Space } from "antd";

const { RangePicker } = DatePicker;

/**
 * A date range filter component that allows users to select a date range.
 * Calls the `onDateChange` prop with the selected dates when changed.
 *
 * @param {function} onDateChange - Callback function that receives the selected dates.
 * @returns {JSX.Element} - A date range picker component wrapped in a vertical space container.
 */
const DateRangeFilter = ({ onDateChange }) => {
  const handleChange = (dates) => {
    // Call the onDateChange prop with the selected dates
    onDateChange(dates);
  };

  return (
    <Space direction="vertical">
      <RangePicker
        onChange={handleChange}
        className="placeholder-color py-2 px-5 mr-1 border-gray-400 max-[640px]:w-64 max-[640px]:py-0"
        popupClassName="text-xs sm:text-base"
      />
    </Space>
  );
};

export default DateRangeFilter;
