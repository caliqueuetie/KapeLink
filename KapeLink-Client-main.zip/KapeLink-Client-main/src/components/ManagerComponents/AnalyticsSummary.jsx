import React, { useState, useEffect } from "react";
import StatCard from "./StatCard";
import BarChartComponent from "./BarChartComponent";
import axios from "axios";

const AnalyticsSummary = ({ currentDate }) => {
  const [stats, setStats] = useState({
    totalSales: 0,
    totalCupsSold: 0,
    totalOrders: 0,
    totalCoffeeSales: 0,
    totalNonCoffeeSales: 0,
    otherSales: 0,
  });
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [years, setYears] = useState([]);

  /**
   * Fetches today's orders and updates the statistics.
   *
   * @async
   * @returns {void} - Updates the stats with the total sales, cups sold, orders, and categorized sales data.
   */
  const getOrdersToday = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-orders-today"
      );

      if (response.status !== 200) {
        throw new Error(response.data.error || "Failed to fetch orders");
      }

      const data = response.data;

      setStats({
        totalSales: data.totalSales,
        totalCupsSold: data.totalCupsSold,
        totalOrders: data.totalOrders,
        totalCoffeeSales: data.totalCoffeeSales,
        totalNonCoffeeSales: data.totalNonCoffeeSales,
        otherSales: data.otherSales,
      });
    } catch (error) {
      console.error("Error fetching today's orders:", error);
    }
  };

  /**
   * Fetches unique years and updates the state with the retrieved data.
   *
   * @async
   * @returns {void} - Updates the years state with the fetched unique years.
   */
  const fetchUniqueYears = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-unique-years"
      );
      setYears(response.data); // Update state with fetched years
    } catch (error) {
      console.error("Failed to fetch unique years");
    }
  };

  /**
   * Fetches today's orders and unique years when the component mounts or when `currentDate` changes.
   *
   * @returns {void} - Triggers data fetch for orders and unique years based on `currentDate`.
   */
  useEffect(() => {
    getOrdersToday();
    fetchUniqueYears();
  }, [currentDate]);

  return (
    <div className="w-full">
      {/* Stats Row */}
      <div className="grid grid-cols-1 px-5 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-5 xl:mt-8 max-[640px]:gap-3 max-[640px]:mt-5 max-[640px]:px-0">
        <StatCard title="Total Sales" value={stats.totalSales} />
        <StatCard
          title={
            stats.totalCupsSold === 1 ? "Total Cup Sold" : "Total Cups Sold"
          }
          value={stats.totalCupsSold}
        />
        <StatCard
          title={
            stats.totalOrders === 1
              ? "Total Completed Order"
              : "Total Completed Orders"
          }
          value={stats.totalOrders}
        />
        <StatCard title="Total Coffee Sales" value={stats.totalCoffeeSales} />
        <StatCard
          title="Total Non-Coffee Sales"
          value={stats.totalNonCoffeeSales}
        />
        <StatCard title="Other Sales" value={stats.otherSales} />
      </div>

      <main className="flex flex-col max-[640px]:items-center max-[640px]:justify-center py-10 px-5 max-[640px]:px-0">
        <div className="w-full">
          <GridItem title="Sales Summary">
            <div className="mb-4">
              <label htmlFor="year-select" className="mr-2 ">
                Select Year:
              </label>
              <select
                id="year-select"
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                className="border rounded p-2"
              >
                {years.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>
            <BarChartComponent selectedYear={selectedYear} />
          </GridItem>
        </div>
      </main>
    </div>
  );
};

function GridItem({ title, children }) {
  return (
    <div className="flex flex-col justify-center p-20 border border-color-custom bg-white rounded-xl h-72 lg:h-[500px] xl:h-[900px] max-[640px]:p-3">
      <h3 className="text-4xl font-semibold text-color-custom mb-10 max-[640px]:text-sm">
        {title}
      </h3>
      {children}
    </div>
  );
}

export default AnalyticsSummary;
