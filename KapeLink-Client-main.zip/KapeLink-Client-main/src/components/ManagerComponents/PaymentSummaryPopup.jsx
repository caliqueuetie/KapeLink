import React, { useEffect, useState } from "react";
import { X } from "lucide-react";
import axios from "axios";
import FloatingSuccessfulNotification from "../Global/FloatingSuccessfulNotification";
import Zoom from "react-medium-image-zoom";
import "react-medium-image-zoom/dist/styles.css";

const PaymentSummaryPopup = ({ onClose, order }) => {
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const [customerName, setCustomerName] = useState("Loading...");
  const [paymentMethodName, setPaymentMethodName] = useState("Loading...");
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [actionToConfirm, setActionToConfirm] = useState(null);
  const [reason, setReason] = useState("");
  const [customReason, setCustomReason] = useState("");

  /**
   * Closes the payment summary popup by calling the onClose callback.
   *
   * @returns {void}
   */
  const handlePaymentSummaryClosePopup = () => {
    onClose();
  };

  const headerDetailsFormat =
    "text-xl font-semibold mb-1 md:mb-2 max-[640px]:text-xs";
  const contentDetailsFormat =
    "text-xl text-color-custom font-medium max-w-72 min-w-44 max-[640px]:text-xs max-[640px]:min-w-20";

  /**
   * Fetches user data by user ID from the API.
   *
   * @param {string} userId - The ID of the user to fetch.
   * @returns {Object|null} - The user data if successful, or null if there is an error.
   */
  const fetchUserById = async (userId) => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-user/${userId}`
      );
      return response.data;
    } catch (error) {
      console.error("Failed to fetch user:", error);
      return null;
    }
  };

  /**
   * Fetches the payment method name by its ID from the API.
   *
   * @param {string} paymentMethodId - The ID of the payment method to fetch.
   * @returns {string} - The payment method name or "Unknown Payment Method" if not found.
   */
  const fetchPaymentNameById = async (paymentMethodId) => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-payment-methods/${paymentMethodId}`
      );
      return response.data.name || "Unknown Payment Method";
    } catch (error) {
      console.error("Failed to fetch payment:", error);
      return null;
    }
  };

  /**
   * Fetches and updates the customer and payment method names based on the order details.
   *
   * @param {Object} order - The current order containing `customerId` and `paymentMethodId`.
   * @returns {void}
   */
  useEffect(() => {
    const fetchCustomerName = async () => {
      if (order?.customerId) {
        const user = await fetchUserById(order.customerId);
        if (user) {
          setCustomerName(`${user.firstName} ${user.lastName}`);
        } else {
          setCustomerName("Unknown Customer");
        }
      }
    };

    const fetchPaymentName = async () => {
      if (order?.paymentMethodId) {
        const name = await fetchPaymentNameById(order.paymentMethodId);
        setPaymentMethodName(name || "Unknown Payment Method");
      }
    };

    fetchCustomerName();
    fetchPaymentName();
  }, [order]);

  const orderID = order?.orderId || "N/A";
  const totalPrice = order
    ? order.items.reduce((total, item) => total + (item.totalPrice || 0), 0)
    : 0;
  const orderDate = order?.orderDate || "N/A";
  const timeOrdered = order?.timeOrdered || "N/A";
  const paymentStatus = order?.verificationStatus || "N/A";
  const proofOfPayment = order?.proofOfPayment;

  /**
   * Verifies the payment status and updates the payment status to "Verified".
   *
   * @returns {void}
   */
  const verifyPayment = async () => {
    try {
      await axios.patch(
        `http://localhost:9000/api/kape-link/update-payment-status/${orderID}`,
        { status: "Verified" }
      );
      handlePaymentSummaryClosePopup();
    } catch (error) {
      console.error("Failed to verify payment:", error);
    }
  };

  /**
   * Returns the payment status and updates the payment status to "Returned" with a reason.
   *
   * @returns {void}
   */
  const returnPayment = async () => {
    try {
      await axios.patch(
        `http://localhost:9000/api/kape-link/update-payment-status/${orderID}`,
        {
          status: "Returned",
          reason: reason === "Others" ? customReason : reason,
        }
      );
      handlePaymentSummaryClosePopup();
    } catch (error) {
      console.error("Failed to return payment:", error);
    }
  };

  /**
   * Rejects the payment and updates the payment status to "Rejected" with a reason.
   *
   * @returns {void}
   */
  const rejectPayment = async () => {
    try {
      await axios.patch(
        `http://localhost:9000/api/kape-link/update-payment-status/${orderID}`,
        {
          status: "Rejected",
          reason: reason === "Others" ? customReason : reason,
        }
      );
      handlePaymentSummaryClosePopup();
    } catch (error) {
      console.error("Failed to reject payment:", error);
    }
  };

  /**
   * Handles the confirmation of actions (verify, return, reject payment) and validates the reason if applicable.
   * If the action requires a reason, it ensures a valid reason is provided before proceeding.
   *
   * @returns {void}
   */
  const handleConfirmAction = async () => {
    try {
      if (actionToConfirm === "verify") {
        await verifyPayment();
      } else {
        const isReasonValid =
          reason && (reason !== "Others" || customReason.trim() !== "");

        if (!isReasonValid) {
          setNotificationMessage(
            "Please provide a reason for returning or rejecting the payment."
          );
          setShowNotification(true);

          setTimeout(() => {
            setShowNotification(false);
          }, 5000);

          return;
        }

        if (actionToConfirm === "return") {
          await returnPayment();
        } else if (actionToConfirm === "reject") {
          await rejectPayment();
        }
      }

      setActionToConfirm(null);
      setReason("");
      setCustomReason("");
      setShowConfirmation(false);
    } catch (error) {
      console.error("Failed to complete action:", error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
      <div className="bg-white p-14 rounded-lg shadow-lg relative max-[640px]:p-4 max-[640px]:w-80">
        <div className="flex">
          <div className="mb-5">
            <h2 className="font-semibold text-xl max-[640px]:text-base">
              Payment Summary
            </h2>
          </div>
          <X
            className="cursor-pointer flex ml-auto mb-3"
            onClick={handlePaymentSummaryClosePopup}
          />
        </div>
        <div className="flex gap-5 mb-9 max-[640px]:mb-5 max-[640px]:ml-1">
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Name</h1>
            <h1 className={contentDetailsFormat}>{customerName}</h1>
          </div>
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Total Amount</h1>
            <h1 className={contentDetailsFormat}>P{totalPrice.toFixed(2)}</h1>
          </div>
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Payment Method</h1>
            <h1 className={contentDetailsFormat}>{paymentMethodName}</h1>
          </div>
        </div>

        <div className="flex gap-5 mb-9 max-[640px]:mb-5 max-[640px]:ml-1">
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Date</h1>
            <h1 className={contentDetailsFormat}>{orderDate}</h1>
          </div>
          <div className="flex flex-col">
            <h1 className={headerDetailsFormat}>Time Ordered</h1>
            <h1 className={contentDetailsFormat}>{timeOrdered}</h1>
          </div>
        </div>
        <div className="min-w-96 flex flex-col mb-5 items-center max-[640px]:min-w-20">
          <h1 className="font-semibold text-xl text-center max-[640px]:text-sm">
            Attached Proof of Payment
          </h1>
          <div className="h-96 max-w-96 w-full border border-gray-400 rounded-lg overflow-hidden mt-2 p-7 max-[640px]:p-5 max-[640px]:h-60">
            {proofOfPayment ? (
              <div className="flex items-center justify-center">
                <Zoom>
                  <img
                    src={`http://localhost:9000/${proofOfPayment}`}
                    alt="Proof of Payment"
                    className="max-h-96 max-[640px]:max-h-52 max-w-full object-contain cursor-pointer"
                  />
                </Zoom>
              </div>
            ) : (
              <p>No proof of payment available.</p>
            )}
          </div>
        </div>

        {/* Display reason for returned or rejected payments */}
        {(paymentStatus === "Returned" || paymentStatus === "Rejected") && (
          <div className="mt-4 text-center">
            <h2 className="font-semibold text-lg">Reason:</h2>
            <p>{order.reason || "No reason provided."}</p>
          </div>
        )}

        {paymentStatus != "Verified" &&
          paymentStatus != "Returned" &&
          paymentStatus != "Rejected" && (
            <div className="flex flex-wrap justify-center gap-2 md:gap-5 sm">
              <button
                onClick={() => {
                  setShowConfirmation(true);
                  setActionToConfirm("verify");
                }}
                className="custom-button-color text-white py-1 px-8 rounded-lg whitespace-nowrap max-[640px]:px-3 max-[640px]:text-xs"
              >
                Confirm Payment
              </button>

              <button
                onClick={() => {
                  setShowConfirmation(true);
                  setActionToConfirm("return");
                }}
                className="custom-button-black rounded-lg py-1 sm:px-12 whitespace-nowrap max-[640px]:px-4 max-[640px]:text-xs"
              >
                Return Payment
              </button>

              <button
                onClick={() => {
                  setShowConfirmation(true);
                  setActionToConfirm("reject");
                }}
                className="bg-gray-400 text-white hover:bg-gray-300 duration-300 rounded-lg py-1 px-12 whitespace-nowrap max-[640px]:px-4 max-[640px]:text-xs"
              >
                Reject Payment
              </button>
            </div>
          )}
      </div>

      {/* Confirmation Dialog */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-30">
          <div className="bg-white p-10 mx-5 w-50 rounded-lg shadow-lg max-[640px]:w-90">
            <h2 className="font-semibold text-lg mb-4">
              Are you sure you want to{" "}
              {actionToConfirm === "reject"
                ? "reject"
                : actionToConfirm === "return"
                ? "return"
                : "verify"}{" "}
              this payment?
            </h2>

            {(actionToConfirm === "reject" || actionToConfirm === "return") && (
              <div>
                <label className="block mb-2">Reason:</label>

                <div className="mb-2">
                  <input
                    type="radio"
                    id="invalid-payment-details"
                    name="rejectionReason"
                    value="Invalid Payment Details"
                    checked={reason === "Invalid Payment Details"}
                    onChange={() => {
                      setReason("Invalid Payment Details");
                      setCustomReason("");
                    }}
                    className="custom-radio-button"
                  />
                  <label htmlFor="invalid-payment-details">
                    Invalid Payment Details
                  </label>
                </div>

                <div className="mb-2">
                  <input
                    type="radio"
                    id="incorrect-payment-amount"
                    name="rejectionReason"
                    value="Incorrect Payment Amount"
                    checked={reason === "Incorrect Payment Amount"}
                    onChange={() => {
                      setReason("Incorrect Payment Amount");
                      setCustomReason("");
                    }}
                    className="custom-radio-button"
                  />
                  <label htmlFor="incorrect-payment-amount">
                    Incorrect Payment Amount
                  </label>
                </div>

                <div className="mb-2">
                  <input
                    type="radio"
                    id="fraud-detection"
                    name="fraudReason"
                    value="Fraud Detection"
                    checked={reason === "Fraud Detection"}
                    onChange={() => {
                      setReason("Fraud Detection");
                      setCustomReason("");
                    }}
                    className="custom-radio-button"
                  />
                  <label htmlFor="fraud-detection-amount">
                    Fraud Detection
                  </label>
                </div>

                <div className="mb-2">
                  <input
                    type="radio"
                    id="others"
                    name="rejectionReason"
                    value="Others"
                    checked={reason === "Others"}
                    onChange={() => {
                      setReason("Others");
                      setCustomReason("");
                    }}
                    className="custom-radio-button"
                  />
                  <label htmlFor="others">Others:</label>

                  {reason === "Others" && (
                    <input
                      type="text"
                      value={customReason}
                      onChange={(e) => setCustomReason(e.target.value)}
                      className="border rounded-lg p-2 w-full mt-2"
                      placeholder="Enter other reason"
                    />
                  )}
                </div>
                {/* Render FloatingSuccessfulNotification conditionally */}
                <FloatingSuccessfulNotification
                  showNotification={showNotification}
                  notificationMessage={notificationMessage}
                />
              </div>
            )}

            <div className="flex justify-end gap-4 mt-4">
              <button
                className="bg-gray-200 hover:bg-gray-300 py-2 px-4 rounded-lg"
                onClick={() => setShowConfirmation(false)}
              >
                Cancel
              </button>
              <button
                className="custom-button-color text-white py-2 px-4 rounded-lg"
                onClick={handleConfirmAction}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentSummaryPopup;
