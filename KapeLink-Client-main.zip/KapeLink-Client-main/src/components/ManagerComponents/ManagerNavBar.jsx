import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import NavBar, { NavbarItem } from "../Global/NavBar";
import axios from "/axios.config";

const ManagerNavBar = () => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const [user, setUser] = useState({ firstName: "Loading", lastName: "..." });

  /**
   * Sets the active menu item based on the given path.
   *
   * @function handleSetActive
   * @param {string} path - The path representing the menu item to set as active.
   * @returns {void} - Updates the active item in the state.
   */
  const handleSetActive = (path) => {
    setActiveItem(path);
  };

  /**
   * Fetches user data from the server and updates the state with the user information.
   * This effect runs once on component mount.
   *
   * @function useEffect
   * @returns {void} - Initiates a GET request to fetch the authenticated user's data.
   */
  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/auth",
          {
            withCredentials: true,
          }
        );
        if (response.data) {
          setUser(response.data);
        } else {
          console.error("Error fetching user data: Auth error");
        }
      } catch (err) {
        console.error("Error fetching user data:", err);
      }
    };

    fetchUser();
  }, []);

  return (
    <>
      <NavBar user={user} role="Manager">
        <Link
          to="/manager-manage-payment"
          onClick={() => handleSetActive("/manager-manage-payment")}
        >
          <NavbarItem
            text="Payment Management"
            active={activeItem === "/manager-manage-payment"}
          />
        </Link>

        <Link
          to="/manager-manage-order"
          onClick={() => handleSetActive("/manager-manage-order")}
        >
          <NavbarItem
            text="Order Management"
            active={activeItem === "/manager-manage-order"}
          />
        </Link>

        <Link
          to="/manager-order-tracking"
          onClick={() => handleSetActive("/manager-order-tracking")}
        >
          <NavbarItem
            text="Order Tracking"
            active={activeItem === "/manager-order-tracking"}
          />
        </Link>

        <Link
          to="/manager-notifications"
          onClick={() => handleSetActive("/manager-notifications")}
        >
          <NavbarItem
            text="Notifications"
            active={activeItem === "/manager-notifications"}
          />
        </Link>
        <Link
          to="/manager-analytics"
          onClick={() => handleSetActive("/manager-analytics")}
        >
          <NavbarItem
            text="Analytics"
            active={activeItem === "/manager-analytics"}
          />
        </Link>
        <Link
          to="/manager-customer-profile"
          onClick={() => handleSetActive("/manager-customer-profile")}
        >
          <NavbarItem
            text="Customer Profile"
            active={activeItem === "/manager-customer-profile"}
          />
        </Link>
      </NavBar>
    </>
  );
};

export default ManagerNavBar;
