import React, { useEffect, useState } from "react";
import {
  useLocation,
  Navigate,
  Route,
  createBrowserRouter,
  createRoutesFromElements,
  RouterProvider,
} from "react-router-dom";
import { Loader } from "lucide-react";

import MainOutlet from "./layouts/MainOutlet";
import AdminManageProducts from "./pages/AdminPages/AdminManageProducts";
import AdminManageUsers from "./pages/AdminPages/AdminManageUsers";
import AdminManageConfigurations from "./pages/AdminPages/AdminManageConfigurations";
import Page404 from "./pages/Page404";
import BaristaOrderTracking from "./pages/BaristaPages/BaristaOrderTracking";
import BaristaOrderManagement from "./pages/BaristaPages/BaristaOrderManagement";
import BaristaManualOrder from "./pages/BaristaPages/BaristaManualOrder";
import BaristaNotifications from "./pages/BaristaPages/BaristaNotifications";
import BaristaCustomerProfile from "./pages/BaristaPages/BaristaCustomerProfile";
import ManagerAnalytics from "./pages/ManagerPages/ManagerAnalytics";
import ManagerOrderTracking from "./pages/ManagerPages/ManagerOrderTracking";
import ManagerOrderManagement from "./pages/ManagerPages/ManagerOrderManagement";
import ManagerPaymentManagement from "./pages/ManagerPages/ManagerPaymentManagement";
import ManagerNotifications from "./pages/ManagerPages/ManagerNotifications";
import ManagerCustomerProfile from "./pages/ManagerPages/ManagerCustomerProfile";
import OrderHistory from "./pages/CustomerPages/OrderHistory";
import OrderDetails from "./components/CustomerComponents/OrderDetails";
import EditUserDetails from "./components/CustomerComponents/EditUserDetails";
import Login from "./components/Global/Login";
import LogoutPopup from "./components/Global/LogoutPopup";
import MenuPage from "./pages/CustomerPages/MenuPage";
import Registration from "./components/Global/Registration";
import ResetPassword from "./components/Global/ResetPassword";
import SuccessfulRegistration from "./components/Global/SuccessfulRegistration";
import AdminManageProductCategory from "./pages/AdminPages/AdminManageProductCategory";
import AdminManagePaymentOptions from "./pages/AdminPages/AdminManagePaymentOptions";
import RedirectingPage from "./pages/CustomerPages/RedirectingPage";
import BaristaManageProductAvailability from "./pages/BaristaPages/BaristaManageProductAvailability";
import TermsAndConditions from "./components/Global/TermsAndConditions";
import AdminManageLocations from "./pages/AdminPages/AdminManageLocations";
import Unauthorized from "./components/Global/Unauthorized";
import axios from "/axios.config"; // Import configured axios

const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const login = async (loginNumber, password) => {
    try {
      // Clear localStorage and cookies before attempting login
      localStorage.clear();
      document.cookie.split(";").forEach((cookie) => {
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie =
          name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
      });

      await axios.post("http://localhost:9000/api/kape-link/login", {
        loginNumber,
        password,
      });

      const response = await axios.get(
        "http://localhost:9000/api/kape-link/auth",
        {
          withCredentials: true, // Ensure credentials are included
        }
      );
      if (response.data) {
        setUser(response.data);
        setLoading(false);
        return "success"; // Login successful
      } else {
        setLoading(false);
        return "Authentication error. Please try again."; // Login failed
      }
    } catch (error) {
      const parsedResponse = JSON.parse(error.request.response);
      setLoading(false);
      return parsedResponse.error; // Login failed
    }
  };

  // useEffect(() => {
  //   if ("serviceWorker" in navigator) {
  //     window.addEventListener("load", async () => {
  //       try {
  //         const registration = await navigator.serviceWorker.register(
  //           "/serviceworker.js"
  //         );
  //         console.log(
  //           "Service Worker registered with scope:",
  //           registration.scope
  //         );
  //       } catch (error) {
  //         console.log("Service Worker registration failed:", error);
  //       }
  //     });
  //   }
  // }, []);

  const screenWidth = window.innerWidth;

  useEffect(() => {
    // Initialize the app by checking user authentication status
    const checkAuthStatus = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/auth",
          {
            withCredentials: true,
          }
        );
        if (response.data) {
          setUser(response.data);
        }
      } catch (error) {
        console.log("Error checking auth status:", error);
      } finally {
        setLoading(false);
      }
    };
    checkAuthStatus();
  }, []);

  const SwitchRoute = () => {
    if (!user) {
      return <Navigate to="/login" />;
    }

    switch (user.role) {
      case "admin":
        return <Navigate to="/manage-products" />;
      case "customer":
        return <Navigate to="/redirecting" />;
      case "barista":
        const baristaRoute =
          screenWidth > 640 ? "/barista-manual-order" : "/barista-manage-order";
        return <Navigate to={baristaRoute} />;
      case "manager":
        return <Navigate to="/manager-manage-payment" />;
      default:
        return <Navigate to="/login" />;
    }
  };

  const PrivateRoute = ({ allowedRoles, element }) => {
    const location = useLocation();
    if (loading) {
      return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
          <Loader className="animate-spin" size={40} />
        </div>
      );
    }

    if (user && user.status === "temporary" && location.pathname !== "/redirecting") {
      return <Navigate to="/redirecting
      " />;
    }

    if (!user || !allowedRoles.includes(user.role)) {
      return <Navigate to="/unauthorized" />;
    }
    return element;
  };

  const handleUpdateProfile = (updatedFields) => {
    setUser((prevProfile) => ({
      ...prevProfile,
      ...updatedFields,
    }));
  };

  const router = createBrowserRouter(
    createRoutesFromElements(
      <Route path="/" element={<MainOutlet />}>
        <Route index element={<SwitchRoute />} />
        <Route path="/login-switch" element={<SwitchRoute />} />

        {/* Admin Pages (Protected) */}
        <Route
          path="/manage-products"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManageProducts />}
            />
          }
        />
        <Route
          path="/manage-users"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManageUsers />}
            />
          }
        />
        <Route
          path="/manage-configurations"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManageConfigurations />}
            />
          }
        />
        <Route
          path="/manage-product-category"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManageProductCategory />}
            />
          }
        />
        <Route
          path="/manage-payment-options"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManagePaymentOptions />}
            />
          }
        />
        <Route
          path="/manage-locations"
          element={
            <PrivateRoute
              allowedRoles={["admin"]}
              element={<AdminManageLocations />}
            />
          }
        />

        {/* Barista Pages (Protected) */}
        <Route
          path="/barista-manual-order"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaManualOrder />}
            />
          }
        />
        <Route
          path="/barista-manage-order"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaOrderManagement />}
            />
          }
        />
        <Route
          path="/barista-order-tracking"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaOrderTracking />}
            />
          }
        />
        <Route
          path="/barista-product-availability"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaManageProductAvailability />}
            />
          }
        />
        <Route
          path="/barista-notifications"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaNotifications />}
            />
          }
        />
        <Route
          path="/barista-customer-profile"
          element={
            <PrivateRoute
              allowedRoles={["barista"]}
              element={<BaristaCustomerProfile />}
            />
          }
        />
        {/* Manager Pages (Protected) */}
        <Route
          path="/manager-analytics"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerAnalytics />}
            />
          }
        />
        <Route
          path="/manager-manage-payment"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerPaymentManagement />}
            />
          }
        />
        <Route
          path="/manager-manage-order"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerOrderManagement />}
            />
          }
        />
        <Route
          path="/manager-order-tracking"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerOrderTracking />}
            />
          }
        />
        <Route
          path="/manager-notifications"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerNotifications />}
            />
          }
        />
        <Route
          path="/manager-customer-profile"
          element={
            <PrivateRoute
              allowedRoles={["manager"]}
              element={<ManagerCustomerProfile />}
            />
          }
        />

        {/* Customer Pages (Protected) */}
        <Route
          path="/redirecting"
          element={
            <PrivateRoute
              allowedRoles={["customer"]}
              element={<RedirectingPage user={user} />}
            />
          }
        />
        <Route
          path="/menu"
          element={
            <PrivateRoute
              allowedRoles={["customer"]}
              element={<MenuPage user={user} />}
            />
          }
        />
        <Route
          path="/order-history"
          element={
            <PrivateRoute
              allowedRoles={["customer"]}
              element={<OrderHistory user={user} />}
            />
          }
        />
        <Route
          path="/order/:orderId"
          element={
            <PrivateRoute
              allowedRoles={["customer"]}
              element={<OrderDetails user={user} />}
            />
          }
        />
        <Route
          path="/profile-settings"
          element={
            <PrivateRoute
              allowedRoles={["customer"]}
              element={
                <EditUserDetails
                  user={user}
                  onUpdateProfile={handleUpdateProfile}
                />
              }
            />
          }
        />

        {/* Public Pages */}
        <Route path="/login" element={<Login login={login} />} />
        <Route path="/logout" element={<LogoutPopup user={user} />} />
        <Route path="/registration" element={<Registration />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route
          path="/successful-registration"
          element={<SuccessfulRegistration />}
        />
        <Route path="/terms-and-conditions" element={<TermsAndConditions />} />

        {/* Error Pages */}
        <Route path="/*" element={<Page404 />} />
        <Route path="/unauthorized" element={<Unauthorized />} />
      </Route>
    )
  );

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-20">
        <Loader className="animate-spin" size={40} />
      </div>
    );
  }

  return <RouterProvider router={router} />;
};

export default App;
