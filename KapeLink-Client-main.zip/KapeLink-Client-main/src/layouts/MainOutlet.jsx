import { Outlet } from "react-router-dom";

const MainOutlet = () => {
  return (
    <>
      <Outlet />
    </>
  );
};

export default MainOutlet;
