import React, { useState, useEffect } from "react";
import BaristaSideBar from "../../components/BaristaComponents/BaristaSideBar";
import SearchBar from "../../components/Global/SearchBar";
import TabFilters from "../../components/Global/TabFilters";
import ManualOrderProducts from "../../components/BaristaComponents/ManualOrderProducts";
import ManualOrderDetails from "../../components/BaristaComponents/ManualOrderDetails";
import BaristaNavBar from "../../components/BaristaComponents/BaristaNavBar";
import { io } from "socket.io-client";
import axios from "axios";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

const BaristaManualOrder = () => {
  const [tabNames, setTabNames] = useState([]);
  const [activeTab, setActiveTab] = useState("Beverages");
  const [searchQuery, setSearchQuery] = useState("");
  const [orderSummaryData, setOrderSummaryData] = useState(
    JSON.parse(localStorage.getItem("orderSummaryData")) || []
  );
  const [rowSelections, setRowSelections] = useState([]);

  /**
   * Fetches category data from the server, filters for categories marked as 'show',
   * and sets the category names for the UI.
   *
   * @async
   * @function fetchCategoriesData
   * @returns {Promise<void>} - Resolves when the category data is fetched and tab names are set.
   * @throws Will throw an error if the fetch request fails.
   */
  const fetchCategoriesData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-categories"
      );
      const categoriesData = response.data.mainCategories;

      const names = categoriesData
        .filter((category) => category.show)
        .map((category) => category.name);

      setTabNames(names);
    } catch (error) {
      console.error("Error fetching orders data:", error);
    }
  };

  /**
   * Synchronizes order summary data with local storage whenever
   * `orderSummaryData` changes.
   *
   * @function useEffect
   * @param {Array} [orderSummaryData] - Dependency array monitoring `orderSummaryData`.
   * @returns {void} - This effect has no return.
   */
  useEffect(() => {
    localStorage.setItem("orderSummaryData", JSON.stringify(orderSummaryData));
  }, [orderSummaryData]);

  /**
   * Initializes category data fetch, sets up WebSocket connections for
   * real-time updates, and cleans up on component unmount.
   *
   * @function useEffect
   * @returns {void} - This effect has no return.
   */
  useEffect(() => {
    fetchCategoriesData();

    const socket = io("http://localhost:9000");

    socket.on("updatedCategory", () => {
      fetchCategoriesData();
    });

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <BaristaSideBar />
      </div>
      <div className="sm:hidden w-full">
        <BaristaNavBar />
      </div>

      <div className=" mt-10 mx-5 2xl:mt-10 2xl:mx-10 max-[640px]:m-0">
        <div className="flex mb-3">
          <h1 className="text-3xl font-semibold">In-Store Orders</h1>
        </div>
        <div className="flex items-center">
          <div className="text-lg 2xl:text-xl">
            <TabFilters
              tabNames={tabNames}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
          </div>
          <div className="flex-grow text-right lg:mr-3">
            <div className="inline-flex items-center space-x-4">
              <div className="text-right">
                <SearchBar
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex lg:mr-3">
          <div className="w-auto pr-1 2xl:w-3/4 2xl:pr-5">
            <ManualOrderProducts
              activeTab={activeTab}
              searchQuery={searchQuery}
              setOrderSummaryData={setOrderSummaryData}
              rowSelections={rowSelections}
              setRowSelections={setRowSelections}
            />
          </div>
          <div className="w-auto 2xl:min-w-fit 2xl:w-1/4">
            <ManualOrderDetails
              orderSummaryData={orderSummaryData}
              setOrderSummaryData={setOrderSummaryData}
              setRowSelections={setRowSelections}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BaristaManualOrder;
