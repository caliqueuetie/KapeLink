import React, { useState, useEffect } from "react";
import BaristaSideBar from "../../components/BaristaComponents/BaristaSideBar";
import BaristaNavBar from "../../components/BaristaComponents/BaristaNavBar";
import TabFilters from "../../components/Global/TabFilters";
import SearchBar from "../../components/Global/SearchBar";
import ProductAvailabilityTable from "../../components/BaristaComponents/ProductAvailabilityTable";
import { io } from "socket.io-client";
import HeaderFilterTooltip from "../../components/Global/HeaderFilterTooltip";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";
import axios from "axios";

/**
 * BaristaManageProductAvailability component allows baristas to manage the availability of products.
 * It displays a table of products, filtered by categories and availability status, with search functionality.
 *
 * @function BaristaManageProductAvailability
 * @returns {JSX.Element} - Renders the product availability management interface.
 */
const BaristaManageProductAvailability = () => {
  const tabNames = ["All", "Available", "Hidden"];
  const [activeTab, setActiveTab] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [availableProducts, setAvailableProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedSubcategory, setSelectedSubcategory] = useState("");
  const [activeFilter, setActiveFilter] = useState({});

  /**
   * useEffect hook to establish a socket connection and listen for expired notifications.
   * When an expired notification is received, the HandlePushSubscription function is triggered.
   * The socket connection is cleaned up when the component is unmounted.
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * useEffect hook to fetch product data from the server.
   * This hook runs once when the component is mounted and fetches the product list and categories.
   *
   * @async
   * @function fetchData
   * @returns {void}
   */
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/all-products"
        );
        setAvailableProducts(response.data);

        const uniqueCategories = [
          ...new Set(response.data.map((item) => item.category)),
        ];
        setCategories(uniqueCategories);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <BaristaSideBar />
      </div>
      <div className="sm:hidden w-full">
        <BaristaNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-12 max-[640px]:m-0">
        <div>
          <div className="flex flex-col justify-center mt-2 mb-5 ml-4 max-[640px]:mb-4 max-[640px]:ml-0">
            <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap mr-5">
              Manage Product Availability
            </h1>

            <div className="md:flex md:items-center mt-4 max-[640px]:mt-0">
              <div>
                <div className="inline-flex items-center space-x-3 max-[640px]:w-full max-[640px]:mt-2 max-[640px]:mb-4">
                  <SearchBar
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                  />
                </div>
              </div>

              <div className="flex sm:space-x-5">
                <TabFilters
                  tabNames={tabNames}
                  activeTab={activeTab}
                  setActiveTab={setActiveTab}
                />
                <div className="max-[640px]:ml-auto">
                  <HeaderFilterTooltip />
                </div>
              </div>
            </div>
          </div>

          <ProductAvailabilityTable
            activeTab={activeTab}
            searchQuery={searchQuery}
            activeFilter={activeFilter}
            categories={categories}
            setSelectedSubcategory={setSelectedSubcategory}
          />
        </div>
      </div>
    </div>
  );
};

export default BaristaManageProductAvailability;
