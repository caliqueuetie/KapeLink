import React, { useState, useEffect } from "react";
import BaristaSideBar from "../../components/BaristaComponents/BaristaSideBar";
import NotificationPane from "../../components/Global/NotificationPane";
import BaristaNavBar from "../../components/BaristaComponents/BaristaNavBar";
import { io } from "socket.io-client";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

const BaristaNotifications = () => {
  const receivers = "all"; // You can modify this to be dynamic as needed
  const roles = ["barista"]; // Specific roles can be passed based on the user or context

  /**
   * Establishes a socket connection and listens for the "expiredNotification" event.
   * When an "expiredNotification" event is received, the `HandlePushSubscription` function is triggered.
   *
   * The socket connection is established when the component mounts and disconnected when the component unmounts.
   *
   * @function useEffect
   * @returns {void} - Initializes the socket connection and cleans it up on unmount.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <BaristaSideBar />
      </div>
      <div className="sm:hidden w-full">
        <BaristaNavBar />
      </div>

      <div className="flex justify-center w-full h-full">
        <div className="flex flex-col sm:mt-20 mt-5">
          <h1 className="text-3xl font-semibold max-[640px]:text-xl mb-5">
            Notifications
          </h1>
          <NotificationPane receivers={receivers} roles={roles} />
        </div>
      </div>
    </div>
  );
};

export default BaristaNotifications;
