import { Link } from "react-router-dom";
import { FaExclamationTriangle } from "react-icons/fa";

/**
 * Page404 component displays a "404 Not Found" error message.
 * It informs users that the requested page does not exist and provides a button to return to a login switch page.
 * 
 * @function Page404
 * @returns {JSX.Element} - Renders the 404 error page with navigation options.
 */
const Page404 = () => {
  return (
    <section className="flex flex-col justify-center items-center h-96 mt-24">
      <FaExclamationTriangle className="text-yellow-400 text-6xl mb-4" />
      <h1 className="text-4xl sm:text-6xl font-bold mb-4">404 Not Found</h1>
      <p className="text-xl mb-5">This page does not exist</p>
      <Link
        to="/login-switch"
        className="text-white rounded-md px-3 py-2 mt-4 custom-button-color"
      >
        Go Back
      </Link>
    </section>
  );
};

export default Page404;
