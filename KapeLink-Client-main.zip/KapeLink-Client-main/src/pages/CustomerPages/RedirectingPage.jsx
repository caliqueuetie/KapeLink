import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import logo from "../../images/KapeLinkNameLogo.png";

/**
 * Component that displays a redirecting page.
 *
 * - Displays a message informing the user that they are being redirected.
 * - Optionally, can show user-specific content based on the `user` prop.
 * - Can be used as a loading or intermediary screen while redirecting users to another page.
 *
 * @component RedirectingPage
 * @param {Object} user - The user object, which contains user-specific information (optional).
 */
const RedirectingPage = ({ user }) => {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [userStatus, setUserStatus] = useState("");
  const navigate = useNavigate();

  // Create an array of refs to manage focus on each input
  const inputRefs = useRef([]);

  /**
   * Effect that fetches the user status when the component mounts or when `user.userId` changes.
   *
   * - Calls the `fetchUserStatus()` function to fetch the user's status from the API.
   * - Sets the user's status in the state after a successful response.
   * - Logs an error message if the API request fails.
   *
   * @function useEffect
   * @dependency [user.userId] - Triggers the effect whenever the `user.userId` changes.
   */
  useEffect(() => {
    const fetchUserStatus = async () => {
      try {
        const response = await axios.get(
          `http://localhost:9000/api/kape-link/get-user/${user.userId}`,
          {
            withCredentials: true,
          }
        );
        setUserStatus(response.data.status);
      } catch (err) {
        console.error("Failed to fetch user status", err);
      }
    };

    fetchUserStatus();
  }, [user.userId]);

  /**
   * Effect that redirects the user to the "/menu" page if the user's status is not "temporary" or "restricted".
   *
   * - Checks the `userStatus` and redirects to the "/menu" page if the status is neither "temporary" nor "restricted".
   * - The effect triggers whenever the `userStatus` or `navigate` dependencies change.
   *
   * @function useEffect
   * @dependency [userStatus, navigate] - Runs whenever the `userStatus` or `navigate` values change.
   */
  useEffect(() => {
    if (
      userStatus &&
      userStatus !== "temporary" &&
      userStatus !== "restricted"
    ) {
      navigate("/menu");
    }
  }, [userStatus, navigate]);

  /**
   * Handles OTP input changes and updates the OTP array.
   *
   * - Validates the entered value to ensure it is a number.
   * - Updates the OTP array at the specified index with the new value.
   * - Automatically focuses the next input field if a digit is entered, except for the last input.
   *
   * @function handleOtpChange
   * @param {Object} e - The event object from the input change.
   * @param {number} index - The index of the OTP input field being edited.
   * @dependency otp - Uses the current OTP array state to update the value.
   */
  const handleOtpChange = (e, index) => {
    const { value } = e.target;
    if (/^\d*$/.test(value)) {
      const newOtp = [...otp];
      newOtp[index] = value;
      setOtp(newOtp);

      // Automatically move to the next input if a digit is entered
      if (value && index < 5) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  /**
   * Handles keydown events for OTP input fields, specifically managing the backspace key.
   *
   * - If the backspace key is pressed and the current input field is empty, focus is moved to the previous input field.
   *
   * @function handleKeyDown
   * @param {Object} e - The event object from the keydown event.
   * @param {number} index - The index of the OTP input field.
   * @dependency otp - Relies on the current OTP array state to check if the field is empty.
   */
  const handleKeyDown = (e, index) => {
    // Handle backspace and move focus to the previous input
    if (e.key === "Backspace" && index > 0 && !otp[index]) {
      inputRefs.current[index - 1].focus();
    }
  };

  /**
   * Handles OTP submission and verification process.
   *
   * - Joins the OTP digits into a single string and checks if the length is 6 digits.
   * - Sends the entered OTP along with the user ID to the server for verification.
   * - If the OTP is valid, updates the user's status, shows a success message, and initiates a countdown before redirecting to the login page.
   * - If the OTP is invalid, an error message is shown.
   * - Handles loading and error states throughout the process.
   *
   * @function handleOtpSubmit
   * @dependency otp - The current array of OTP digits entered by the user.
   * @dependency user - The user object, particularly the user ID, required for OTP verification.
   * @dependency navigate - Used to redirect the user after successful OTP verification.
   */
  const handleOtpSubmit = async () => {
    const enteredOtp = otp.join("");
    if (enteredOtp.length !== 6) {
      setError("OTP must be 6 digits");
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post("/otp-verify", {
        userId: user.userId,
        enteredOtp: enteredOtp,
      });

      if (response.data.success) {
        user.status = "active";
        setError("");
        let countdown = 5; // 5 seconds
        setSuccessMessage(
          `Congrats! Your Account is now Verified. Redirecting in ${countdown} seconds...`
        );

        const interval = setInterval(() => {
          countdown -= 1;
          setSuccessMessage(
            `Congrats! Your Account is now Verified. Redirecting in ${countdown} seconds...`
          );

          if (countdown === 0) {
            clearInterval(interval);
            navigate("/login-switch");
          }
        }, 1000);
      } else {
        setError("Invalid OTP. Please try again.");
      }
    } catch (err) {
      const parsedResponse = JSON.parse(err.request.response);
      setLoading(false);
      setError(parsedResponse.error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Handles the user logout process.
   *
   * - Sends a logout request to the server.
   * - Clears localStorage and removes cookies to log the user out.
   * - Redirects the user to the login page after a successful logout.
   * - Handles loading and error states throughout the process.
   *
   * @function handleLogout
   * @dependency navigate - Used to redirect the user to the login page after logout.
   */
  const handleLogout = async () => {
    setLoading(true);

    try {
      await axios.post("/logout");
      localStorage.clear();
      document.cookie.split(";").forEach((cookie) => {
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
        document.cookie =
          name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
      });
      navigate("/login");
    } catch (error) {
      console.error("Logout failed", error);
      setError("Failed to log out. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (userStatus === "temporary") {
    return (
      <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
        <div className="w-full max-w-md p-7 sm:bg-white sm:shadow-md rounded-lg">
          <div className="mb-6 text-center">
            <img src={logo} alt="Logo" className="w-2/6 mx-auto my-3" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold mb-4 text-center">
            Verify Your Account
          </h2>
          <p className="text-sm sm:text-base text-gray-600 mb-4 text-center flex-wrap mx-5">
            Please enter the OTP sent to your email to verify your account.
          </p>
          <div className="flex space-x-2 justify-center">
            {otp.map((digit, index) => (
              <input
                key={index}
                type="text"
                maxLength="1"
                value={digit}
                onChange={(e) => handleOtpChange(e, index)}
                onKeyDown={(e) => handleKeyDown(e, index)}
                ref={(el) => (inputRefs.current[index] = el)}
                className="py-4 sm:py-5 border border-gray-300 rounded-md w-10 sm:w-12 text-center"
              />
            ))}
          </div>
          {error && <p className="text-red-500 mt-2">{error}</p>}

          {successMessage && (
            <p className="success-message">{successMessage}</p>
          )}

          <div className="flex justify-center">
            <button
              onClick={handleOtpSubmit}
              disabled={loading}
              className="mt-5 flex justify-center px-6 py-2 text-white font-bold rounded-md custom-button-color"
            >
              {loading ? "Verifying..." : "Submit"}
            </button>
          </div>

          <div className="flex justify-center">
            <button
              onClick={handleLogout}
              className="mt-2 flex justify-center px-6 py-2 font-medium rounded-md text-color-custom hover:text-custom-text-hover duration-300"
            >
              Log Out
            </button>
          </div>
        </div>
      </div>
    );
  } else if (userStatus === "restricted") {
    return (
      <div className="flex items-center justify-center min-h-screen sm:bg-gray-100">
        <div className="w-full max-w-md p-7 sm:bg-white sm:shadow-md rounded-lg">
          <div className="mb-6 text-center">
            <img src={logo} alt="Logo" className="w-2/6 mx-auto my-3" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold mb-4 text-center">
            Restricted Account
          </h2>
          <p className="text-sm sm:text-base text-gray-600 mb-4 text-center flex-wrap mx-5">
            Your account has been restricted for violating our rules.
          </p>
          <div className="flex justify-center">
            <button
              onClick={handleLogout}
              className="mt-2  px-6 py-2 font-medium rounded-md text-color-custom hover:text-custom-text-hover duration-300"
            >
              Log Out
            </button>
          </div>
        </div>
      </div>
    );
  }
};

export default RedirectingPage;
