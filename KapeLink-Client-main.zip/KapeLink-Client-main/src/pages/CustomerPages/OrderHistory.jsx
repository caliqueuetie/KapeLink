import React, { useState, useEffect } from "react";
import OrderHistoryNavBar from "../../components/CustomerComponents/OrderHistoryNavBar";
import Header from "../../components/CustomerComponents/Header";
import Footer from "../../components/CustomerComponents/Footer";
import OrderHistoryCard from "../../components/CustomerComponents/OrderHistoryCard";
import axios from "axios";
import SearchAndFilter from "../../components/CustomerComponents/SearchAndFilter";
import { io } from "socket.io-client";
import { Player } from "@lottiefiles/react-lottie-player";
import loader from "../../assets/manualPlaceOrder.json";
import OfflinePage from "../../pages/OfflinePage";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

/**
 * Displays the user's order history.
 *
 * - Fetches the user's order data from the server.
 * - Renders a list of orders with the option to view details.
 * - Handles loading, error, and empty states for the order history.
 *
 * @function OrderHistory
 * @param {Object} user - The current user's information.
 * @dependency user - The user object is used to fetch the order history.
 */
const OrderHistory = ({ user }) => {
  const [orders, setOrders] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [loading, setLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(false);

  /**
   * Fetches and sets the user's order data.
   *
   * - Sends a request to the server to get the user's orders.
   * - Sorts the orders by `orderId` in descending order.
   * - Sets an offline state if the content type is HTML.
   * - Handles any errors that occur during the fetch process.
   *
   * @function fetchOrders
   * @dependency [] - Runs once when the component is mounted to fetch the user's orders.
   */
  const fetchOrders = async () => {
    try {
      const ordersResponse = await axios.get(
        "http://localhost:9000/api/kape-link/get-order-of-customer"
      );

      if (ordersResponse.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        const sortedOrders = ordersResponse.data.sort(
          (a, b) => b.orderId - a.orderId
        );
        setOrders(sortedOrders);
      }
    } catch (error) {
      console.error("Failed to fetch data from the server:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Effect that fetches user orders and listens for real-time updates.
   *
   * - Calls `fetchOrders()` to fetch the user's orders when the component mounts.
   * - Sets up a WebSocket connection to listen for "userOrders" and "expiredNotification" events.
   *   - On "userOrders" event, it re-fetches the orders.
   *   - On "expiredNotification" event, it calls `HandlePushSubscription()`.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    fetchOrders();
    const socket = io("http://localhost:9000");
    socket.on("userOrders", () => {
      fetchOrders();
    });

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Effect that fetches payment methods from the server.
   *
   * - Calls `fetchPaymentMethods()` to retrieve payment methods when the component mounts.
   * - Sets the fetched payment methods to the `paymentMethods` state.
   * - Logs an error if the request fails.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    const fetchPaymentMethods = async () => {
      try {
        const paymentResponse = await axios.get(
          "http://localhost:9000/api/kape-link/get-payment-methods"
        );
        setPaymentMethods(paymentResponse.data);
      } catch (error) {
        console.error("Failed to fetch data from the server:", error);
      }
    };

    fetchPaymentMethods();
  }, []);

  /**
   * Filters orders based on the search query and status filter.
   *
   * - Converts the `searchQuery` to lowercase and checks if it matches any part of the `orderId`, `orderOption`, `tracking.orderStatus`, `verificationStatus`, or payment method name.
   * - If `statusFilter` is set and not "All", it checks if the order's status matches the filter.
   * - Filters orders that match the search query and status, then sorts them by `orderId` in descending order.
   *
   * @function filterOrders
   * @dependency searchQuery - Triggers the filtering process whenever the search query changes.
   * @dependency statusFilter - Filters orders based on the selected status.
   */
  const filterOrders = () => {
    const lowerCaseSearchQuery = searchQuery.toLowerCase();

    const filtered = orders
      .filter((order) => {
        const orderIdStr = order.orderId
          ? String(order.orderId).toLowerCase()
          : "";
        const orderOption = order.orderOption
          ? String(order.orderOption).toLowerCase()
          : "";

        // Check if any tracking status matches the search query
        const trackingMatches = order.tracking?.some((trackingItem) =>
          trackingItem.orderStatus.toLowerCase().includes(lowerCaseSearchQuery)
        );

        // Use verificationStatus if tracking is empty
        const verificationStatus = order.verificationStatus
          ? order.verificationStatus.toLowerCase()
          : "";

        // Get payment method name from paymentMethods array
        const paymentMethod = paymentMethods.find(
          (method) => method.id === order.paymentMethodId
        );
        const paymentMethodName = paymentMethod
          ? paymentMethod.name.toLowerCase()
          : "";

        const matchesSearch =
          orderIdStr.includes(lowerCaseSearchQuery) ||
          orderOption.includes(lowerCaseSearchQuery) ||
          trackingMatches ||
          verificationStatus.includes(lowerCaseSearchQuery) ||
          paymentMethodName.includes(lowerCaseSearchQuery);

        const matchesStatus =
          statusFilter && statusFilter !== "All"
            ? (order.tracking?.length > 0 &&
                order.tracking[
                  order.tracking.length - 1
                ].orderStatus.toLowerCase() === statusFilter.toLowerCase()) ||
              verificationStatus === statusFilter.toLowerCase()
            : true;

        return matchesSearch && matchesStatus;
      })
      .sort((a, b) => b.orderId - a.orderId);
    setFilteredOrders(filtered);
  };

  /**
   * Effect that filters orders based on the search query, status filter, and payment methods.
   *
   * - Calls the `filterOrders()` function whenever the `orders`, `searchQuery`, `statusFilter`, or `paymentMethods` change.
   * - If the app is offline (`isOffline` is true), it renders the `OfflinePage` component.
   *
   * @function useEffect
   * @dependency orders - Triggers the filtering process when the orders change.
   * @dependency searchQuery - Triggers the filtering process when the search query changes.
   * @dependency statusFilter - Triggers the filtering process when the status filter changes.
   * @dependency paymentMethods - Triggers the filtering process when the available payment methods change.
   */
  useEffect(() => {
    filterOrders();
  }, [orders, searchQuery, statusFilter, paymentMethods]);

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} />
      <OrderHistoryNavBar setFilter={setStatusFilter} />

      {/* Main content wrapper, flex-grow makes sure this section grows to fill space */}
      <div className="flex-grow">
        {/* Loading indicator */}
        {loading ? (
          <div className="flex justify-center items-center h-screen">
            <Player
              autoplay
              loop
              src={loader}
              style={{ height: "200px", width: "200px" }}
            />
          </div>
        ) : (
          <div className="container mx-auto px-5 sm:px-30 pt-5 pb-10 overflow-y-auto">
            {/* Search and Filter Component */}
            <div className="flex justify-center sm:justify-start mb-8 px-4 sm:px-0">
              <SearchAndFilter
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                placeholderText="Search Orders..."
              />
            </div>

            {/* Display filtered orders in a 3-column grid */}
            {filteredOrders.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredOrders.map((order) => (
                  <OrderHistoryCard
                    key={order.orderId}
                    order={order}
                    paymentOptions={paymentMethods}
                  />
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500">
                No orders found for the selected filter.
              </p>
            )}
          </div>
        )}
      </div>

      {/* Footer stays at the bottom */}
      <Footer />
    </div>
  );
};

export default OrderHistory;
