import React, { useState, useEffect } from "react";
import axios from "/axios.config"; // Import configured axios with credentials
import MenuProducts from "../../components/CustomerComponents/MenuProducts";
import MenuCategories from "../../components/CustomerComponents/MenuCategories";
import Header from "../../components/CustomerComponents/Header";
import Footer from "../../components/CustomerComponents/Footer";
import Cart from "../../components/CustomerComponents/Cart";
import OrderSummary from "../../components/CustomerComponents/OrderSummary";
import ReviewPayment from "../../components/CustomerComponents/ReviewPayment";
import { Loader, TriangleAlert } from "lucide-react"; // Import a loading icon
import { ShoppingBag } from "lucide-react";
import SearchAndFilter from "../../components/CustomerComponents/SearchAndFilter";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";
import { io } from "socket.io-client";
import { openDB } from "idb";
import OfflinePage from "../OfflinePage";
import background from "../../images/MenuCategoriesBackground.png";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

/**
 * MenuPage component that displays the menu to the user.
 *
 * - Accepts `user` as a prop to customize the page's behavior based on the user's information.
 * - The component can include logic for rendering the menu, handling user interactions, etc.
 *
 * @function MenuPage
 * @param {Object} user - The user object containing user information.
 */
const MenuPage = ({ user }) => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrderSummaryOpen, setIsOrderSummaryOpen] = useState(false);
  const [orderSummaryData, setOrderSummaryData] = useState(null);
  const [isReviewPaymentOpen, setIsReviewPaymentOpen] = useState(false);
  const [products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [menucategories, setMenucategories] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [chatbotScripts, setChatbotScripts] = useState(null);
  const [loadingChatbot, setLoadingChatbot] = useState(true);
  const [chatbotError, setChatbotError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isAddItemToCartOpen, setAddItemToCartOpen] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");
  const [isOffline, setIsOffline] = useState(false);

  const [cartItems, setCartItems] = useState([]);

  /**
   * Creates a IndexedDB instance to store cart items for a specific user.
   *
   * - Initializes a database named `cart_{user.userId}` where `{user.userId}` is the dynamic user ID.
   * - Creates an object store `cartItems` with a unique key `prodId`, which is assumed to be a unique identifier for each cart item.
   *
   * @function dbPromise
   * @param {string} user.userId - The unique user ID used to name the IndexedDB.
   * @returns {Promise} - Resolves to the IndexedDB database instance.
   */
  const dbPromise = openDB(`cart_${user.userId}`, 1, {
    upgrade(db) {
      db.createObjectStore("cartItems", { keyPath: "prodId" }); // Assuming each item has a unique 'id'
    },
  });

  /**
   * Adds a cart item to the IndexedDB.
   *
   * - Waits for the database instance to be available.
   * - Adds the provided `item` to the `cartItems` object store in the database using its `prodId` as the unique key.
   *
   * @function addItemToDB
   * @param {Object} item - The cart item to be added to the database.
   * @param {string} item.prodId - The unique product ID of the item being added to the cart.
   * @returns {Promise} - Resolves when the item has been successfully added to the database.
   */
  const addItemToDB = async (item) => {
    const db = await dbPromise;
    await db.put("cartItems", item);
  };

  /**
   * Retrieves all cart items from the IndexedDB.
   *
   * - Waits for the database instance to be available.
   * - Fetches all the items stored in the `cartItems` object store.
   *
   * @function getItemsFromDB
   * @returns {Promise<Array>} - Resolves with an array of all cart items stored in the database.
   */
  const getItemsFromDB = async () => {
    const db = await dbPromise;
    return db.getAll("cartItems");
  };

  /**
   * Removes an item from the IndexedDB based on its product ID.
   *
   * - Waits for the database instance to be available.
   * - Deletes the item with the specified product ID from the `cartItems` object store.
   *
   * @function removeItemFromDB
   * @param {string} prodId - The unique product ID of the item to be removed from the database.
   * @returns {Promise<void>} - Resolves when the item has been successfully deleted.
   */
  const removeItemFromDB = async (prodId) => {
    const db = await dbPromise;
    await db.delete("cartItems", prodId);
  };

  /**
   * Clears all items from the `cartItems` object store in IndexedDB.
   *
   * - Waits for the database instance to be available.
   * - Clears all entries from the `cartItems` object store.
   *
   * @function clearDB
   * @returns {Promise<void>} - Resolves when all items have been successfully cleared.
   */
  const clearDB = async () => {
    const db = await dbPromise;
    await db.clear("cartItems"); // Clear the 'cartItems' object store
  };

  /**
   * Clears all items from the `cartItems` object store in IndexedDB.
   *
   * - Waits for the database instance to be available.
   * - Clears all entries from the `cartItems` object store.
   *
   * @function clearDB
   * @returns {Promise<void>} - Resolves when all items have been successfully cleared.
   */
  useEffect(() => {
    const fetchItems = async () => {
      const storedItems = await getItemsFromDB();
      setCartItems(storedItems);
    };
    fetchItems();
  }, []);

  useEffect(() => {}, [isCartOpen]);

  /**
   * Function that fetches product data from the server.
   *
   * - Sends a GET request to retrieve product data from the server.
   * - If the server returns an HTML response (indicating offline status), it sets `isOffline` to true.
   * - If the request is successful, it sets the `products` state with the fetched data.
   * - If an error occurs, it sets `products` to an empty array.
   * - Sets `loading` to true while fetching and to false when the operation is complete.
   *
   * @function fetchProductsData
   */
  const fetchProductsData = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-products"
      );

      if (response.headers["content-type"] === "text/html") {
        setIsOffline(true);
      } else {
        setProducts(response.data);
      }
    } catch (error) {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Effect that fetches product data and listens for updates via WebSocket.
   *
   * - Initially calls `fetchProductsData()` to fetch the product data.
   * - Sets up a WebSocket connection to listen for "products" events, triggering a re-fetch of the product data when an event is received.
   * - Sets up a listener for "expiredNotification" events to handle push subscriptions.
   * - Cleans up the WebSocket connection when the component unmounts.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    fetchProductsData();
    const socket = io("http://localhost:9000");
    socket.on("products", () => {
      fetchProductsData();
    });

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Effect that fetches chatbot data and updates state.
   *
   * - Initially calls `fetchChatbotData()` to retrieve the chatbot credentials from the API.
   * - If successful, sets the fetched data into the `chatbotScripts` state.
   * - In case of an error, sets the `chatbotError` state to `true` and logs the error.
   * - Updates the loading state (`setLoadingChatbot`) once the fetch operation is complete.
   *
   * @function useEffect
   * @dependency [] - Runs only once when the component is mounted.
   */
  useEffect(() => {
    const fetchChatbotData = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/credentials"
        ); // Adjust the endpoint as necessary

        setChatbotScripts(response.data); // Assuming the credentials are in the first item of the array
      } catch (error) {
        setChatbotError(true);
        console.error("Error fetching chatbot data:", error);
      } finally {
        setLoadingChatbot(false);
      }
    };

    fetchChatbotData();
  }, []);

  /**
   * Effect that dynamically loads chatbot scripts when the chatbot scripts are available.
   *
   * - Creates two `<script>` elements with `src` set to the URLs for `script1` and `script2` retrieved from `chatbotScripts`.
   * - Appends these script elements to the body of the document.
   * - Sets up error handling for both scripts by setting `chatbotError` to `true` and logging the failure in case of errors.
   * - Cleans up by removing the scripts from the body when the component unmounts or when `chatbotScripts` changes.
   *
   * @function useEffect
   * @dependency [chatbotScripts] - Runs whenever `chatbotScripts` changes.
   */
  useEffect(() => {
    if (chatbotScripts) {
      try {
        const script1 = document.createElement("script");
        script1.src = chatbotScripts.chatbot.script1;
        script1.async = true;
        script1.onerror = () => {
          setChatbotError(true);
          console.error("Failed to load script1:", script1.src);
        };
        document.body.appendChild(script1);

        const script2 = document.createElement("script");
        script2.src = chatbotScripts.chatbot.script2;
        script2.defer = true;
        script2.onerror = () => {
          setChatbotError(true);
          console.error("Failed to load script2:", script2.src);
        };
        document.body.appendChild(script2);

        return () => {
          document.body.removeChild(script1);
          document.body.removeChild(script2);
        };
      } catch (err) {
        setChatbotError(true);
      }
    }
  }, [chatbotScripts]);

  /**
   * Effect that updates the `menucategories` state based on the selected category and the available products.
   *
   * - Filters the products by `selectedCategory` and generates a list of distinct `menuCategory` values.
   * - If a category is selected, the `menucategories` state is updated with the distinct categories found within the filtered products.
   * - If no category is selected or if the `products` array is invalid, it clears the `menucategories` state.
   *
   * @function useEffect
   * @dependency [selectedCategory, products] - Runs whenever `selectedCategory` or `products` changes.
   */
  useEffect(() => {
    if (Array.isArray(products)) {
      if (selectedCategory) {
        const filteredProducts = products.filter(
          (product) => product.category === selectedCategory
        );

        const distinctMenucategories = [
          ...new Set(
            filteredProducts.map((product) => product["menuCategory"])
          ),
        ];

        setMenucategories(distinctMenucategories);
      } else {
        setMenucategories([]);
      }
    } else {
      setMenucategories([]);
    }
  }, [selectedCategory, products]);

  const handleOpenCart = () => {
    setIsCartOpen(true);
  };

  const handleCloseCart = () => {
    setIsCartOpen(false);
  };

  /**
   * Handles adding a product to the cart and updates the cart items.
   *
   * - Checks if the product already exists in the cart (based on `name` and `type`).
   * - If the product is found, it updates the quantity; otherwise, it adds the new product to the cart.
   * - Saves the updated cart items to IndexedDB using `addItemToDB` for each item.
   * - Displays a notification confirming the product has been added to the cart, which disappears after 3 seconds.
   *
   * @function handleAddToCart
   * @param {Object} product - The product to be added to the cart.
   * @param {string} product.name - The name of the product.
   * @param {string} product.type - The type of the product.
   * @param {number} product.quantity - The quantity of the product to add.
   */
  const handleAddToCart = (product) => {
    setCartItems((prevItems) => {
      const existingItemIndex = prevItems.findIndex(
        (item) => item.name === product.name && item.type === product.type
      );

      let updatedItems;
      if (existingItemIndex >= 0) {
        updatedItems = [...prevItems];
        updatedItems[existingItemIndex] = {
          ...updatedItems[existingItemIndex],
          quantity: updatedItems[existingItemIndex].quantity + product.quantity,
        };
      } else {
        updatedItems = [...prevItems, product];
      }
      updatedItems.forEach((item) => addItemToDB(item));
      return updatedItems;
    });

    // Show success notification
    setNotificationMessage(`${product.name} has been added to your cart!`);
    setAddItemToCartOpen(true);

    // Automatically hide the notification after 3 seconds
    setTimeout(() => {
      setAddItemToCartOpen(false);
    }, 3000);
  };

  /**
   * Removes all items from the cart and clears the cart data from IndexedDB.
   *
   * - Resets the `cartItems` state to an empty array, effectively removing all items from the cart.
   * - Clears the cart data stored in IndexedDB by calling `clearDB`.
   * - Closes the cart by invoking the `handleCloseCart` function.
   *
   * @function removeAllCartItems
   *
   * @returns {Promise<void>} A promise that resolves once all cart items are removed and the cart is cleared.
   */
  const removeAllCartItems = async () => {
    setCartItems([]);
    await clearDB();
    handleCloseCart();
  };

  /**
   * Opens the order summary modal and sets the data to be displayed.
   *
   * - Sets the `orderSummaryData` state with the provided `orderSummary` object.
   * - Sets the `isOrderSummaryOpen` state to `true`, which triggers the display of the order summary modal.
   *
   * @function handleOpenOrderSummary
   *
   * @param {Object} orderSummary - The order summary data to be displayed in the modal.
   */
  const handleOpenOrderSummary = (orderSummary) => {
    setOrderSummaryData(orderSummary);
    setIsOrderSummaryOpen(true);
  };

  const handleCloseOrderSummary = () => setIsOrderSummaryOpen(false);

  /**
   * Opens the review payment modal and closes the order summary modal.
   *
   * - Sets the `isReviewPaymentOpen` state to `true`, which triggers the display of the review payment modal.
   * - Sets the `isOrderSummaryOpen` state to `false`, which closes the order summary modal.
   *
   * @function handleOpenReviewPayment
   */
  const handleOpenReviewPayment = () => {
    setIsReviewPaymentOpen(true);
    setIsOrderSummaryOpen(false);
  };

  /**
   * Closes both the review payment and order summary modals, and removes all items from the cart.
   *
   * - Sets the `isReviewPaymentOpen` state to `false`, closing the review payment modal.
   * - Sets the `isOrderSummaryOpen` state to `false`, closing the order summary modal.
   * - Calls `removeAllCartItems` to clear all items from the cart.
   *
   * @function handleCloseReviewPayment
   */
  const handleCloseReviewPayment = () => {
    setIsReviewPaymentOpen(false);
    setIsOrderSummaryOpen(false);
    removeAllCartItems();
  };

  /**
   * Handles the navigation back to the order summary from the review payment screen.
   *
   * - Sets the `isReviewPaymentOpen` state to `false`, closing the review payment modal.
   * - Sets the `isOrderSummaryOpen` state to `true`, opening the order summary modal.
   *
   * @function handleReviewBack
   */
  const handleReviewBack = () => {
    setIsReviewPaymentOpen(false);
    setIsOrderSummaryOpen(true);
  };

  const handleCategoryChange = (category) => setSelectedCategory(category);

  /**
   * Updates the quantity of a specific item in the cart.
   *
   * - Finds the item in the cart based on the `name` and `type` properties.
   * - Updates the `quantity` of the matched item to the new value.
   * - Calls `addItemToDB` for each item to persist changes in the database.
   *
   * @function updateCartItemQuantity
   *
   * @param {Object} itemToUpdate - The item to update in the cart.
   * @param {string} itemToUpdate.name - The name of the item to update.
   * @param {string} itemToUpdate.type - The type of the item to update.
   * @param {number} newQuantity - The new quantity to set for the item.
   */
  const updateCartItemQuantity = (itemToUpdate, newQuantity) => {
    setCartItems((prevItems) => {
      const updatedItems = prevItems.map((item) =>
        item.name === itemToUpdate.name && item.type === itemToUpdate.type
          ? { ...item, quantity: newQuantity }
          : item
      );

      updatedItems.forEach((item) => addItemToDB(item));
      return updatedItems;
    });
  };

  /**
   * Removes a specific item from the cart.
   *
   * - Filters out the item from the `cartItems` state based on the `name` and `type` properties.
   * - Calls `removeItemFromDB` to remove the item from the database using its `prodId`.
   *
   * @function removeCartItem
   *
   * @param {Object} itemToRemove - The item to remove from the cart.
   * @param {string} itemToRemove.name - The name of the item to remove.
   * @param {string} itemToRemove.type - The type of the item to remove.
   * @param {string} itemToRemove.prodId - The unique product ID of the item to remove from the database.
   */
  const removeCartItem = (itemToRemove) => {
    setCartItems((prevItems) => {
      const updatedItems = prevItems.filter(
        (item) =>
          item.name !== itemToRemove.name || item.type !== itemToRemove.type
      );

      removeItemFromDB(itemToRemove.prodId);
      return updatedItems;
    });
  };

  /**
   * Filters the `products` array based on the selected category and the search query.
   *
   * - Filters products to include only those that match the `selectedCategory` and contain the `searchQuery` in either the `name` or `menuCategory`.
   * - Converts both the product `name` and `menuCategory` to lowercase for case-insensitive matching.
   * - If `products` is not an array, it returns an empty array.
   *
   * @function filteredProducts
   *
   * @param {Array} products - The array of product objects to be filtered.
   * @param {string} selectedCategory - The category to filter the products by.
   * @param {string} searchQuery - The search query used to filter products by name or menu category.
   *
   * @returns {Array} - An array of products that match the selected category and search query.
   */
  const filteredProducts = Array.isArray(products)
    ? products.filter(
        (product) =>
          product.category === selectedCategory &&
          (product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
            product["menuCategory"]
              .toLowerCase()
              .includes(searchQuery.toLowerCase()))
      )
    : [];

  /**
   * Extracts distinct menu categories from the filtered products.
   *
   * - Maps the `filteredProducts` to get an array of `menuCategory` values.
   * - Uses a `Set` to ensure only unique `menuCategory` values are retained.
   * - Returns an array of distinct `menuCategory` values.
   *
   * @function filteredMenucategories
   *
   * @param {Array} filteredProducts - The array of filtered product objects.
   *
   * @returns {Array} - An array of distinct menu categories.
   */
  const filteredMenucategories = [
    ...new Set(filteredProducts.map((product) => product["menuCategory"])),
  ];

  /**
   * Effect that updates the chatbot error status on the server whenever the `chatbotError` or `chatbotScripts` state changes.
   *
   * - Sends a `PUT` request to update the chatbot error status in the server with the value of `chatbotError`.
   * - If successful, it then sends a `GET` request to fetch the latest chatbot credentials.
   * - Logs an error to the console if the requests fail.
   *
   * @function useEffect
   * @dependency [chatbotError, chatbotScripts] - Runs whenever `chatbotError` or `chatbotScripts` changes.
   */
  useEffect(() => {
    const updateChatbotErrorStatus = async () => {
      try {
        await axios.put("http://localhost:9000/api/kape-link/chatbot-error", {
          chatbot: {
            isError: chatbotError,
          },
        });
        await axios.get("http://localhost:9000/api/kape-link/credentials");
      } catch (error) {
        console.error("Failed to update chatbot error status:", error);
      }
    };
    updateChatbotErrorStatus();
  }, [chatbotError, chatbotScripts]);

  if (isOffline) {
    return <OfflinePage />;
  }

  return (
    <div>
      <Header user={user} />
      <div className="bg-cover bg-center">
        <img
          src={background}
          alt="Menu Categories"
          className="w-full h-20 sm:h-auto"
        />
      </div>
      <FloatingSuccessfulNotification
        showNotification={isAddItemToCartOpen}
        notificationMessage={notificationMessage}
      />
      <MenuCategories
        onCategoryChange={handleCategoryChange}
        className="mt-20"
      />
      {/* Loading indicator */}
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          {/* Centered loading gif */}
          <Loader className="animate-spin text-white" size={24} />
        </div>
      ) : (
        <>
          <div className="flex justify-center my-4 px-4">
            <SearchAndFilter
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              placeholderText="Search Products..."
            />
          </div>

          <div className="px-5 md:px-20 py-2 sm:py-10 md:py-5">
            {filteredMenucategories.map((menucategory) => (
              <MenuProducts
                key={menucategory}
                items={filteredProducts.filter(
                  (product) => product["menuCategory"] === menucategory
                )}
                menucategory={menucategory}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>

          <button
            onClick={handleOpenCart}
            className="fixed bottom-[107px] right-[25px] custom-cart-button text-white font-bold py-[20px] px-[20px] rounded-full shadow-lg flex items-center justify-center"
          >
            <ShoppingBag size={24} className="text-white" />
          </button>

          {loadingChatbot && (
            <div className="relative flex items-center z-0">
              <button className="fixed bottom-6 right-6 bg-[#A79277] transform transition-transform duration-300 hover:scale-110 text-white font-bold py-5 px-5 rounded-full shadow-[0_6px_6px_rgba(0,0,0,1)] flex items-center justify-center group">
                <Loader className="animate-spin text-white" size={24} />
                <span className="absolute bottom-14 left-1/2 transform -translate-x-1/2 bg-black text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Chatbot Loading...
                </span>
              </button>
            </div>
          )}

          {chatbotError && (
            <div className="relative flex items-center z-0">
              <button className="fixed bottom-6 right-6 bg-[#A79277] transform transition-transform duration-300 hover:scale-110 text-white font-bold py-5 px-5 rounded-full shadow-[0_6px_6px rgba(0,0,0,1)] flex items-center justify-center group">
                <TriangleAlert size={24} />
                <span className="absolute bottom-14 left-1/2 transform -translate-x-1/2 bg-red-500 text-white text-xs py-1 px-2 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Chatbot Unavailable
                </span>
              </button>
            </div>
          )}

          {isCartOpen && (
            <Cart
              isCartOpen={isCartOpen}
              cartItems={cartItems}
              onClose={handleCloseCart}
              updateCartItemQuantity={updateCartItemQuantity}
              removeCartItem={removeCartItem}
              onReviewOrder={handleOpenOrderSummary}
              customerId={user.userId}
            />
          )}
          {isOrderSummaryOpen && (
            <OrderSummary
              isOpen={isOrderSummaryOpen}
              orders={orderSummaryData}
              onClose={handleCloseOrderSummary}
              onCheckOut={handleOpenReviewPayment}
              user={user}
            />
          )}
          {isReviewPaymentOpen && (
            <ReviewPayment
              isOpen={isReviewPaymentOpen}
              onBack={handleReviewBack}
              onClose={handleCloseReviewPayment}
              orders={orderSummaryData}
              user={user}
            />
          )}
          <Footer />
        </>
      )}
    </div>
  );
};

export default MenuPage;
