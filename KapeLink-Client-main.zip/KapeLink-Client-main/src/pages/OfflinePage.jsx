import { Link } from "react-router-dom";
import { FaExclamationTriangle } from "react-icons/fa";

/**
 * OfflinePage component displays a message indicating that the service is currently unavailable.
 * It includes an icon, message text, and a button to navigate back to the login page.
 * 
 * @function OfflinePage
 * @returns {JSX.Element} - Renders the offline notification interface.
 */
const OfflinePage = () => {
  return (
    <section className="flex flex-col justify-center items-center h-96 mt-24">
      <FaExclamationTriangle className="text-yellow-400 text-6xl mb-4" />
      <h1 className="text-4xl sm:text-6xl font-bold mb-4">Service Unavailable</h1>
      <p className="text-xl mb-5">We’re currently experiencing some technical issues and are working hard to get things up and running. Please check back soon!</p>
      <Link
        to="/login"
        className="text-white rounded-md px-3 py-2 mt-4 custom-button-color"
      >
        Go Back
      </Link>
    </section>
  );
};

export default OfflinePage;
