import React, { useState, useEffect } from "react";
import ManagerSideBar from "../../components/ManagerComponents/ManagerSideBar";
import SearchBar from "../../components/Global/SearchBar";
import CustomerProfile from "../../components/Global/CustomerProfile";
import CustomerTable from "../../components/Global/CustomerTable";
import ManagerNavBar from "../../components/ManagerComponents/ManagerNavBar";
import { io } from "socket.io-client";
import HeaderFilterTooltip from "../../components/Global/HeaderFilterTooltip";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";
import axios from "axios";

/**
 * ManagerCustomerProfile component displays the customer profile or customer list.
 * It fetches customer data, handles socket notifications, and allows filtering of customers.
 *
 * @function ManagerCustomerProfile
 * @returns {JSX.Element} - Renders the customer profile or customer table based on selected state.
 */
const ManagerCustomerProfile = () => {
  const [activeFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [customers, setCustomers] = useState([]); // State to hold customer data
  const [totalCustomers, setTotalCustomers] = useState(0); // State to hold total customers

  /**
   * Handles socket connection and listens for expired notifications to trigger push subscription.
   * Runs once when the component is mounted and cleans up the socket connection on unmount.
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/get-customers"
        );
        const data = response.data;

        if (Array.isArray(data)) {
          setCustomers(data); // Set fetched customer data
          setTotalCustomers(data.length); // Set total customers
        }
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
    };

    fetchCustomers();
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <ManagerSideBar />
      </div>
      <div className="sm:hidden w-full">
        <ManagerNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        {selectedCustomer ? (
          <CustomerProfile
            selectedCustomer={selectedCustomer}
            setSelectedCustomer={setSelectedCustomer}
          />
        ) : (
          <div>
            <div className="justify-between items-center mt-2 sm:mt-4 mb-4 ml-4 flex max-[640px]:flex-col max-[640px]:items-start max-[640px]:mb-2 max-[640px]:ml-0">
              <h1 className="font-semibold text-3xl max-[640px]:text-xl">
                Customers
              </h1>
            </div>

            <div className="flex items-center max-[640px]:flex-col">
              <div className="w-full">
                <SearchBar
                  searchQuery={searchQuery}
                  setSearchQuery={setSearchQuery}
                />
              </div>
              <div className="flex items-center md:ml-auto max-[640px]:w-full max-[640px]:mt-2">
                <h1 className="text-gray-600 md:text-lg md:font-medium mr-5 whitespace-nowrap">
                  Total Customers: {totalCustomers}
                </h1>
                <div className="max-[640px]:ml-auto">
                  <HeaderFilterTooltip />
                </div>
              </div>
            </div>

            <CustomerTable
              customers={customers} // Pass customer data to the table
              searchQuery={searchQuery}
              activeFilter={activeFilter} // Pass active filter
              setSelectedCustomer={setSelectedCustomer}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ManagerCustomerProfile;
