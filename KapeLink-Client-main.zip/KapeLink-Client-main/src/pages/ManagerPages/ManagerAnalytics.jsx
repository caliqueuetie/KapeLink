import React, { useState, useEffect } from "react";
import ManagerSideBar from "../../components/ManagerComponents/ManagerSideBar";
import ManagerNavBar from "../../components/ManagerComponents/ManagerNavBar";
import TabFilters from "../../components/Global/TabFilters";
import AnalyticsSummary from "../../components/ManagerComponents/AnalyticsSummary";
import AnalyticsReports from "../../components/ManagerComponents/AnalyticsReports";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

import { io } from "socket.io-client";

const ManagerAnalytics = () => {
  const tabNames = ["Summary", "Reports"];
  const [activeTab, setActiveTab] = useState("Summary");
  const [currentDate, setCurrentDate] = useState("");
  const [notifications, setNotifications] = useState([]);

  /**
   * Updates the current date every minute and sets it in the component state.
   * The date format includes weekday, month, day, and year.
   * Runs once on mount and updates every minute.
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const updateDate = () => {
      const options = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      };
      setCurrentDate(new Date().toLocaleDateString("en-US", options));
    };

    // Update date immediately on mount
    updateDate();

    // Set an interval to update the date every minute
    const intervalId = setInterval(updateDate, 60000);

    // Cleanup interval on component unmount
    return () => clearInterval(intervalId);
  }, []);

  /**
   * Listens for "expiredNotification" event from the server and triggers HandlePushSubscription.
   * Cleans up the socket connection on component unmount.
   *
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <ManagerSideBar />
      </div>
      <div className="sm:hidden w-full">
        <ManagerNavBar />
      </div>

      <div className="flex w-full h-full my-4 2xl:my-8 mx-5 2xl:mx-10 max-[640px]:mx-0 max-[640px]:my-0 max-[640px]:justify-center max-[640px]:item-center">
        <div className="sm:w-full">
          <div className="justify-between items-center mt-4 ml-4 sm:flex max-[640px]:flex-col max-[640px]:mb-0 max-[640px]:ml-0">
            <h1 className="font-semibold sm:text-3xl max-[640px]:text-xl">
              Analytics
            </h1>
          </div>

          <div className="flex items-end max-[640px]:flex-col max-[640px]:items-start">
            <div className="2xl:mt-5 max-[640px]:mt-2">
              <TabFilters
                tabNames={tabNames}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
            </div>

            <div className="flex-grow text-right px-5 text-gray-500 max-[640px]:text-left max-[640px]:mt-4 max-[640px]:px-0">
              <p className="font-medium text-xl max-[640px]:hidden">Today is</p>
              <p className="font-semibold text-3xl max-[640px]:text-xl">
                {currentDate}
              </p>
            </div>
          </div>

          {/* Conditional rendering based on active tab */}
          {activeTab === "Summary" && (
            <AnalyticsSummary currentDate={currentDate} />
          )}
          {activeTab === "Reports" && <AnalyticsReports />}
        </div>
      </div>
    </div>
  );
};

export default ManagerAnalytics;
