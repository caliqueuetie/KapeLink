import React, { useEffect, useState } from "react";
import ManagerSideBar from "../../components/ManagerComponents/ManagerSideBar";
import NotificationPane from "../../components/Global/NotificationPane";
import ManagerNavBar from "../../components/ManagerComponents/ManagerNavBar";
import { io } from "socket.io-client";
import TabFilters from "../../components/Global/TabFilters";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

/**
 * Manages the notifications view for the manager, handles socket connections for real-time notifications.
 *
 * @function ManagerNotifications
 * @returns {React.Component} - The rendered component with notification pane
 */
const ManagerNotifications = () => {
  const receivers = "all";
  const roles = ["manager"];

  /**
   * Sets up the socket connection for real-time notifications and handles expired notifications.
   *
   * @async
   * @function useEffect
   * @returns {Promise<void>} - The side-effect of setting up and cleaning up the socket connection
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <ManagerSideBar />
      </div>
      <div className="sm:hidden w-full">
        <ManagerNavBar />
      </div>

      <div className="flex justify-center w-full h-full">
        <div className="flex flex-col sm:mt-20 max-[640px]:mt-5">
          <h1 className="text-3xl font-semibold max-[640px]:text-xl mb-5">
            Notifications
          </h1>

          <NotificationPane receivers={receivers} roles={roles} />
        </div>
      </div>
    </div>
  );
};

export default ManagerNotifications;
