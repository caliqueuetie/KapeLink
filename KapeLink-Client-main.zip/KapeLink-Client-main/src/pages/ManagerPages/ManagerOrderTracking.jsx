import React, { useState, useEffect } from "react";
import ManagerSideBar from "../../components/ManagerComponents/ManagerSideBar";
import TabFilters from "../../components/Global/TabFilters";
import SearchBar from "../../components/Global/SearchBar";
import FilterButton from "../../components/Global/FilterButton";
import ForDeliveryDetails from "../../components/Global/ForDeliveryDetails";
import ForPickUpDetails from "../../components/Global/ForPickUpDetails";
import InStoreDetails from "../../components/Global/InStoreDetails";
import ManagerNavBar from "../../components/ManagerComponents/ManagerNavBar";
import OrderTrackingTable from "../../components/Global/OrderTrackingTable";
import { io } from "socket.io-client";
import axios from "axios";
import HeaderFilterTooltip from "../../components/Global/HeaderFilterTooltip";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";

const ManagerOrderTracking = () => {
  const tabNames = ["All", "Complete", "Failed", "Cancelled"];
  const [activeTab, setActiveTab] = useState("All");
  const [activeFilter, setActiveFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [data, setData] = useState([]);
  const [userNames, setUserNames] = useState({});
  const [loading, setLoading] = useState(true);

  /**
   * Fetches orders data from the server and updates component state with orders data and customer names.
   *
   * @async
   * @function fetchOrdersData
   * @returns {Promise<void>} - Resolves when data is successfully fetched and state is updated.
   * @throws Will log an error message and set loading state to false if there is a fetch error.
   */
  const fetchOrdersData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-orders"
      );
      const ordersData = response.data;
      setData(ordersData);
      setLoading(false);

      const uniqueCustomerIds = [
        ...new Set(ordersData.map((order) => order.customerId).filter(Boolean)),
      ];

      console.log("Unique Customer IDs:", uniqueCustomerIds);

      if (uniqueCustomerIds.length > 0) {
        const userResponse = await axios.post(
          "http://localhost:9000/api/kape-link/get-user-names",
          { userIds: uniqueCustomerIds }
        );
        console.log("User Response from API:", userResponse.data);

        const userMap = userResponse.data;

        const newUserNames = ordersData.reduce((acc, order) => {
          console.log("Processing Order:", order);
          acc[order.orderId] = userMap[order.customerId]
            ? `${userMap[order.customerId].firstName} ${
                userMap[order.customerId].lastName
              }`
            : "NA";
          return acc;
        }, {});

        console.log("User Names Map:", newUserNames);
        setUserNames(newUserNames);
      }
    } catch (error) {
      console.error("Error fetching orders data:", error);
      setLoading(false);
    }
  };

  /**
   * Initializes fetching of orders data on component mount, sets up WebSocket listeners for real-time updates,
   * and cleans up on unmount by disconnecting the socket.
   *
   * @function useEffectCallback
   * @returns {void} - Sets up WebSocket listeners and triggers fetchOrdersData on component mount.
   * @throws No direct throws, but WebSocket errors or unhandled errors may be logged.
   */
  useEffect(() => {
    fetchOrdersData();

    const socket = io("http://localhost:9000");

    socket.on("newOrder", (message) => {
      fetchOrdersData();
    });

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    socket.on("orderStatusUpdated", () => {
      fetchOrdersData();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    fetchOrdersData();
  }, []);

  /**
   * Generates a list of unique order options for dropdown selection based on the current data.
   *
   * @constant
   * @type {Array<string>}
   */
  const orderOptions = [...new Set(data.map((item) => item.orderOption))];

  /**
   * Renders the appropriate component for order details based on the selected order's option.
   *
   * @function renderOrderDetails
   * @returns {JSX.Element|null} - Returns the corresponding JSX component based on the selected order option.
   */
  const renderOrderDetails = () => {
    if (!selectedOrder) return null;
    switch (selectedOrder.orderOption) {
      case "Delivery":
        return (
          <ForDeliveryDetails
            selectedOrder={selectedOrder}
            setSelectedOrder={setSelectedOrder}
            fetchOrdersData={fetchOrdersData}
          />
        );
      case "Pickup":
        return (
          <ForPickUpDetails
            selectedOrder={selectedOrder}
            setSelectedOrder={setSelectedOrder}
            fetchOrdersData={fetchOrdersData}
          />
        );
      case "In-store":
        return (
          <InStoreDetails
            selectedOrder={selectedOrder}
            setSelectedOrder={setSelectedOrder}
            fetchOrdersData={fetchOrdersData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <ManagerSideBar />
      </div>
      <div className="sm:hidden w-full">
        <ManagerNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        {selectedOrder ? (
          renderOrderDetails()
        ) : (
          <div>
            <div className="justify-between items-center mt-2 mb-5 2xl:mb-10 ml-4 sm:flex max-[640px]:flex-col max-[640px]:mb-4 max-[640px]:ml-0">
              <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap mr-5 max-[640px]:mb-2">
                Order Tracking
              </h1>
              <div>
                <div className="inline-flex items-center space-x-3 w-full">
                  <SearchBar
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                  />
                  <FilterButton
                    activeFilter={activeFilter}
                    setActiveFilter={setActiveFilter}
                    orderOptions={orderOptions}
                    pageKey="managerOrderTracking"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center">
              <TabFilters
                tabNames={tabNames}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />
              <div className="ml-auto">
                <HeaderFilterTooltip />
              </div>
            </div>

            <OrderTrackingTable
              activeTab={activeTab}
              data={data}
              searchQuery={searchQuery}
              setSelectedOrder={setSelectedOrder} // Set the selected order when a table row is clicked
              activeFilter={activeFilter}
              userNames={userNames}
              loading={loading}
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default ManagerOrderTracking;
