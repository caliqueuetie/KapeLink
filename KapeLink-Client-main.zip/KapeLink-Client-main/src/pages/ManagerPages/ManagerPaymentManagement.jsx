import React, { useState, useEffect } from "react";
import ManagerSideBar from "../../components/ManagerComponents/ManagerSideBar";
import TabFilters from "../../components/Global/TabFilters";
import SearchBar from "../../components/Global/SearchBar";
import FilterButton from "../../components/Global/FilterButton";
import PaymentTable from "../../components/ManagerComponents/PaymentTable";
import ManagerNavBar from "../../components/ManagerComponents/ManagerNavBar";
import SliderButton from "../../components/ManagerComponents/SliderButton";
import { HandlePushSubscription } from "../../components/Global/HandlePushSubscription";
import { io } from "socket.io-client";
import axios from "axios";
import HeaderFilterTooltip from "../../components/Global/HeaderFilterTooltip";
import { message } from "antd";

const ManagerPaymentManagement = () => {
  const tabNames = ["Pending", "Confirmed", "Returned", "Rejected"];
  const [activeTab, setActiveTab] = useState("Pending");
  const [activeFilter, setActiveFilter] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [data, setData] = useState([]);
  const [paymentStatuses, setPaymentStatuses] = useState([]);
  const [paymentMethod, setPaymentMethods] = useState([]);
  const [loading, setLoading] = useState(true);

  /**
   * Establishes a WebSocket connection to listen for events and updates the component's state accordingly.
   *
   * - Listens for the "orderStatusUpdated" event to trigger fetching the latest payment data.
   * - Listens for the "expiredNotification" event to handle push subscription updates.
   * - Cleans up by disconnecting the WebSocket when the component is unmounted.
   *
   * @async
   * @function useEffect
   * @returns {void} - No direct return value, but the effect modifies component state and handles WebSocket events.
   * @throws Error if there's an issue with the WebSocket connection or event handling.
   */
  useEffect(() => {
    const socket = io("http://localhost:9000");

    socket.on("newOrder", (message) => {
      fetchPaymentsData();
    });

    socket.on("orderStatusUpdated", (message) => {
      fetchPaymentsData();
    });

    socket.on("expiredNotification", () => {
      HandlePushSubscription();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  /**
   * Fetches order data and payment methods from the API, extracts unique payment method names,
   * and updates the state with the orders and unique payment methods.
   *
   * @async
   * @function fetchPaymentsData
   * @returns {Promise<void>} - Updates the state with orders and unique payment methods
   * @throws Error if there's an issue with the API request
   */
  const fetchPaymentsData = async () => {
    try {
      const response = await axios.get(
        `http://localhost:9000/api/kape-link/get-all-orders-by-verification-status`
      );
      const orders = response.data;

      // Extract unique paymentMethodIds from orders
      const uniquePaymentMethodIds = [
        ...new Set(orders.map((order) => order.paymentMethodId)),
      ];

      // Fetch all payment methods
      const paymentResponse = await axios.get(
        `http://localhost:9000/api/kape-link/get-all-payment-methods`
      );

      const allPaymentMethods = paymentResponse.data;

      const paymentMethodsMap = allPaymentMethods.reduce((acc, method) => {
        if (uniquePaymentMethodIds.includes(method.opid)) {
          acc[method.opid] = method.name;
        }
        return acc;
      }, {});

      // Extract unique payment method names
      const uniquePaymentNames = Object.values(paymentMethodsMap);

      setPaymentMethods(uniquePaymentNames);
      setData(orders);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching payment data:", error);
      setLoading(false);
    }
  };

  /**
   * Fetches payment data from the API and updates the state with orders and payment methods when the component is mounted.
   *
   * @async
   * @function useEffect
   * @returns {Promise<void>} - Updates the state with fetched payment data
   * @throws Error if there's an issue with the API request
   */
  useEffect(() => {
    fetchPaymentsData();
  }, []);

  /**
   * Fetches payment methods from the API and updates the state with filtered payment statuses.
   *
   * @async
   * @function fetchPaymentStatus
   * @returns {Promise<void>} - Updates the state with filtered payment statuses
   * @throws Error if there's an issue with the API request
   */
  const fetchPaymentStatus = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-all-payment-methods"
      );
      // Filter out payments with opid "3" and "4"
      const filteredStatuses = response.data.filter(
        (payment) => !["1"].includes(payment.opid.toString())
      );
      setPaymentStatuses(filteredStatuses);
    } catch (error) {
      console.error("Error fetching payment methods:", error);
    }
  };

  /**
   * Fetches and updates the payment status when the component mounts.
   * Runs once on mount, calling `fetchPaymentStatus` to retrieve and filter payment methods.
   *
   * @async
   * @function useEffect
   * @returns {void}
   */
  useEffect(() => {
    fetchPaymentStatus();
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <ManagerSideBar />
      </div>
      <div className="sm:hidden w-full">
        <ManagerNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        <div>
          <div className="flex justify-between mt-2 2xl:mb-0 flex-col max-[640px]:flex-col max-[640px]:ml-0">
            <div className="flex items-center max-[640px]:flex-col max-[640px]:items-start max-[640px]:block">
              <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap mr-5">
                Payment Management
              </h1>
              <div className="flex-grow text-right mt-2 max-[640px]:mb-3">
                <div className="inline-flex items-center space-x-3 max-[640px]:w-full">
                  <SearchBar
                    searchQuery={searchQuery}
                    setSearchQuery={setSearchQuery}
                  />
                  <FilterButton
                    activeFilter={activeFilter}
                    setActiveFilter={setActiveFilter}
                    paymentMethods={paymentMethod}
                    pageKey="paymentManagement"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center mt-4 max-[640px]:mt-0 max-[640px]:flex-col max-[640px]:items-start">
              <TabFilters
                tabNames={tabNames}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
              />

              <div className="flex-grow text-right max-[640px]:mt-2 sm:ml-5">
                <div className="inline-flex items-center space-x-3">
                  <h1 className="max-[640px]:text-xs whitespace-nowrap">
                    Online Payment:{" "}
                  </h1>
                  <SliderButton statuses={paymentStatuses} />
                  <HeaderFilterTooltip />
                </div>
              </div>
            </div>
          </div>

          <PaymentTable
            activeTab={activeTab}
            activeFilter={activeFilter}
            searchQuery={searchQuery}
            data={data}
            loading={loading}
          />
        </div>
      </div>
    </div>
  );
};

export default ManagerPaymentManagement;
