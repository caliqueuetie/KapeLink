/**
 * Admin page component to manage payment options.
 * Displays a list of payment methods with options to edit or add new methods.
 * Utilizes popup modals for adding and editing payment options, with notifications on success.
 *
 * @module AdminManagePaymentOptions
 */
import React, { useState, useEffect } from "react";
import { Plus } from "lucide-react";
import AdminSideBar from "../../components/AdminComponents/AdminSideBar";
import AdminNavBar from "../../components/AdminComponents/AdminNavBar";
import EditPaymentPopup from "../../components/AdminComponents/EditPaymentPopup";
import AddPaymentPopup from "../../components/AdminComponents/AddPaymentPopup";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";
import axios from "axios";

const AdminManagePaymentOptions = () => {
  const [isEditPaymentPopupOpen, setEditPaymentPopupOpen] = useState(false);
  const [isAddPaymentPopupOpen, setAddPaymentPopupOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [data, setData] = useState([]);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  /**
   * Fetches the list of payment methods from the server and updates the state.
   * Executes once on component mount to populate the payment options list.
   *
   * @async
   * @function fetchPaymentData
   * @returns {Promise<void>}
   */
  const fetchPaymentData = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-all-payment-methods"
      );
      setData(response.data);
    } catch (error) {
      console.error("Error fetching payment data:", error);
    }
  };

  /**
   * Triggers an update to the payment data by re-fetching the list.
   * Useful as a callback after successful add/edit actions.
   *
   * @function handlePaymentUpdated
   * @returns {void}
   */
  const handlePaymentUpdated = () => {
    fetchPaymentData();
  };

  /**
   * Opens the edit popup and sets the selected payment method to be edited.
   *
   * @function handleEditPaymentOpenPopup
   * @param {Object} payment - The payment method to edit.
   * @returns {void}
   */
  const handleEditPaymentOpenPopup = (payment) => {
    setEditPaymentPopupOpen(true);
    setSelectedPayment(payment);
  };

  /**
   * Opens the add payment method popup.
   *
   * @function handleAddPaymentOpenPopup
   * @returns {void}
   */
  const handleAddPaymentOpenPopup = () => {
    setAddPaymentPopupOpen(true);
  };

  /**
   * Triggers the initial fetch of payment data when the component mounts.
   * Ensures that the `fetchPaymentData` function runs only once to populate the list of payment options.
   *
   * @useEffect
   * @returns {void}
   */
  useEffect(() => {
    fetchPaymentData();
  }, []);

  /**
   * Adds a new payment method to the existing list of payment methods.
   * Updates the state to include the new payment method.
   *
   * @function handlePaymentAdded
   * @param {Object} newPayment - The new payment method object.
   * @returns {void}
   */
  const handlePaymentAdded = (newPayment) => {
    setData((prevData) => [...prevData, newPayment]);
  };

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <AdminSideBar />
      </div>
      <div className="sm:hidden w-full">
        <AdminNavBar />
      </div>

      <div className="w-full h-full m-12 max-[640px]:m-0">
        <h1 className="font-semibold text-3xl max-[640px]:text-xl max-[640px]:m-6">
          Manage Payment Options
        </h1>

        <div className="flex w-full sm:flex-wrap mt-10 ml-10 gap-6 max-[640px]:ml-0 max-[640px]:mt-5 max-[640px]:flex-col max-[640px]:justify-center max-[640px]:items-center">
          {data.map((payment, index) => {
            return (
              <div
                key={index}
                className="flex flex-col justify-center items-center w-[300px] h-40 border-collapse border border-gray-400 rounded-lg p-3 cursor-pointer hover:bg-gray-200 transition duration-200 shadow-lg"
                onClick={() => handleEditPaymentOpenPopup(payment)}
              >
                <h1 className="mt-2 ml-1 font-semibold text-lg md:text-xl">
                  {payment.name}
                </h1>

                {/* Payment Status Text */}
                <p
                  className={`text-sm font-medium ${
                    payment.status === "Active"
                      ? "text-green-500"
                      : "text-gray-500"
                  }`}
                >
                  {payment.status === "Active" ? "Active" : "Inactive"}
                </p>
              </div>
            );
          })}

          <div
            className="flex w-[300px] h-40 justify-center border-collapse border border-gray-400 rounded-lg items-center
            p-3 cursor-pointer hover:bg-gray-200 transition duration-200 max-[640px]:ml-0 mb-10"
            onClick={handleAddPaymentOpenPopup}
          >
            <div>
              <Plus className="text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Edit Payment Popup */}
      {isEditPaymentPopupOpen && (
        <EditPaymentPopup
          setEditPaymentPopupOpen={setEditPaymentPopupOpen}
          data={selectedPayment}
          onPaymentUpdated={handlePaymentUpdated}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}

      {/* Add Payment Popup */}
      {isAddPaymentPopupOpen && (
        <AddPaymentPopup
          setAddPaymentPopupOpen={setAddPaymentPopupOpen}
          onPaymentAdded={handlePaymentAdded}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}

      <FloatingSuccessfulNotification
        showNotification={showNotification}
        notificationMessage={notificationMessage}
      />
    </div>
  );
};

export default AdminManagePaymentOptions;
