import React, { useState, useEffect } from "react";
import {
  Plus,
  FileText,
  Loader,
  Settings,
  RefreshCw,
  Clock,
} from "lucide-react";
import AdminSideBar from "../../components/AdminComponents/AdminSideBar";
import AdminNavBar from "../../components/AdminComponents/AdminNavBar";
import BotSettingsPopup from "../../components/AdminComponents/BotSettingsPopup";
import EditPdfPopup from "../../components/AdminComponents/EditPdfPopup";
import AddPdfPopup from "../../components/AdminComponents/AddPdfPopup";
import { Client } from "@botpress/client";
import axios from "/axios.config"; // Import configured axios with credentials

const AdminManageChatbot = () => {
  const [isBotSettingsPopupOpen, setBotSettingsPopupOpen] = useState(false);
  const [isEditPdfPopupOpen, setEditPdfPopupOpen] = useState(false);
  const [isAddPdfPopupOpen, setAddPdfPopupOpen] = useState(false);
  const [selectedPdf, setSelectedPdf] = useState(null);
  const [data, setData] = useState([]);
  const [pdfKeys, setPdfKeys] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [validKnowledgeBase, setValid] = useState(false);
  const [client, setClient] = useState(null);
  const [openingTime, setOpeningTime] = useState({ hours: 7, minutes: 0 });
  const [closingTime, setClosingTime] = useState({ hours: 18, minutes: 0 });

  useEffect(() => {
    // Fetch store configuration (opening and closing times) on component mount
    const fetchStoreHours = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/current-store-hour"
        );
        setOpeningTime(response.data.openingTime);
        setClosingTime(response.data.closingTime);
      } catch (error) {
        setErrorMessage(`Fetch error: ${error.message}`);
      }
    };

    fetchStoreHours();
  }, []);

  const handleStoreHoursUpdate = async () => {
    try {
      const { data: serverConfig } = await axios.get(
        "http://localhost:9000/api/kape-link/current-store-hour"
      );

      const currentConfig = { openingTime, closingTime };

      if (
        currentConfig.openingTime.hours === serverConfig.openingTime.hours &&
        currentConfig.openingTime.minutes ===
          serverConfig.openingTime.minutes &&
        currentConfig.closingTime.hours === serverConfig.closingTime.hours &&
        currentConfig.closingTime.minutes === serverConfig.closingTime.minutes
      ) {
        handleSuccess("No changes were made. The store hours remain the same.");
        return;
      }

      if (
        currentConfig.openingTime.hours !== serverConfig.openingTime.hours ||
        currentConfig.openingTime.minutes !== serverConfig.openingTime.minutes
      ) {
        await axios.patch(
          "http://localhost:9000/api/kape-link/store-opening-time",
          { openingTime: currentConfig.openingTime }
        );
      }

      if (
        currentConfig.closingTime.hours !== serverConfig.closingTime.hours ||
        currentConfig.closingTime.minutes !== serverConfig.closingTime.minutes
      ) {
        await axios.patch(
          "http://localhost:9000/api/kape-link/store-closing-time",
          { closingTime: currentConfig.closingTime }
        );
      }

      handleSuccess("Store hours updated successfully.");
    } catch (error) {
      setErrorMessage(`Update error: ${error.message}`);
    }
  };

  useEffect(() => {
    // Fetch chatbot credentials on component mount
    const fetchChatbotCredentials = async () => {
      try {
        const response = await axios.get(
          "http://localhost:9000/api/kape-link/credentials"
        );
        const chatbotData = response.data;

        if (!chatbotData || !chatbotData.credentials) {
          throw new Error("Failed to fetch chatbot credentials");
        }

        // Create Botpress client instance with the fetched credentials
        const botpressClient = new Client({
          token: chatbotData.credentials.token,
          botId: chatbotData.credentials.botId,
          workspaceId: chatbotData.credentials.workspaceId,
        });
        setClient(botpressClient); // Store the client in state
      } catch (error) {
        setErrorMessage(`Fetch error: ${error.message}`);
      }
    };

    fetchChatbotCredentials();
  }, []);

  const fetchKnowledgeBase = async () => {
    if (!client) return; // Wait until client is initialized
    setLoading(true);
    setData([]);
    setErrorMessage("");
    setSuccessMessage("");
    setValid(false);

    try {
      const { files } = await client.listFiles({});

      if (files) {
        setData(files);
        const keys = files.map((file) => file.key);
        setPdfKeys(keys);
        setValid(true);
      } else {
        setErrorMessage("Error: Unexpected response structure");
      }
    } catch (error) {
      setErrorMessage(
        error + ". Please review your Chatbot configuration in the Settings."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (client) {
      fetchKnowledgeBase();
    }
  }, [client]);

  const handleBotSettingsOpenPopup = () => {
    setBotSettingsPopupOpen(true);
  };

  const handleEditPdfOpenPopup = (pdf) => {
    setEditPdfPopupOpen(true);
    setSelectedPdf(pdf);
  };

  const handleAddPdfOpenPopup = () => {
    if (validKnowledgeBase) {
      setAddPdfPopupOpen(true);
    }
  };

  const handleSuccess = (message) => {
    setSuccessMessage(message);
    setTimeout(() => {
      setSuccessMessage("");
    }, 3000);
  };

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <AdminSideBar />
      </div>
      <div className="sm:hidden w-full">
        <AdminNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        <div className="w-[80%] sm:w-8/12 2xl:w-6/12 flex flex-col">
          <div className="mb-10">
            <h1 className="font-semibold text-3xl mb-5 max-[640px]:text-xl whitespace-nowrap max-[640px]:mt-5 max-[640px]:mb-3">
              Manage Chatbot
            </h1>

            <div className="flex items-center flex-wrap">
              <button
                onClick={handleBotSettingsOpenPopup}
                className="flex items-center whitespace-nowrap text-white custom-button-black mt-1 text-sm 2xl:text-base py-2 px-4 rounded-xl max-[640px]:px-4 max-[640px]:rounded-lg mr-2"
              >
                <Settings className="mr-2" size={18} />
                Chatbot Settings
              </button>

              <button
                onClick={fetchKnowledgeBase}
                disabled={loading || !client} // Disable until client is initialized
                className={`flex items-center whitespace-nowrap text-white py-2 px-4 rounded-xl mt-1 text-xs sm:text-base max-[640px]:px-4  max-[640px]:rounded-lg mr-2 ${
                  loading
                    ? "bg-gray-300 cursor-not-allowed"
                    : "custom-button-black"
                }`}
              >
                {loading ? (
                  <Loader className="animate-spin mr-2" size={18} />
                ) : (
                  <RefreshCw className="lg:mr-2" size={18} />
                )}
                <span className="max-[810px]:hidden">Refresh</span>
              </button>

              <button
                onClick={handleAddPdfOpenPopup}
                disabled={!validKnowledgeBase}
                className={`flex items-center whitespace-nowrap text-white py-2 px-4 rounded-xl mt-1 text-xs sm:text-base max-[640px]:px-4 max-[640px]:rounded-lg ${
                  !validKnowledgeBase
                    ? "bg-gray-300 cursor-not-allowed"
                    : "custom-button-black"
                }`}
              >
                <Plus className="lg:mr-2" size={18} />
                <span className="max-[810px]:hidden">Add PDF</span>
              </button>
            </div>

            <div
              id="pdf-list"
              className="max-[640px]:flex max-[640px]:flex-col max-[640px]:items-center w-full mt-7 max-[640px]:mt-4"
            >
              {loading ? (
                <div className="fixed inset-0 flex items-center justify-center z-20">
                  <Loader className="animate-spin" size={40} />
                </div>
              ) : (
                <>
                  {data.filter((pdf) => pdf.tags.title).length === 0 ? (
                    <div className="text-gray-500 text-center font-semibold mt-5">
                      No PDFs uploaded.
                    </div>
                  ) : (
                    data.map((pdf) => {
                      if (!pdf.tags.title) return null; // Skip if title is undefined

                      return (
                        <div
                          className="flex border-collapse items-center border border-gray-400 rounded-lg p-5 mb-3 cursor-pointer hover:bg-gray-200 transition duration-200 max-[640px]:w-full max-[640px]:mb-2 max-[640px]:p-3"
                          key={pdf.tags.title}
                          onClick={() => handleEditPdfOpenPopup(pdf)}
                        >
                          <FileText className="text-gray-400 w-12 h-8" />
                          <h1 className="mt-2 ml-1 font-semibold sm:text-lg">
                            {pdf.tags.title}
                          </h1>
                        </div>
                      );
                    })
                  )}
                </>
              )}
            </div>
          </div>

          <div>
            {" "}
            {/* Manage Store Hours Section */}
            <h2 className="font-semibold text-3xl mb-5 max-[640px]:text-xl whitespace-nowrap max-[640px]:mt-5 max-[640px]:mb-3">
              Manage Store Hours
            </h2>
            {/* Opening Time */}
            <div className="flex items-center mb-4">
              <label className="font-medium mr-4">Opening Time:</label>
              <input
                type="number"
                min="0"
                max="23"
                value={openingTime.hours}
                onChange={(e) =>
                  setOpeningTime({
                    ...openingTime,
                    hours: Number(e.target.value),
                  })
                }
                className="border rounded p-2 w-16"
                placeholder="HH"
              />
              <span className="mx-1">:</span>
              <input
                type="number"
                min="0"
                max="59"
                value={openingTime.minutes}
                onChange={(e) =>
                  setOpeningTime({
                    ...openingTime,
                    minutes: Number(e.target.value),
                  })
                }
                className="border rounded p-2 w-16"
                placeholder="MM"
              />
            </div>
            {/* Closing Time */}
            <div className="flex items-center mb-4">
              <label className="font-medium mr-4">Closing Time:</label>
              <input
                type="number"
                min="0"
                max="23"
                value={closingTime.hours}
                onChange={(e) =>
                  setClosingTime({
                    ...closingTime,
                    hours: Number(e.target.value),
                  })
                }
                className="border rounded p-2 w-16 flex items-center"
                placeholder="HH"
              />
              <span className="mx-1">:</span>
              <input
                type="number"
                min="0"
                max="59"
                value={closingTime.minutes}
                onChange={(e) =>
                  setClosingTime({
                    ...closingTime,
                    minutes: Number(e.target.value),
                  })
                }
                className="border rounded p-2 w-16"
                placeholder="MM"
              />
            </div>
            {/* Update Button */}
            <button
              onClick={handleStoreHoursUpdate}
              className="text-white custom-button-black py-2 px-4 rounded"
            >
              Update Store Hours
            </button>
          </div>

          {successMessage && (
            <p className="success-message">{successMessage}</p>
          )}
          {errorMessage && (
            <p className="text-white border-l-4 border-red-700 bg-red-500 rounded-lg px-4 py-2 mt-2">
              {errorMessage}
            </p>
          )}
        </div>
      </div>

      {isBotSettingsPopupOpen && (
        <BotSettingsPopup
          setBotSettingsPopupOpen={setBotSettingsPopupOpen}
          refreshKnowledgeBase={() => {
            fetchKnowledgeBase();
            handleSuccess("Settings updated successfully");
          }}
        />
      )}

      {isEditPdfPopupOpen && (
        <EditPdfPopup
          setEditPdfPopupOpen={setEditPdfPopupOpen}
          refreshKnowledgeBase={() => {
            fetchKnowledgeBase();
            handleSuccess("PDF deleted successfully");
          }}
          data={selectedPdf}
        />
      )}

      {isAddPdfPopupOpen && (
        <AddPdfPopup
          setAddPdfPopupOpen={setAddPdfPopupOpen}
          refreshKnowledgeBase={() => {
            fetchKnowledgeBase();
            handleSuccess("PDF added successfully");
          }}
          pdfKeys={pdfKeys}
        />
      )}
    </div>
  );
};

export default AdminManageChatbot;
