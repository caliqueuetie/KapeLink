import React, { useState, useEffect } from "react";
import axios from "axios";
import { PencilLine, Plus, RefreshCw, Loader } from "lucide-react";
import AdminSideBar from "../../components/AdminComponents/AdminSideBar";
import AdminNavBar from "../../components/AdminComponents/AdminNavBar";
import AddCategoryPopup from "../../components/AdminComponents/AddCategoryPopup";
import EditCategoryPopup from "../../components/AdminComponents/EditCategoryPopup";
import { motion } from "framer-motion";

const CategorySection = ({ title, description, categories, handleEdit }) => (
  <>
    <h2 className="text-base sm:text-2xl font-medium ml-0 sm:ml-10 sm:mt-10">
      {title}
    </h2>
    {description && (
      <p className="ml-4 mb-3 mt-1 sm:ml-10 max-[640px]:hidden">
        {description}
      </p>
    )}
    {categories.map((category, index) => (
      <div
        key={index}
        className="flex w-80 sm:w-[91%] border border-gray-400 rounded-lg mt-3 ml-0 sm:ml-10 p-4 items-center"
      >
        <div className="flex items-center">
          <div>
            <div
              className={`w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full ${
                category.show ? "bg-green-500" : "bg-gray-500"
                }`}
            ></div>
          </div>

          <div className="ml-4">
            <h3 className="text-lg sm:text-xl font-medium">{category.name}</h3>
            {category.description && (
              <p className="max-[640px]:text-xs text-justify mr-5">
                {category.description}
              </p>
            )}
          </div>
        </div>
        <div className="ml-auto mr-1 sm:mr-5" title="Edit / Delete Category">
          <PencilLine
            size={20}
            onClick={() => handleEdit(category)}
            className="cursor-pointer"
          />
        </div>
      </div>
    ))}
  </>
);

const RefreshButton = ({ loading, onClick }) => (
  <button
    className={`flex items-center bg-gray-800 hover:bg-gray-600 duration-300 font-semibold py-2 px-4 rounded-full ${
      loading ? "bg-gray-300 text-gray-200 cursor-not-allowed" : "text-white"
      }`}
    onClick={onClick}
    disabled={loading}
    title="Refresh Category List"
  >
    {loading ? (
      <Loader className="animate-spin mr-2" size={20} />
    ) : (
      <RefreshCw className="mr-2" size={20} />
    )}
    Refresh
  </button>
);

const AddCategoryButton = ({ loading, onClick }) => (
  <div
    className={`flex w-80 sm:w-[91%] justify-center border border-gray-400 rounded-lg items-center mt-3 ml-0 sm:ml-10 mb-10 sm:mb-0 p-3 cursor-pointer hover:bg-gray-200 transition ${
      loading ? "bg-gray-300 cursor-not-allowed" : ""
      }`}
    onClick={onClick}
    title="Add New Category"
  >
    {loading ? (
      <Loader className="animate-spin" size={20} />
    ) : (
      <Plus className="text-gray-400" />
    )}
  </div>
);

const AdminManageProductCategory = () => {
  const [mainCategories, setMainCategories] = useState([]);
  const [menuCategories, setMenuCategories] = useState([]);
  const [salesCategories, setSalesCategories] = useState([]);

  const [isAddPopupOpen, setAddPopupOpen] = useState(false);
  const [isEditPopupOpen, setEditPopupOpen] = useState(false);
  const [popupType, setPopupType] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [notificationMessage, setNotificationMessage] = useState("");

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link/get-categories"
      );
      setMainCategories(response.data.mainCategories);
      setMenuCategories(response.data.menuCategories);
      setSalesCategories(response.data.salesCategories);
    } catch (error) {
      console.error("Error fetching categories:", error);
    } finally {
      setLoading(false);
    }
  };

  const openAddPopup = (type) => {
    setPopupType(type);
    setAddPopupOpen(true);
  };

  const openEditPopup = (type, category) => {
    setPopupType(type);
    setSelectedCategory(category);
    setEditPopupOpen(true);
  };

  const handleSuccess = (message) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(""), 3000);
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const toPascalCase = (str) => {
    return str.replace(/(^\w|_\w)/g, (match) =>
      match.replace("_", "").toUpperCase()
    );
  };

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <AdminSideBar />
      </div>
      <div className="sm:hidden w-full">
        <AdminNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        <div>
          {successMessage && (
            <motion.p
              initial={{ y: -100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeInOut" }}
              className="success-message"
            >
              {successMessage}
            </motion.p>
          )}

          <div className="justify-between items-center mt-2 ml-4 max-[640px]:mb-4 max-[640px]:ml-0">
            <div className="flex mb-5">
              <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap max-[640px]:mt-5">
                Manage Product Category
              </h1>
              <div className="ml-auto max-[640px]:hidden">
                <RefreshButton loading={loading} onClick={fetchCategories} />
              </div>
            </div>

            <div className="w-full border-collapse overflow-y-auto h-[520px] 2xl:h-[760px] max-[640px]:max-w-80">
              <CategorySection
                title="Main Categories"
                categories={mainCategories}
                handleEdit={(category) => openEditPopup("main", category)}
              />
              <AddCategoryButton
                loading={loading}
                onClick={() => openAddPopup("main")}
              />

              <CategorySection
                title="Menu Categories"
                description="These are categories assigned to products displayed on the menu."
                categories={menuCategories}
                handleEdit={(category) => openEditPopup("menu", category)}
              />
              <AddCategoryButton
                loading={loading}
                onClick={() => openAddPopup("menu")}
              />

              <CategorySection
                title="Sales Categories"
                description="These are categories used for sales report generation."
                categories={salesCategories}
                handleEdit={(category) => openEditPopup("sales", category)}
              />
              <AddCategoryButton
                loading={loading}
                onClick={() => openAddPopup("sales")}
              />

              {/* Popups */}
              {isAddPopupOpen && (
                <AddCategoryPopup
                  setPopupOpen={setAddPopupOpen}
                  refreshCategories={() => {
                    fetchCategories();
                    handleSuccess(
                      `${toPascalCase(popupType)} category added successfully`
                    );
                  }}
                  type={popupType}
                />
              )}
              {isEditPopupOpen && (
                <EditCategoryPopup
                  setPopupOpen={setEditPopupOpen}
                  refreshCategories={() => {
                    fetchCategories();
                    handleSuccess("Details updated successfully");
                  }}
                  data={selectedCategory}
                  type={popupType}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminManageProductCategory;
