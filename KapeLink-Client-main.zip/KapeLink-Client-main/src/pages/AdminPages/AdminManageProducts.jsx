/**
 * Admin page component to manage products.
 * Displays a product table with filters and search functionality.
 * Integrates notification popups and various components for product management actions.
 *
 * @module AdminManageProducts
 */
import AdminSideBar from "../../components/AdminComponents/AdminSideBar";
import ProductTable from "../../components/AdminComponents/ProductTable";
import React, { useState } from "react";
import TabFilters from "../../components/Global/TabFilters";
import SearchBar from "../../components/Global/SearchBar";
import AdminNavBar from "../../components/AdminComponents/AdminNavBar";
import HeaderFilterTooltip from "../../components/Global/HeaderFilterTooltip";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";

const AdminManageProducts = () => {
  const tabNames = ["All", "Available", "Hidden"];
  const [activeTab, setActiveTab] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  return (
    <>
      <div className="flex max-[640px]:flex-col">
        <div className="flex max-[640px]:hidden">
          <AdminSideBar />
        </div>
        <div className="sm:hidden w-full">
          <AdminNavBar />
        </div>

        <div className="flex justify-center items-center w-full h-full mx-7 mt-7 2xl:mx-10 2xl:mt-10 max-[640px]:m-0">
          <div>
            <div className="justify-between items-center mt-2 mb-5 ml-4 max-[640px]:mb-4 max-[640px]:ml-0">
              <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap mr-5 max-[640px]:mb-2">
                Manage Products
              </h1>

              <div className="flex items-center mt-4 mb-4 max-[640px]:flex-col-reverse max-[640px]:items-start max-[640px]:mt-0">
                <div className="flex items-center w-full max-[640px]:mt-2">
                  <div className="mr-5">
                    <TabFilters
                      tabNames={tabNames}
                      activeTab={activeTab}
                      setActiveTab={setActiveTab}
                    />
                  </div>

                  <div className="sm:hidden ml-auto">
                    <HeaderFilterTooltip />
                  </div>
                </div>

                <div className="text-right max-[640px]:w-full">
                  <div className="inline-flex items-center md:space-x-3 w-full">
                    <div className="max-[640px]:hidden">
                      <HeaderFilterTooltip />
                    </div>

                    <SearchBar
                      searchQuery={searchQuery}
                      setSearchQuery={setSearchQuery}
                    />
                  </div>
                </div>
              </div>

              <ProductTable
                activeTab={activeTab}
                searchQuery={searchQuery}
                setShowNotification={setShowNotification}
                setNotificationMessage={setNotificationMessage}
              />
            </div>
          </div>
        </div>

        <FloatingSuccessfulNotification
          showNotification={showNotification}
          notificationMessage={notificationMessage}
        />
      </div>
    </>
  );
};

export default AdminManageProducts;
