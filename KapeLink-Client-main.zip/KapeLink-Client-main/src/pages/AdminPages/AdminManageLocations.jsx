/**
 * Admin page component to manage location entries.
 * Displays a list of locations with options to edit or add new locations.
 * Utilizes popup modals for adding and editing locations, with notifications on success.
 *
 * @module AdminManageLocations
 */
import AdminSideBar from "../../components/AdminComponents/AdminSideBar";
import AdminNavBar from "../../components/AdminComponents/AdminNavBar";
import React, { useState, useEffect } from "react";
import { PencilLine, Plus } from "lucide-react";
import EditLocationsPopup from "../../components/AdminComponents/EditLocationsPopup";
import AddLocationsPopup from "../../components/AdminComponents/AddLocationsPopup";
import axios from "axios";
import FloatingSuccessfulNotification from "../../components/Global/FloatingSuccessfulNotification";

const AdminManageLocations = () => {
  const [locations, setLocations] = useState([]);
  const [isEditLocationsPopupOpen, setEditLocationsPopupOpen] = useState(false);
  const [isAddLocationsPopupOpen, setAddLocationsPopupOpen] = useState(false);
  const [selectedLocation, setSelectedLocationId] = useState(null);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationMessage, setNotificationMessage] = useState("");

  /**
   * Opens the edit popup and sets the selected location to be edited.
   *
   * @function handleEditLocationsOpenPopup
   * @param {Object} location - Location object to edit.
   * @returns {void}
   */
  const handleEditLocationsOpenPopup = (location) => {
    setSelectedLocationId(location);
    setEditLocationsPopupOpen(true);
  };

  /**
   * Opens the add location popup.
   *
   * @function handleAddLocationsOpenPopup
   * @returns {void}
   */
  const handleAddLocationsOpenPopup = () => {
    setAddLocationsPopupOpen(true);
  };

  /**
   * Fetches the list of locations from the server and updates the state.
   * Executes once on component mount to populate the list.
   *
   * @async
   * @function fetchLocations
   * @returns {Promise<void>}
   */
  const fetchLocations = async () => {
    try {
      const response = await axios.get(
        "http://localhost:9000/api/kape-link//all-locations"
      );
      setLocations(response.data); // Set the list of locations in the state
    } catch (error) {
      console.error("Error fetching locations:", error);
    }
  };

  /**
   * Triggers the initial fetch of location data when the component mounts.
   * Ensures that the `fetchLocations` function runs only once, populating the locations list with current data.
   *
   * @useEffect
   * @returns {void}
   */
  useEffect(() => {
    fetchLocations();
  }, []);

  return (
    <div className="flex max-[640px]:flex-col">
      <div className="flex max-[640px]:hidden">
        <AdminSideBar />
      </div>
      <div className="sm:hidden w-full">
        <AdminNavBar />
      </div>

      <div className="flex justify-center items-center w-full h-full m-7 2xl:m-10 max-[640px]:m-0">
        <div className="justify-between items-center mt-2 mb-5 ml-4 max-[640px]:mb-4 max-[640px]:ml-0">
          <h1 className="font-semibold text-3xl max-[640px]:text-xl whitespace-nowrap max-[640px]:mt-5">
            Manage Locations
          </h1>

          {locations.map((item, index) => (
            <div
              key={index}
              className="flex w-80 sm:w-full border border-gray-400 rounded-lg mt-3 ml-0 sm:ml-10 p-4 items-center"
            >
              <div className="flex items-center">
                <div>
                  <div
                    className={`w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-full ${
                      item.status === "Available"
                        ? "bg-green-500"
                        : "bg-gray-500"
                    }`}
                  ></div>
                </div>

                <div className="ml-4">
                  <h3 className="text-base sm:text-xl font-medium">
                    {item.locationName}
                  </h3>
                </div>
              </div>
              <div className="ml-auto mr-2 sm:mr-5">
                <PencilLine
                  size={20}
                  onClick={() => {
                    handleEditLocationsOpenPopup(item);
                  }}
                  className="cursor-pointer"
                />
              </div>
            </div>
          ))}
          <div
            className="flex w-80 sm:w-full justify-center border border-gray-400 rounded-lg items-center mt-3 ml-0 sm:ml-10 mb-10 sm:mb-0 p-3 cursor-pointer hover:bg-gray-200 transition"
            onClick={handleAddLocationsOpenPopup}
          >
            <div>
              <Plus className="text-gray-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Edit Category Description Popup */}
      {isEditLocationsPopupOpen && (
        <EditLocationsPopup
          setEditLocationsPopupOpen={setEditLocationsPopupOpen}
          currentLocation={selectedLocation}
          onLocationUpdated={fetchLocations}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}

      {/* Add Category Description Popup */}
      {isAddLocationsPopupOpen && (
        <AddLocationsPopup
          setAddLocationsPopupOpen={setAddLocationsPopupOpen}
          onLocationUpdated={fetchLocations}
          setShowNotification={setShowNotification}
          setNotificationMessage={setNotificationMessage}
        />
      )}

      <FloatingSuccessfulNotification
        showNotification={showNotification}
        notificationMessage={notificationMessage}
      />
    </div>
  );
};

export default AdminManageLocations;
