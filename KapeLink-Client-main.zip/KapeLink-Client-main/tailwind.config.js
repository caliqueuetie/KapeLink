/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
      },
      colors: {
        'custom-active': '#A79277',
        'custom-brown-border': '#A79277',
        'custom-text-hover': '#d1bb9f'
      },
      textAlign: {
        'justify': 'justify',
      },
    },
  },
  plugins: [],
}