/**
 * Express router for order-related routes.
 * Defines routes for creating orders, retrieving orders, updating tracking, 
 * managing order history, and processing payments.
 *
 * @module OrderRouter
 */
const express = require('express');
const router = express.Router();
const upload = require('../middleware/MulterImageUpload');
const {
    createOrder,
    getOrders,
    getOrder,
    updateOrderTracking,
    getOrderHistoryByCustomerId,
    getOrdersByCustomerId,
    getOrdersToday,
    getMonthlyRevenue,
    updatePayment,
    getRecentOrders,
    getUniqueYears
} = require('../controllers/OrderController')

const protectRoute = require('../middleware/ProtectRoute'); 

/**
 * Retrieves a list of all orders, sorted by order date and time.
 * 
 * @route GET /get-orders
 * @access Protected - Accessible only to baristas and managers.
 * @returns {Object[]} Array of all orders.
 */
router.get('/get-orders', protectRoute(['barista', 'manager']), getOrders);

/**
 * Retrieves a single order by its orderId.
 * 
 * @route GET /get-order/:orderId
 * @access Protected - Accessible only to customers.
 * @param {string} orderId - Unique identifier for the order.
 * @returns {Object} Order details for the specified orderId.
 */
router.get('/get-order/:orderId', protectRoute(['customer']), getOrder);

/**
 * Retrieves the order history of the customer.
 * 
 * @route GET /get-order-of-customer
 * @access Protected - Accessible only to customers.
 * @returns {Object[]} List of orders placed by the customer.
 */
router.get('/get-order-of-customer', protectRoute(['customer']), getOrderHistoryByCustomerId);

/**
 * Retrieves orders placed by a specific customer, based on the customer's customerId.
 * 
 * @route GET /get-orders/customer/:customerId
 * @access Protected - Accessible to customers, baristas, and managers.
 * @param {string} customerId - Unique identifier for the customer.
 * @returns {Object[]} Array of orders placed by the specified customer.
 */
router.get('/get-orders/customer/:customerId', protectRoute(['customer','barista','manager']), getOrdersByCustomerId);

/**
 * Updates the tracking information for an order.
 * 
 * @route PATCH /update-order-tracking
 * @access Protected - Accessible to all users.
 * @returns {Object} Updated order tracking information.
 */
router.patch('/update-order-tracking', protectRoute(['*']), updateOrderTracking);

/**
 * Creates a new order.
 * 
 * @route POST /create-order
 * @access Protected - Accessible to both baristas and customers.
 * @param {Object} req.body - Information about the order (custName, orderOption, paymentMethodId, items, deliveryDetails).
 * @param {Object} req.file - Proof of payment (optional).
 * @returns {Object} The newly created order.
 */
router.post('/create-order', upload.single('proofImage'), protectRoute(['barista', 'customer']), createOrder);

/**
 * Retrieves orders placed today.
 * 
 * @route GET /get-orders-today
 * @access Protected - Accessible only to managers.
 * @returns {Object[]} Array of orders placed today.
 */
router.get('/get-orders-today', protectRoute(['manager']), getOrdersToday);

/**
 * Retrieves the total monthly revenue for a specified year.
 * 
 * @route GET /get-monthly-revenue/:year
 * @access Protected - Accessible only to managers.
 * @param {string} year - The year for which to fetch the monthly revenue.
 * @returns {Object} Monthly revenue data for the specified year.
 */
router.get('/get-monthly-revenue/:year', protectRoute(['manager']), getMonthlyRevenue);

/**
 * Retrieves a list of recent orders for a customer.
 * 
 * @route GET /get-recent-orders/:customerId
 * @access Protected - Accessible only to customers.
 * @param {string} customerId - Unique identifier for the customer.
 * @returns {Object[]} Array of recent orders placed by the specified customer.
 */
router.get('/get-recent-orders/:customerId', protectRoute(['customer']), getRecentOrders);

/**
 * Updates the proof of payment for an order.
 * 
 * @route PATCH /reupload-payment/:orderId
 * @access Protected - Accessible only to customers.
 * @param {string} orderId - Unique identifier for the order.
 * @param {Object} req.file - New proof of payment.
 * @returns {Object} Updated payment information for the order.
 */
router.patch('/reupload-payment/:orderId', upload.single('proofImage'), protectRoute(['customer']), updatePayment)

/**
 * Retrieves the unique years for which orders exist.
 * 
 * @route GET /get-unique-years
 * @access Protected - Accessible only to managers.
 * @returns {Object[]} List of unique years based on order data.
 */
router.get('/get-unique-years/', protectRoute(['manager']), getUniqueYears)

module.exports = router;
