const express = require('express');
const router = express.Router();
const {
    getAllOrdersByStatus,
    updatePaymentStatus
} = require('../controllers/PaymentController');
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

//Public routes
router.get('/get-all-orders-by-verification-status', protectRoute(['manager']), getAllOrdersByStatus);
router.patch('/update-payment-status/:orderId', protectRoute(['manager']), updatePaymentStatus);

module.exports = router;