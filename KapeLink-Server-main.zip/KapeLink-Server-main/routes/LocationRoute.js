/**
 * Express router for location management routes.
 * Defines routes for fetching, creating, updating, and deleting locations.
 *
 * @module LocationRouter
 */
const express = require("express");
const router = express.Router();
const {
  getAllLocations,
  getAvailableLocations,
  createLocation,
  updateLocation,
  updateLocationStatus,
  getLocationByName,
  deleteLocation,
} = require("../controllers/LocationController");

const protectRoute = require("../middleware/ProtectRoute"); // Import the middleware

/**
 * @route GET /all-locations
 * @description Fetches all locations (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.get("/all-locations", protectRoute(["admin"]), getAllLocations);

/**
 * @route GET /get-locations
 * @description Fetches locations with the status 'Available' (Protected for Customer).
 * @access Protected (Customer only)
 */
router.get("/get-locations", protectRoute(["customer"]), getAvailableLocations);

/**
 * @route GET /get-location-by-name/:locationName
 * @description Fetches a location by its name (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.get(
  "/get-location-by-name/:locationName",
  protectRoute(["admin"]),
  getLocationByName
);

/**
 * @route POST /create-location
 * @description Creates a new location (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.post("/create-location", protectRoute(["admin"]), createLocation);

/**
 * @route PATCH /update-location/:locationId
 * @description Updates the details of a location (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.patch(
  "/update-location/:locationId",
  protectRoute(["admin"]),
  updateLocation
);

/**
 * @route PATCH /update-location-status/:locationId
 * @description Updates the status of a location (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.patch(
  "/update-location-status/:locationId",
  protectRoute(["admin"]),
  updateLocationStatus
);

/**
 * @route DELETE /delete-location/:id
 * @description Deletes a location (Protected for Admin only).
 * @access Protected (Admin only)
 */
router.delete("/delete-location/:id", protectRoute(["admin"]), deleteLocation);

module.exports = router;
