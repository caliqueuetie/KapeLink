const express = require('express');
const router = express.Router();
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

const {
    createUser,
    getUser,
    checkUser,
    getAllCustomers,
    updateUser,
    getLatestUser, 
    getAllUsers,
    updateUserStatus,
    createCustomer,
    deleteUser,
    updateCustomerPassword,
    getUserNames
} = require('../controllers/UserController');

// Route to create a customer (Public)
router.post('/create-customer', createCustomer);

// Route to check a single user by userId (Public)
router.get('/check-user/:data', checkUser);

// Route to get latest user (Public)
router.get('/get-latest', getLatestUser);

// Route to create a user
router.post('/create-user', protectRoute(['admin']), createUser);

// Route to get a single user by userId
router.get('/get-user/:data', protectRoute(['*']), getUser);

// Route to get all customers
router.get('/get-customers', protectRoute(['*']), getAllCustomers);

// Route to update user profile
router.patch('/update-user/:userId', protectRoute(['admin' , 'customer']), updateUser);

// Route to update customer password
router.patch('/update-customer-password/:userId', protectRoute(['customer']), updateCustomerPassword);

// Route to get all users
router.get('/get-users', protectRoute(['admin']), getAllUsers);

// Route to update user status
router.patch('/update-user-status/:userId', protectRoute(['admin']), updateUserStatus);

// Route to delete user
router.delete('/delete-user/:userId', protectRoute(['admin']), deleteUser);

// Route to get user names
router.post('/get-user-names', protectRoute(['*']), getUserNames);

module.exports = router;
