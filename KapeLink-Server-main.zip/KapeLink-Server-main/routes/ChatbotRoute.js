/**
 * Express router for chatbot-related routes.
 * Defines routes for getting chatbot credentials, uploading PDFs,
 * creating/updating chatbot credentials, and reporting chatbot errors.
 *
 * @module ChatbotRouter
 */
const express = require("express");
const router = express.Router();
const {
  getChatbotCredentials,
  uploadPDF,
  upsertChatbotCredentials,
  upsertChatbotError,
} = require("../controllers/ChatbotController");
const protectRoute = require("../middleware/ProtectRoute"); // Import the middleware

/**
 * Route to create or update chatbot credentials.
 * Protects the route for the 'admin' role and performs the upsert (insert or update) of chatbot credentials.
 *
 * @route PUT /credentials
 * @access Protected (All roles)
 */
router.get("/credentials", protectRoute(["*"]), getChatbotCredentials);

/**
 * Route to upload a PDF file.
 * Protects the route for the 'admin' role and allows uploading a PDF file as raw data.
 *
 * @route PUT /upload-pdf/:uploadUrl
 * @access Protected (Admin only)
 * @param {string} uploadUrl - URL for the PDF upload destination.
 * @body {Buffer} - The raw PDF file.
 */
router.put(
  "/upload-pdf/:uploadUrl",
  protectRoute(["admin"]),
  express.raw({ type: "application/octet-stream", limit: "10mb" }),
  uploadPDF
);

/**
 * Route to create or update chatbot credentials.
 * Protects the route for the 'admin' role and performs the upsert (insert or update) of chatbot credentials.
 *
 * @route PUT /credentials
 * @access Protected (Admin only)
 */
router.put("/credentials", protectRoute(["admin"]), upsertChatbotCredentials);

/**
 * Route to report chatbot errors.
 * Protects the route for the 'customer' role and allows reporting chatbot errors.
 *
 * @route PUT /chatbot-error
 * @access Protected (Customer only)
 */
router.put("/chatbot-error", protectRoute(["customer"]), upsertChatbotError);

module.exports = router;
