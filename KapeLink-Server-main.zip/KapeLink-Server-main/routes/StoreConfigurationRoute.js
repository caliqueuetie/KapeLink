const express = require("express");
const router = express.Router();
const StoreConfigurationController = require("../controllers/StoreConfigurationController");
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

router.patch("/store-opening-time", protectRoute(['admin']), StoreConfigurationController.setOpeningTime);
router.patch("/store-closing-time", protectRoute(['admin']), StoreConfigurationController.setClosingTime);
router.patch("/store-hours-status", protectRoute(['admin']), StoreConfigurationController.setStatus);
router.get('/current-store-hour', protectRoute(['admin']), StoreConfigurationController.getStoreConfiguration);


module.exports = router;
