/**
 * Express router for email-related routes.
 * Defines routes for getting email credentials and creating/updating email credentials.
 *
 * @module EmailRouter
 */
const express = require("express");
const router = express.Router();
const {
  getEmailCredentials,
  upsertEmailCredentials,
} = require("../controllers/EmailController");
const protectRoute = require("../middleware/ProtectRoute");

/**
 * @route GET /email
 * @description Fetches the email credentials for the Nodemailer service (Public).
 * @access Public
 */
router.get("/email", getEmailCredentials);

/**
 * @route PUT /email
 * @description Creates or updates the Nodemailer email credentials.
 * @access Protected (Admin only)
 */
router.put("/email", protectRoute(["admin"]), upsertEmailCredentials);

module.exports = router;
