const express = require('express');
const router = express.Router();
const multer = require('multer');
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

const {
  getAllPaymentMethods,
  getPaymentMethods,
  getPaymentName,
  updatePaymentStatus,
  updatePayment,
  addPaymentMethod,
  deletePaymentMethod
} = require('../controllers/PaymentMethodController');

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/payment_method');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

router.get('/get-all-payment-methods', protectRoute(['*']), getAllPaymentMethods);
router.get('/get-payment-methods', protectRoute(['*']), getPaymentMethods);
router.post('/add-payment-method', upload.single('img'), protectRoute(['admin']), addPaymentMethod);
router.delete('/delete-payment-method/:id', protectRoute(['admin']), deletePaymentMethod);
router.get('/get-payment-methods/:opid', protectRoute(['*']), getPaymentName);
router.patch('/update-payment-status', protectRoute(['manager']), updatePaymentStatus);
router.patch('/update-payment-information/:id', upload.fields([{ name: 'img', maxCount: 1 }]), protectRoute(['admin']), updatePayment);


module.exports = router;
