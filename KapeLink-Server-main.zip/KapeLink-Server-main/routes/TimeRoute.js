const express = require('express');
const router = express.Router();
const getTime = require('../controllers/TimeController')
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

router.get('/get-time', protectRoute(['customer']), getTime);

module.exports = router;