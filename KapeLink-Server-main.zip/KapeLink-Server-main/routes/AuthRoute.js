/**
 * Express router for authentication-related routes.
 * Defines routes for login, authentication, OTP verification, password recovery, and logout.
 *
 * @module AuthRouter
 */
const express = require('express');
const router = express.Router();
const authController = require('../controllers/AuthController');
const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

/**
 * Login route (Public)
 * Allows users to log in to their account by providing valid credentials.
 * 
 * @name POST /login
 * @function
 * @param {string} email - The user's email address or contact number.
 * @param {string} password - The user's password.
 */
router.post('/login', authController.login);

/**
 * Auth route (Protected)
 * Verifies user authentication for any role.
 * 
 * @name GET /auth
 * @function
 * @param {Array<string>} roles - Array containing `'*'`, allowing access for any role.
 */
router.get('/auth', protectRoute(['*']), authController.auth)

/**
 * OTP verification route (Protected)
 * Allows 'customer' role to verify a one-time password (OTP) for additional authentication.
 * 
 * @name POST /otp-verify
 * @function
 * @param {string} otp - The one-time password entered by the user.
 * @param {Array<string>} roles - Array containing `'customer'`, allowing access to to customers.
 */
router.post('/otp-verify', protectRoute(['customer']), authController.otpVerify);

/**
 * Forgot password route (Protected)
 * Allows 'customer' role to initiate password recovery.
 * 
 * @name POST /forgot-password
 * @function
 * @param {string} email - The user's email address for password recovery.
 * @param {Array<string>} roles - Array containing `'customer'`, allowing access to to customers.
 */
router.post('/forgot-password', protectRoute(['customer']), authController.forgotPassword)

/**
 * Logout route (Protected)
 * Logs out the user, available to any role.
 * 
 * @name POST /logout
 * @function
 * @param {Array<string>} roles - Array containing `'*'`, allowing access for any role.
 */
router.post('/logout', protectRoute(['*']), authController.logout);

module.exports = router;
