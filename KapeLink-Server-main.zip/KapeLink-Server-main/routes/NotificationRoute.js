/**
 * Express router for notification management routes.
 * Defines routes for creating, fetching, updating, and sending notifications.
 *
 * @module NotificationRouter
 */
const express = require("express");
const router = express.Router();
const {
  createNotification,
  getNotifications,
  toggleNotificationRead,
  getNotificationsByCustomerID,
  saveSubscription,
  sendNotification,
  sendBatchNotification,
  checkSubscription,
  markAllAsRead
} = require("../controllers/NotificationController");
const protectRoute = require("../middleware/ProtectRoute");

/**
 * @route POST /create-notification
 * @description Creates a new notification.
 * @access Protected for all roles
 */
router.post("/create-notification", protectRoute(["*"]), createNotification);

/**
 * @route GET /get-notifications
 * @description Fetches all notifications with optional query parameters to filter by receiver or roles.
 * @access Protected for all roles
 */
router.get("/get-notifications", protectRoute(["*"]), getNotifications);

/**
 * @route PUT /toggle-notification-read/:id
 * @description Toggles the read/unread status of a notification by its ID.
 * @access Protected for all roles
 */
router.put(
  "/toggle-notification-read/:id",
  protectRoute(["*"]),
  toggleNotificationRead
);

/**
 * @route PUT /toggle-notifications-read
 * @description Marks all notifications as read for specific roles (e.g., "barista", "manager").
 * @access Protected for all roles
 */
router.put(
  "/toggle-notifications-read",
  protectRoute(["*"]), 
  markAllAsRead 
);

/**
 * @route GET /get-notifications-by-customer-id
 * @description Fetches notifications for a specific customer based on their customer ID.
 * @access Protected for all roles
 */
router.get(
  "/get-notifications-by-customerid/:id",
  protectRoute(["*"]),
  getNotificationsByCustomerID
);

/**
 * @route POST /save-subscription
 * @description Saves a new subscription for notifications.
 * @access Protected for all roles
 */
router.post("/save-subscription", protectRoute(["*"]), saveSubscription);

/**
 * @route POST /send-batch-notification
 * @description Sends notifications to a batch of recipients (multiple users).
 * @access Protected for all roles
 */
router.post(
  "send-batch-notifications",
  protectRoute(["*"]),
  sendBatchNotification
);

/**
 * @route POST /send-notification
 * @description Sends a notification (e.g., push notification, email) to one or more users.
 * @access Protected for all roles
 */
router.post("/send-notification", protectRoute(["*"]), sendNotification);

/**
 * @route GET /check-subscription
 * @description Checks if the user has an active subscription for notifications.
 * @access Protected for all roles
 */
router.get(
  "/check-subscription/:userId",
  protectRoute(["*"]),
  checkSubscription
);

module.exports = router;
