/**
 * Express router for category management routes.
 * Defines routes for fetching, creating, updating, and deleting categories.
 *
 * @module CategoryRouter
 */
const express = require('express');
const router = express.Router();
const {
  getAllCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory
} = require('../controllers/CategoriesController');

const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

/**
 * Route to get all categories (Protected)
 * Retrieves a list of all categories, accessible to any role.
 * 
 * @name GET /get-categories
 * @function
 * @param {Array<string>} roles - Array containing `'*'`, allowing access for any role.
 */
router.get('/get-categories', protectRoute(['*']), getAllCategories);

/**
 * Route to get a specific category by ID and type (Protected)
 * Retrieves details of a specific category, accessible to any role.
 * 
 * @name POST /get-category
 * @function
 * @param {string} id - The unique identifier of the category.
 * @param {string} type - The type of the category (e.g., main, menu, sales).
 * @param {Array<string>} roles - Array containing `'*'`, allowing access for any role.
 */
router.post('/get-category', protectRoute(['*']), getCategory);

/**
 * Route to create a new category (Protected)
 * Allows only an 'admin' role to add a new category to the collection.
 * 
 * @name POST /create-category
 * @function
 * @param {Object} category - The new category data including name, description, and type.
 * @param {Array<string>} roles - Array containing `'admin'`, allowing access to admins only.
 */
router.post('/create-category', protectRoute(['admin']), createCategory);

/**
 * Route to update an existing category (Protected)
 * Allows only an 'admin' role to modify category details by ID.
 * 
 * @name PUT /update-category
 * @function
 * @param {string} id - The unique identifier of the category to be updated.
 * @param {Object} updates - The updated category details including name, description, and type.
 * @param {Array<string>} roles - Array containing `'admin'`, allowing access to admins only.
 */
router.put('/update-category', protectRoute(['admin']), updateCategory);

/**
 * Route to delete a category by ID and type (Protected)
 * Allows only an 'admin' role to remove a category from the collection.
 * 
 * @name DELETE /delete-category
 * @function
 * @param {string} id - The unique identifier of the category to be deleted.
 * @param {string} type - The type of the category (e.g., main, menu, sales).
 * @param {Array<string>} roles - Array containing `'admin'`, allowing access to admins only.
 */
router.delete('/delete-category', protectRoute(['admin']), deleteCategory);

module.exports = router;
