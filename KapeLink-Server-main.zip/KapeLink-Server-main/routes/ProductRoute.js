const express = require('express');
const router = express.Router();

const {
    getAllProducts,
    getProducts,
    createProduct,
    getProduct,
    updateProduct,
    updateProductStatus,
    deleteProduct,
    filterProducts
} = require('../controllers/ProductController');

const protectRoute = require('../middleware/ProtectRoute'); // Import the middleware

// Protected routes
router.get('/all-products', protectRoute(['admin', 'barista']), getAllProducts);
router.get('/get-products', protectRoute(['*']), getProducts);
router.get('/get-product/:prodId', protectRoute(['*']), getProduct);
router.post('/filter-products', protectRoute(['*']), filterProducts);
router.post('/create-product', protectRoute(['admin']), createProduct);
router.patch('/update-product/:prodId', protectRoute(['admin']), updateProduct);
router.patch('/update-product-status/:prodId', protectRoute(['admin', 'barista']), updateProductStatus);
router.delete('/delete-product/:prodId', protectRoute(['admin']), deleteProduct);

module.exports = router;
