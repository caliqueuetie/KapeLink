const { Order, PickupOrder, DeliveryOrder } = require("../models/OrderModel");
const PaymentMethod = require("../models/PaymentModel");
const getDateAndTime = require("../helpers/DateTimeHelper");
const { customerTransactionPath } = require("../helpers/ImagePathHelper");
const {
  sendNotification,
  createNotification,
} = require("./NotificationController");
/**
 * Retrieves all orders with specified verification statuses and non-cash payment methods.
 * Enhances the orders by mapping payment method IDs to their corresponding names and appending
 * the transaction path to available proof of payment URLs.
 *
 * @async
 * @function getAllOrdersByStatus
 * @param {Object} req - The Express request object, containing client request data.
 * @param {Object} res - The Express response object used to send back the processed orders or an error message.
 *
 * @returns {Promise<void>} - Sends a 200 response containing the list of orders that meet the specified criteria,
 * including enhanced payment method names and proof of payment URLs if available.
 *
 * @throws {Error} - Sends a 500 response with an error message if the operation fails.
 */
const getAllOrdersByStatus = async (req, res) => {
  try {
    // Fetch all payment methods to create a mapping of opid to name
    const paymentMethods = await PaymentMethod.find({});
    const paymentMethodsMap = paymentMethods.reduce((acc, method) => {
      acc[method.opid] = method.name; // Map opid to name
      return acc;
    }, {});

    // Fetch all orders with specific verification statuses and non-cash payment methods
    const orders = await Order.find({
      paymentMethodId: { $ne: 1 }, // Exclude cash payment
      verificationStatus: {
        $in: ["Verified", "Not Verified", "Returned", "Rejected"],
      },
    });

    // Replace paymentMethodId with its corresponding name
    const updatedOrders = orders.map((order) => {
      const paymentName = paymentMethodsMap[order.paymentMethodId] || "Unknown";
      return {
        ...order.toObject(),
        paymentMethodName: paymentName, // Add the payment method name
      };
    });

    // Update proofOfPayment URLs
    updatedOrders.forEach((order) => {
      if (order.proofOfPayment && order.proofOfPayment.trim() !== "") {
        order.proofOfPayment = customerTransactionPath() + order.proofOfPayment;
      }
    });

    console.log(updatedOrders);
    res.status(200).json(updatedOrders);
  } catch (error) {
    console.error("Failed to fetch orders by status:", error);
    res.status(500).json({ error: "Failed to fetch orders by status" });
  }
};

/**
 * Updates the payment verification status of an order, including optional reason and tracking status update.
 * Triggers socket events for tracking and order updates if the status is "Verified".
 *
 * @async
 * @function updatePaymentStatus
 * @param {Object} req - The request object containing orderId as a route parameter.
 * @param {Object} req.body - The request body with the new verification status and optional reason.
 * @param {Object} res - The response object to send back the update status or error message.
 *
 * @returns {Promise<void>} - Sends a 200 response with a success message and updated order details.
 *
 * @throws {Error} - Returns a 500 status with an error message if updating the payment status or tracking fails.
 */
const updatePaymentStatus = async (req, res) => {
  const { orderId } = req.params;
  const { status, reason } = req.body;
  const { time } = getDateAndTime();

  const statusMessages = {
    Verified: `Your payment for the order with the ID ${orderId} has been verified.`,
    Returned: `Your payment for the order with the ID ${orderId} has been returned for the reason: ${reason}.`,
    Rejected: `Your payment for the order with the ID ${orderId} has been rejected for the reason: ${reason}.`,
  };

  try {
    const updateData = { verificationStatus: status };
    if (reason) updateData.reason = reason;

    const updatedOrder = await Order.findOneAndUpdate(
      { orderId: orderId },
      updateData,
      { new: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({ error: "Order not found!" });
    }

    // Additional logic for updating tracking if status is "Verified"
    if (status === "Verified") {
      const newTrackingEntry = { timestamp: time, orderStatus: "Preparing" };
      const orderOption = updatedOrder.orderOption;

      let trackingUpdateResult;
      if (orderOption === "Pickup") {
        trackingUpdateResult = await PickupOrder.findOneAndUpdate(
          { orderId: orderId },
          { $push: { tracking: newTrackingEntry } },
          { new: true }
        );
      } else if (orderOption === "Delivery") {
        trackingUpdateResult = await DeliveryOrder.findOneAndUpdate(
          { orderId: orderId },
          { $push: { tracking: newTrackingEntry } },
          { new: true }
        );
      }

      if (!trackingUpdateResult) {
        return res.status(500).json({
          error: "Failed to update tracking status after payment verification",
        });
      }

      const io = req.app.get("socketio");
      io.emit("orderStatusUpdated", trackingUpdateResult);
      io.emit("orderDetails", trackingUpdateResult);
    }

    const io = req.app.get("socketio");
    io.emit("orderDetails", updatedOrder);
    io.emit("userOrders");

    // Construct notification data
    const notificationMessage = statusMessages[status];
    const notificationData = {
      receiver: updatedOrder.customerId,
      roles: ["customer"],
      message: notificationMessage,
      date: new Date().toLocaleDateString(),
      time: new Date().toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }),
      readStatus: false,
    };

    // Call createNotification function with structured req/res objects
    await createNotification(
      { body: { ...notificationData } }, // Mock request object with notification data
      {
        status: (statusCode) => ({
          json: (response) => {
            console.log(
              `Notification created with status ${statusCode}:`,
              response
            );
          },
        }),
      } // Mock response object
    );

    // Send notification to the frontend if needed
    await sendNotification({
      userId: updatedOrder.customerId,
      notificationPayload: {
        title: `Order Payment ${status}!`,
        body: notificationMessage,
        order: updatedOrder,
      },
    });

    res.status(200).json({
      message: `Order ${orderId} was successfully marked as ${status.toLowerCase()}.`,
      order: updatedOrder,
    });
  } catch (error) {
    console.error("Failed to update payment status:", error);
    res.status(500).json({ error: "Failed to verify the payment." });
  }
};

module.exports = {
  getAllOrdersByStatus,
  updatePaymentStatus,
};
