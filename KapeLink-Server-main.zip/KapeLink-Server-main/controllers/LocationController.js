const Location = require("../models/LocationModel");

/**
 * Fetches all locations from the database.
 * Returns the list of locations.
 *
 * @function getAllLocations
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - An array of locations.
 *
 * @throws {Error} If there is an issue fetching the locations from the database.
 */
const getAllLocations = async (req, res) => {
  try {
    const locations = await Location.find();
    res.status(200).json(locations);
  } catch (error) {
    console.error("Error fetching all locations:", error);
    res.status(500).json({ message: "Error fetching locations", error });
  }
};

/**
 * Fetches all locations with a status of 'Available' for customer use.
 * Returns the list of available locations.
 *
 * @function getAvailableLocations
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - An array of available locations.
 *
 * @throws {Error} If there is an issue fetching the available locations from the database.
 */
const getAvailableLocations = async (req, res) => {
  const location = await Location.find({ status: "Available" });
  res.status(200).json(location);
};

/**
 * Creates a new location with the provided location name.
 * Sets a unique location ID based on the current count of locations and assigns a default status of 'Available'.
 * Emits a real-time update to connected clients and returns the new location details in the response.
 *
 * @function createLocation
 * @param {Object} req - The request object, containing the location name in the body.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The newly created location's details.
 *
 * @throws {Error} If there is an issue creating the location or communicating with the database.
 */
const createLocation = async (req, res) => {
  const { locationName } = req.body;

  console.log(req.body);

  if (!locationName) {
    return res.status(400).json({ message: "Location name is required" });
  }

  try {
    const locationCount = await Location.countDocuments();
    const newLocationId = locationCount + 1;

    console.log(`New Location ID: ${newLocationId}`);

    const status = "Available";
    const newLocation = await Location.create({
      locationId: newLocationId,
      locationName,
      status,
    });

    const io = req.app.get("socketio");
    io.emit("locations", newLocation);
    res.status(201).json(newLocation);
    console.log("Location created successfully:", newLocation);
  } catch (error) {
    console.error("Error creating location:", error);
    res.status(500).json({ message: "Error creating location", error });
  }
};

/**
 * Updates an existing location's name and status based on the provided location ID.
 * Emits a real-time update to connected clients and returns the updated location details in the response.
 *
 * @function updateLocation
 * @param {Object} req - The request object, containing the location ID in the URL parameters and updated location details in the body.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The updated location's details.
 *
 * @throws {Error} If there is an issue updating the location in the database or if the location is not found.
 */
const updateLocation = async (req, res) => {
  const { locationId } = req.params;

  const { locationName, status } = req.body;

  try {
    const updatedLocation = await Location.findByIdAndUpdate(
      locationId,
      { locationName, status },
      { new: true }
    );

    if (!updatedLocation) {
      return res.status(404).json({ message: "Location not found" });
    }

    const io = req.app.get("socketio");
    io.emit("locations", updatedLocation);
    res.status(200).json(updatedLocation);
  } catch (error) {
    res.status(500).json({ message: "Error updating location", error });
  }
};

/**
 * Updates the status of a specific location based on the provided location ID.
 * Emits a real-time update to connected clients and returns the updated location status in the response.
 *
 * @function updateLocationStatus
 * @param {Object} req - The request object, containing the location ID in the URL parameters and the new status in the body.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The updated location's status.
 *
 * @throws {Error} If there is an issue updating the location status in the database or if the location is not found.
 */
const updateLocationStatus = async (req, res) => {
  const { locationId } = req.params;
  const { status } = req.body;

  try {
    const updatedLocation = await Location.findByIdAndUpdate(
      locationId,
      { status },
      { new: true }
    );

    if (!updatedLocation) {
      return res.status(404).json({ message: "Location not found" });
    }

    const io = req.app.get("socketio");
    io.emit("locations", updatedLocation);
    res.status(200).json(updatedLocation);
  } catch (error) {
    res.status(500).json({ message: "Error updating location status", error });
  }
};

/**
 * Retrieves a location by its name in a case-insensitive manner.
 * Returns the full location object if found.
 *
 * @function getLocationByName
 * @param {Object} req - The request object, containing the location name in the URL parameters.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The location's details if found.
 *
 * @throws {Error} If there is an issue fetching the location from the database.
 */
const getLocationByName = async (req, res) => {
  const { locationName } = req.params;

  try {
    const location = await Location.findOne({
      locationName: { $regex: new RegExp(`^${locationName}$`, "i") },
    });

    if (!location) {
      return res.end();
    }

    res.status(200).json(location);
    console.log("Fetched Location:", location);
  } catch (error) {
    res.status(500).json({ message: "Error fetching location", error });
  }
};

/**
 * Deletes a location by its ID.
 * Emits a real-time update to connected clients and returns a success message upon deletion.
 *
 * @function deleteLocation
 * @param {Object} req - The request object, containing the location ID in the URL parameters.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A JSON response confirming the deletion of the location.
 *
 * @throws {Error} If there is an issue deleting the location from the database or if the location is not found.
 */
const deleteLocation = async (req, res) => {
  const { id } = req.params;

  console.log(id);

  try {
    const deletedLocation = await Location.findByIdAndDelete(id);

    if (!deletedLocation) {
      return res.status(404).json({ message: "Location not found" });
    }

    const io = req.app.get("socketio");
    io.emit("locations", deletedLocation);
    res.status(200).json({ message: "Location deleted successfully" });
  } catch (error) {
    console.error("Error deleting location:", error);
    res.status(500).json({ message: "Error deleting location", error });
  }
};

module.exports = {
  getAllLocations,
  getAvailableLocations,
  createLocation,
  updateLocation,
  updateLocationStatus,
  getLocationByName,
  deleteLocation,
};
