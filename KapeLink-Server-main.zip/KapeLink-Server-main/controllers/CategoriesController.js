const Category = require("../models/CategoriesModel");

/**
 * Controller to get all categories.
 *
 * @function getAllCategories
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns categories data or 404 if none found.
 */
const getAllCategories = async (req, res) => {
  try {
    const categories = await Category.findOne({});
    if (!categories) {
      return res.status(404).json({ message: "No categories found" });
    }
    res.status(200).json(categories);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Controller to get one category by type.
 *
 * @function getCategory
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns selected category data or 404 if not found.
 */
const getCategory = async (req, res) => {
  const { type } = req.body;

  try {
    // Fetch the category document
    const categories = await Category.findOne({});

    if (!categories) {
      return res.status(404).json({ message: "No categories found" });
    }

    // Determine which category to return based on type
    let category;
    switch (type) {
      case "main":
        category = categories.mainCategories;
        break;
      case "menu":
        category = categories.menuCategories;
        break;
      case "sales":
        category = categories.salesCategories;
        break;
      default:
        return res.status(400).json({ message: "Invalid category type" });
    }

    // Return the selected category array
    if (!category) {
      return res.status(404).json({ message: "Category not found" });
    }

    res.status(200).json(category);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Controller to create a new category.
 *
 * @function createCategory
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns created category or 400 for invalid type.
 */
const createCategory = async (req, res) => {
  const { type, id, name, description, show } = req.body;

  try {
    let categories = await Category.findOne({});
    if (!categories) {
      categories = new Category({
        mainCategories: [],
        menuCategories: [],
        salesCategories: [],
      });
    }

    switch (type) {
      case "main":
        categories.mainCategories.push({ id, name, description, show });
        break;
      case "menu":
        categories.menuCategories.push({ id, name, show });
        break;
      case "sales":
        categories.salesCategories.push({ id, name, show });
        break;
      default:
        return res.status(400).json({ message: "Invalid category type" });
    }

    const newCategory = await categories.save();
    res.status(201).json(newCategory);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Controller to update an existing category by type and id.
 *
 * @function updateCategory
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns updated category or 404 if not found.
 */
const updateCategory = async (req, res) => {
  const { type, id, name, description, show } = req.body;
  const io = req.app.get("socketio");

  try {
    const categories = await Category.findOne({});
    if (!categories) {
      return res.status(404).json({ message: "No categories found" });
    }

    let category;
    switch (type) {
      case "main":
        category = categories.mainCategories.find((cat) => cat.id == id);
        if (category) {
          category.name = name;
          category.description = description;
          category.show = show;
        }
        break;
      case "menu":
        category = categories.menuCategories.find((cat) => cat.id == id);
        if (category) {
          category.name = name;
          category.show = show;
        }
        break;
      case "sales":
        category = categories.salesCategories.find((cat) => cat.id == id);
        if (category) {
          category.name = name;
          category.show = show;
        }
        break;
      default:
        return res.status(400).json({ message: "Invalid category type" });
    }

    if (!category)
      return res.status(404).json({ message: "Category not found" });

    await categories.save();
    io.emit("updatedCategory");
    res.status(200).json(category);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Controller to delete a category by type and id.
 *
 * @function deleteCategory
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns success message or 404 if not found.
 */
const deleteCategory = async (req, res) => {
  const { type, id } = req.body;

  try {
    const categories = await Category.findOne({});
    if (!categories) {
      return res.status(404).json({ message: "No categories found" });
    }

    let categoryIndex;
    switch (type) {
      case "main":
        categoryIndex = categories.mainCategories.findIndex(
          (cat) => cat.id == id
        );
        if (categoryIndex !== -1)
          categories.mainCategories.splice(categoryIndex, 1);
        break;
      case "menu":
        categoryIndex = categories.menuCategories.findIndex(
          (cat) => cat.id == id
        );
        if (categoryIndex !== -1)
          categories.menuCategories.splice(categoryIndex, 1);
        break;
      case "sales":
        categoryIndex = categories.salesCategories.findIndex(
          (cat) => cat.id == id
        );
        if (categoryIndex !== -1)
          categories.salesCategories.splice(categoryIndex, 1);
        break;
      default:
        return res.status(400).json({ message: "Invalid category type" });
    }

    if (categoryIndex === -1)
      return res.status(404).json({ message: "Category not found" });

    await categories.save();
    res.status(200).json({ message: "Category deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {
  getAllCategories,
  getCategory,
  createCategory,
  updateCategory,
  deleteCategory
};
