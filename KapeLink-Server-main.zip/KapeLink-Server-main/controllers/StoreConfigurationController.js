const StoreConfiguration = require("../models/StoreConfigurationModel");

/**
 * Fetches the current store configuration including storeId, opening time, closing time, and status.
 * If the store configuration is not found, a 404 error is returned.
 * If there is an error fetching the configuration, a 500 error is returned.
 *
 * @function getStoreConfiguration
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A JSON response containing the store configuration if found.
 *
 * @throws {Error} If there is an error while fetching the store configuration from the database.
 */

const getStoreConfiguration = async (req, res) => {
  try {
    const config = await StoreConfiguration.findOne();
    if (!config) {
      return res.status(404).json({ message: "Store configuration not found" });
    }
    res.status(200).json({
      storeId: config.storeId,
      openingTime: config.openingTime,
      closingTime: config.closingTime,
      status: config.status,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Error fetching store configuration", error });
  }
};

/**
 * Updates the opening time for the store with a given storeId.
 * If the store configuration is not found, a 404 error is returned.
 * If the opening time is successfully updated, a success message is returned.
 * If there are no changes to the opening time, a message indicating no changes is returned.
 *
 * @function setOpeningTime
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request.
 * @param {string} req.body.storeId - The ID of the store whose opening time is to be updated.
 * @param {Object} req.body.openingTime - The new opening time to be set for the store.
 * @param {number} req.body.openingTime.hours - The hours of the opening time.
 * @param {number} req.body.openingTime.minutes - The minutes of the opening time.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the opening time is updated or if no changes are detected.
 *
 * @throws {Error} If there is an error while updating the store's opening time in the database.
 */
const setOpeningTime = async (req, res) => {
  const { storeId, openingTime } = req.body;

  try {
    let config = await StoreConfiguration.findOne({ storeId: 1 });

    if (!config) {
      return res
        .status(404)
        .json({ message: "Store configuration with storeId 1 not found" });
    }

    if (
      config.openingTime.hours !== openingTime.hours ||
      config.openingTime.minutes !== openingTime.minutes
    ) {
      config.openingTime = openingTime;
      await config.save();
      return res
        .status(200)
        .json({ message: "Opening time updated successfully" });
    } else {
      return res
        .status(200)
        .json({ message: "No changes detected for opening time" });
    }
  } catch (error) {
    console.error("Error in setOpeningTime:", error);
    return res
      .status(500)
      .json({ message: "Error setting opening time", error });
  }
};

/**
 * Updates the closing time for the store with a given storeId.
 * If the store configuration is not found, a 404 error is returned.
 * If the closing time is successfully updated, a success message is returned.
 * If there are no changes to the closing time, a message indicating no changes is returned.
 *
 * @function setClosingTime
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request.
 * @param {string} req.body.storeId - The ID of the store whose closing time is to be updated.
 * @param {Object} req.body.closingTime - The new closing time to be set for the store.
 * @param {number} req.body.closingTime.hours - The hours of the closing time.
 * @param {number} req.body.closingTime.minutes - The minutes of the closing time.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the closing time is updated or if no changes are detected.
 *
 * @throws {Error} If there is an error while updating the store's closing time in the database.
 */
const setClosingTime = async (req, res) => {
  const { storeId, closingTime } = req.body;

  try {
    let config = await StoreConfiguration.findOne({ storeId: 1 });

    if (!config) {
      return res
        .status(404)
        .json({ message: "Store configuration with storeId 1 not found" });
    }

    if (
      config.closingTime.hours !== closingTime.hours ||
      config.closingTime.minutes !== closingTime.minutes
    ) {
      config.closingTime = closingTime;
      await config.save();
      return res
        .status(200)
        .json({ message: "Closing time updated successfully" });
    } else {
      return res
        .status(200)
        .json({ message: "No changes detected for closing time" });
    }
  } catch (error) {
    console.error("Error in setClosingTime:", error);
    return res
      .status(500)
      .json({ message: "Error setting closing time", error });
  }
};

/**
 * Updates the status of a store based on the provided storeId and status.
 * The status can only be set to "open" or "closed". If the status is invalid, a 400 error is returned.
 * If the store configuration is not found, a 404 error is returned.
 * If the status is changed successfully, a success message is returned.
 *
 * @function setStatus
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request.
 * @param {string} req.body.storeId - The ID of the store whose status is to be updated.
 * @param {string} req.body.status - The new status to be set for the store.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the status is updated or if no changes are detected.
 *
 * @throws {Error} If there is an error while updating the store's status in the database.
 */
const setStatus = async (req, res) => {
  const { storeId, status } = req.body;
  if (!["open", "closed"].includes(status)) {
    return res.status(400).json({ message: "Invalid status value" });
  }
  try {
    let config = await StoreConfiguration.findOne({ storeId });
    if (!config) {
      return res.status(404).json({ message: "Store configuration not found" });
    }
    if (config.status !== status) {
      config.status = status;
      await config.save();
      res.status(200).json({ message: "Status updated successfully" });
    } else {
      res.status(200).json({ message: "No changes detected for status" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error updating status", error });
  }
};

module.exports = {
  getStoreConfiguration,
  setOpeningTime,
  setClosingTime,
  setStatus,
};
