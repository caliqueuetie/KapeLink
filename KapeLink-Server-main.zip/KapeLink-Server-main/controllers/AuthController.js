const bcrypt = require("bcryptjs");
const { User } = require("../models/UserModel");
const nodemailer = require("nodemailer");
const axios = require("axios");

// Function to fetch email credentials
/**
 * Fetches email credentials from an external API endpoint.
 * Makes a GET request to retrieve Nodemailer configuration data (email and password).
 *
 * @function getEmailCredentials
 *
 * @returns {Promise<Object>} - An object containing email and password for Nodemailer.
 *
 * @throws {Error} If there is an issue fetching email credentials from the API.
 */
const getEmailCredentials = async () => {
    try {
        const response = await axios.get("http://localhost:9000/api/kape-link/email");
        return response.data.nodemailer; // Expected to return an object { email, password }
    } catch (error) {
        console.error('Failed to fetch email credentials:', error);
        throw new Error('Could not fetch email credentials');
    }
};

/**
 * Controller to authenticate if user session exists.
 * Returns session user data if authenticated; otherwise, returns false.
 *
 * @function auth
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - User data or false depending on session status.
 */
const auth = async (req, res) => {
    if (req.session.user) {
        res.json(req.session.user); // Send user data from session
    } else {
        res.json(false);
    }
};

/**
 * Controller to handle user login.
 * Authenticates user by contact number or email and sets session if valid.
 *
 * @function login
 * @param {Object} req - The request object containing loginNumber and password.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - User data without password if login is successful.
 *
 * @throws {Error} If user is not found or password is incorrect.
 */
const login = async (req, res) => {
    const { loginNumber, password } = req.body;
    try {
        let user;
        let contactNumber = loginNumber;

        // If the input starts with "09" or "9", replace it with "+639"
        if (contactNumber.startsWith("09")) {
            contactNumber = "+639" + contactNumber.slice(2);
        } else if (contactNumber.startsWith("639")) {
            contactNumber = "+639" + contactNumber.slice(3);
        } else if (contactNumber.startsWith("9")) {
            contactNumber = "+639" + contactNumber.slice(1);
        }

        // Attempt to find the user by contactNumber
        user = await User.findOne({ contactNumber });

        // If user wasn't found by contactNumber, try finding by email
        if (!user) {
            user = await User.findOne({ email: loginNumber });
        }

        // If no user is found, return an error
        if (!user) {
            return res.status(404).json({ error: 'User does not exist.' });
        }

        // Compare the password with the stored hashed password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ error: 'Incorrect password.' });
        }

        // Return user info without password
        const { password: _, ...userWithoutPassword } = user.toObject();

        // Set session
        req.session.user = {
            id: user._id,
            userId: user.userId,
            role: user.role,
            firstName: user.firstName,
            lastName: user.lastName,
            contactNumber: user.contactNumber,
            status: user.status,
        };

        console.log('User logged in:', req.session.user); // Debugging line
        res.status(200).json(userWithoutPassword);
    } catch (error) {
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
};

/**
 * Controller for OTP verification.
 * Verifies OTP for user and activates account if valid.
 *
 * @function otpVerify
 * @param {Object} req - The request object containing userId and enteredOtp.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Success message if OTP is verified.
 *
 * @throws {Error} If OTP is incorrect or user is not found.
 */
const otpVerify = async (req, res) => {
    const { userId, enteredOtp } = req.body;
    try {
        // Attempt to find the user by userId
        const user = await User.findOne({ userId });

        // If no user is found, return an error
        if (!user) {
            return res.status(404).json({ error: 'User does not exist.' });
        }

        // Compare the OTP with the stored hashed OTP
        const isMatch = await bcrypt.compare(enteredOtp, user.otp);
        if (!isMatch) {
            return res.status(400).json({ error: 'OTP incorrect.' });
        }

        // Update user's status to 'active'
        user.status = 'active';

        // Save the user to update their status in the database
        await user.save();

        // Return a success response
        res.status(200).json({ success: true, message: 'OTP verified and account activated.' });
    } catch (error) {
        console.error('Error during OTP verification:', error);
        res.status(500).json({ error: 'Server error. Please try again later.' });
    }
};

/**
 * Helper function to generate a random 6-character password.
 *
 * @function generateRandomPassword
 * @returns {string} - A random password of length 6.
 */
const generateRandomPassword = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let password = '';
    for (let i = 0; i < 6; i++) {
        const randomIndex = Math.floor(Math.random() * chars.length);
        password += chars[randomIndex];
    }
    return password;
};

/**
 * Controller to handle password reset.
 * Generates and emails a temporary password to the user if they exist.
 *
 * @function forgotPassword
 * @param {Object} req - The request object containing user email.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Success message if email is sent.
 *
 * @throws {Error} If email fails to send or user is not found.
 */
const forgotPassword = async (req, res) => {
    const { email } = req.body;

    try {
        // Fetch email credentials
        const { senderEmail, pass } = await getEmailCredentials();

        // Create a transporter object using the fetched credentials
        const transporter = nodemailer.createTransport({
            service: 'gmail', // or your email service provider
            auth: {
                user: senderEmail, // fetched email
                pass: pass, // fetched password
            }
        });

        // Attempt to find the user by email
        const user = await User.findOne({ email });

        // If no user is found, return an error
        if (!user) {
            return res.status(404).json({ error: 'User does not exist.' });
        }

        // Generate a random password
        const generatedPassword = generateRandomPassword();

        // Hash the new password before saving it
        const hashedPassword = await bcrypt.hash(generatedPassword, 10);

        // Update the user's password in the database
        user.password = hashedPassword;
        await user.save();

        // Send the email with the generated password
        const mailOptions = {
            from: `"KapeLink" <${senderEmail}>`,
            to: email,
            subject: 'KapeLink Password Reset ☕',
            html: `
        <table style="border-collapse: collapse; width: 49.1447%; height: 508.8px; border-style: none; border-color: #ffffff;" border="0">
            <colgroup><col style="width: 100%;"></colgroup>
            <tbody>
            <tr style="height: 148.8px;">
            <td style="padding: 10px; background-color: #a79277; border-color: #ffffff;">
            <p><span style="font-family: 'trebuchet ms', geneva, sans-serif;"><span style="font-size: 18pt;"><strong><span style="color: #ffffff;">KapeLink Password Reset ☕</span></strong></span></span></p>
            </td>
            </tr>
            <tr style="height: 177.6px;">
            <td style="padding: 10px; border-color: #ffffff;">
            <p><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Your account ${email} has requested a password reset.</span></p>
            <p><span style="font-family: trebuchet ms, geneva, sans-serif;">A temporary password has been generated for you to use. Please use it to log in to your account and change your password as soon as possible.</span></p>
            <p><span style="font-family: trebuchet ms, geneva, sans-serif;">Your new password:</span></p>
            </td>
            </tr>
            <tr style="height: 142.4px;">
            <td style="padding: 10px; border-color: #ffffff;">
            <p><span style="font-size: 36pt; font-family: 'trebuchet ms', geneva, sans-serif;"><strong>${generatedPassword}</strong></span></p>
            <p>&nbsp;</p>
            </td>
            </tr>
            <tr style="height: 40px;">
            <td style="padding: 10px; border-color: #ffffff;"><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Thank you for using KapeLink!</span></td>
            </tr>
            </tbody>
        </table>
        <p>&nbsp;</p>
      `,
        };

        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.error('Error sending email:', error);
                return res.status(500).json({ error: 'Failed to send email' });
            } else {
                console.log('Email sent:', info.response);
                res.status(200).json({ message: 'Temporary password sent to your email.' });
            }
        });

    } catch (error) {
        console.error('Error in forgotPassword:', error);
        res.status(500).json({ error: 'Server error. Please try again later.' });
    }
};

/**
 * Controller to log out user by destroying session.
 *
 * @function logout
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {void} - Success message if session is destroyed.
 */
const logout = (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.json({ message: 'Logged out successfully' });
    });
};

module.exports = {
    auth,
    login,
    otpVerify,
    forgotPassword,
    logout
};