const getDateAndTime = require("../helpers/DateTimeHelper");
const StoreConfiguration = require("../models/StoreConfigurationModel");

/**
 * Fetches available time slots based on the store's opening and closing times, and the current time.
 * Returns the current date, time, and available time slots for booking.
 *
 * @function getTime
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The current date, time, and available time slots.
 *
 * @throws {Error} If there is an issue fetching the store configuration or generating the time slots.
 */
const getTime = async (req, res) => {
  const { date, time } = getDateAndTime();
  const [currentHour, currentMinute] = time.split(":").map(Number);
  let timeSlots = [];
  let openingTime = { hours: 0, minutes: 0 };
  let closingTime = { hours: 23, minutes: 59 };

  try {
    const currentConfig = await StoreConfiguration.findOne()
      .sort({ createdAt: -1 })
      .exec();

    if (!currentConfig) {
      console.warn("No configuration found in the database.");
      return res.status(404).json({ error: "No configuration found" });
    }
    openingTime = currentConfig.openingTime;
    closingTime = currentConfig.closingTime;
  } catch (error) {
    console.error("Error fetching current configuration:", error);
    return res.status(500).json({ error: "Internal server error" });
  }

  const openingMinutesFromMidnight =
    openingTime.hours * 60 + openingTime.minutes;
  const closingMinutesFromMidnight =
    closingTime.hours * 60 + closingTime.minutes;
  const currentMinutesFromMidnight = currentHour * 60 + currentMinute;

  if (currentMinutesFromMidnight >= openingMinutesFromMidnight) {
    const startMinutes =
      currentMinutesFromMidnight +
      (currentMinute >= 30 ? 60 - currentMinute : 30 - currentMinute);
    for (
      let minutes = startMinutes;
      minutes < closingMinutesFromMidnight;
      minutes += 30
    ) {
      const startHour = Math.floor(minutes / 60);
      const startMin = minutes % 60;
      const endHour = Math.floor((minutes + 30) / 60);
      const endMin = (minutes + 30) % 60;

      const startTime = `${String(startHour).padStart(2, "0")}:${String(
        startMin
      ).padStart(2, "0")}`;
      const endTime = `${String(endHour).padStart(2, "0")}:${String(
        endMin
      ).padStart(2, "0")}`;
      timeSlots.push(`${startTime}-${endTime}`);
    }
    const io = req.app.get("socketio");
    io.emit("time", { date, time, timeSlots });
  }

  res.status(200).json({ date, time, timeSlots });
};

module.exports = getTime;
