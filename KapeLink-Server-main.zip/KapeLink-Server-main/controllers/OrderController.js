const {
  Order,
  PickupOrder,
  DeliveryOrder,
  InStoreOrder,
  TrackingSchema,
} = require("../models/OrderModel");
const StoreConfiguration  = require("../models/StoreConfigurationModel");
const getDateAndTime = require("../helpers/DateTimeHelper");
const {
  sendNotification,
  sendBatchNotification,
} = require("./NotificationController");
const path = require("path");
const moment = require("moment");
const { User } = require("../models/UserModel");
const { DateTime } = require("luxon");
const { customerTransactionPath } = require("../helpers/ImagePathHelper");
const momentTZ = require("moment-timezone");
const cron = require("node-cron");

/**
 * Updates the status of orders when the store is closed.
 *
 * @function updateOrdersOnStoreClosed
 * @returns {void}
 */
const updateOrdersOnStoreClosed = async () => {
  try {
    const storeConfig = await StoreConfiguration.findOne({ storeId: 1 }); // Replace with your store ID
    if (!storeConfig || storeConfig.status !== "Closed") {
      console.log("Store is not closed. No updates necessary.");
      return;
    }

    console.log("Store status is Closed. Proceeding with order updates.");

    // Find orders that have tracking information
    const ordersToUpdate = await Order.find({
      tracking: { $exists: true, $ne: [] }, // Ensure tracking exists and is not empty
    });

    let updatedCount = 0;

    // Iterate through the orders and update them based on their orderOption
    for (let order of ordersToUpdate) {
      const latestTracking = order.tracking[order.tracking.length - 1];
      let newStatus = null;

      // Determine the new status based on the latest tracking status
      if (latestTracking.orderStatus === "Preparing") {
        newStatus = "Cancelled";
      } else if (
        latestTracking.orderStatus === "For Pickup" ||
        latestTracking.orderStatus === "Out For Delivery"
      ) {
        newStatus = "Failed";
      }

      if (newStatus) {
        const timestamp = momentTZ().tz("Asia/Manila").format("HH:mm");

        // Create a plain object for the new tracking entry
        const newTrackingEntry = {
          timestamp,
          orderStatus: newStatus,
        };

        // Define the update object for pushing tracking and setting reason
        const updateObj = {
          $push: { tracking: newTrackingEntry },
          $set: { reason: "Store Closed" },
        };

        // Use PickupOrder or DeliveryOrder based on orderOption
        let updatedOrder;
        if (order.orderOption === "Pickup") {
          updatedOrder = await PickupOrder.findOneAndUpdate(
            { orderId: order.orderId },
            updateObj,
            { new: true }
          );
        } else if (order.orderOption === "Delivery") {
          updatedOrder = await DeliveryOrder.findOneAndUpdate(
            { orderId: order.orderId },
            updateObj,
            { new: true }
          );
        } else {
          continue;
        }

        if (updatedOrder) {
          updatedCount++;
        }
      }
    }

    if (updatedCount > 0) {
      console.log(`${updatedCount} orders updated.`);
    } else {
      console.log("No orders to update.");
    }
  } catch (error) {
    console.error("Error updating orders on store closure:", error);
  }
};


/**
 * Cron task to execute `updateOrdersOnStoreClosed` at store closing time.
 */
cron.schedule("0 0 * * *", async () => {
  // Replace "59 21 * * *" with the appropriate cron expression for your closing time.
  console.log("Running scheduled task: updateOrdersOnStoreClosed");
  await updateOrdersOnStoreClosed();
});

/**
 * This function retrieves all orders sorted by date and time.
 * It adds the payment proof path if it is available.
 *
 * @function getOrders
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Orders or error message.
 *
 * @throws {Error} - If there's an error retrieving orders.
 */
const getOrders = async (req, res) => {
  try {
    const orders = await Order.find().sort({
      orderDate: -1,
      timeOrdered: -1,
    });

    orders.forEach((order) => {
      if (order.proofOfPayment && order.proofOfPayment.trim() !== "") {
        order.proofOfPayment = customerTransactionPath() + order.proofOfPayment;
      }
    });

    res.status(200).json(orders);
  } catch (error) {
    res.status(500).json({ message: "Error retrieving orders", error });
  }
};

/**
 * This function retrieves a single order by orderId.
 * It adds the payment proof path if it is available.
 *
 * @function getOrder
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 * @returns {void} - Order details or error message.
 * @throws {Error} - If order not found or an error occurs.
 */
const getOrder = async (req, res) => {
  const order = await Order.findOne({ orderId: req.params.orderId });

  if (order.proofOfPayment && order.proofOfPayment.trim() !== "") {
    order.proofOfPayment = customerTransactionPath() + order.proofOfPayment;
  }

  if (!order) {
    return res.status(404).json({ error: "No such order" });
  }
  res.status(200).json(order);
};

/**
 * This function creates a new order with appropriate tracking and notifications.
 * It determines order type (In-store, Delivery, or Pickup) and saves it.
 *
 * @function createOrder
 * @param {Object} req - Express request object with order data in the body.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Created order details.
 *
 * @throws {Error} - If there's an error while creating the order.
 */
const createOrder = async (req, res) => {
  try {
    const latestOrder = await Order.findOne().sort({ orderId: -1 }).exec();
    const nextOrderId = latestOrder ? latestOrder.orderId + 1 : 1;
    const time = momentTZ().tz("Asia/Manila").format("HH:mm");
    const custName = req.body.custName;
    const orderOption = req.body.orderOption.toLowerCase();

    let updatedData = {
      orderId: nextOrderId,
      timeOrdered: time,
      ...req.body,
      tracking: [],
    };

    if (typeof req.body.items === "string") {
      updatedData.items = JSON.parse(req.body.items);
    }

    if (typeof req.body.deliveryDetails === "string") {
      updatedData.deliveryDetails = JSON.parse(req.body.deliveryDetails);
    }

    if (
      ["Delivery", "Pickup"].includes(req.body.orderOption) &&
      req.body.paymentMethodId !== "1"
    ) {
      updatedData.verificationStatus = "Not Verified";
    } else {
      updatedData.tracking.push({ timestamp: time, orderStatus: "Preparing" });
    }

    if (["Delivery", "Pickup"].includes(req.body.orderOption)) {
      updatedData.customerId = req.session.user.userId;
    }

    if (req.file) {
      updatedData.proofOfPayment = req.file ? req.file.filename : null;
    }

    let order;
    switch (req.body.orderOption) {
      case "In-store":
        order = await InStoreOrder.create(updatedData);
        break;
      case "Delivery":
        order = await DeliveryOrder.create(updatedData);
        break;
      case "Pickup":
        order = await PickupOrder.create(updatedData);
        break;
      default:
        return res.status(400).json({ error: "Invalid order option" });
    }

    const io = req.app.get("socketio");

    const notificationPayload = {
      title:
        order.paymentMethodId === 1 ? "New Order!" : "Order for Verification!",
      body:
        order.paymentMethodId === 1
          ? `New order received: ORDER#${order.orderId}`
          : `Order for verification: ORDER#${order.orderId}`,
      order: order,
    };

    const notificationData = {
      receiver: "all",
      roles: ["barista", "manager"],
      message: `${custName} placed a new order for ${orderOption}.`,
      date: momentTZ().tz("Asia/Manila").format("MM/DD/YYYY"),
      time: time,
      readStatus: false,
    };

    res.status(200).json(order);
    await sendBatchNotification(notificationPayload, notificationData);
    io.emit("newOrder");
    io.emit("userOrders", order);
  } catch (error) {
    console.error("Error creating order:", error);
    res
      .status(400)
      .json({ error: "An error occurred while creating the order" });
  }
};

/**
 * This function updates the tracking information of an existing order.
 * It notifies the customer of status updates and triggers socket events.
 *
 * @function updateOrderTracking
 * @param {Object} req - Express request object with tracking info in the body.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Updated order.
 *
 * @throws {Error} - If tracking update fails or order not found.
 */
const updateOrderTracking = async (req, res) => {
  try {
    const { order, newTrackingEntry, message } = req.body;
    const { orderId, orderOption } = order;

    let updatedOrder;

    // Check the orderOption and update the tracking accordingly
    if (orderOption === "Pickup") {
      updatedOrder = await PickupOrder.findOneAndUpdate(
        { orderId },
        { $push: { tracking: newTrackingEntry } },
        { new: true }
      );
    } else if (orderOption === "Delivery") {
      updatedOrder = await DeliveryOrder.findOneAndUpdate(
        { orderId },
        { $push: { tracking: newTrackingEntry } },
        { new: true }
      );
    } else {
      return res.status(400).json({ error: "Invalid order option" });
    }

    if (!updatedOrder) {
      return res.status(404).json({ error: "Failed to update tracking" });
    }

    if (newTrackingEntry.orderStatus === "Cancelled") {
      updatedOrder.set("reason", message);
    }

    await updatedOrder.save();

    const io = req.app.get("socketio");

    const statusMessages = {
      "For Pickup": `Your order with the ID ${order.orderId} is now ready for pickup.`,
      "Out For Delivery": `Your order with the ID ${order.orderId} is now out for delivery.`,
      Failed: `Your order with the ID ${order.orderId} has failed.`,
      Complete: `Your order with the ID ${order.orderId} has been completed.`,
      Cancelled: `${message}`,
    };

    const notificationMessage = statusMessages[newTrackingEntry.orderStatus];

    const notificationPayload = {
      title: `Order ${newTrackingEntry.orderStatus}!`,
      body: notificationMessage,
      order: order,
    };

    await sendNotification({ userId: order.customerId, notificationPayload });

    io.emit("orderStatusUpdated", updatedOrder);
    io.emit("orderDetails", updatedOrder);
    return res.status(200).json(updatedOrder);
  } catch (error) {
    console.error("Error occurred:", error.message);
    return res.status(400).json({ error: error.message });
  }
};

/**
 * This function retrieves order history of an authenticated user by customerId.
 *
 * @function getOrderHistoryByCustomerId
 * @param {Object} req - Express request object with session containing userId.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Customer's order history.
 *
 * @throws {Error} - If there's an error fetching the order history.
 */
const getOrderHistoryByCustomerId = async (req, res) => {
  // Ensure the user is authenticated
  if (!req.session || !req.session.user || !req.session.user.userId) {
    return res.status(401).json({ error: "User not authenticated" });
  }

  const customerId = req.session.user.userId;

  try {
    // Find orders by customerId
    const orders = await Order.find({ customerId });

    if (!orders || orders.length === 0) {
      return res.status(200).json([]);
    }

    orders.forEach((order) => {
      if (order.proofOfPayment && order.proofOfPayment.trim() !== "") {
        order.proofOfPayment = customerTransactionPath() + order.proofOfPayment;
      }
    });

    res.status(200).json(orders);
  } catch (error) {
    console.error("Error fetching order history:", error);
    res
      .status(500)
      .json({ error: "Server error while fetching order history" });
  }
};

/**
 * Thiis function retrieves all orders associated with a specific customer by customerId.
 *
 * @function getOrdersByCustomerId
 * @param {Object} req - Express request object with customerId parameter.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Orders or an empty response if no orders found.
 *
 * @throws {Error} - If there's an error retrieving the orders.
 */
const getOrdersByCustomerId = async (req, res) => {
  try {
    const { customerId } = req.params;
    const orders = await Order.find({ customerId });

    if (!orders || orders.length === 0) {
      return res.status(204).send();
    }

    orders.forEach((order) => {
      if (order.proofOfPayment && order.proofOfPayment.trim() !== "") {
        order.proofOfPayment = customerTransactionPath() + order.proofOfPayment;
      }
    });

    res.status(200).json(orders);
  } catch (error) {
    console.error("Error fetching orders by customerId:", error);
    res.status(500).json({
      error: "An error occurred while fetching orders.",
      details: error.message || "Internal Server Error",
    });
  }
};

/**
 * This function retrieves recent orders for a customer within the last 30 minutes.
 *
 * @function getRecentOrders
 * @param {Object} req - Express request object with customerId parameter.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Recent orders.
 *
 * @throws {Error} - If there's an error retrieving recent orders.
 */
const getRecentOrders = async (req, res) => {
  const customerId = req.params.customerId;

  // Get current date and time in the Philippines timezone
  const recentDate = DateTime.now().setZone("Asia/Manila");
  // Subtract 30 minutes from the current date and time
  const thirtyMinutesAgo = recentDate.minus({ minutes: 30 });

  console.log("Thirty Minutes Ago:", thirtyMinutesAgo.toISODate());
  console.log("Recent Date:", recentDate.toISODate());

  try {
    const recentOrders = await Order.find({
      customerId: customerId,
      orderDate: {
        $gte: thirtyMinutesAgo.toISODate(),
        $lte: recentDate.toISODate(),
      },
      timeOrdered: {
        $gte: thirtyMinutesAgo.toFormat("HH:mm"),
        $lte: recentDate.toFormat("HH:mm"),
      },
    });

    res.status(200).json(recentOrders);
  } catch (error) {
    res.status(500).json({ message: "Error fetching recent orders", error });
  }
};

/**
 * This function retrieves today’s orders and calculates statistics, including total sales, cups sold, and revenue.
 *
 * @function getOrdersToday
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Daily order statistics or message if no orders.
 *
 * @throws {Error} - If there's an error fetching today’s orders.
 */
const getOrdersToday = async (req, res) => {
  try {
    const currentDate = moment().format("YYYY-MM-DD");
    const orders = await Order.find({
      orderDate: currentDate,
      $or: [
        { orderStatus: "Complete" },
        { "tracking.orderStatus": "Complete" },
      ],
    });

    if (!orders || orders.length === 0) {
      return res.status(200).json({
        message: "No orders found for today",
        totalSales: 0,
        totalCupsSold: 0,
        totalOrders: 0,
        totalCoffeeSales: 0,
        totalNonCoffeeSales: 0,
        otherSales: 0,
      });
    }

    let totalSales = 0;
    let totalCupsSold = 0;
    let totalOrders = 0;
    let totalCoffeeSales = 0;
    let totalNonCoffeeSales = 0;
    let otherSales = 0;

    orders.forEach((order) => {
      totalOrders += 1;

      order.items.forEach((item) => {
        totalSales += item.totalPrice;

        if (item.category === "Beverages") {
          totalCupsSold += item.quantity;
        }

        if (item.salesReport === "Coffee Based") {
          totalCoffeeSales += item.totalPrice;
        } else if (item.salesReport === "Non-Coffee Based") {
          totalNonCoffeeSales += item.totalPrice;
        } else {
          otherSales += item.totalPrice;
        }
      });
    });

    res.status(200).json({
      totalSales,
      totalCupsSold,
      totalOrders,
      totalCoffeeSales,
      totalNonCoffeeSales,
      otherSales,
    });
  } catch (error) {
    res
      .status(500)
      .json({ error: "Server error while fetching today's orders" });
  }
};

/**
 * This functions retrieves monthly revenue by aggregating completed orders within a specified year.
 *
 * @function getMonthlyRevenue
 * @param {Object} req - Express request object with year parameter.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Revenue data for each month.
 *
 * @throws {Error} - If there's an error fetching monthly revenue.
 */
const getMonthlyRevenue = async (req, res) => {
  try {
    const selectedYear = parseInt(req.params.year, 10);
    console.log("Selected year:", selectedYear);

    const startDate = `${selectedYear}-01-01`;
    const endDate = `${selectedYear + 1}-01-01`;

    const monthlyRevenue = await Order.aggregate([
      {
        $match: {
          $or: [
            {
              orderStatus: "Complete",
              orderDate: {
                $gte: startDate,
                $lt: endDate,
              },
            },
            {
              "tracking.orderStatus": "Complete",
              orderDate: {
                $gte: startDate,
                $lt: endDate,
              },
            },
          ],
        },
      },
      {
        $unwind: "$items",
      },
      {
        $group: {
          _id: {
            $month: {
              $dateFromString: { dateString: "$orderDate" },
            },
          },
          totalRevenue: { $sum: "$items.totalPrice" },
        },
      },
      {
        $sort: { _id: 1 },
      },
    ]);

    console.log("Aggregated monthly revenue data:", monthlyRevenue);

    res.status(200).json(monthlyRevenue);
  } catch (error) {
    console.error("Error fetching monthly revenue:", error);
    res.status(500).json({ error: "Error fetching monthly revenue" });
  }
};

/**
 * Updates the payment method and verification status of an order.
 * If a proof of payment is uploaded, adds it to the order.
 *
 * @function updatePayment
 * @param {Object} req - Express request object with orderId parameter and payment info.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Updated order.
 *
 * @throws {Error} - If order not found or update fails.
 */
const updatePayment = async (req, res) => {
  const { paymentMethodId } = req.body;

  if (req.file) {
    const order = await Order.findOneAndUpdate(
      { orderId: req.params.orderId },
      {
        proofOfPayment: req.file ? req.file.filename : null,
        paymentMethodId,
        verificationStatus: "Not Verified",
      },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({ error: "No such order" });
    }
    const io = req.app.get("socketio");
    io.emit("newOrder", order);
    return res.status(200).json(order);
  } else if (paymentMethodId) {
    const { time } = getDateAndTime();

    const order = await Order.findOne({ orderId: req.params.orderId });

    if (!order) {
      return res.status(404).json({ error: "No such order" });
    }

    order.paymentMethodId = paymentMethodId;
    order.proofOfPayment = undefined;
    order.verificationStatus = undefined;

    order.tracking.push({
      timestamp: time,
      orderStatus: "Preparing",
    });

    await order.save();

    return res.status(200).json(order);
  } else {
    return res
      .status(400)
      .json({ error: "No file uploaded and paymentMethodId is missing" });
  }
};

/**
 * This function fetches unique years from orderDate of completed orders.
 *
 * @function getUniqueYears
 * @param {Object} req - Express request object.
 * @param {Object} res - Express response object.
 *
 * @returns {void} - Array of unique years.
 *
 * @throws {Error} - If there's an error fetching unique years.
 */

const getUniqueYears = async (req, res) => {
  try {
    const orders = await Order.find(
      {
        $or: [
          { orderStatus: "Complete" },
          { "tracking.orderStatus": "Complete" },
        ],
      },
      { orderDate: 1 }
    );

    const years = new Set();

    orders.forEach((order) => {
      const year = moment(order.orderDate).year();
      years.add(year);
    });

    const uniqueYears = Array.from(years).sort((a, b) => a - b);

    res.status(200).json(uniqueYears);
  } catch (error) {
    res.status(500).json({ error: "Server error while fetching unique years" });
  }
};

module.exports = {
  createOrder,
  getOrders,
  getOrder,
  getOrderHistoryByCustomerId,
  updateOrderTracking,
  getOrdersByCustomerId,
  getOrdersToday,
  getMonthlyRevenue,
  updatePayment,
  getRecentOrders,
  getUniqueYears,
};
