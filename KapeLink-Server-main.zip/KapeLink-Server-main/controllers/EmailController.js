const Email = require ('../models/EmailModel');

/**
 * Controller to retrieve email credentials for client-side.
 * Fetches email configuration if it exists.
 *
 * @function getEmailCredentials
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Email configuration data or 404 if not found.
 */
const getEmailCredentials = async (req, res) => {
  try {
    const email = await Email.findOne();
    if (!email) {
      return res.status(404).json({ error: 'Email configuration not found' });
    }
    res.status(200).json(email);
  } catch (error) {
    res.status(500).json({ error: 'Server error: ' + error.message });
  }
};

/**
 * Creates or updates the email credentials in the database.
 * Checks if email credentials exist; if so, updates them; otherwise, creates a new entry.
 *
 * @function upsertEmailCredentials
 * @param {Object} req - The request object containing Nodemailer credentials in req.body.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Responds with the updated or created email configuration.
 *
 * @throws {Error} If there is an issue with the database operation.
 */
const upsertEmailCredentials = async (req, res) => {
    const { senderEmail, pass } = req.body.nodemailer;
  
    try {
      let email = await Email.findOne();
      if (email) {
        // Update existing email configuration
        email.nodemailer.senderEmail = senderEmail;
        email.nodemailer.pass = pass;
      } else {
        // Create new chatbot configuration
        email = new Email({
          nodemailer: {
            email,
            pass
          }
        });
      }
  
      await email.save();
      res.status(200).json(email);
    } catch (error) {
      res.status(500).json({ error: 'Server error: ' + error.message });
    }
  };
  
// Export the CRUD functions
module.exports = {
    getEmailCredentials,
    upsertEmailCredentials,
  };
  

