const Product = require("../models/ProductModel");

/**
 * Retrieves all products from the database.
 * Fetches all products and returns them in the response.
 *
 * @function getAllProducts
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns an array of all products in the response.
 * @throws {Error} If there is an issue retrieving the products from the database.
 */
const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (error) {
    console.error("Error fetching all products:", error);
    res.status(500).json({ message: "Server error" });
  }
};

/**
 * Retrieves all available products from the database.
 * Fetches products where the status is "Available" and returns them in the response.
 *
 * @function getProducts
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns an array of available products in the response.
 * @throws {Error} If there is an issue retrieving the products from the database.
 */

const getProducts = async (req, res) => {
  try {
    const products = await Product.find({ status: "Available" });
    res.status(200).json(products);
  } catch (error) {
    console.error("Error fetching products:", error);
  }
};

/**
 * Retrieves a product by its `prodId` from the database.
 * If the product exists, it returns the product data in the response.
 * If the product is not found, a 404 error is returned with a message.
 *
 * @function getProduct
 * @param {Object} req - The request object containing the `prodId` in the URL parameters.
 * @param {string} req.params.prodId - The ID of the product to be retrieved.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Returns the product data in the response if found.
 * @throws {Error} If there is an issue retrieving the product from the database.
 */
const getProduct = async (req, res) => {
  const product = await Product.findOne({ prodId: req.params.prodId });

  if (!product) {
    return res.status(404).json({ error: "No such product" });
  }

  res.status(200).json(product);
};

/**
 * Creates a new product with an automatically incremented `prodId`.
 * The function fetches all existing products, calculates the next `prodId` by sorting the current ones,
 * and then creates the new product with the next available `prodId`. The newly created product is then
 * emitted via Socket.IO and returned in the response.
 *
 * @function createProduct
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing the new product data.
 * @param {string} req.body.name - The name of the product.
 * @param {string} req.body.category - The category of the product.
 * @param {number} req.body.price - The price of the product.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The newly created product is returned in the response.
 *
 * @throws {Error} If there is an issue creating the product or retrieving the current products from the database.
 */
const createProduct = async (req, res) => {
  try {
    const products = await Product.find().exec();

    const parsedProducts = products.map((product) => ({
      ...product._doc,
      prodId: parseInt(product.prodId, 10),
    }));

    parsedProducts.sort((a, b) => b.prodId - a.prodId);

    const latestProdId =
      parsedProducts.length > 0 ? parsedProducts[0].prodId : 0;
    const nextProdId = latestProdId + 1;

    const newProductData = {
      ...req.body,
      prodId: nextProdId,
    };

    console.log(newProductData);

    const product = await Product.create(newProductData);

    const io = req.app.get("socketio");
    io.emit("products", product);

    res.status(200).json(product);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Updates the product information based on the provided prodId and request body.
 * If the update is successful, an "updateProduct" event is emitted and the updated product is returned.
 *
 * @function updateProduct
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.prodId - The ID of the product to update.
 * @param {Object} req.body - The body of the request, containing the updated product information.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The updated product information in the response.
 *
 * @throws {Error} If the product is not found or there is an error updating the product information.
 */

const updateProduct = async (req, res) => {
  const product = await Product.findOneAndUpdate(
    { prodId: req.params.prodId },
    {
      ...req.body,
    }
  );

  if (!product) {
    return res.status(404).json({ error: "No such product" });
  }

  const io = req.app.get("socketio");
  io.emit("updateProduct", product);

  res.status(200).json(product);
};

/**
 * Updates the status of a product based on the provided prodId and status.
 * If the update is successful, an "updateProductStatus" event is emitted and the updated product is returned.
 *
 * @function updateProductStatus
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.prodId - The ID of the product to update.
 * @param {Object} req.body - The body of the request containing the new status of the product.
 * @param {string} req.body.status - The new status of the product ("Available" or "Unavailable").
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The updated product information in the response.
 *
 * @throws {Error} If the product is not found or there is an invalid status provided.
 */
const updateProductStatus = async (req, res) => {
  try {
    const { prodId } = req.params;
    const { status } = req.body;

    if (!["Available", "Unavailable"].includes(status)) {
      return res.status(400).json({ error: "Invalid status value" });
    }

    const product = await Product.findOneAndUpdate(
      { prodId },
      { status },
      { new: true }
    );

    if (!product) {
      return res.status(404).json({ error: "No such product" });
    }

    const io = req.app.get("socketio");
    io.emit("updateProductStatus", product);
    res.status(200).json(product);
  } catch (error) {
    console.error(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Deletes a product based on the provided prodId.
 * If the product is found and deleted, a "deleteProduct" event is emitted and a success message is returned.
 *
 * @function deleteProduct
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.prodId - The ID of the product to delete.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the product is deleted successfully.
 *
 * @throws {Error} If the product is not found or there is an issue during the deletion process.
 */
const deleteProduct = async (req, res) => {
  const { prodId } = req.params;

  try {
    const product = await Product.findOneAndDelete({ prodId });
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    const io = req.app.get("socketio");
    io.emit("deleteProduct", product);

    res.status(200).json({ message: "Product deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

/**
 * Filters products based on the provided categories.
 * The function dynamically constructs a filter object and fetches products that match the given categories.
 *
 * @function filterProducts
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing filter criteria.
 * @param {string} req.body.mainCategory - The main category to filter products by.
 * @param {string} req.body.menuCategory - The menu category to filter products by.
 * @param {string} req.body.salesCategory - The sales category to filter products by.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A list of filtered products based on the provided categories.
 *
 * @throws {Error} If there is an issue fetching the filtered products from the database.
 */

const filterProducts = async (req, res) => {
  const { mainCategory, menuCategory, salesCategory } = req.body;

  try {
    const filter = {};

    if (mainCategory && mainCategory !== "*") {
      filter.category = mainCategory;
    }
    if (menuCategory && menuCategory !== "*") {
      filter.menuCategory = menuCategory;
    }
    if (salesCategory && salesCategory !== "*") {
      filter.salesReport = salesCategory;
    }

    const products = await Product.find(filter);

    res.status(200).json(products);
    console.log(products);
  } catch (error) {
    console.error("Error fetching filtered products:", error);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  getAllProducts,
  createProduct,
  getProducts,
  getProduct,
  updateProduct,
  updateProductStatus,
  deleteProduct,
  filterProducts,
};
