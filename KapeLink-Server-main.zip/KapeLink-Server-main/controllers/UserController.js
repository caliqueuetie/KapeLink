const {
  User,
  Admin,
  Manager,
  Barista,
  Customer,
} = require("../models/UserModel");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const axios = require("axios");

/**
 * Fetches email credentials (email and password) for the Nodemailer service from an external API.
 * The credentials are expected to be returned as an object with `email` and `password` properties.
 * If the fetch fails, an error is thrown.
 *
 * @function getEmailCredentials
 * @returns {Promise<Object>} - An object containing the email and password for Nodemailer.
 * @throws {Error} If there is an error fetching the email credentials from the API.
 */
const getEmailCredentials = async () => {
  try {
    const response = await axios.get(
      "http://localhost:9000/api/kape-link/email"
    );
    return response.data.nodemailer; // Expected to return an object { email, password }
  } catch (error) {
    console.error("Failed to fetch email credentials:", error);
    throw new Error("Could not fetch email credentials");
  }
};

/**
 * Creates a new user based on the provided role and request body.
 * The user is created under one of the following roles: manager, barista, customer, or admin.
 * If the role is invalid, an error is thrown. After the user is created, a socket event is emitted to notify about the new user.
 *
 * @function createUser
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing the new user information, including the role.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The newly created user object or an error message if the creation fails.
 *
 * @throws {Error} If the role is invalid or there is an error creating the user.
 */
const createUser = async (req, res) => {
  try {
    let user;
    console.log(req.body.role);
    switch (req.body.role) {
      case "manager":
        user = await Manager.create(req.body);
        break;
      case "barista":
        user = await Barista.create(req.body);
        break;
      case "customer":
        user = await Customer.create(req.body);
        break;
      case "admin":
        user = await Admin.create(req.body);
        break;
      default:
        throw new Error("Invalid role");
    }

    // Emit the updated user list via socket.io
    const io = req.app.get("socketio");
    io.emit("users", user);

    res.status(200).json(user);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Creates a new customer, generates an OTP for verification, and sends it via email.
 * The OTP is hashed before being stored in the user's record, and a verification email is sent to the customer.
 * Additionally, a socket event is emitted to notify about the new customer creation.
 *
 * @function createCustomer
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing the customer information.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message indicating the OTP was sent to the email, or an error message if the process fails.
 *
 * @throws {Error} If there is an error during the customer creation, OTP generation, or email sending process.
 */
const createCustomer = async (req, res) => {
  try {
    // Fetch email credentials
    const { senderEmail, pass } = await getEmailCredentials();

    // Create a transporter object using the fetched credentials
    const transporter = nodemailer.createTransport({
      service: "gmail", // or your email service provider
      auth: {
        user: senderEmail, // fetched email
        pass: pass, // fetched password
      },
    });

    // Attempt to find the user by email
    const user = await Customer.create(req.body);

    // Generate OTP
    const generatedOtp = Math.floor(100000 + Math.random() * 900000).toString();

    // Hash the new password before saving it
    const hashedOtp = await bcrypt.hash(generatedOtp, 10);

    // Update the user's password in the database
    user.otp = hashedOtp;
    await user.save();

    // Send the email with the generated password
    const mailOptions = {
      from: `"KapeLink" <${senderEmail}>`,
      to: req.body.email,
      subject: "KapeLink Verification Code ☕",
      html: `
            <table style="border-collapse: collapse; width: 46.7711%; height: 508.8px; border-style: none; border-color: #ffffff;" border="0"><colgroup><col style="width: 100%;"></colgroup>
            <tbody>
            <tr style="height: 148.8px;">
            <td style="padding: 10px; background-color: #a79277; border-color: #ffffff;">
            <p><span style="font-family: 'trebuchet ms', geneva, sans-serif;"><span style="font-size: 18pt;"><strong><span style="color: #ffffff;">KapeLink Verification Code ☕</span></strong></span></span></p>
            </td>
            </tr>
            <tr style="height: 177.6px;">
            <td style="padding: 10px; border-color: #ffffff;">
            <p><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Thank you for signing up on KapeLink!</span></p>
            <p class="m_-9026757104894115568mcnTextContentContainer"><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Your account ${req.body.email} is almost ready to use.</span></p>
            <p class="m_-9026757104894115568mcnTextContentContainer"><span style="font-family: 'trebuchet ms', geneva, sans-serif;">To continue to KapeLink, please secure your account by verifying your email address.</span></p>
            <p><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Your verification code is:</span></p>
            </td>
            </tr>
            <tr style="height: 142.4px;">
            <td style="padding: 10px; border-color: #ffffff;">
            <p><span style="font-size: 36pt; font-family: 'trebuchet ms', geneva, sans-serif;"><strong>${generatedOtp}</strong></span></p>
            <p>&nbsp;</p>
            </td>
            </tr>
            <tr style="height: 40px;">
            <td style="padding: 10px; border-color: #ffffff;"><span style="font-family: 'trebuchet ms', geneva, sans-serif;">Please enter the code on the KapeLink site.</span></td>
            </tr>
            </tbody>
            </table>
            <p>&nbsp;</p>
        `,
    };

    // Emit the updated user list via socket.io
    const io = req.app.get("socketio");
    io.emit("createCustomer", user);

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error sending email:", error);
        return res.status(500).json({ error: "Failed to send email" });
      } else {
        console.log("Email sent:", info.response);
        res.status(200).json({ message: "OTP sent to your email." });
      }
    });
  } catch (error) {
    console.error("Error in Verification Code:", error);
    res.status(500).json({ error: "Server error. Please try again later." });
  }
};

/**
 * Retrieves a user based on the provided userId, email, or contact number.
 * If the user is found, their information is returned; otherwise, a default "Deleted User" is returned.
 *
 * @function getUser
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.data - The userId, email, or contact number to search for.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The user data if found, or a default "Deleted User" if not found.
 *
 * @throws {Error} If there is an error while retrieving the user.
 */
const getUser = async (req, res) => {
  // use userId to find
  let user = await User.findOne({ userId: req.params.data });

  // if email is provided
  if (!user) {
    user = await Customer.findOne({ email: req.params.data });
  }

  // if contact number is provided
  if (!user) {
    user = await User.findOne({ contactNumber: req.params.data });
  }

  if (!user) {
    return res.status(200).json({
      found: false,
      firstName: "Deleted",
      lastName: "User",
    });
  }

  res.status(200).json(user);
};

/**
 * Retrieves user information based on the provided user IDs.
 * This function takes an array of user IDs from the request body, fetches the corresponding users from the database, and returns a map of user IDs to user data. 
 * If no users are found or no user IDs are provided, appropriate error responses are sent.
 *
 * @function getUserNames
 * @param {Object} req - The request object containing the user IDs in the body.
 * @param {Object} res - The response object to send back the user data or error message.
 *
 * @returns {Promise<void>} - Sends a 200 response with a map of user data indexed by user ID or an empty response if no users are found.
 *                             Sends a 400 error if no user IDs are provided, or a 500 error if there is an internal server issue.
 *
 * @throws {Error} - If there is an issue during the database query or other unexpected errors, a 500 status with an error message is returned.
 */
const getUserNames = async (req, res) => {
  try {
    const { userIds } = req.body; // Get userIds from the request body
    if (!userIds || userIds.length === 0) {
      return res.status(400).json({ error: "No user IDs provided" });
    }

    // Fetch users that match the provided userIds
    const users = await User.find({
      userId: { $in: userIds }, // Match users with the provided IDs
    });

    // If no users are found, send an empty response
    if (!users.length) {
      return res.status(200).json({});
    }

    // Map users by their customerId
    const userMap = users.reduce((acc, user) => {
      acc[user.userId] = user; // Map userId to the user data
      return acc;
    }, {});

    // Return the user map with customerIds
    res.status(200).json(userMap);
  } catch (error) {
    console.error("Error fetching user names:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

/**
 * Checks if a user exists based on the provided userId, email, or contact number.
 * If no user is found, it returns an object indicating that the user does not exist.
 *
 * @function checkUser
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.data - The userId, email, or contact number to search for.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A response indicating whether the user exists or not.
 *
 * @throws {Error} If there is an error while searching for the user.
 */
const checkUser = async (req, res) => {
  // use userId to find
  let user = await User.findOne({ userId: req.params.data });

  // if email is provided
  if (!user) {
    user = await Customer.findOne({ email: req.params.data });
  }

  // if contact number is provided
  if (!user) {
    user = await User.findOne({ contactNumber: req.params.data });
  }

  if (!user) {
    return res.status(200).json({ exists: false });
  }

  res.status(200).json({ exists: true });
};

/**
 * Retrieves all customers from the database.
 * This function filters users by their role to return only customers. If no customers are found, a 404 error is returned.
 *
 * @async
 * @function getAllCustomers
 * @param {Object} req - The request object.
 * @param {Object} res - The response object to send back the customers or error message.
 *
 * @returns {Promise<void>} - Sends a 200 response with the list of customers or a 404 error if no customers are found.
 *
 * @throws {Error} - If there is an error while fetching customers, a 400 status with the error message is returned.
 */
const getAllCustomers = async (req, res) => {
  try {
    const customers = await User.find({ role: "customer" });
    if (!customers || customers.length === 0) {
      return res.status(404).json({ error: "No customers found" });
    }
    res.status(200).json(customers);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Updates the user information based on the provided userId and request body.
 * If the update is successful and the user is updating their own information, the session is updated.
 *
 * @function updateUser
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.userId - The ID of the user to update.
 * @param {Object} req.body - The body of the request, containing the new user information.
 * @param {Object} req.session - The session object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - The updated user information in the session if the user is updating their own data.
 * 
 * @throws {Error} If the user is not found or there is an error updating the user information.
 */
const updateUser = async (req, res) => {
  try {
    const currentUser = await User.findOne({
      userId: req.params.userId,
    }).lean();

    if (!currentUser) {
      return res.json({ error: "No such user" });
    }

    if (req.body.password) {
      const isPasswordMatch = await bcrypt.compare(
        req.body.password,
        currentUser.password
      );
      if (isPasswordMatch) {
        return res.json({
          error: "New password cannot be the same as the current password.",
        });
      }
      const salt = await bcrypt.genSalt(10);
      req.body.password = await bcrypt.hash(req.body.password, salt);
    } else {
      delete req.body.password;
    }

    const user = await User.findOneAndUpdate(
      { userId: req.params.userId },
      { ...req.body },
      { new: true, runValidators: true }
    );

    // Determines whether the update is being done by an admin or a customer
    if (req.params.userId === req.session.user.userId) {
      updateUserSession(req, user);
    }

    res.status(200).json(req.session.user);
  } catch (error) {
    res.status(400).json({ error: error.message });
    console.log(error.message);
  }
};

/**
 * Updates the customer's password after verifying the old password and ensuring the new password is different.
 * Hashes the new password and saves it to the database.
 *
 * @function updateCustomerPassword
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.userId - The ID of the user whose password is being updated.
 * @param {Object} req.body - The body of the request.
 * @param {string} req.body.oldPassword - The user's current password.
 * @param {string} req.body.newPassword - The new password to be set.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the password update is successful, or an error message if validation fails.
 *
 * @throws {Error} If there is an issue with the password update process or validation.
 */
const updateCustomerPassword = async (req, res) => {
  try {
    console.log(req.body);

    const currentUser = await User.findOne({
      userId: req.params.userId,
    }).lean();

    if (!currentUser) {
      return res.status(404).json({ error: "No such user" });
    }

    const isOldPasswordMatch = await bcrypt.compare(
      req.body.oldPassword,
      currentUser.password
    );
    if (isOldPasswordMatch) {
      const isNewPasswordMatch = await bcrypt.compare(
        req.body.newPassword,
        currentUser.password
      );
      if (isNewPasswordMatch) {
        return res
          .status(400)
          .json({
            error: "New password cannot be the same as the current password.",
          });
      }
    } else {
      return res
        .status(400)
        .json({
          error:
            "The old password you have entered does not match with your current password.",
        });
    }

    const salt = await bcrypt.genSalt(10);
    req.body.newPassword = await bcrypt.hash(req.body.newPassword, salt);

    await User.findOneAndUpdate(
      { userId: req.params.userId },
      {
        password: req.body.newPassword,
      }
    );

    return res.status(200).json({ message: "Password Successfully Updated" });
  } catch (error) {
    res.status(400).json({ error: error.message });
    console.log(error.message);
  }
};

/**
 * Retrieves all users from the database.
 * This function fetches all user records from the User collection. If no users are found, a 404 error is returned.
 * If an error occurs during the database query, a 400 error is returned with the error message.
 *
 * @function getLatestUser
 * @param {Object} req - The request object.
 * @param {Object} res - The response object to send back the user data or error message.
 *
 * @returns {Promise<void>} - Sends a 200 response with the list of users if found. Sends a 404 error if no users are found.
 *                             If there is a database or internal error, a 400 error with the error message is returned.
 *
 * @throws {Error} - Returns a 400 status with an error message if there is an issue fetching the users from the database.
 */
const getLatestUser = async (req, res) => {
  try {
    const users = await User.find({});
    if (!users || users.length === 0) {
      return res.status(404).json({ error: "No users found" });
    }
    res.status(200).json(users);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Updates the user's session with the provided user details.
 * It modifies the session information to reflect the new user data such as first name, last name, and contact number.
 *
 * @function updateUserSession
 * @param {Object} req - The request object.
 * @param {Object} req.session - The session object associated with the current request.
 * @param {Object} req.session.user - The user object stored in the session.
 * @param {Object} user - The user data that will update the session.
 * @param {string} user.firstName - The updated first name of the user.
 * @param {string} user.lastName - The updated last name of the user.
 * @param {string} user.contactNumber - The updated contact number of the user.
 * 
 * @returns {void} - The function does not return anything; it directly updates the session with the new user data.
 */
const updateUserSession = (req, user) => {
  req.session.user.firstName = user.firstName;
  req.session.user.lastName = user.lastName;
  req.session.user.contactNumber = user.contactNumber;
};

/**
 * Retrieves all users from the database.
 * Fetches the list of users and returns them in the response. If no users are found, a 404 error is returned.
 *
 * @async
 * @function getAllUsers
 * @param {Object} req - The request object.
 * @param {Object} res - The response object to send back the users or error message.
 *
 * @returns {Promise<void>} - Sends a 200 response with the list of users or a 404 error if no users are found.
 *
 * @throws {Error} - If there is an error while fetching users, a 400 status with the error message is returned.
 */
const getAllUsers = async (req, res) => {
  console.log("getAllUsers route hit"); // Debugging line
  try {
    const users = await User.find(); // Fetch all users
    if (!users || users.length === 0) {
      return res.status(404).json({ error: "No users found" });
    }
    res.status(200).json(users);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Updates the status of a user based on the provided userId and status.
 * If the user is found and the status is updated successfully, a success message is returned with the updated user information.
 * If the user is not found, a 404 error is returned.
 *
 * @function updateUserStatus
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.userId - The ID of the user whose status needs to be updated.
 * @param {Object} req.body - The body of the request, containing the new status.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message with the updated user information if the update is successful.
 *
 * @throws {Error} If there is an error updating the user's status or if the user is not found.
 */
const updateUserStatus = async (req, res) => {
  const { userId } = req.params;
  const { status } = req.body;

  console.log(userId);

  try {
    // Find the user by userId and update their status
    const user = await User.findOneAndUpdate(
      { userId: userId },
      { status: status },
      { new: true, runValidators: true }
    ).lean();

    if (!user) {
      return res.status(404).json({ error: "No such user" });
    }

    res.status(200).json({ message: "Status updated successfully", user });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * Deletes a user based on the provided userId.
 * If the user is found and deleted successfully, a success message is returned.
 * If the user is not found, a 404 error is returned.
 *
 * @function deleteUser
 * @param {Object} req - The request object.
 * @param {Object} req.params - The route parameters.
 * @param {string} req.params.userId - The ID of the user to be deleted.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message if the user is deleted successfully.
 *
 * @throws {Error} If there is an error deleting the user or if the user is not found.
 */
const deleteUser = async (req, res) => {
  const { userId } = req.params;
  try {
    const user = await User.findOneAndDelete({ userId });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.status(200).json({ message: "User deleted successfully." }); // Delete Success
  } catch (error) {
    console.log(error.message);
    res.status(500).json({ error: error.message });
  }
};

module.exports = {
  createUser,
  createCustomer,
  getUser,
  checkUser,
  getAllCustomers,
  updateUser,
  getLatestUser,
  getAllUsers,
  updateUserStatus,
  deleteUser,
  updateCustomerPassword,
  getUserNames,
};
