const Chatbot = require('../models/ChatbotModel');
const axios = require('axios');

/**
 * Controller to retrieve chatbot credentials for client-side.
 * Fetches chatbot configuration if it exists.
 *
 * @function getChatbotCredentials
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Chatbot configuration data or 404 if not found.
 */
const getChatbotCredentials = async (req, res) => {
  try {
    const chatbot = await Chatbot.findOne();
    if (!chatbot) {
      return res.status(404).json({ error: 'Chatbot configuration not found' });
    }
    res.status(200).json(chatbot);
  } catch (error) {
    res.status(500).json({ error: 'Server error: ' + error.message });
  }
};

/**
 * Controller to upload PDF files to a specified S3 URL.
 * Sends file content to the upload URL provided.
 *
 * @function uploadPDF
 * @param {Object} req - The request object containing upload URL and file content.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Success message if upload is successful.
 *
 * @throws {Error} If file upload to S3 fails.
 */
const uploadPDF = async (req, res) => {
  const uploadUrl = req.params.uploadUrl; // Get uploadUrl from the URL parameters
  const buffer = req.body; // Buffer is directly available from the raw body

  try {
    // Upload the actual file content to the provided uploadUrl
    const response = await axios.put(uploadUrl, buffer, {
      headers: {
        'Content-Type': 'application/octet-stream',
      },
    });

    // Check if the upload was successful
    if (response.status !== 200) {
      throw new Error('Failed to upload file to S3');
    }

    res.status(200).send('File uploaded successfully');
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).send('Failed to upload file');
  }
};

/**
 * Controller to create or update chatbot credentials and scripts.
 * Saves or modifies chatbot configuration data based on presence.
 *
 * @function upsertChatbotCredentials
 * @param {Object} req - The request object containing chatbot scripts and credentials.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Updated chatbot configuration.
 *
 * @throws {Error} If server error occurs during save or update.
 */
const upsertChatbotCredentials = async (req, res) => {
  const { script1, script2 } = req.body.chatbot;
  const { fetchLink, token, botId, workspaceId, kbId, source } = req.body.credentials;

  try {
    let chatbot = await Chatbot.findOne();
    if (chatbot) {
      // Update existing chatbot configuration
      chatbot.chatbot.script1 = script1;
      chatbot.chatbot.script2 = script2;
      chatbot.credentials.fetchLink = fetchLink;
      chatbot.credentials.token = token;
      chatbot.credentials.botId = botId;
      chatbot.credentials.workspaceId = workspaceId;
      chatbot.credentials.kbId = kbId;
      chatbot.credentials.source = source;
    } else {
      // Create new chatbot configuration
      chatbot = new Chatbot({
        chatbot: {
          script1,
          script2,
        },
        credentials: {
          fetchLink,
          token,
          botId,
          workspaceId,
          kbId,
          source,
        },
      });
    }

    await chatbot.save();
    res.status(200).json(chatbot);
  } catch (error) {
    res.status(500).json({ error: 'Server error: ' + error.message });
  }
};

/**
 * Controller to update chatbot error status.
 * Sets isError flag for chatbot configuration based on request.
 *
 * @function upsertChatbotError
 * @param {Object} req - The request object containing isError flag.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - Success message if isError flag is updated.
 *
 * @throws {Error} If isError is not boolean or server error occurs.
 */
const upsertChatbotError = async (req, res) => {
  try {
    const { isError } = req.body.chatbot; // Destructure isError from the request body

    if (typeof isError !== 'boolean') {
      return res.status(400).json({ error: 'Invalid value for isError. It should be a boolean.' });
    }

    let chatbot = await Chatbot.findOne();
    if (chatbot) {
      // Update the isError flag in the existing chatbot configuration
      chatbot.chatbot.isError = isError;
      await chatbot.save();
      res.status(200).json({ message: 'Chatbot error status updated successfully', chatbot });
    } else {
      // If no chatbot configuration exists, return a 404 error
      res.status(404).json({ error: 'Chatbot configuration not found' });
    }
  } catch (error) {
    // Handle any server errors
    res.status(500).json({ error: 'Server error: ' + error.message });
  }
};



// Export the CRUD functions
module.exports = {
  getChatbotCredentials,
  uploadPDF,
  upsertChatbotCredentials,
  upsertChatbotError
};