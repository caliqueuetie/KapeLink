const Notification = require("../models/NotificationModel");
const webpush = require("web-push");
const { User } = require("../models/UserModel");
const moment = require("moment-timezone");


/**
 * Sets VAPID (Voluntary Application Server Identification for Web Push) keys and contact details for web push notifications.
 *
 * @constant {string} publicVapidKey - The public VAPID key used to identify the application server.
 * @constant {string} privateVapidKey - The private VAPID key used for signing web push notifications.
 *
 * @function webpush.setVapidDetails
 * @param {string} contactEmail - Contact email for the application, used for identification and support.
 * @param {string} publicVapidKey - The public VAPID key for web push notification subscriptions.
 * @param {string} privateVapidKey - The private VAPID key for secure notification signing.
 *
 */
const publicVapidKey =
  "BPS_7mTXWgrxKlol9cuAajX5WQ5GnZpQ7x3F367aWNAgCuP-9TMSL6bEcgSri1HbGFxp9Jo64OxOfE-ySQEPURI";
const privateVapidKey = "MMiSyZ5sfD8DrlgY1c1jgFuy7NCnFDEQQnD79QAJVHQ";

webpush.setVapidDetails(
  "mailto:kapelink.business@gmail.com",
  publicVapidKey,
  privateVapidKey
);

/**
 * This function creates a new notification in the database. It first retrieves all existing notifications
 * to determine the latest `notificationId`, then parses and sorts them to ensure the IDs are in descending order.
 * Using the highest `notificationId`, it calculates the next unique ID for the new notification. A new notification
 * object is then created using the data provided in the request body, while also adding the current date and time
 * formatted in the "Asia/Manila" timezone. This notification is saved to the database and returned in the response
 * with a status code of 200. If an error occurs during any part of the process, the error message is logged, and a
 * response with a status code of 400 is sent back, including the error details.
 *
 * @param {Object} req - Notification data.
 * @param {Object} res - The response object
 * @throws {Error} If there is an issue retrieving or saving notifications in the database.
 */

const createNotification = async (req, res) => {
  try {

    const { receiver, roles, message, date, time } = req.body;

    const recentNotification = await Notification.findOne({
      receiver,
      roles,
      message: { $regex: /order\/s must be prepared soon!/i }, 
      date,
      time,
    });

    if (recentNotification) {
      console.log("Similar notification already exists. Skipping creation.");
      return res.status(200).json({ message: "Duplicate notification avoided" });
    }

    const notificationCount = await Notification.find().exec();

    const parsedNotifications = notificationCount.map((notification) => ({
      ...notification._doc,
      notificationId: parseInt(notification.notificationId, 10),
    }));

    parsedNotifications.sort((a, b) => b.notificationId - a.notificationId);

    const latestNotifId =
      parsedNotifications.length > 0
        ? parsedNotifications[0].notificationId
        : 0;
    const nextNotificationId = latestNotifId + 1;

    const newNotificationData = {
      ...req.body,
      notificationId: `${nextNotificationId}`,
      date: moment().tz("Asia/Manila").format("MM/DD/YYYY"), // Change to your desired timezone
      time: moment().tz("Asia/Manila").format("HH:mm"), // 24-hour format
    };

    const notification = await Notification.create(newNotificationData);

    res.status(200).json(notification);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * This function toggles the `read` status of a notification between `true` and `false` based on its current value.
 * It retrieves the notification by its ID from the request parameters and checks if the notification exists.
 * If the notification is found, its `read` status is updated to the opposite value and saved in the database.
 * The function also emits a socket event `readNotificationBM` to notify relevant roles about the status change.
 * If both "barista" and "manager" roles are present in the notification, a specific log message is printed to the console.
 * The updated notification is returned in the response with a status code of 200. If the notification is not found,
 * a 404 status code is returned with an appropriate error message. In case of any other errors, a 400 status code is
 * returned with the error details.
 *
 * @param {Object} req - Notification ID in the `params`.
 * @param {Object} res - The response.
 * @throws {Error} If there is an issue retrieving or updating the notification in the database.
 */

const toggleNotificationRead = async (req, res) => {
  try {
    const { id } = req.params;

    const notification = await Notification.findById(id);

    if (!notification) {
      return res.status(404).json({ message: "Notification not found" });
    }

    const updatedNotification = await Notification.findByIdAndUpdate(
      id,
      { read: !notification.read },
      { new: true }
    );

    const roles = updatedNotification.roles;

    const io = req.app.get("socketio");

    if (roles.includes("barista") && roles.includes("manager")) {
      io.emit("readNotificationBM", updatedNotification.read);
      console.log("Notification emitted for baristas and managers");
    } else {
      io.emit("readNotificationBM", updatedNotification.read);
      console.log("Notification emitted");
    }

    res.status(200).json(updatedNotification);
  } catch (error) {
    console.error(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * This function toggles the `read` status of all notification as  `true`.
 * It retrieves the notification by its roles or reciever id based on what's passed to the function.
 * If the notification is found, its `read` status is updated to true and saved in the database.
 * The function also emits a socket event `readNotificationBM` to notify relevant roles about the status change.
 *
 * @param {Object} req - Recievers ID or roles array in the `params`.
 * @param {Object} res - The response.
 * @throws {Error} If there is an issue updating the notifications in the database.
 */
const markAllAsRead = async (req, res) => {
  try {
    const { roles, id } = req.body;  // Get roles and id from request body
    const io = req.app.get("socketio");

    let query = {};

    // If roles are provided, match notifications with those roles
    if (roles && Array.isArray(roles)) {
      query.roles = { $in: roles };
    }

    // If id is provided, match notifications with that ID
    if (id) {
      query.userId = mongoose.Types.ObjectId(id);  // Assuming userId is an ObjectId
    }

    // Find and update the matching notifications to mark them as read
    const updatedNotifications = await Notification.updateMany(
      query,
      { $set: { read: true } },
      { new: true }
    );
    
    if (roles && Array.isArray(roles)) {
      io.emit("readNotificationBM", updatedNotifications.read);
    }

    // Return the number of updated notifications
    res.status(200).json({
      message: `${updatedNotifications.nModified} notifications marked as read.`,
      updatedNotifications,
    });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

module.exports = { markAllAsRead };


// get notifications by receiver and roles
/**
 * This function retrieves notifications from the database based on the `receiver` and `roles` query parameters.
 * If `receiver` is set to "all," it fetches notifications that match any of the specified roles.
 * Otherwise, it retrieves notifications where the `receiver` matches the specified value or is set to "all,"
 * and the roles include at least one of the specified roles. The fetched notifications are returned in the response
 * with a status code of 200. If an error occurs during the process, it logs the error and sends a 400 status code
 * with the error details.
 *
 * @param {Object} req - The `receiver` and `roles` in the query parameters.
 * @param {Object} res - The response.
 * @throws {Error} If there is an issue retrieving notifications from the database.
 */

const getNotifications = async (req, res) => {
  try {
    const { receiver, roles } = req.query;

    let notifications;

    if (receiver === "all") {
      notifications = await Notification.find({
        roles: { $in: roles },
      });
    } else {
      notifications = await Notification.find({
        $or: [{ receiver: receiver }, { receiver: "all" }],
        roles: { $in: roles },
      });
    }

    res.status(200).json(notifications);
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ error: error.message });
  }
};

/**
 * This function retrieves notifications for the currently authenticated customer based on their `userId`.
 * The function first checks if the user's session is valid and ensures the presence of a `userId`
 * in the session. If the user is not authenticated, a 401 status code is returned with an error message.
 * For authenticated users, it queries the database to fetch notifications where the `receiver` array includes
 * the customer's `userId`. The notifications are returned in the response with a status code of 200. If no
 * notifications are found, an empty array is returned. In case of any server-side errors during the database
 * query, a 500 status code is returned with an appropriate error message.
 *
 * @param {Object} req - Authenticated user's session data.
 * @param {Object} res - The response.
 * @throws {Error} If there is an issue fetching notifications from the database.
 */

const getNotificationsByCustomerID = async (req, res) => {
  if (!req.session || !req.session.user || !req.session.user.userId) {
    return res.status(401).json({ error: "User not authenticated" });
  }
  const customerId = req.session.user.userId;

  try {
    const notifications = await Notification.find({
      receiver: { $in: [customerId] },
    });
    res.status(200).json(notifications.length ? notifications : []);
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res
      .status(500)
      .json({ error: "Server error while fetching notifications" });
  }
};

/**
 * This function saves a push subscription for a user based on their email or contact number.
 * This accepts a subscription and a `userId` from the request body. It formats
 * the `userId` to ensure compatibility with Philippine contact number conventions by
 * converting numbers starting with "0" to the international format "+63". The function
 * then updates the user's `pushSubscription` field in the database by searching for the
 * user based on their email or formatted contact number. If the user is not found, a 404
 * status code is returned with an appropriate error message. On successful update, a
 * success message is returned with a status code of 200. If an error occurs during the
 * database operation, a 500 status code is returned with an error message, and the error
 * is logged for debugging purposes.
 *
 * @param {Object} req - The `subscription` and `userId`.
 * @param {Object} res - The response.
 * @throws {Error} If there is an issue updating the user's subscription in the database.
 */
const saveSubscription = async (req, res) => {
  const formatContactNumber = (number) => {
    if (number.startsWith("0")) {
      return "+63" + number.slice(1);
    } else if (!number.startsWith("+63")) {
      return "+63" + number;
    }
    return number;
  };

  const { subscription, userId } = req.body;

  try {
    const formattedUserId = formatContactNumber(userId);
    const user = await User.findOneAndUpdate(
      {
        $or: [{ email: userId }, { contactNumber: formattedUserId }],
      },
      { pushSubscription: subscription },
      { new: true }
    );

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.status(200).json({ message: "Subscription saved successfully" });
  } catch (error) {
    console.error("Error saving subscription:", error);
    res.status(500).json({ error: "Failed to save subscription" });
  }
};

/**
 * Sends a notification to a specified user if a valid push subscription exists.
 *
 * This function finds the user by their `userId`. If the user or their push subscription
 * does not exist, it logs a message and exits. If a valid subscription is found, it sends
 * the notification using `webpush.sendNotification`. In case of an error, it logs the error.
 * If the error is due to an expired subscription (status code 410), the function:
 * - Clears the expired subscription.
 * - Emits an `expiredNotification` event to the front-end.
 * - Waits 30 seconds before retrying the notification.
 *
 * @async
 * @function sendNotification
 * @param {Object} params - The parameters.
 * @param {string} params.userId - The user ID for whom the notification is being sent.
 * @param {Object} params.notificationPayload - The notification content.
 * @throws Will throw an error if notification sending fails.
 */
const sendNotification = async ({ userId, notificationPayload }) => {
  try {
    const user = await User.findOne({ userId });

    // Enhanced null check to ensure the subscription and endpoint exist
    if (!user || !user.pushSubscription || !user.pushSubscription.endpoint) {
      console.log(
        `No valid subscription found for user ${userId}. Skipping notification.`
      );
      return; // Exit the function if no valid subscription
    }

    const subscription = user.pushSubscription;
    const payload = JSON.stringify(notificationPayload);

    await webpush.sendNotification(subscription, payload);
    console.log("Notification sent successfully");
  } catch (error) {
    console.error("Error sending notification:", error);

    if (error.statusCode && error.statusCode === 410) {
      console.log(
        `Push subscription expired for user ${userId}. Clearing subscription...`
      );

      const io = req.app.get("socketio");
      io.emit("expiredNotification");

      setTimeout(async () => {
        try {
          await sendNotification({ userId, notificationPayload });
        } catch (retryError) {
          console.error(
            "Error resending notification after expiration:",
            retryError
          );
        }
      }, 30000);

      console.log(`Cleared push subscription for user ${userId}.`);
    } else {
      console.error("User Signed Out / Has no subscription!");
    }

    throw error;
  }
};

/**
 * This function sends a batch notification to all users with specified roles who have a valid push subscription,
 * handling potential issues with expired subscriptions and creating notification records.
 *
 * @async
 * @function sendBatchNotification
 * @param {Object} notificationPayload - The payload for the notification, serialized to JSON for sending.
 * @param {Object} notificationData - The data to create a notification record for the barista/manager's interface.
 *
 * @returns {Promise<void>} - Executes the batch notification process and handles errors and retries if needed.
 *
 * @throws {Error} - Logs and continues on specific errors related to sending notifications.
 */
const sendBatchNotification = async (notificationPayload, notificationData) => {
  try {
    const managers = await User.find({
      role: { $in: ["manager", "barista"] },
      pushSubscription: { $exists: true },
    });

    const payload = JSON.stringify(notificationPayload);

    await Promise.all(
      managers.map(async (manager) => {
        const subscription = manager.pushSubscription;

        // Enhanced null check: ensure subscription and its endpoint exist
        if (!subscription || !subscription.endpoint) {
          console.log(
            `Invalid subscription for user ${manager.userId}. Skipping notification.`
          );
          return; // Skip to the next manager if no valid subscription
        }

        try {
          await webpush.sendNotification(subscription, payload);
          console.log(
            `Notification sent successfully to user ${manager.userId}`
          );

          // Create a notification record for the barista/manager's interface
          await createNotification(
            { body: { ...notificationData } },
            {
              status: (statusCode) => ({
                json: (response) => {
                  console.log(
                    `Notification entry created with status ${statusCode} for user ${manager.userId}`
                  );
                },
              }),
            }
          );
        } catch (error) {
          console.error(
            `Error sending notification to user ${manager.userId}:`,
            error
          );

          if (error.statusCode === 410) {
            console.log(
              `Push subscription expired for user ${manager.userId}. Clearing subscription...`
            );
            const io = req.app.get("socketio");
            io.emit("expiredNotification");

            setTimeout(async () => {
              try {
                const refreshedUser = await User.findOne({
                  userId: manager.userId,
                });
                if (
                  refreshedUser &&
                  refreshedUser.pushSubscription &&
                  refreshedUser.pushSubscription.endpoint
                ) {
                  await webpush.sendNotification(
                    refreshedUser.pushSubscription,
                    payload
                  );
                  console.log(
                    `Notification resent successfully to user ${manager.userId}`
                  );
                } else {
                  console.error(
                    `No valid subscription found for user ${manager.userId} after clearing.`
                  );
                }
              } catch (retryError) {
                console.error(
                  `Error resending notification after expiration for user ${manager.userId}:`,
                  retryError
                );
              }
            }, 30000);

            console.log(
              `Cleared push subscription for user ${manager.userId}.`
            );
          } else {
            console.error(
              `User ${manager.userId} has no active subscription or is signed out.`
            );
          }
        }
      })
    );
  } catch (generalError) {
    console.error("Error in batch notification:", generalError);
  }
};

/**
 * Checks if a user has a push notification subscription by searching with either their email or formatted contact number.
 *
 * @async
 * @function checkSubscription
 * @param {Object} req - The request object containing route parameters.
 * @param {string} req.params.userId - The user identifier, which could be an email or contact number.
 * @param {Object} res - The response object for sending results back to the client.
 *
 * @returns {Promise<void>} - User's push subscription if found, or an error if not.
 *
 * @throws {Error} If an error occurs while querying the database or during data formatting.
 *   - Database connection issues or query errors may lead to errors during user lookup.
 *   - An internal server error will be returned if an error occurs, with the message logged to the console.
 */
const checkSubscription = async (req, res) => {
  const { userId } = req.params;

  const formatContactNumber = (number) => {
    if (number.startsWith("0")) {
      return "+63" + number.slice(1);
    } else if (!number.startsWith("+63")) {
      return "+63" + number;
    }
    return number;
  };

  try {
    const formattedUserId = formatContactNumber(userId);

    const user = await User.findOne({
      $or: [{ email: userId }, { contactNumber: formattedUserId }],
    });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    return res.status(200).json({ subscription: user.pushSubscription });
  } catch (error) {
    console.error("Error checking subscription:", error);
    return res.status(500).json({ error: "Internal server error" });
  }
};

module.exports = {
  createNotification,
  toggleNotificationRead,
  getNotifications,
  getNotificationsByCustomerID,
  saveSubscription,
  sendNotification,
  sendBatchNotification,
  checkSubscription,
  markAllAsRead
};
