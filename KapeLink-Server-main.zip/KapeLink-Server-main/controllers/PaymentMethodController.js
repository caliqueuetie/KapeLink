const PaymentMethod = require("../models/PaymentModel");
const path = require("path");
const fs = require("fs");
const { paymentMethodPath } = require("../helpers/ImagePathHelper");

/**
 * Fetches all payment methods from the database and returns their details.
 * If the payment method has an image, the image path is updated before returning the details.
 * If no payment methods are found, it returns an empty array.
 *
 * @function getAllPaymentMethods
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Object} - A JSON response containing a list of all payment methods, including their image URLs (if available).
 *
 * @throws {Error} If there is an error during the database query or processing.
 */

const getAllPaymentMethods = async (req, res) => {
  try {
    const paymentMethods = await PaymentMethod.find();

    if (paymentMethods) {
      paymentMethods.forEach((paymentMethod) => {
        if (paymentMethod.img !== null) {
          paymentMethod.img = paymentMethodPath() + paymentMethod.img;
        }
      });
    } else {
      console.error("paymentMethods is null or undefined");
    }

    res.status(200).json(paymentMethods);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching payment methods" });
  }
};

/**
 * Fetches all active payment methods and returns their details.
 * If the payment method has an image, the image path is updated before returning the details.
 * If no active payment methods are found, it returns an empty array.
 *
 * @function getPaymentMethods
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 *
 * @returns {Object} - A JSON response containing a list of active payment methods, including their image URLs (if available).
 *
 * @throws {Error} If there is an error during the database query or processing.
 */

const getPaymentMethods = async (req, res) => {
  try {
    const paymentMethods = await PaymentMethod.find({ status: "Active" });

    if (paymentMethods) {
      paymentMethods.forEach((paymentMethod) => {
        if (paymentMethod.img !== null) {
          paymentMethod.img = paymentMethodPath() + paymentMethod.img;
        }
      });
    } else {
      console.error("paymentMethods is null or undefined");
    }

    res.status(200).json(paymentMethods);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching payment methods" });
  }
};

/**
 * Fetches the payment method by its operation ID (`opid`) and returns its name and image.
 * If the payment method is found, its image path is updated before returning the details.
 * If no payment method is found, it returns a default response with "N/A" as the name and null for the image.
 *
 * @function getPaymentName
 * @param {Object} req - The request object.
 * @param {Object} req.params - The parameters of the request.
 * @param {string} req.params.opid - The operation ID of the payment method to be fetched.
 * @param {Object} res - The response object.
 *
 * @returns {Object} - A JSON response with the payment name and image URL or default values if not found.
 *
 * @throws {Error} If there is an error during the database query or processing.
 */

const getPaymentName = async (req, res) => {
  try {
    const opid = parseInt(req.params.opid);

    const payment = await PaymentMethod.findOne({ opid });

    if (!payment) {
      return res.status(200).json({ name: "N/A", img: null });
    }

    payment.img = paymentMethodPath() + payment.img;

    res.status(200).json(payment);
  } catch (error) {
    res
      .status(500)
      .json({ error: "An error occurred while fetching the payment" });
  }
};

/**
 * Updates the status of multiple payment methods, excluding certain payment methods specified by their operation IDs.
 * The status is updated for all payment methods except those in the `excludeOids` array.
 * The updated payment methods are broadcasted via Socket.IO to notify connected clients.
 *
 * @function updatePaymentStatus
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing the status update and excluded payment method IDs.
 * @param {string} req.body.status - The new status to be set for the payment methods.
 * @param {Array} req.body.excludeOids - An array of operation IDs to exclude from the status update.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message is returned in the response once the statuses are updated.
 *
 * @throws {Error} If there is an issue with updating the payment statuses.
 */
const updatePaymentStatus = async (req, res) => {
  const { status, excludeOids } = req.body;

  try {
    const paymentMethod = await PaymentMethod.updateMany(
      { opid: { $nin: excludeOids } },
      { $set: { status: status } }
    );

    const io = req.app.get("socketio");
    io.emit("paymentMethods", paymentMethod);
    res.status(200).send({ message: "Payment statuses updated successfully." });
  } catch (error) {
    res.status(500).send({ error: "Failed to update payment statuses." });
  }
};

/**
 * Updates the details of an existing payment method.
 * The method updates the name, payment details, and status of the payment method.
 * If a new image is uploaded, it replaces the old image.
 * The updated payment method is saved and broadcasted via Socket.IO to notify connected clients.
 *
 * @function updatePayment
 * @param {Object} req - The request object.
 * @param {Object} req.params - The URL parameters, including the payment method ID.
 * @param {string} req.params.id - The ID of the payment method to be updated.
 * @param {Object} req.body - The body of the request containing updated payment method details.
 * @param {string} req.body.name - The new name of the payment method.
 * @param {string} req.body.payment_details - The updated payment details.
 * @param {string} req.body.status - The updated status of the payment method.
 * @param {Object} req.files - The uploaded files, including the image for the payment method.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A message and the updated payment method object are returned in the response.
 *
 * @throws {Error} If the payment method cannot be found or there is an issue during the update process.
 */

const updatePayment = async (req, res) => {
  const { id } = req.params;
  const { name, payment_details, status } = req.body;

  try {
    const payment = await PaymentMethod.findById(id);
    if (!payment) {
      return res.status(404).json({ error: "Payment method not found" });
    }

    console.log("Files received by multer:", req.files);

    if (name) payment.name = name;
    if (payment_details && payment_details.trim() !== "")
      payment.payment_details = payment_details;
    if (status) payment.status = status;

    if (req.files && req.files.img && req.files.img[0]) {
      const newImgPath = req.files.img[0].filename;

      if (payment.img) {
        const oldImgPath = path.join(
          __dirname,
          "../uploads/payment_method/",
          payment.img
        );
        if (fs.existsSync(oldImgPath)) {
          console.log("Removing old image:", oldImgPath);
          fs.unlinkSync(oldImgPath);
        }
      }

      console.log("Updating image path to:", newImgPath);
      payment.img = newImgPath;
    }

    const newPayment = await payment.save();
    const io = req.app.get("socketio");
    io.emit("paymentMethods", newPayment);
    res
      .status(200)
      .json({ message: "Payment method updated successfully", payment });
  } catch (error) {
    console.error("Error updating payment method:", error);
    res.status(500).json({ error: "Error updating payment method" });
  }
};

/**
 * Adds a new payment method to the database.
 * The method first checks if a payment method with the same name already exists.
 * If a file is received via Multer, it is saved and associated with the payment method.
 * After the payment method is successfully added, it is broadcasted via Socket.IO to notify connected clients.
 *
 * @function addPaymentMethod
 * @param {Object} req - The request object.
 * @param {Object} req.body - The body of the request containing payment details.
 * @param {string} req.body.name - The name of the payment method.
 * @param {string} req.body.payment_details - The details of the payment method.
 * @param {Object} req.file - The file uploaded via Multer (e.g., image for the payment method).
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A newly created payment method object is returned in the response.
 *
 * @throws {Error} If the payment method name already exists or there is an issue during the payment method creation.
 */

const addPaymentMethod = async (req, res) => {
  const { name, payment_details } = req.body;

  try {
    console.log("File received by multer:", req.file);

    const existingPayment = await PaymentMethod.findOne({
      name: { $regex: new RegExp("^" + name + "$", "i") },
    });

    if (existingPayment) {
      return res.status(400).json({
        error:
          "Payment method name already exists. Please choose a different name.",
      });
    }

    const count = await PaymentMethod.countDocuments();
    const newOpid = count + 1;

    const img = req.file ? req.file.filename : null;

    console.log("Image path:", img);

    const newPayment = new PaymentMethod({
      opid: newOpid,
      name,
      payment_details,
      img,
      status: "Inactive",
    });

    const payment = await newPayment.save();
    const io = req.app.get("socketio");
    io.emit("paymentMethods", payment);
    res.status(201).json(newPayment);
  } catch (error) {
    console.error("Error adding new payment method:", error);
    res.status(500).json({ error: "Error adding new payment method" });
  }
};

/**
 * Deletes a payment method from the database.
 * If the payment method has an associated image, it will be deleted from the file system.
 * The deletion is then broadcasted via Socket.IO to notify connected clients.
 *
 * @function deletePaymentMethod
 * @param {Object} req - The request object.
 * @param {Object} req.params - The URL parameters containing the payment method `id`.
 * @param {string} req.params.id - The ID of the payment method to delete.
 * @param {Object} res - The response object.
 *
 * @returns {Promise<void>} - A success message is returned in the response.
 *
 * @throws {Error} If there is an issue deleting the payment method or removing the associated image.
 */
const deletePaymentMethod = async (req, res) => {
  const { id } = req.params;

  try {
    const payment = await PaymentMethod.findById(id);
    if (!payment) {
      return res.status(404).json({ error: "Payment method not found" });
    }

    if (payment.img) {
      const imgPath = path.join(__dirname, "..", payment.img);
      if (fs.existsSync(imgPath)) {
        fs.unlinkSync(imgPath);
      }
    }

    const newPayment = await PaymentMethod.findByIdAndDelete(id);
    const io = req.app.get("socketio");
    io.emit("paymentMethods", newPayment);
    res.status(200).json({ message: "Payment method deleted successfully" });
  } catch (error) {
    console.error("Error deleting payment method:", error);
    res.status(500).json({ error: "Error deleting payment method" });
  }
};

module.exports = {
  getAllPaymentMethods,
  getPaymentMethods,
  getPaymentName,
  updatePaymentStatus,
  updatePayment,
  addPaymentMethod,
  deletePaymentMethod,
};
