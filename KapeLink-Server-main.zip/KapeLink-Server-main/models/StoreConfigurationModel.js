/**
 * Mongoose schema for store configuration settings.
 *
 * This module defines the schema for the store configuration, including store ID,
 * opening and closing times, and the status of the store (open or closed).
 *
 * @module StoreConfiguration
 */

/**
 * Store configuration schema definition.
 *
 * @typedef {Object} StoreConfiguration
 * @property {number} storeId - Unique identifier for the store.
 * @property {Object} openingTime - The store's opening time.
 * @property {number} openingTime.hours - The hour of the store's opening time (0-23).
 * @property {number} openingTime.minutes - The minute of the store's opening time (0-59).
 * @property {Object} closingTime - The store's closing time.
 * @property {number} closingTime.hours - The hour of the store's closing time (0-23).
 * @property {number} closingTime.minutes - The minute of the store's closing time (0-59).
 * @property {string} status - The store's current status (e.g., "Open" or "Closed").
 */
const mongoose = require("mongoose");

const storeConfigurationSchema = new mongoose.Schema(
  {
    storeId: {
      type: Number,
      required: true,
      unique: true,
    },
    openingTime: {
      hours: { type: Number, required: true, min: 0, max: 23 },
      minutes: { type: Number, required: true, min: 0, max: 59 },
    },
    closingTime: {
      hours: { type: Number, required: true, min: 0, max: 23 },
      minutes: { type: Number, required: true, min: 0, max: 59 },
    },
    status: {
      type: String,
      enum: ["Open", "Closed"],
      required: true,
    },
  },
  { collection: "store_configuration", versionKey: false }
);
const StoreConfiguration = mongoose.model(
  "StoreConfiguration",
  storeConfigurationSchema
);

module.exports = StoreConfiguration;
