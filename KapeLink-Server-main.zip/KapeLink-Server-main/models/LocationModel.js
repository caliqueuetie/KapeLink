/**
 * Mongoose schema and model for the `Location` entity.
 * Defines the structure of the `Locations` collection in the database.
 *
 * @module Location
 */

/**
 * Mongoose schema for `Location` collection.
 * Defines the fields: `locationId`, `locationName`, and `status`.
 *
 * @typedef {Object} Location
 * @property {number} locationId - Unique identifier for the location.
 * @property {string} locationName - Name of the location.
 * @property {string} status - The current status of the location (e.g., 'Active', 'Inactive').
 */
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const locationSchema = new Schema(
  {
    locationId: {
      type: Number,
      required: true,
      unique: true,
    },
    locationName: {
      type: String,
      required: true,
      unique: true,
    },
    status: {
      type: String,
      required: true,
    },
  },
  {
    versionKey: false,
  }
);

const Location = mongoose.model("Locations", locationSchema);

module.exports = Location;
