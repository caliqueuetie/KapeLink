/**
 * Mongoose schema for payment methods in the system.
 *
 * This module defines the schema for a payment method, including its ID, name,
 * payment details, associated image, and status. It also defines the validation rules
 * for each field.
 *
 * @module Payment
 */

/**
 * Payment method schema definition.
 *
 * @typedef {Object} Payment
 * @property {number} opid - Unique identifier for the payment method.
 * @property {string} name - The name of the payment method (e.g., "Credit Card").
 * @property {string} payment_details - Detailed information about the payment method.
 * @property {string|null} img - Optional image associated with the payment method.
 * @property {string} status - Status of the payment method (e.g., "Active", "Inactive").
 */
const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    opid: {
      type: Number,
      required: true,
      unique: true,
    },
    name: {
      type: String,
      required: true,
    },
    payment_details: {
      type: String,
      required: true,
    },
    img: {
      type: String,
      required: false,
    },
    status: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

const Payment = mongoose.model("Payment", paymentSchema);

module.exports = Payment;
