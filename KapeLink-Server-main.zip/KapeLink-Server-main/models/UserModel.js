/**
 * Mongoose schema for users with role-based discriminators.
 *
 * This module defines a base `User` schema with shared fields and includes discriminators
 * for different user roles: `Manager`, `Barista`, `Customer`, and `Admin`.
 *
 * @module User
 */

/**
 * Base User schema definition.
 *
 * The base schema defines the fields common to all user roles, including `userId`,
 * `firstName`, `lastName`, `password`, `contactNumber`, `role`, and `status`.
 * It also includes a `pushSubscription` field to store information for push notifications.
 *
 * @typedef {Object} User
 * @property {string} userId - Unique identifier for the user.
 * @property {string} firstName - The user's first name.
 * @property {string} lastName - The user's last name.
 * @property {string} password - The user's password.
 * @property {string} contactNumber - The user's contact number (unique).
 * @property {string} role - The user's role (e.g., "customer", "manager", "barista", "admin").
 * @property {string} status - The user's account status (e.g., "active", "restricted", "temporary").
 * @property {Object} pushSubscription - The user's push subscription details.
 * @property {string} pushSubscription.endpoint - The push notification endpoint.
 * @property {Object} pushSubscription.keys - Keys for the push notification subscription.
 * @property {string} pushSubscription.keys.p256dh - Public key for the push subscription.
 * @property {string} pushSubscription.keys.auth - Authentication key for the push subscription.
 */

/**
 * This discriminator for users with the "manager" role
 *
 * @typedef {User} Manager
 */

/**
 * This discriminator for users with the "barista" role
 *
 * @typedef {User} Barista
 */

/**
 * This discriminator adds fields specific to customers, including an `email` field
 * for unique identification and an `otp` field for one-time password functionality.
 *
 * @typedef {User} Customer
 * @property {string} email - The customer's unique email address.
 * @property {string} otp - A one-time password for the customer.
 */

/**
 * Serves as a discriminator for the "admin" role.
 *
 * @typedef {User} Admin
 */

const mongoose = require("mongoose");

const options = {
  discriminatorKey: "role",
  collection: "users",
  versionKey: false,
};

// Base User Schema
const userSchema = new mongoose.Schema(
  {
    userId: {
      type: String,
      required: true,
      unique: true,
    },
    firstName: {
      type: String,
      required: true,
    },
    lastName: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
    },
    contactNumber: {
      type: String,
      required: true,
      unique: true,
    },
    role: {
      type: String,
      required: true,
      enum: ["customer", "manager", "barista", "admin"],
    },
    status: {
      type: String,
      required: true,
      enum: ["active", "restricted", "temporary"],
    },
    // Add pushSubscription field
    pushSubscription: {
      endpoint: String,
      keys: {
        p256dh: String,
        auth: String,
      },
    },
  },
  options
);

const User = mongoose.model("User", userSchema);

// Discriminator schemas
const Manager = User.discriminator(
  "manager",
  new mongoose.Schema({
    orderTracking: {
      type: [String],
    },
    paymentVerification: {
      type: [String],
    },
    reportGeneration: {
      type: String,
    },
  })
);

const Barista = User.discriminator(
  "barista",
  new mongoose.Schema({
    orderTracking: {
      type: [String],
    },
    reportGeneration: {
      type: String,
    },
  })
);

const Customer = User.discriminator(
  "customer",
  new mongoose.Schema({
    email: {
      type: String,
      required: true,
      unique: true,
    },
    otp: {
      type: String,
    },
  })
);

const Admin = User.discriminator("admin", new mongoose.Schema({}));

module.exports = { User, Manager, Barista, Customer, Admin };
