/**
 * Mongoose schema and model for the `Chatbot` configuration.
 * Defines the structure of the `Chatbot` collection in the database for storing chatbot scripts and credentials.
 *
 * @module Chatbot
 */

/**
 * Mongoose schema for the `Chatbot` collection.
 * Stores chatbot configuration, including scripts and authentication credentials.
 *
 * @typedef {Object} Chatbot
 * @property {Object} chatbot - Configuration related to chatbot scripts.
 * @property {string} chatbot.script1 - The first script for the chatbot.
 * @property {string} chatbot.script2 - The second script for the chatbot.
 * @property {boolean} chatbot.isError - Flag indicating whether there's an error in the chatbot's script.
 * @property {Object} credentials - Authentication and access details for the chatbot.
 * @property {string} credentials.fetchLink - URL for fetching chatbot data.
 * @property {string} credentials.token - Token used for authentication with the chatbot service.
 * @property {string} credentials.botId - Unique identifier for the chatbot.
 * @property {string} credentials.workspaceId - Workspace ID for the chatbot.
 * @property {string} credentials.kbId - Knowledge base ID for the chatbot.
 * @property {string} credentials.source - Source of the chatbot configuration.
 */
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define the schema for the chatbot configuration
const chatbotSchema = new Schema(
  {
    chatbot: {
      script1: { type: String, required: true },
      script2: { type: String, required: true },
      isError: { type: Boolean, required: true },
    },
    credentials: {
      fetchLink: { type: String, required: true },
      token: { type: String, required: true },
      botId: { type: String, required: true },
      workspaceId: { type: String, required: true },
      kbId: { type: String, required: true },
      source: { type: String, required: true },
    },
  },
  { timestamps: true, versionKey: false }
);

// Create and export the model
module.exports = mongoose.model("Chatbot", chatbotSchema);
