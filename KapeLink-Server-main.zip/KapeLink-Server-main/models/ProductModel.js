/**
 * Mongoose schema for products in the system.
 *
 * This module defines the schema for a product, including its ID, name, markup rate,
 * base price, category, menu category, sales report, and status. It also defines the
 * default values and validation rules for each field.
 *
 * @module Product
 */

/**
 * Product schema definition.
 *
 * @typedef {Object} Product
 * @property {string} prodId - Unique identifier for the product.
 * @property {string} name - Name of the product.
 * @property {number} markupRate - The markup rate applied to the base price.
 * @property {number} basePrice - The base price of the product before markup.
 * @property {string} category - The category of the product.
 * @property {string} menuCategory - The menu category the product belongs to.
 * @property {string} salesReport - Associated sales report for the product.
 * @property {string|null} type - The type of the product (optional, default is null).
 * @property {string} status - Status of the product (default is 'Available').
 */
const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const productSchema = new Schema(
  {
    prodId: {
      type: String,
      required: true,
      unique: true,
    },
    name: {
      type: String,
      required: true,
    },
    markupRate: {
      type: Number,
      required: true,
    },
    basePrice: {
      type: Number,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    menuCategory: {
      type: String,
      required: true,
    },
    salesReport: {
      type: String,
      required: true,
    },
    type: {
      type: String,
      default: null,
    },
    status: {
      type: String,
      required: true,
      default: "Available",
    },
  },
  {
    versionKey: false,
  }
);

const Product = mongoose.model("Product", productSchema);

module.exports = Product;
