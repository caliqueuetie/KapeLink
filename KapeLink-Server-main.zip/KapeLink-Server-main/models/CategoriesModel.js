/**
 * Mongoose schema and model for the `Category` entity.
 * Defines the structure of the `Category` collection in the database.
 *
 * @module Category
 */

/**
 * Mongoose schema for the `Category` collection.
 * Stores categories for different purposes (main, menu, and sales).
 *
 * @typedef {Object} Category
 * @property {Array} mainCategories - List of main categories.
 * @property {number} mainCategories.id - Unique identifier for the category.
 * @property {string} mainCategories.name - The name of the category.
 * @property {string} mainCategories.description - A description of the category.
 * @property {boolean} mainCategories.show - Whether the category is visible.
 * @property {Array} menuCategories - List of menu categories.
 * @property {number} menuCategories.id - Unique identifier for the category.
 * @property {string} menuCategories.name - The name of the category.
 * @property {boolean} menuCategories.show - Whether the category is visible.
 * @property {Array} salesCategories - List of sales categories.
 * @property {number} salesCategories.id - Unique identifier for the category.
 * @property {string} salesCategories.name - The name of the category.
 * @property {boolean} salesCategories.show - Whether the category is visible.
 */
const mongoose = require("mongoose");

const categorySchema = new mongoose.Schema(
  {
    mainCategories: [
      {
        id: Number,
        name: String,
        description: String,
        show: Boolean,
      },
    ],
    menuCategories: [
      {
        id: Number,
        name: String,
        show: Boolean,
      },
    ],
    salesCategories: [
      {
        id: Number,
        name: String,
        show: Boolean,
      },
    ],
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

const Category = mongoose.model("Category", categorySchema);

module.exports = Category;
