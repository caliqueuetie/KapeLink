/**
 * Mongoose schema for notifications.
 *
 * This module defines the schema for storing notifications in the database.
 * A notification can be sent to multiple users (specified in the `receiver` array)
 * and to specific roles (in the `roles` array). Each notification includes a unique
 * `notificationId`, a message, a timestamp (`date` and `time`), and a `read` status.
 *
 * @module Notification
 */

/**
 * Notification schema definition.
 *
 * This schema defines the structure of a notification document in the database.
 * @typedef {Object} Notification
 * @property {Array<string>} receiver - An array of user identifiers that will receive the notification.
 * @property {Array<string>} roles - An array of roles that will receive the notification (e.g., "admin", "manager").
 * @property {string} notificationId - The unique identifier for the notification.
 * @property {string} message - The content of the notification message.
 * @property {string} date - The date when the notification was sent.
 * @property {string} time - The time when the notification was sent.
 * @property {boolean} read - Indicates whether the notification has been read by the receiver.
 */
const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema(
  {
    receiver: {
      type: [String],
      required: true,
    },
    roles: {
      type: [String],
      required: true,
    },
    notificationId: {
      type: String,
      required: true,
      unique: true,
    },
    message: {
      type: String,
      required: true,
    },
    date: {
      type: String,
      required: true,
    },
    time: {
      type: String,
      required: true,
    },
    read: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

const Notification = mongoose.model(
  "Notification",
  notificationSchema,
  "notifications"
);

module.exports = Notification;
