/**
 * Mongoose schema and model for the `Email` entity.
 * Defines the structure of the `Email` collection in the database, used for storing email configuration.
 *
 * @module Email
 */

/**
 * Mongoose schema for the `Email` collection.
 * Stores email configuration details for Nodemailer.
 *
 * @typedef {Object} Email
 * @property {Object} nodemailer - Configuration for the Nodemailer service.
 * @property {string} nodemailer.senderEmail - The email address used for sending emails.
 * @property {string} nodemailer.pass - The password for the sender's email account.
 */
const mongoose = require("mongoose");

const emailSchema = new mongoose.Schema(
  {
    nodemailer: {
      senderEmail: { type: String, required: true },
      pass: { type: String, required: true },
    },
  },
  {
    timestamps: false,
    versionKey: false,
  }
);

const Email = mongoose.model("Email", emailSchema);

module.exports = Email;
