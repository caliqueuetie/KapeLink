/**
 * Mongoose schema and models for handling orders in the system.
 *
 * This module defines a base order schema and its discriminators for different order options
 * (Delivery, Pickup, In-store). It also contains various sub-schemas for order items,
 * tracking, and delivery details.
 *
 * @module Order
 */

/**
 * Order item schema definition for individual items in an order.
 *
 * @typedef {Object} OrderItem
 * @property {number} productId - Unique identifier for the product in the order.
 * @property {string} category - The category of the product.
 * @property {string} menuCategory - The menu category of the product.
 * @property {string} salesReport - Associated sales report for the product.
 * @property {string} type - The type of the product (optional).
 * @property {string} name - Name of the product.
 * @property {number} quantity - Quantity of the product ordered.
 * @property {number} pricePerItem - Price per individual item.
 * @property {number} totalPrice - Total price for the quantity ordered.
 */

/**
 * Tracking schema definition for tracking the status of an order.
 *
 * @typedef {Object} Tracking
 * @property {string} timestamp - Timestamp of the status update.
 * @property {string} orderStatus - The status of the order at that point in time.
 */

/**
 * Delivery details schema definition for delivery-specific information.
 *
 * @typedef {Object} DeliveryDetails
 * @property {string} building - The building where the order will be delivered.
 * @property {string} description - Description of the delivery.
 * @property {string} deliveryTime - Time for the order delivery.
 */

/**
 * Base order schema definition that applies to all orders (Delivery, Pickup, In-store).
 *
 * @typedef {Object} BaseOrder
 * @property {number} orderId - Unique identifier for the order.
 * @property {number} customerId - Identifier for the customer (optional).
 * @property {OrderItem[]} items - List of items in the order.
 * @property {string} orderDate - Date the order was placed.
 * @property {string} timeOrdered - Time the order was placed.
 * @property {string} orderOption - The type of order: In-store, Pickup, or Delivery.
 * @property {number} paymentMethodId - The payment method used for the order.
 * @property {string} proofOfPayment - Proof of payment (if applicable).
 * @property {string} verificationStatus - Verification status of the payment (optional).
 * @property {string} reason - Reason for the order, if applicable.
 */

/**
 * Delivery order schema definition, which extends the base order schema.
 *
 * @typedef {BaseOrder} DeliveryOrder
 * @property {DeliveryDetails} deliveryDetails - Specific details for the delivery order.
 * @property {Tracking[]} tracking - List of tracking updates for the delivery order.
 */

/**
 * Pickup order schema definition, which extends the base order schema.
 *
 * @typedef {BaseOrder} PickupOrder
 * @property {string} pickUpTime - Time for the order pickup.
 * @property {Tracking[]} tracking - List of tracking updates for the pickup order.
 */

/**
 * In-store order schema definition, which extends the base order schema.
 *
 * @typedef {BaseOrder} InStoreOrder
 * @property {boolean} dineIn - Indicates whether the order is for dine-in.
 * @property {string} orderStatus - Status of the in-store order.
 */
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const options = {
  discriminatorKey: "orderOption",
  collection: "orders",
  versionKey: false,
};

const OrderItemSchema = new Schema(
  {
    productId: {
      type: Number,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    menuCategory: {
      type: String,
      required: true,
    },
    salesReport: {
      type: String,
      required: true,
    },
    type: {
      type: String,
    },
    name: {
      type: String,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
    pricePerItem: {
      type: Number,
      required: true,
    },
    totalPrice: {
      type: Number,
      required: true,
    },
  },
  { _id: false, versionKey: false }
);

const TrackingSchema = new Schema(
  {
    timestamp: {
      type: String,
      required: true,
    },
    orderStatus: {
      type: String,
      required: true,
    },
  },
  { _id: false, versionKey: false }
);

const DeliveryDetailsSchema = new Schema(
  {
    building: {
      type: String,
    },
    description: {
      type: String,
    },
    deliveryTime: {
      type: String,
    },
  },
  { _id: false, versionKey: false }
);

const BaseOrder = new Schema(
  {
    orderId: {
      type: Number,
      unique: true,
    },
    customerId: {
      type: Number,
      required: false,
    },
    items: [OrderItemSchema],
    orderDate: {
      type: String,
      required: true,
    },
    timeOrdered: {
      type: String,
    },
    orderOption: {
      type: String,
      required: true,
      enum: ["In-store", "Pickup", "Delivery"],
    },
    paymentMethodId: {
      type: Number,
      required: true,
    },
    proofOfPayment: {
      type: String,
    },
    verificationStatus: {
      type: String,
    },
    reason: {
      type: String,
    },
  },
  options
);

const Order = mongoose.model("Order", BaseOrder);

const DeliveryOrder = Order.discriminator(
  "Delivery",
  new Schema({
    deliveryDetails: {
      type: DeliveryDetailsSchema,
      required: true,
    },
    tracking: {
      type: [TrackingSchema],
      required: true,
    },
  })
);

const PickupOrder = Order.discriminator(
  "Pickup",
  new Schema({
    pickUpTime: {
      type: String,
      required: true,
    },
    tracking: {
      type: [TrackingSchema],
      required: true,
    },
  })
);

const InStoreOrder = Order.discriminator(
  "In-store",
  new Schema({
    dineIn: {
      type: Boolean,
      required: true,
    },
    orderStatus: {
      type: String,
      required: true,
    },
  })
);

module.exports = {
  Order,
  DeliveryOrder,
  PickupOrder,
  InStoreOrder,
};
