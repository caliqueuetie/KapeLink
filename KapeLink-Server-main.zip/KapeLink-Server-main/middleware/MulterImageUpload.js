const multer = require("multer");
const path = require("path");

/**
 * Configures the storage settings for file uploads using Multer.
 * Determines the destination folder based on the route and generates a unique filename for each uploaded file.
 * If the route includes 'online-payment', the file will be stored in the 'payment_method' directory.
 * Otherwise, it will be stored in the 'customer_transactions' directory.
 *
 * @constant storage
 * @type {Object}
 * @property {Function} destination - A function that determines where the file should be uploaded based on the request's route.
 * @param {Object} req - The request object.
 * @param {Object} file - The file to be uploaded.
 * @param {Function} cb - The callback function to specify the upload path.
 * @returns {void} Specifies the upload path where the file will be stored.
 *
 * @property {Function} filename - A function that generates a unique filename for the uploaded file.
 * @param {Object} req - The request object.
 * @param {Object} file - The file to be uploaded.
 * @param {Function} cb - The callback function to specify the filename.
 * @returns {void} Specifies the unique filename for the uploaded file.
 */
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let uploadPath;

    // Check the route or other logic to determine where to store the file
    if (req.baseUrl.includes("online-payment")) {
      // If it's an online payment upload
      uploadPath = path.join(__dirname, "../uploads/payment_method/");
    } else {
      // Default to customer transactions if not online payment
      uploadPath = path.join(__dirname, "../uploads/customer_transactions/");
    }

    // Ensure that the directory is correctly set for the file
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);

    // You can access session or other identifiers if needed
    const filePrefix = req.session?.user?.userId
      ? req.session.user.userId + "-"
      : "";
    cb(null, filePrefix + uniqueSuffix + "-" + file.originalname);
  },
});

/**
 * Filters uploaded files based on their MIME type, allowing only specific image formats (JPEG, PNG, JPG).
 * If the file type is allowed, it accepts the file. Otherwise, it returns an error.
 *
 * @function fileFilter
 * @param {Object} req - The request object.
 * @param {Object} file - The file to be uploaded.
 * @param {string} file.mimetype - The MIME type of the file.
 * @param {Function} cb - The callback function to determine whether to accept or reject the file.
 * @param {Error} [cb.error] - An error message if the file type is invalid.
 * @param {boolean} cb.accept - A flag indicating whether the file is accepted or rejected.
 *
 * @returns {void} Accepts or rejects the file based on its MIME type.
 */
const fileFilter = (req, file, cb) => {
  const allowedMimeTypes = ["image/jpeg", "image/png", "image/jpg"];
  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true); // Accept file
  } else {
    cb(
      new Error("Invalid file type. Only JPEG, PNG, and JPG are allowed."),
      false
    );
  }
};

/**
 * Configures the file upload limits for Multer.
 * This sets a maximum file size limit of 5MB for uploaded files.
 *
 * @constant limits
 * @type {Object}
 * @property {number} fileSize - The maximum allowed file size in bytes (5MB).
 *
 */
const limits = {
  fileSize: 1024 * 1024 * 5, // 5MB file size limit
};

/**
 * Configures the file upload behavior using Multer.
 * Sets the storage options, file filtering, and upload limits for handling file uploads.
 *
 * @constant upload
 * @type {Object}
 * @property {Object} storage - Specifies the storage settings for file uploads, including the destination and filename configuration.
 * @property {Function} fileFilter - A function that filters uploaded files based on MIME type (only allows JPEG, PNG, and JPG files).
 * @property {Object} limits - Configures the maximum allowed file size for uploads (5MB limit).
 *
 */
const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: limits,
});

module.exports = upload;
