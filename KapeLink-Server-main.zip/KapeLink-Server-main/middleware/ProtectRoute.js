// middleware/ProtectRoute.js

const protectRoute = (roles = []) => {
  return (req, res, next) => {
    if (roles.includes("*")) {
      roles = ["admin", "customer", "barista", "manager"];
    }

    // Check if the user is authenticated
    if (!req.session.user) {
      console.log("Access Denied: User not authenticated");
      return res.status(401).json({ error: "User not authenticated" });
    }

    // Check if the user's role is included in the allowed roles
    if (roles.length > 0 && !roles.includes(req.session.user.role)) {
      return res
        .status(403)
        .json({ error: "Access Denied: User does not have the required role" });
    }

    // User is authenticated and has the correct role
    next();
  };
};

module.exports = protectRoute;
