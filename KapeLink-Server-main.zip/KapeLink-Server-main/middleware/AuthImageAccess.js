const path = require("path");
const express = require("express");

/**
 * Middleware function that checks if the user is authenticated by verifying the session.
 * If the user is authenticated, it allows the request to proceed; otherwise, it sends a 401 Unauthorized response.
 *
 * @function isAuthenticated
 * @param {Object} req - The request object.
 * @param {Object} req.session - The session object.
 * @param {Object} req.session.user - The authenticated user's data in the session.
 * @param {Object} res - The response object.
 * @param {Function} next - The next middleware function to call if the user is authenticated.
 *
 * @returns {void} If authenticated, proceed to the next middleware. If not, return a 401 Unauthorized response.
 */
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    console.log("User authenticated");
    return next();
  } else {
    console.log("User not authenticated");
    return res.status(401).send("You are not authenticated");
  }
};

/**
 * Middleware function to serve images from the 'uploads' directory, with authentication required.
 * Uses the 'isAuthenticated' middleware to ensure the user is authenticated before serving images.
 *
 * @function serveImagesWithAuth
 * @param {Object} app - The Express application object.
 * @param {Object} app.use - The method to register middleware in the Express application.
 * @param {string} app.use('/uploads') - The route for serving images from the 'uploads' directory.
 * @param {Function} isAuthenticated - The middleware function used to check if the user is authenticated.
 * @param {Object} express.static - The middleware used to serve static files (images in this case).
 * @param {string} path.join - The method used to join paths to locate the 'uploads' directory.
 *
 * @returns {void} Registers the middleware to serve images with authentication.
 */
const serveImagesWithAuth = (app) => {
  app.use(
    "/uploads",
    isAuthenticated,
    express.static(path.join(__dirname, "../uploads"))
  );
};

module.exports = serveImagesWithAuth;
