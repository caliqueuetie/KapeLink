const express = require("express");
const session = require("express-session");
const mongoose = require("mongoose");
require("dotenv").config();
const cors = require("cors");
const serveImagesWithAuth = require("./middleware/AuthImageAccess");
const http = require("http");
const { Server } = require("socket.io");
const cron = require("node-cron");
const { User } = require('./models/UserModel');
const { PickupOrder, DeliveryOrder } = require("./models/OrderModel");
const { sendBatchNotification } = require("./controllers/NotificationController"); // Adjust the path accordingly
const momentTZ = require('moment-timezone');
const moment = require("moment");

// express app
const app = express();

// Set the limit to 10mb (adjust as needed)
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

app.use(
  cors({
    credentials: true,
    origin: true, // Adjust according to your setup
  })
);

// Session setup
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 1 day
    },
  })
);

// MongoDB connection
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    serveImagesWithAuth(app);

    const server = http.createServer(app);
    const io = new Server(server, {
      cors: {
        origin: process.env.CLIENT_URL, 
        methods: ["GET", "POST"],
        credentials: true,
      },
    });

    app.set("socketio", io);

    // Start the server
    server.listen(process.env.PORT, () => {
      console.log("Listening on port " + process.env.PORT);
    });


  })
  .catch((error) => {
    console.log("Database connection failed");
    console.log(error);
  });

// Protected routes
const authRoutes = require("./routes/AuthRoute");
app.use("/api/kape-link", authRoutes);

const productRoutes = require("./routes/ProductRoute");
app.use("/api/kape-link", productRoutes);

const userRoutes = require("./routes/UserRoute");
app.use("/api/kape-link", userRoutes);

const notificationRoutes = require("./routes/NotificationRoute");
app.use("/api/kape-link", notificationRoutes);

const paymentMethodRoutes = require("./routes/PaymentMethodRoute");
app.use("/api/kape-link", paymentMethodRoutes);

const orderRoutes = require("./routes/OrderRoute");
app.use("/api/kape-link", orderRoutes);

const chatbotRoutes = require("./routes/ChatbotRoute");
app.use("/api/kape-link", chatbotRoutes);

const emailRoutes = require("./routes/EmailRoute");
app.use("/api/kape-link", emailRoutes);

const categoriesRoutes = require("./routes/CategoriesRoute");
app.use("/api/kape-link", categoriesRoutes);

const locationRoutes = require("./routes/LocationRoute");
app.use("/api/kape-link", locationRoutes);

const paymentRoutes = require("./routes/PaymentRoute");
app.use("/api/kape-link", paymentRoutes);

const timeRoute = require("./routes/TimeRoute");
app.use("/api/kape-link", timeRoute);

const storeConfiguration = require("./routes/StoreConfigurationRoute");
app.use("/api/kape-link", storeConfiguration);