/**
 * Returns the path for customer transaction uploads.
 *
 * @function customerTransactionPath
 * @returns {string} The path for customer transaction uploads.
 */

const customerTransactionPath = () => {
    return `uploads/customer_transactions/`;
};

/**
 * Returns the path for payment method image uploads.
 *
 * @function paymentMethodPath
 * @returns {string} The path for payment method image uploads.
 */
const paymentMethodPath = () => {
    return `uploads/payment_method/`;
};
  
module.exports = {
    customerTransactionPath,
    paymentMethodPath
};