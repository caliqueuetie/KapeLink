const { DateTime } = require('luxon');

/**
 * Retrieves the current date and time in the 'Asia/Manila' timezone.
 * The date is formatted as 'yyyy-MM-dd' and the time as 'HH:mm'.
 *
 * @function getDateAndTime
 * @returns {Object} The current date and time.
 * @returns {string} return.date - The current date in 'yyyy-MM-dd' format.
 * @returns {string} return.time - The current time in 'HH:mm' format.
 */
const getDateAndTime = () => {
    const now = DateTime.now().setZone('Asia/Manila');
    
    const date = now.toFormat('yyyy-MM-dd');
    const time = now.toFormat('HH:mm');

    return {
        date: date,
        time: time
    };
};
module.exports = getDateAndTime;
